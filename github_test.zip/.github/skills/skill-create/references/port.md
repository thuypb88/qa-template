# skill-create: port mode

> **Created:** 2026-11-13 10:43:14 · **Updated:** 2026-11-13 15:06:23 (UTC+7)

Read when the request is to release an **existing workspace skill** (`.claude/skills/<name>/`) as a standalone one.
The workspace skill is never changed by a port; the standalone copy is a new product with its own name and version.

## Steps

1. **List what it leans on:** `python3 $M deps .claude/skills/<name>` prints every link, path, script, rule ID
   (`R6`, `PR-3`, `P4`, `L-T07` …), other skill and project file the skill and its references use, grouped as
   *inline* (a rule or method text the package needs), *drop* (project memory, status boards, guard, commits, version
   tags: workspace mechanics a buyer does not have), *replace* (a workspace script the skill runs: rewrite its job as
   a step, or ship a small standard-library script of its own, S10).
2. **Decide the product edge.** A workspace skill often depends on the pipeline before it (an analysis, a mindmap).
   Standalone, that upstream becomes an *input the user supplies*, audited in the input step (S6). Write the edge in
   one line: "Takes <inputs>; gives <output>; does not <neighbour work>".
3. **Start the port folder:** `python3 $M init <market-name> --path market/ports --license <id> --author "<…>"`. A
   product name without the group prefix when the prefix means nothing outside (S1).
4. **Shared methods stay one source.** A method that is already generic (a `standards/methods/` file, a pack's
   scenario guide) is **generated**, never copied: list it in `port.json` › `generate`
   (`"references/<file>.md": {"title", "intro", "from": [paths or {path, heading}], "sections": ["1.", …],
   "keep_intro", "demote"}`) and neutralise its few workspace words with `port.json` › `replace` (regex → text).
   A rule written for the workspace (core rules with `project.json` keys, folder names, script names) is rewritten
   once by hand into the port's `references/`, in neutral words. Name the source in `port.json` › `source_skill`,
   never in the package (S2).
5. **Write the hand part** in the port folder: `SKILL.md` in the standalone shape (S4, S11), its output rules and
   template (S8), README, CHANGELOG, `agents/openai.yaml`, the three test cases and the trigger set (S9, S12), with
   synthetic examples.
6. **Build:** `python3 $M build market/ports/<name>` writes `market/skills/<name>/` (the whole folder; never edit
   it), then runs the S1–S12 check; repeat until 0 Error. `build --check` reports a package older than its port or
   its shared methods (after a method change: rebuild, new version, CHANGELOG entry).
7. Continue with the **new** mode from its step 5 (skill-creator runs on `market/skills/<name>/`, then `pack`). The
   port's test cases compare the standalone skill with the workspace skill's typical output where one exists.

## What never ports

Anything that only makes sense inside a workspace: `project.json` reads, `project/` registers, `guard.py`,
`sync_agents.py`, git commit or tag steps, Excel export by our scripts, deliverable approval. Port the *decision* a
step makes, not the tool that records it.
