# skill-create: standalone rules (S1–S12)

> **Created:** 2026-11-13 10:43:14 · **Updated:** 2026-11-13 14:07:52 (UTC+7)

Read in every mode. These are the rules a skill must meet to be **released outside this workspace**: installed by
copying one folder into any agent that loads the agentskills.io layout (Claude Code, Codex, GitHub Copilot, Gemini
CLI), with no project, template, script folder or other skill behind it. Studied from the awesome-qa-skills set
(the open awesome-qa-skills library, github.com/naodeng/awesome-qa-skills: `skills/SKILL_AUTHORING_EN.md`, `SKILL_STYLE_GUIDE_EN.md`,
`EXTERNAL_SNAPSHOT_POLICY_EN.md`, `docs/SKILL_QUALITY_GATE_EN.md`, `docs/SKILL_DESIGN_GUIDE_EN.md`,
`scripts/validate_skills_independence.py`) and adapted to our skill architecture. The craft (interview, draft,
test-case runs, review viewer, description optimization, packaging) is Claude's **skill-creator**; these rules are
what a release adds on top. **Checked** marks what
`scripts/skill_market.py check` enforces; the rest is judged by `check-skill` and the evals.

| ID | Rule | Checked |
| --- | --- | --- |
| S1 | **One folder is the whole product.** Name = folder = `agents/openai.yaml` key, lowercase-hyphen, ≤ 64 chars. No group prefix is required outside the workspace; a product name says what it does (`boundary-value-design`, not `design-bva`). | yes |
| S2 | **No outside dependency.** No link, path or command that leaves the folder: no `../`, no absolute path, no `standards/`, `packs/`, `project/`, `project.json`, `scripts/` of a workspace, no other skill's files, no `/<other-skill>` hand-off as a required step. A neighbour is named as *another kind of task*, never as a file to open. | yes |
| S3 | **No workspace vocabulary.** No project code, module IDs, client names, people, `Q-INIT-…`, `L-0nn`, `PR-n`, `ADR-nnn`, `TC-<MOD>-…` or Updated stamps from a project. Examples are synthetic. | yes (from `project.json`: code, name, client as Error, module IDs as Warning; rule IDs, stamps) |
| S4 | **Frontmatter for the market.** Only `name`, `description`, `license`, `metadata`, optional `compatibility` / `allowed-tools` (skill-creator's validator refuses other keys). `description` in double quotes, 1–1024 chars, no `<` `>`, starts `Use this skill when …` (or the third-person `This skill should be used when …` of the open skill-creator guide), says what + when + trigger phrases in the users' words and languages (a little "pushy", as skill-creator advises), ends with the near miss `Not for: …`. `metadata.version` (semver), `metadata.author` (an organisation or role, never a private person's name or e-mail without their OK). | yes |
| S5 | **Shared rules inlined, once.** A rule the workspace keeps in `standards/` or a pack, and that the skill needs, is rewritten into the skill's own `references/` in neutral words (no rule IDs from the workspace). Copy only what this skill uses; one copy per skill. | judged |
| S6 | **Input audit first.** The skill starts from what the user supplied and states `known · missing · conflicting · stale · out of scope · assumptions` before any output; missing facts become open questions, never invented values. | judged (eval) |
| S7 | **Evidence states.** Output separates facts, inferences, recommendations and decisions left to a person; anything not run is `NOT_RUN`, anything unreachable `BLOCKED`, never "passed". | judged (eval) |
| S8 | **Output contract in the folder.** Each output has a template in `assets/` and its rules in `references/output-rules.md`; findings or items carry a stable ID prefix (`BVT-01`, `TC-001`). | yes (files) |
| S9 | **Test cases in skill-creator's layout** (the one `claude plugin eval` reads): `evals/<case>/prompt.md` (settings block, then the prompt), `case.yaml` (`schema_version: "1.1"`, `name` = folder, `expected_outcome`), `graders/NN-….md` (block `type` / `focus` / `weight`, one statement each). At least `basic-success`, `edge-incomplete-input`, `edge-scope-boundary` (a near miss or a request to overclaim). `evals/trigger-queries.json`: ≥ 8 should-trigger and ≥ 8 near-miss queries for skill-creator's description optimization. Runs go to `<name>-workspace/`, never into the folder. The evals stay in the source; skill-creator leaves them out of the `.skill`. | yes |
| S10 | **Safe to install.** Nothing runs on install. Scripts (optional) are standard-library Python 3.10+ or POSIX shell, read their input from arguments, write only where told, and never fetch from the network. No secret, token, cookie, real customer data. | yes (imports, secrets) |
| S11 | **Lean entry, progressive disclosure.** `SKILL.md` ≤ 500 lines (aim ≤ 150), body under 5,000 words: when to use, inputs, steps, output, constraints, pre-delivery check, reference files, pitfalls. Depth goes to `references/`, each linked with *when* to read it; a fact lives in one place (SKILL.md or a reference); a reference over 10,000 words gets grep patterns in SKILL.md; every file in `scripts/`, `references/`, `assets/` is named; imperative style, verb first ([creation-process.md](creation-process.md) §4). | yes (size, words, sections, orphans, repeated lines, 'you should') |
| S12 | **Release record.** `README.md` (what, install per agent, use, files, licence) and `CHANGELOG.md` with the version in the frontmatter as its top entry; the package is the `.skill` built by skill-creator's `package_skill` through `skill_market.py pack` (S1–S12 first), never zipped by hand. | yes |

## Install paths written in the package README

| Agent | Personal | In a repository |
| --- | --- | --- |
| Claude Code | `~/.claude/skills/<name>/` | `.claude/skills/<name>/` |
| Codex | `~/.agents/skills/<name>/` | `.agents/skills/<name>/` |
| GitHub Copilot | — | `.github/skills/<name>/` |
| Gemini CLI | `~/.gemini/skills/<name>/` | `.gemini/skills/<name>/` |
| claude.ai / Claude API | upload the `.skill` file | — |

These paths are the ones this workspace's own mirrors use (`project.json › agents.mirrors`); a buyer's agent version
may differ, so the README says "the skills folder your agent reads" first and the table second.

## Workspace skill vs standalone skill

| | Workspace skill (`.claude/skills/<group>-<objective>/`) | Standalone skill (`market/skills/<name>/`) |
| --- | --- | --- |
| Rules | linked from `standards/`, packs, `project/` | inlined in its own `references/` (S5) |
| Hand-off | `**Next:** <skill>`, `Stop if … → <skill>` | "Not for" in the description; a missing input becomes an open question |
| Frontmatter | `metadata.group`, `metadata.order` | `license`, `metadata.version`, `metadata.author` |
| Checks | `scripts/check_skills.py`, `guard.py` | `skill_market.py check`, skill-creator's validator and test-case runs |
| Ships as | part of the workspace | one `.skill` per version, `market/dist/<name>-<version>.skill` |
