# skill-create: creation process

> **Created:** 2026-11-13 11:25:20 · **Updated:** 2026-11-13 14:07:52 (UTC+7)

Read in modes new and port, before writing the draft. Studied from the open skill-creator guide
(the open skill-creator guide of awesome-claude-skills, Apache-2.0: Skill Creation Process steps 1–6,
anatomy, progressive disclosure, writing style) and joined to Claude's current skill-creator loop (test-case runs,
viewer, description optimization) and the market rules S1–S12 ([standalone-rules.md](standalone-rules.md)).

## 1. Concrete examples first

Collect at least three real requests the skill must handle, from the owner or drafted and confirmed by them: "What
would a user say that should load this skill? What should come back?" Ask the most important questions first, a few
per message, never a questionnaire. Stop when the job, the inputs and the output are clear; these examples become
the `basic-success` test case and the should-trigger queries.

## 2. Resource plan (one row per example)

For each example, think through doing it from scratch and note what would be rewritten every time:

| Example | Done from scratch needs | Resource | Kind |
| --- | --- | --- | --- |
| <request> | the same parsing code each time | `scripts/<verb_noun>.py` | script (deterministic, run without reading) |
| <request> | re-finding the same rules or schema | `references/<topic>.md` | reference (read on demand) |
| <request> | the same output skeleton | `assets/<output>.md` | asset (copied into the output, never read as instructions) |

Write the table in the release report (Inlined rules / Resources). A resource no example needs is not created.

## 3. Initialise, never copy by hand

`python3 $M init <name> --license <id> --author "<organisation or role>"` writes the skeleton into
`market/skills/<name>/` from this skill's templates: frontmatter filled, the three skill-creator test cases with
placeholder graders, the trigger set, README, CHANGELOG, `agents/openai.yaml`, an output-rules stub and an output
template. Every `<placeholder>` and `TODO` left is an Error for `check`, so nothing half-filled ships.

## 4. Edit: the skill is written for another Claude

- **Non-obvious knowledge only.** Procedures, domain rules, schemas and pitfalls a capable model would not know;
  nothing it already does well.
- **Structure the body** by one pattern (mix when needed), under the fixed sections of the template:
  **workflow** (sequential steps: Step 1 → Step 2), **task** (several operations: Quick start → one part per task),
  **reference** (standards or specifications: Guidelines → Specifications → Usage), **capabilities** (related
  features: numbered capabilities).
- **Style:** imperative, verb first ("To do X, run Y"; "Record …"), not "you should …". The description says what and
  when, with trigger phrases (S4).
- **Progressive disclosure:** metadata (~100 words, always loaded) → SKILL.md body (under 5,000 words, loaded on
  trigger) → resources (loaded or run on demand). A fact lives in SKILL.md *or* a reference, never both; prefer the
  reference unless every run needs it. A reference over 10,000 words gets grep patterns in SKILL.md (which heading
  or keyword to search).
- **Delete what init made and the skill does not use.** Every file in `scripts/`, `references/` and `assets/` is
  named in SKILL.md or a reference; `check` warns on an orphan.

## 5. Test, package, iterate

Run the test cases and the description optimization with Claude's skill-creator (SKILL.md steps 5–6), then `pack`
(step 7). After release, the owner uses the skill on real tasks; each struggle becomes a new test case first, then a
change, a new version and a CHANGELOG entry.
