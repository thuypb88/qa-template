---
name: skill-create
description: Skill engineering (writer, any pack): create a standalone skill to release to a marketplace or another team, with no dependence on this workspace. Uses Claude's skill-creator (interview, draft, test-case runs, review viewer, description optimization, packaging) and adds the market rules S1-S12 - one self-contained folder (SKILL.md, references, assets, agents/openai.yaml, test cases, trigger queries, README, CHANGELOG, licence, version) that installs in Claude Code, Codex, GitHub Copilot or Gemini CLI, or uploads as a .skill file. Modes new, port (a workspace skill → standalone) and pack. Use for "create a skill to sell", "release design-cases as a standalone skill", "package the skill for the market", "make this skill independent", "tạo skill bán", "đóng gói skill". Not for: a skill used only in this workspace → copy SKILL_TEMPLATE.md (kept in this skill's folder); improving a workspace skill's triggering or evals → skill-creator; reviewing a skill → check-skill.
metadata:
  group: skill
  order: "-"
---

# Skill engineering: create a standalone skill with skill-creator (new · port · pack)

> **Created:** 2026-11-13 10:43:14 · **Updated:** 2026-11-13 15:06:34 (UTC+7)

**In:** the idea or the workspace skill to port (`.claude/skills/<name>/`); the owner's licence, author (organisation
or role) and version; the users' trigger words. **Uses:** Claude's **skill-creator** (`anthropic-skills:skill-creator`;
its folder: `python3 $M creator`) — this skill adds the market rules and the workspace record, it does not
re-implement the creator. **Out:** `market/skills/<name>/` (the product; in port mode generated from
`market/ports/<name>/` by `build`, never edited); skill-creator's run workspace
`market/skills/<name>-workspace/` (not in git); on pack, `market/dist/<name>-<version>.skill` + `.sha256` (not in
git); a line in `project/log.md`. **Rules:** S1–S12 [references/standalone-rules.md](references/standalone-rules.md);
core R1 (no invention, [core-rules](../../../standards/core-rules.md)) in every example and rule we write; a new
or changed skill is listed in the same change set ([CLAUDE.md](../../../CLAUDE.md) › Adding a skill).
**Next:** `check-skill` on the package by another agent, standalone profile: its checks 1, 4, 5, 7, 8, 10, 12 plus
S1–S12 (checks 2, 3, 6, 11 are workspace rules: group, contract line, linked core rules, template evals); then `pack`.
**Stop if** the owner has not chosen a licence and an author line → ask; never pick a licence or a person's name.
skill-creator is not found (`python3 $M creator` fails) → say so and where it installs (Claude Code plugin or
`$SKILL_CREATOR`); never fall back to a home-made runner or packager.
**Output:** [assets/standalone-SKILL.md](assets/standalone-SKILL.md) · [assets/eval-prompt.md](assets/eval-prompt.md) · [assets/eval-case.yaml](assets/eval-case.yaml) · [assets/eval-grader.md](assets/eval-grader.md) · [assets/trigger-queries.json](assets/trigger-queries.json) · [assets/openai.yaml](assets/openai.yaml) · [assets/README.md](assets/README.md) · [assets/CHANGELOG.md](assets/CHANGELOG.md) · [assets/release-report.md](assets/release-report.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

**Also holds** [SKILL_TEMPLATE.md](SKILL_TEMPLATE.md): the skeleton of every skill, workspace or standalone profile
(read by `check-skill`, linked from the catalog). It is not a skill (no `SKILL.md` name), so no agent loads it.

Script: `M=.claude/skills/skill-create/scripts/skill_market.py` (`env`, `creator`, `init`, `deps`, `check`, `build`, `pack`). After
changing it: `python3 .claude/skills/skill-create/scripts/test_skill_market.py`. After changing this skill:
its behaviour evals [evals/skill-create.json](evals/skill-create.json), before and after (A/B).

## Modes

| Mode | When | Read |
| --- | --- | --- |
| **new** | an idea, a method or a checklist the team wants to sell or share | [references/standalone-rules.md](references/standalone-rules.md), [references/creation-process.md](references/creation-process.md) |
| **port** | an existing workspace skill (`design-cases`, `req-review` …) released on its own: a port folder `market/ports/<name>/` (hand-written part + `port.json`), then `python3 $M build market/ports/<name>` generates the package with the shared methods pulled in | the two above + [references/port.md](references/port.md) |
| **pack** | the folder passes its checks, its test cases ran, and the owner approved the release | `python3 $M pack market/skills/<name>` |

## Steps

1. **Load skill-creator** (Skill `anthropic-skills:skill-creator`) and follow its loop; the steps below say what this
   skill adds at each stage. In every shell that runs its scripts, first `eval "$(python3 $M env)"`: it exports
   `SKILL_CREATOR` (run its scripts from there) and puts the `claude` CLI on PATH (the one on PATH, else the binary
   the VS Code extension ships, newest first) for that shell only; it never edits a profile.
2. **Concrete examples and resource plan** ([references/creation-process.md](references/creation-process.md) §1–2,
   with skill-creator › Capture intent): ≥ 3 real requests confirmed by the owner, a few questions per message; then
   per example the script, reference or asset that stops rework. Plus the market facts: one job, one primary output
   and its item ID prefix (`BVT-`, `TC-`), the inputs the user supplies, licence, author, version. Search
   `market/skills/` and the catalog first: the same job twice is a mode of the existing product. Port: `python3 $M
   deps .claude/skills/<name>` and [references/port.md](references/port.md).
3. **Initialise, then edit** (§3–4): `python3 $M init <name> --license <id> --author "<organisation or role>"` writes
   the skeleton from [assets/standalone-SKILL.md](assets/standalone-SKILL.md) and the other templates; fill it for
   another Claude: non-obvious knowledge only, one body pattern (workflow · task · reference · capabilities),
   imperative style, each fact in SKILL.md or a reference (never both), unused init files deleted. Inline the
   rules it uses into its own `references/` (S2, S5); input audit and evidence states in the body (S6, S7); the
   output template and `references/output-rules.md` (S8); `agents/openai.yaml`, `README.md`, `CHANGELOG.md` (S12).
4. **Test cases** in skill-creator's layout `evals/<case>/{prompt.md, case.yaml, graders/NN-….md}`, at least
   `basic-success`, `edge-incomplete-input`, `edge-scope-boundary` (S9). Check: `python3 $M check
   market/skills/<name>` until 0 Error; answer each Warning. It reads the workspace words from `project.json` (code,
   name, client: Error; module ids: Warning); add others with `--vocab`.
5. **Run and review** with skill-creator (› Running and evaluating test cases): with-skill and baseline runs in
   `market/skills/<name>-workspace/iteration-N/`, grading, `aggregate_benchmark`, the eval viewer
   (`generate_review.py`, `--static <file>` when headless) for the owner's feedback; improve and repeat. Until a run
   is graded, the test cases are *written, not run*.
6. **Description optimization** (skill-creator › Description Optimization): the trigger set is kept in
   `evals/trigger-queries.json` (≥ 8 should, ≥ 8 near misses; skill-creator advises 20), reviewed by the owner, then
   `run_loop` (it calls `claude -p`, found by `env`). With Claude Code ≥ 2.1.269 the same test cases also run with
   `claude plugin eval . --allow-tools Write,Edit,Bash` from the skill folder; both are real, billed runs, so ask the
   owner first. Only when `env` finds no CLI: say *not run* and why.
7. **Pack** on the owner's approval: `python3 $M pack market/skills/<name>` — S1–S12 first, then skill-creator's
   `quick_validate` and `package_skill` (`evals/` stays out of the `.skill`); quote the sha256. A changed product gets
   a new version and CHANGELOG entry; a released file is never replaced.
8. Record: `project/log.md` line; commit `market skill <name> v<version>: <new | port | pack>` (only this change set).

## Rules

- **skill-creator does the craft, this skill the gate:** never a home-made test runner, viewer or packager.
- **Independent or not released:** a link, script or rule outside the folder is an Error, never a Warning to accept.
- **No invention:** a method step, threshold or example the sources don't give is an assumption written as one.
- **The workspace skill is untouched** by a port; findings about it go to `check-skill` / `learn-retro`.
- **Nothing is published from here.** Upload to any marketplace, claude.ai or a repository is the owner's action.

## Done when

- [ ] `skill_market.py check`: 0 Error, every Warning answered; every file opened after writing.
- [ ] Three skill-creator test cases and the trigger set written; run state reported (benchmark pass rate with the
      iteration, or *not run* with the reason); the owner's viewer feedback applied or listed.
- [ ] Pack (when asked): `.skill` and sha256 in `market/dist/`; version = CHANGELOG top entry.
- [ ] `project/log.md` line and the commit of step 8 (this change set only).
- [ ] Report per [assets/release-report.md](assets/release-report.md); suggest `check-skill` by another agent
      (standalone profile).
