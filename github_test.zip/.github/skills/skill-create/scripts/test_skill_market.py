#!/usr/bin/env python3
"""Regression tests for skill_market.py on a synthetic skill built in a temporary folder (pack tests need skill-creator).

    python3 .claude/skills/skill-create/scripts/test_skill_market.py
"""
from __future__ import annotations

import io
import json
import sys
import tempfile
import unittest
import zipfile
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import skill_market as sm  # noqa: E402

SKILL = """---
name: demo-skill
description: "Use this skill when a tester needs demo items from a short note; triggers include 'demo items'. Not for: running tests."
license: MIT
metadata:
  version: "0.1.0"
  author: "QA team"
---

# Demo

## When to Use

- A note.

## Inputs

known · missing · conflicting · stale · out of scope · assumptions.

## How to Use

1. Read [references/output-rules.md](references/output-rules.md).

## Output

DEM-01 items; VERIFIED · NOT_RUN · BLOCKED · UNASSESSED.

## Core Constraints

- No invention.

## Pre-delivery Check

- [ ] Audit written.

## Reference Files

| File | Read when |
|---|---|
| [references/output-rules.md](references/output-rules.md) | before writing |
"""
PROMPT = "---\ntags: [skill-creator]\nmax_turns: 20\ntimeout_seconds: 600\n---\n\nDemo request for {id}.\n"
CASEY = 'schema_version: "1.1"\nname: {id}\nexpected_outcome: |\n  DEM- items with open questions.\n'
GRADER = "---\ntype: llm\nfocus: trace\nweight: 1\n---\n\nThe answer lists DEM-01.\n"
TRIG = json.dumps([{"query": f"q{i}", "should_trigger": i < 8} for i in range(16)])


def build(root: Path) -> Path:
    s = root / "demo-skill"
    files = {
        "SKILL.md": SKILL,
        "references/output-rules.md": "# rules\n",
        "assets/items.md": "<!-- Template: … -->\n# <title>\n",
        "agents/openai.yaml": 'version: 1\nmetadata:\n  key: "demo-skill"\n',
        "evals/trigger-queries.json": TRIG,
        "README.md": "# Demo\n",
        "CHANGELOG.md": "# Changelog\n\n## 0.1.0 — 2026-11-13\n\n- First.\n",
        "scripts/tool.py": "import json\nfrom pathlib import Path\n",
    }
    for c in sm.REQUIRED_CASES:
        files[f"evals/{c}/prompt.md"] = PROMPT.format(id=c)
        files[f"evals/{c}/case.yaml"] = CASEY.format(id=c)
        files[f"evals/{c}/graders/01-lists-items.md"] = GRADER
    for rel, body in files.items():
        (s / rel).parent.mkdir(parents=True, exist_ok=True)
        (s / rel).write_text(body, encoding="utf-8")
    return s


def errors(s: Path, vocab=()) -> list[str]:
    return [f"{f['rule']} {f['message']}" for f in sm.check(s, list(vocab)) if f["severity"] == "Error"]


class Check(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.s = build(Path(self.tmp.name))

    def tearDown(self):
        self.tmp.cleanup()

    def edit(self, rel, old, new):
        p = self.s / rel
        p.write_text(p.read_text(encoding="utf-8").replace(old, new), encoding="utf-8")

    def test_clean_skill_has_no_error(self):
        self.assertEqual(errors(self.s), [])

    def test_link_outside_folder(self):
        self.edit("SKILL.md", "- A note.", "- See [rules](../../standards/core-rules.md).")
        self.assertTrue(any(e.startswith("S2") for e in errors(self.s)))

    def test_workspace_vocabulary_and_extra_word(self):
        self.edit("SKILL.md", "- No invention.", "- Apply PR-4 and Q-INIT-012 for ACME.")
        errs = errors(self.s, ["ACME"])
        self.assertTrue(any("PR-4" in e for e in errs))
        self.assertTrue(any("Q-INIT-012" in e for e in errs))
        self.assertTrue(any("'ACME'" in e for e in errs))

    def test_missing_license_and_bad_version(self):
        self.edit("SKILL.md", "license: MIT\n", "")
        self.edit("SKILL.md", '"0.1.0"', '"1.0"')
        errs = errors(self.s)
        self.assertTrue(any("license" in e for e in errs))
        self.assertTrue(any("semver" in e for e in errs))

    def test_changelog_must_match_version(self):
        self.edit("CHANGELOG.md", "0.1.0", "0.0.9")
        self.assertTrue(any(e.startswith("S12") and "0.0.9" in e for e in errors(self.s)))

    def test_eval_case_and_triggers_required(self):
        import shutil
        shutil.rmtree(self.s / "evals/edge-scope-boundary")
        (self.s / "evals/trigger-queries.json").write_text(json.dumps([{"query": "q", "should_trigger": True}]))
        errs = errors(self.s)
        self.assertTrue(any("edge-scope-boundary" in e for e in errs))
        self.assertTrue(any("should-not" in e for e in errs))

    def test_case_needs_quoted_version_and_grader(self):
        self.edit("evals/basic-success/case.yaml", '"1.1"', "1.1")
        (self.s / "evals/basic-success/graders/01-lists-items.md").unlink()
        errs = errors(self.s)
        self.assertTrue(any("quoted" in e for e in errs))
        self.assertTrue(any("no grader" in e for e in errs))

    def test_unquoted_description_with_colon(self):
        self.edit("SKILL.md", 'description: "', "description: ")
        self.edit("SKILL.md", 'running tests."', "running tests.")
        self.assertTrue(any("invalid YAML" in e for e in errors(self.s)))

    def test_description_angle_brackets_and_extra_key(self):
        self.edit("SKILL.md", "triggers include", "triggers <include>")
        self.edit("SKILL.md", "license: MIT\n", "license: MIT\nversion: 1\n")
        errs = errors(self.s)
        self.assertTrue(any("< or >" in e for e in errs))
        self.assertTrue(any("frontmatter keys" in e for e in errs))

    def test_non_stdlib_and_network_imports(self):
        (self.s / "scripts/tool.py").write_text("import requests\nimport yaml\n", encoding="utf-8")
        errs = errors(self.s)
        self.assertTrue(any("network module 'requests'" in e for e in errs))
        self.assertTrue(any("non-standard-library import 'yaml'" in e for e in errs))

    def test_secret_and_absolute_path(self):
        self.edit("README.md", "# Demo", "# Demo\napi_key = abcd1234efgh\nSee /home/someone/x")
        errs = errors(self.s)
        self.assertTrue(any(e.startswith("S10") for e in errs))
        self.assertTrue(any("absolute path" in e for e in errs))

    def test_unfilled_placeholder_outside_assets(self):
        self.edit("README.md", "# Demo", "# <Title>")
        self.assertTrue(any("placeholder" in e for e in errors(self.s)))

    def test_template_note_before_frontmatter(self):
        p = self.s / "SKILL.md"
        p.write_text("<!-- Template: x -->\n" + p.read_text(encoding="utf-8"), encoding="utf-8")
        self.assertTrue(any("line 1" in e for e in errors(self.s)))


class Init(unittest.TestCase):
    def test_init_writes_skeleton_that_check_holds_back(self):
        with tempfile.TemporaryDirectory() as t:
            with redirect_stdout(io.StringIO()):
                self.assertEqual(sm.init("demo-skill", Path(t), "MIT", "QA team", "0.1.0"), 0)
            s = Path(t) / "demo-skill"
            for rel in ("SKILL.md", "agents/openai.yaml", "README.md", "CHANGELOG.md", "evals/trigger-queries.json",
                        "evals/basic-success/prompt.md", "evals/edge-scope-boundary/graders/01-expected-output.md"):
                self.assertTrue((s / rel).is_file(), rel)
            self.assertTrue((s / "SKILL.md").read_text().startswith("---\nname: demo-skill\n"))
            self.assertIn('version: "0.1.0"', (s / "SKILL.md").read_text())
            errs = errors(s)
            self.assertTrue(errs)                                  # placeholders and TODOs block it
            self.assertTrue(all(e.split()[0] in {"S4", "S9", "S12"} for e in errs), errs)
            self.assertFalse(any("frontmatter must start" in e or "≠ folder" in e for e in errs))
            with redirect_stderr(io.StringIO()):
                self.assertEqual(sm.init("demo-skill", Path(t), "MIT", "QA team", "0.1.0"), 1)   # never overwrite


class Disclosure(unittest.TestCase):
    def test_orphan_resource_duplicate_line_and_style(self):
        with tempfile.TemporaryDirectory() as t:
            s = build(Path(t))
            (s / "references/unused.md").write_text("# unused\n")
            line = "Record every boundary with its unit, its step and the source line it comes from, always."
            (s / "references/output-rules.md").write_text("# rules\n" + line + "\n")
            p = s / "SKILL.md"
            p.write_text(p.read_text() + line + "\nYou should do A. You must do B. You need to do C.\n")
            warns = [f["file"] + " " + f["message"] for f in sm.check(s, []) if f["severity"] == "Warning"]
            self.assertTrue(any("unused.md" in w and "named nowhere" in w for w in warns))
            self.assertTrue(any("repeated in SKILL.md" in w for w in warns))
            self.assertTrue(any("imperative" in w for w in warns))


class Env(unittest.TestCase):
    def test_find_claude_prefers_path_then_extension(self):
        with tempfile.TemporaryDirectory() as t:
            ext = Path(t) / ".vscode/extensions/anthropic.claude-code-9.9.9-linux-x64/resources/native-binary"
            ext.mkdir(parents=True)
            (ext / "claude").write_text("#!/bin/sh\n"); (ext / "claude").chmod(0o755)
            import os
            from unittest import mock
            with mock.patch.dict(os.environ, {"HOME": t, "PATH": "/nonexistent"}):
                self.assertEqual(sm.find_claude(), (ext / "claude").resolve())


@unittest.skipUnless(sm.find_creator(), "skill-creator not installed")
class Pack(unittest.TestCase):
    def test_pack_uses_skill_creator_and_refuses_changed_release(self):
        with tempfile.TemporaryDirectory() as t:
            s = build(Path(t))
            out = Path(t) / "dist"
            quiet = io.StringIO()
            with redirect_stdout(quiet), redirect_stderr(quiet):
                self.assertEqual(sm.pack(s, out, []), 0)
                self.assertEqual(sm.pack(s, out, []), 0)          # same content → unchanged
                (s / "README.md").write_text("# Demo v2\n", encoding="utf-8")
                self.assertEqual(sm.pack(s, out, []), 1)          # same version, other content → refused
            names = zipfile.ZipFile(out / "demo-skill-0.1.0.skill").namelist()
            self.assertIn("demo-skill/SKILL.md", names)
            self.assertFalse(any(n.startswith("demo-skill/evals/") for n in names))   # skill-creator leaves evals out
            self.assertTrue((out / "demo-skill-0.1.0.skill.sha256").is_file())

    def test_pack_refuses_on_error(self):
        with tempfile.TemporaryDirectory() as t:
            s = build(Path(t))
            (s / "README.md").unlink()
            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(sm.pack(s, Path(t) / "dist", []), 1)
            self.assertFalse(any((Path(t) / "dist").glob("*.skill")))


class ProjectVocab(unittest.TestCase):
    def test_project_json_words_and_default_out(self):
        with tempfile.TemporaryDirectory() as t:
            ws = Path(t)
            (ws / "project.json").write_text(json.dumps({
                "project": {"code": "ZQX", "name": "Zeta Quality Exchange", "client": "Zeta Holdings"},
                "modules": [{"id": "GL"}, {"id": "AP"}]}), encoding="utf-8")
            (ws / "market/skills").mkdir(parents=True)
            s = build(ws / "market/skills")
            hard, soft = sm.project_vocab(s)
            self.assertEqual(hard, ["ZQX", "Zeta Quality Exchange", "Zeta Holdings"])
            self.assertEqual(soft, ["GL", "AP"])
            p = s / "SKILL.md"
            p.write_text(p.read_text(encoding="utf-8").replace("- No invention.",
                         "- No invention, as ZQX does; post to the GL."), encoding="utf-8")
            found = sm.check(s, hard, soft)
            self.assertTrue(any(f["severity"] == "Error" and "'ZQX'" in f["message"] for f in found))
            self.assertTrue(any(f["severity"] == "Warning" and "'GL'" in f["message"] for f in found))
            self.assertFalse(any("'AP'" in f["message"] for f in found))
            self.assertEqual(sm.default_out(s), ws / "market/dist")


class Build(unittest.TestCase):
    def test_build_generates_methods_and_detects_staleness(self):
        with tempfile.TemporaryDirectory() as t:
            ws = Path(t)
            (ws / "project.json").write_text("{}", encoding="utf-8")
            (ws / "standards").mkdir()
            (ws / "standards/method.md").write_text(
                "# Method\n\n> **Created:** 2026-01-01 00:00:00 · **Updated:** 2026-01-01 00:00:00 (UTC)\n\nIntro.\n\n"
                "## 1. Keep\n\nUse R10 here.\n\n## 2. Drop\n\nInternal.\n", encoding="utf-8")
            port = build(ws / "market/ports")          # a clean demo skill as the port folder
            (port / "port.json").write_text(json.dumps({
                "name": "demo-skill", "replace": [["R10", "the variant rule"]],
                "generate": {"references/method.md": {"title": "Method", "from": ["standards/method.md"],
                                                      "sections": ["1."]}}}), encoding="utf-8")
            p = port / "SKILL.md"
            p.write_text(p.read_text(encoding="utf-8").replace("## How to Use\n",
                         "## How to Use\n\nRead [references/method.md](references/method.md).\n"), encoding="utf-8")
            quiet = io.StringIO()
            with redirect_stdout(quiet), redirect_stderr(quiet):
                self.assertEqual(sm.build(port, None, False, [], []), 0)
                out = ws / "market/skills/demo-skill"
                text = (out / "references/method.md").read_text(encoding="utf-8")
                self.assertIn("Use the variant rule here.", text)
                self.assertNotIn("Drop", text)
                self.assertNotIn("Created:", text)
                self.assertFalse((out / "port.json").exists())
                self.assertEqual(sm.build(port, None, True, [], []), 0)          # current
                (ws / "standards/method.md").write_text("# Method\n\n## 1. Keep\n\nChanged.\n", encoding="utf-8")
                self.assertEqual(sm.build(port, None, True, [], []), 1)          # source changed → stale


if __name__ == "__main__":
    unittest.main(verbosity=1)
