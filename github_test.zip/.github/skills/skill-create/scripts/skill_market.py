#!/usr/bin/env python3
"""Standalone (market) skills, built with Claude's skill-creator: dependencies, the S1–S12 check, the package.

    python3 skill_market.py creator                              # where skill-creator is (its scripts are used)
    eval "$(python3 skill_market.py env)"                        # this shell: claude CLI on PATH, $SKILL_CREATOR
    python3 skill_market.py init  <name> --license MIT --author "QA team" [--path market/skills]   # skeleton
    python3 skill_market.py deps  .claude/skills/<name>          # what a port must inline, drop or replace
    python3 skill_market.py check market/skills/<name> [--json] [--vocab WORD …] [--no-project-vocab]
    python3 skill_market.py build market/ports/<name> [--check]   # port + shared methods → market/skills/<name>/ + check
    python3 skill_market.py pack  market/skills/<name> [--out DIR] [--creator DIR]   # DIR default: market/dist

Rules S1–S12: ../references/standalone-rules.md. S3 also reads the workspace's project.json (nearest upwards):
its code, name and client are Errors, its module ids Warnings (--no-project-vocab skips them). `check` exits 1 on any Error. `pack` runs `check`, then
skill-creator's own `quick_validate` and `package_skill` (a `.skill` zip; `evals/` stays out, as skill-creator
packs it), renames it `<name>-<version>.skill`, writes its sha256, and never replaces a released version with other
content. skill-creator is found with --creator, $SKILL_CREATOR, or the usual install folders. This script itself is
standard library only (Python 3.10+); skill-creator's packager needs PyYAML. Nothing touches the network.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+([-+][0-9A-Za-z.-]+)?$")
LINK_RE = re.compile(r"\[[^\]]*\]\(([^)\s]+)\)")
FENCE_RE = re.compile(r"```.*?```", re.S)
REQUIRED_CASES = ("basic-success", "edge-incomplete-input", "edge-scope-boundary")
MIN_TRIGGERS = 8          # skill-creator: 20 queries, 8–10 should trigger and 8–10 near misses that should not
CLAUDE_GLOBS = ("~/.vscode/extensions/anthropic.claude-code-*/resources/native-binary/claude",
                "~/.vscode-server/extensions/anthropic.claude-code-*/resources/native-binary/claude",
                "~/.cursor/extensions/anthropic.claude-code-*/resources/native-binary/claude",
                "~/.local/bin/claude", "~/.claude/local/claude")
CREATOR_GLOBS = ("~/.claude/skills/synced/*/skill-creator", "~/.claude/skills/skill-creator",
                 "~/.claude/plugins/marketplaces/*/plugins/skill-creator/skills/skill-creator")
HTML_TAGS = {"br", "details", "summary", "sup", "sub", "kbd", "b", "i", "em", "strong", "code", "pre", "p", "div",
             "span", "img", "a", "table", "tr", "td", "th", "ul", "ol", "li", "hr"}
PLACEHOLDER_RE = re.compile(r"<(/?)([A-Za-z][^<>\n]{0,80})>")
# S2: paths that only exist inside a QA workspace
WORKSPACE_PATH_RE = re.compile(
    r"(?<![\w/.-])(standards/|packs/|project/|project\.json|template-manifest\.json|\.claude/skills/|\.agents/skills/|"
    r"\.github/skills/|\.gemini/skills/|scripts/workspace/|test-design/|deliverables/|sources/)")
ABS_PATH_RE = re.compile(r"(?<![\w:])(/home/|/Users/|/tmp/|[A-Z]:\\\\)")
# S3: workspace vocabulary
VOCAB_RES = [
    (re.compile(r"\bQ-INIT-\d+"), "open-question ID from a project (Q-INIT-…)"),
    (re.compile(r"\bL-T?\d{2,3}\b"), "lesson ID (L-nnn / L-Tnn)"),
    (re.compile(r"\bPR-\d+\b"), "project rule ID (PR-n)"),
    (re.compile(r"\bADR-\d{3}\b"), "decision record ID (ADR-nnn)"),
    (re.compile(r"\*\*Created:\*\*|\*\*Updated:\*\*"), "workspace Created / Updated stamp"),
]
# S10
SECRET_RES = [
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"), "private key"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "AWS access key"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b"), "GitHub token"),
    (re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"), "API secret key"),
    (re.compile(r"(?i)\b(password|passwd|secret|api[_-]?key|token)\s*[:=]\s*['\"]?[^\s'\"<>]{6,}"), "credential value"),
]
NETWORK_MODULES = {"urllib", "http", "socket", "ftplib", "smtplib", "ssl", "requests", "httpx", "aiohttp"}
TEXT_SUFFIXES = {".md", ".yaml", ".yml", ".json", ".py", ".sh", ".txt", ".csv", ".toml"}


def frontmatter(text: str) -> tuple[dict, dict]:
    """A small YAML subset: top-level `key: value` and one nested `metadata:` map."""
    m = re.match(r"---\n(.*?)\n---\n", text, re.S)
    if not m:
        return {}, {}
    top: dict = {}
    meta: dict = {}
    cur = None
    for line in m.group(1).splitlines():
        if not line.strip():
            continue
        if line.startswith((" ", "\t")):
            if cur == "metadata" and ":" in line:
                k, v = line.strip().split(":", 1)
                meta[k.strip()] = v.strip().strip("\"'")
            continue
        if ":" in line:
            k, v = line.split(":", 1)
            cur = k.strip()
            top[cur] = v.strip().strip("\"'")
    return top, meta


def files_of(root: Path) -> list[Path]:
    return sorted(p for p in root.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"
                  and not any(x.endswith("-workspace") for x in p.relative_to(root).parts))


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


def strip_code(text: str) -> str:
    return FENCE_RE.sub("", text)


# ---------------------------------------------------------------- check
def workspace_root(start: Path) -> Path | None:
    """The QA workspace around a path: the nearest folder upwards with a project.json."""
    for d in [start, *start.parents]:
        if (d / "project.json").is_file():
            return d
    return None


def project_vocab(start: Path) -> tuple[list[str], list[str]]:
    """S3 words from the workspace's project.json: (code, name, client → Error; module ids → Warning, because an
    id such as GL or AP is also an everyday domain word)."""
    ws = workspace_root(start)
    try:
        pj = json.loads((ws / "project.json").read_text(encoding="utf-8")) if ws else {}
    except (OSError, ValueError):
        pj = {}
    pr = pj.get("project", {}) if isinstance(pj.get("project"), dict) else {}
    hard = [pr[k] for k in ("code", "name", "client") if isinstance(pr.get(k), str) and pr[k] and pr[k] != "CHANGE-ME"]
    soft = [m["id"] for m in pj.get("modules", []) if isinstance(m, dict) and isinstance(m.get("id"), str)]
    return hard, soft


def check(root: Path, vocab: list[str], warn_vocab: list[str] | None = None) -> list[dict]:
    out: list[dict] = []

    def add(sev: str, rule: str, where: str, msg: str) -> None:
        out.append({"severity": sev, "rule": rule, "file": where, "message": msg})

    skill_md = root / "SKILL.md"
    if not skill_md.is_file():
        add("Error", "S1", "SKILL.md", "missing")
        return out
    text = read(skill_md)
    top, meta = frontmatter(text)
    name = top.get("name", "")
    # S1
    if not text.startswith("---\n"):
        add("Error", "S1", "SKILL.md", "frontmatter must start on line 1 (template note left in?)")
    if name != root.name:
        add("Error", "S1", "SKILL.md", f"name {name!r} ≠ folder {root.name!r}")
    if not NAME_RE.match(name or "-") or len(name) > 64:
        add("Error", "S1", "SKILL.md", f"name {name!r}: lowercase letters, digits and hyphens, ≤ 64 chars")
    oa = root / "agents/openai.yaml"
    if not oa.is_file():
        add("Error", "S1", "agents/openai.yaml", "missing")
    elif not re.search(rf'^\s*key:\s*"?{re.escape(name)}"?\s*$', read(oa), re.M):
        add("Error", "S1", "agents/openai.yaml", f"metadata.key ≠ {name!r}")
    # S4
    desc = top.get("description", "")
    if not 0 < len(desc) <= 1024:
        add("Error", "S4", "SKILL.md", f"description length {len(desc)} (1–1024)")
    raw = re.search(r"^description:[ \t]*(.*)$", text.split("\n---", 1)[0], re.M)
    if raw and raw.group(1)[:1] not in "\"'|>" and ": " in raw.group(1):
        add("Error", "S4", "SKILL.md", "description is unquoted and holds ': ' (invalid YAML); wrap it in double quotes")
    if "<" in desc or ">" in desc:
        add("Error", "S4", "SKILL.md", "description has < or > (skill-creator's validator and uploads refuse it)")
    extra = set(top) - {"name", "description", "license", "allowed-tools", "metadata", "compatibility"}
    if extra:
        add("Error", "S4", "SKILL.md", f"frontmatter keys {sorted(extra)} (allowed: name, description, license, "
                                       "allowed-tools, metadata, compatibility)")
    if desc and not desc.startswith(("Use this skill when", "This skill should be used when")):
        add("Warning", "S4", "SKILL.md", "description should start 'Use this skill when …' "
                                         "(or 'This skill should be used when …')")
    if desc and "Not for" not in desc:
        add("Warning", "S4", "SKILL.md", "description names no near miss ('Not for: …')")
    if not top.get("license"):
        add("Error", "S4", "SKILL.md", "no license in the frontmatter")
    version = meta.get("version", "")
    if not SEMVER_RE.match(version):
        add("Error", "S4", "SKILL.md", f"metadata.version {version!r} is not semver (x.y.z)")
    if not meta.get("author"):
        add("Error", "S4", "SKILL.md", "no metadata.author (organisation or role)")
    if re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", text.split("---", 2)[1] if text.startswith("---") else ""):
        add("Warning", "S4", "SKILL.md", "an e-mail address in the frontmatter: publish it only with its owner's OK")
    if "group" in meta or "order" in meta:
        add("Warning", "S2", "SKILL.md", "metadata.group / order are workspace fields; drop them")
    # S11
    n = len(text.splitlines())
    if n > 500:
        add("Error", "S11", "SKILL.md", f"{n} lines (over 500)")
    elif n > 150:
        add("Warning", "S11", "SKILL.md", f"{n} lines (aim ≤ 150; move depth to references/)")
    body = text.split("\n---", 1)[1] if text.startswith("---") else text
    words = len(re.findall(r"\S+", body))
    if words > 5000:
        add("Warning", "S11", "SKILL.md", f"body has {words} words (over 5,000: move detail to references/)")
    second = re.findall(r"\byou (?:should|must|need to|will need)\b", strip_code(body), re.I)
    if len(second) >= 3:
        add("Warning", "S11", "SKILL.md", f"{len(second)} 'you should / must …' phrases: write imperative, verb first")
    heads = {h.strip().lower() for h in re.findall(r"^## (.+)$", strip_code(text), re.M)}
    for need, alts in (("when to use", ()), ("how to use", ("steps",)), ("pre-delivery check", ("done when",))):
        if need not in heads and not any(a in heads for a in alts):
            add("Error", "S11", "SKILL.md", f"no '## {need.title()}' section")
    for want in ("inputs", "output", "core constraints", "reference files"):
        if want not in heads:
            add("Warning", "S11", "SKILL.md", f"no '## {want.title()}' section")
    # S8
    if not (root / "references/output-rules.md").is_file():
        add("Error", "S8", "references/output-rules.md", "missing (output contract)")
    if not any((root / "assets").glob("*")) if (root / "assets").is_dir() else True:
        add("Error", "S8", "assets/", "no output template")
    # S9: skill-creator test cases, evals/<case>/{prompt.md, case.yaml, graders/NN-….md}
    ev = root / "evals"
    cases = {p.name: p for p in ev.iterdir() if p.is_dir() and (p / "case.yaml").exists()} if ev.is_dir() else {}
    for c in REQUIRED_CASES:
        if c not in cases:
            add("Error", "S9", f"evals/{c}/", f"case {c} missing (prompt.md, case.yaml, graders/)")
    for c, p in cases.items():
        rel = f"evals/{c}"
        cy, pm = read(p / "case.yaml"), (p / "prompt.md")
        if not re.search(r'^schema_version:\s*"[^"]+"', cy, re.M):
            add("Error", "S9", f"{rel}/case.yaml", "schema_version must be quoted (\"1.1\")")
        if not re.search(rf"^name:\s*{re.escape(c)}\s*$", cy, re.M):
            add("Error", "S9", f"{rel}/case.yaml", "name ≠ folder")
        if "expected_outcome:" not in cy:
            add("Error", "S9", f"{rel}/case.yaml", "no expected_outcome")
        if not pm.is_file() or not re.match(r"---\n.*?\n---\n\s*\S", read(pm), re.S):
            add("Error", "S9", f"{rel}/prompt.md", "missing, or no settings block followed by the prompt")
        graders = sorted((p / "graders").glob("*.md")) if (p / "graders").is_dir() else []
        if not graders:
            add("Error", "S9", f"{rel}/graders/", "no grader (a case without one fails to load)")
        for g in graders:
            if not re.match(r"---\n(.*\n)?type:\s*\w+", read(g)):
                add("Error", "S9", f"{rel}/graders/{g.name}", "no grader block (type / focus / weight) on top")
    trig = ev / "trigger-queries.json"
    if not trig.is_file():
        add("Error", "S9", "evals/trigger-queries.json", "missing (skill-creator description optimization set)")
    else:
        try:
            q = json.loads(read(trig))
            yes = sum(1 for x in q if x.get("should_trigger") is True and x.get("query"))
            no = sum(1 for x in q if x.get("should_trigger") is False and x.get("query"))
            if yes < MIN_TRIGGERS or no < MIN_TRIGGERS:
                add("Error", "S9", "evals/trigger-queries.json",
                    f"{yes} should-trigger / {no} should-not (need ≥ {MIN_TRIGGERS} each)")
        except (ValueError, AttributeError, TypeError) as err:
            add("Error", "S9", "evals/trigger-queries.json", f"not a JSON list of {{query, should_trigger}}: {err}")
    # S12
    if not (root / "README.md").is_file():
        add("Error", "S12", "README.md", "missing")
    cl = root / "CHANGELOG.md"
    if not cl.is_file():
        add("Error", "S12", "CHANGELOG.md", "missing")
    else:
        first = re.search(r"^## \[?v?([0-9][^\]\s—-]*)", read(cl), re.M)
        if not first or first.group(1) != version:
            add("Error", "S12", "CHANGELOG.md", f"top entry {first.group(1) if first else 'none'} ≠ version {version!r}")

    # S11 progressive disclosure: every resource named, big references searchable, no duplicated text
    refs_text = "".join(read(q) for q in (root / "references").glob("*.md")) if (root / "references").is_dir() else ""
    named = text + refs_text
    for d in ("scripts", "references", "assets"):
        for q in sorted((root / d).rglob("*")) if (root / d).is_dir() else []:
            if q.is_file() and "__pycache__" not in q.parts and q.name not in named:
                add("Warning", "S11", f"{d}/{q.relative_to(root / d).as_posix()}",
                    "named nowhere in SKILL.md or references/ (delete it, or say when to use it)")
    for q in sorted((root / "references").glob("*.md")) if (root / "references").is_dir() else []:
        rw = len(re.findall(r"\S+", read(q)))
        if rw > 10000 and not re.search(rf"grep[^\n]*{re.escape(q.name)}|{re.escape(q.name)}[^\n]*grep", text):
            add("Warning", "S11", f"references/{q.name}", f"{rw} words: give grep patterns for it in SKILL.md")
        long_lines = {ln.strip() for ln in read(q).splitlines() if len(ln.strip()) >= 80}
        dup = [ln for ln in strip_code(body).splitlines() if ln.strip() in long_lines]
        if dup:
            add("Warning", "S11", f"references/{q.name}", f"{len(dup)} line(s) repeated in SKILL.md: keep one home")
    vocab_res = [(re.compile(rf"\b{re.escape(w)}\b"), f"workspace word {w!r}") for w in vocab if w]
    warn_res = [(re.compile(rf"\b{re.escape(w)}\b"), w) for w in (warn_vocab or []) if w]
    for p in files_of(root):
        rel = p.relative_to(root).as_posix()
        if p.is_symlink():
            add("Error", "S2", rel, "symbolic link (the package must hold real files)")
            continue
        if p.name.startswith(".") or p.name in {"Thumbs.db"}:
            add("Warning", "S12", rel, "hidden or system file; it is left out of the package")
            continue
        if p.stat().st_size > 5_000_000:
            add("Warning", "S11", rel, "over 5 MB")
        if p.suffix not in TEXT_SUFFIXES:
            continue
        body = read(p)
        prose = strip_code(body) if p.suffix == ".md" else body
        in_assets = rel.startswith("assets/")
        # S2 links and paths
        if p.suffix == ".md":
            for target in LINK_RE.findall(prose):
                if re.match(r"^(https?:|mailto:|#)", target) or "<" in target:
                    continue
                dest = (p.parent / target.split("#")[0]).resolve()
                if not dest.is_relative_to(root.resolve()):
                    add("Error", "S2", rel, f"link leaves the folder: {target}")
                elif not in_assets and not dest.exists():
                    add("Error", "S2", rel, f"link to a missing file: {target}")
        for m in WORKSPACE_PATH_RE.finditer(body):
            if rel == "README.md" and m.group(1).endswith("/skills/"):
                continue  # the install table names the agents' skills folders on purpose
            add("Error", "S2", rel, f"workspace path {m.group(1)!r}")
        for m in ABS_PATH_RE.finditer(body):
            add("Error", "S2", rel, f"absolute path {m.group(1)!r}")
        for m in re.finditer(r"(?:^|[\s(`\[])((?:\.\./)+[\w.<>/-]*)", body):
            if not (p.parent / m.group(1)).resolve().is_relative_to(root.resolve()):
                add("Error", "S2", rel, f"'{m.group(1)}' leaves the folder")
        # S3 vocabulary
        for rx, what in VOCAB_RES + vocab_res:
            for m in rx.finditer(body):
                add("Error", "S3", rel, f"{what}: {m.group(0)!r}")
        for rx, word in warn_res:
            if rx.search(body):
                add("Warning", "S3", rel, f"project module id {word!r}: keep only as a generic domain word")
        # S10 secrets
        for rx, what in SECRET_RES:
            for m in rx.finditer(body):
                if "<" not in m.group(0):
                    add("Error", "S10", rel, f"possible {what}: {m.group(0)[:24]!r}…")
        # unfilled placeholders and TODOs (assets/ are templates and keep theirs)
        if not in_assets and p.suffix in {".md", ".yaml", ".yml", ".json"} and re.search(r"\bTODO\b", prose):
            add("Error", "S12", rel, "TODO left (from init?)")
        if not in_assets and p.suffix in {".md", ".yaml", ".yml"}:
            for m in PLACEHOLDER_RE.finditer(prose):
                tag = m.group(2).split()[0].lower().rstrip("/")
                if m.group(1) or tag in HTML_TAGS or m.group(2).startswith(("!--", "http")):
                    continue
                add("Error", "S12", rel, f"unfilled placeholder <{m.group(2)[:40]}>")
                break
        # S10 scripts
        if p.suffix == ".py":
            local = {q.stem for q in p.parent.glob("*.py")}
            for mod in re.findall(r"^\s*(?:from|import)\s+([A-Za-z_][\w]*)", body, re.M):
                if mod in NETWORK_MODULES:
                    add("Error", "S10", rel, f"network module {mod!r}")
                elif mod not in sys.stdlib_module_names and mod not in local and mod != "__future__":
                    add("Error", "S10", rel, f"non-standard-library import {mod!r}")
        if p.suffix == ".sh" and re.search(r"\b(curl|wget|pip|npm|apt-get|brew)\b", body):
            add("Error", "S10", rel, "the script fetches or installs software")
    return out


# ---------------------------------------------------------------- init
ASSETS = Path(__file__).resolve().parents[1] / "assets"
PLACEHOLDER_GRADER = "The result matches this description: TODO the expected outcome of {case}"


def template(name: str) -> str:
    """An asset of this skill without its first-line template note."""
    body = (ASSETS / name).read_text(encoding="utf-8")
    first, _, rest = body.partition("\n")
    return rest if "Template:" in first else body


def init(name: str, path: Path, license_id: str, author: str, version: str) -> int:
    """Write the skeleton of a standalone skill (creation process step 3); never overwrite."""
    import datetime
    if not NAME_RE.match(name) or len(name) > 64:
        print(f"init: {name!r} must be lowercase letters, digits and hyphens, ≤ 64 chars", file=sys.stderr)
        return 2
    root = path / name
    if root.exists():
        print(f"init: refused, {root} exists (edit it, or pick another name)", file=sys.stderr)
        return 1
    today = datetime.date.today().isoformat()
    skill = template("standalone-SKILL.md")
    skill = re.sub(r"^name: .*$", f"name: {name}", skill, count=1, flags=re.M)
    skill = re.sub(r"^license: .*$", f"license: {license_id}", skill, count=1, flags=re.M)
    skill = re.sub(r'^  version: .*$', f'  version: "{version}"', skill, count=1, flags=re.M)
    skill = re.sub(r'^  author: .*$', f'  author: "{author}"', skill, count=1, flags=re.M)
    files = {
        "SKILL.md": skill,
        "references/output-rules.md": f"# {name}: output rules\n\n| Output | Template | Where |\n| --- | --- | --- |\n"
                                      "| TODO | [../assets/output.md](../assets/output.md) | chat |\n",
        "assets/output.md": "# TODO output title\n\nTODO sections in output order.\n",
        "agents/openai.yaml": template("openai.yaml").replace('"<name>"', f'"{name}"'),
        "evals/trigger-queries.json": template("trigger-queries.json"),
        "README.md": template("README.md").replace("`<name>/`", f"`{name}/`"),
        "CHANGELOG.md": template("CHANGELOG.md").replace("<0.1.0>", version).replace("<YYYY-MM-DD>", today),
    }
    for case in REQUIRED_CASES:
        files[f"evals/{case}/prompt.md"] = template("eval-prompt.md")
        files[f"evals/{case}/case.yaml"] = re.sub(r"^name: .*$", f"name: {case}", template("eval-case.yaml"),
                                                  count=1, flags=re.M).replace("# Template", "#", 1)
        files[f"evals/{case}/graders/01-expected-output.md"] = (
            "---\ntype: llm\nfocus: trace\nweight: 1\n---\n\n" + PLACEHOLDER_GRADER.format(case=case) + "\n")
    for rel, body in files.items():
        (root / rel).parent.mkdir(parents=True, exist_ok=True)
        (root / rel).write_text(body, encoding="utf-8")
    print(f"init: {root} · {len(files)} files · fill every <placeholder> and TODO, then: skill_market.py check {root}")
    return 0


# ---------------------------------------------------------------- deps
def deps(root: Path) -> dict:
    """Group what a workspace skill leans on: inline (rules, methods), drop (workspace mechanics), replace (scripts)."""
    groups: dict[str, set] = {"inline": set(), "drop": set(), "replace": set(), "hand-off": set()}
    skills_dir = root.parent
    others = {p.name for p in skills_dir.iterdir() if p.is_dir() and p.name != root.name} if skills_dir.is_dir() else set()
    for p in files_of(root):
        if p.suffix not in TEXT_SUFFIXES:
            continue
        body = read(p)
        rel = p.relative_to(root).as_posix()
        for target in LINK_RE.findall(body):
            if re.match(r"^(https?:|mailto:|#)", target) or "<" in target:
                continue
            dest = (p.parent / target.split("#")[0]).resolve()
            if not dest.is_relative_to(root.resolve()):
                bucket = "inline" if re.search(r"standards/|packs/", target) else \
                    "hand-off" if "/skills/" in target or any(f"../{o}/" in target for o in others) else "drop"
                groups[bucket].add(f"{target}  ({rel})")
        for m in re.finditer(r"`(python3?\s+)?((?:\.claude/skills/[\w-]+/)?scripts/[\w/.-]+\.py)", body):
            groups["replace"].add(f"{m.group(2)}  ({rel})")
        for m in re.finditer(r"(?<![\w/.-])(project\.json[\w ›.`]*|project/[\w./-]+|guard\.py|sync_agents\.py|"
                             r"git (?:commit|tag)|deliverables/|TEMPLATE_VERSION|CHANGELOG\.md)", body):
            groups["drop"].add(f"{m.group(1).strip('` ')}  ({rel})")
        for m in re.finditer(r"\b(R\d+(?:\.\d+)?|R-(?:UI|API|ETL|SQL)[\w.-]*|P[1-7]|L-T\d+|L-\d{3}|PR-\d+|ADR-\d{3})\b",
                             body):
            groups["inline"].add(f"rule {m.group(1)}  ({rel})")
        for o in others:
            if re.search(rf"`/?{re.escape(o)}`|/{re.escape(o)}\b", body):
                groups["hand-off"].add(f"{o}  ({rel})")
    return {k: sorted(v) for k, v in groups.items()}


# ---------------------------------------------------------------- pack (skill-creator)
def find_creator(given: Path | None = None) -> Path | None:
    """skill-creator's folder: --creator, $SKILL_CREATOR, then the usual install places (newest first)."""
    cands = [given] if given else []
    if os.environ.get("SKILL_CREATOR"):
        cands.append(Path(os.environ["SKILL_CREATOR"]))
    import glob
    for g in CREATOR_GLOBS:
        cands += sorted((Path(f) for f in glob.glob(os.path.expanduser(g))), key=lambda p: p.stat().st_mtime,
                        reverse=True)
    for c in cands:
        if c and (c / "SKILL.md").is_file() and (c / "scripts/package_skill.py").is_file():
            return c.resolve()
    return None


def find_claude() -> Path | None:
    """The claude CLI that skill-creator's run_loop / run_eval and `claude plugin eval` call: PATH first, then the
    binary an IDE extension ships (newest first), so it keeps working after the extension updates."""
    import shutil
    on_path = shutil.which("claude")
    if on_path:
        return Path(on_path).resolve()
    import glob
    found = [Path(f) for g in CLAUDE_GLOBS for f in glob.glob(os.path.expanduser(g))]
    found = [f for f in found if f.is_file() and os.access(f, os.X_OK)]
    return max(found, key=lambda f: f.stat().st_mtime).resolve() if found else None


def zip_content(path: Path) -> dict:
    with zipfile.ZipFile(path) as z:
        return {n: z.read(n) for n in z.namelist() if not n.endswith("/")}


def default_out(root: Path) -> Path:
    """market/skills/<name> → market/dist (beside skills/), wherever the command runs; else ./market/dist."""
    return root.parent.parent / "dist" if root.parent.name == "skills" else Path("market/dist").resolve()


def pack(root: Path, out_dir: Path | None, vocab: list[str], creator: Path | None = None,
         warn_vocab: list[str] | None = None) -> int:
    out_dir = out_dir or default_out(root)
    found = check(root, vocab, warn_vocab)
    errors = [f for f in found if f["severity"] == "Error"]
    if errors:
        report(found)
        print(f"pack: refused, {len(errors)} Error", file=sys.stderr)
        return 1
    sc = find_creator(creator)
    if not sc:
        print("pack: refused, skill-creator not found (--creator DIR or $SKILL_CREATOR)", file=sys.stderr)
        return 1
    _, meta = frontmatter(read(root / "SKILL.md"))
    version = meta["version"]
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / f"{root.name}-{version}.skill"
    with tempfile.TemporaryDirectory() as tmp:
        r = subprocess.run([sys.executable, "-m", "scripts.package_skill", str(root), tmp], cwd=sc,
                           capture_output=True, text=True)
        built = Path(tmp) / f"{root.name}.skill"
        if r.returncode or not built.is_file():
            print(r.stdout + r.stderr, file=sys.stderr)
            print(f"pack: refused by skill-creator's package_skill ({sc})", file=sys.stderr)
            return 1
        if target.exists():
            if zip_content(target) != zip_content(built):
                print(f"pack: refused, {target} exists with other content; bump metadata.version and CHANGELOG",
                      file=sys.stderr)
                return 1
            print(f"pack: {target} unchanged · sha256 {hashlib.sha256(target.read_bytes()).hexdigest()}")
            return 0
        data = built.read_bytes()
    target.write_bytes(data)
    digest = hashlib.sha256(data).hexdigest()
    (out_dir / f"{target.name}.sha256").write_text(f"{digest}  {target.name}\n", encoding="utf-8")
    print(f"pack: {target} · {len(zip_content(target))} files · sha256 {digest} · built by {sc}")
    return 0


# ---------------------------------------------------------------- build (port folder + shared methods → package)
GENERATED_NOTE = ("<!-- Generated by the package build from the team's shared method; change the source and rebuild, "
                  "never edit here. -->")


def method_text(src: str, item: dict, replace: list) -> str:
    """One inlined reference: the source method without its title, stamp and intro (unless keep_intro), only the
    `## ` sections whose heading starts with one of item['sections'] (all when absent), headings shifted by
    item['demote'], then the regex replacements (port-wide first, then the item's own)."""
    lines = src.split("\n")
    body, i = [], 0
    if lines and lines[0].startswith("# "):
        i = 1
    if not item.get("keep_intro"):
        while i < len(lines) and not lines[i].startswith("## "):
            i += 1
    keep, wanted = True, item.get("sections")
    for line in lines[i:]:
        if line.startswith("## ") and wanted is not None:
            keep = any(line[3:].startswith(w) for w in wanted)
        if keep and not re.match(r"> \*\*Created:\*\*", line):
            body.append(line)
    text = "\n".join(body).strip("\n")
    if item.get("demote"):
        text = re.sub(r"^(#+) ", lambda m: "#" * (len(m.group(1)) + item["demote"]) + " ", text, flags=re.M)
    for pat, rep in list(replace) + list(item.get("replace", [])):
        text = re.sub(pat, rep, text, flags=re.M)
    return text


def build_files(port: Path) -> tuple[dict[str, bytes], dict]:
    """{relative path: content} of the package: the port folder (minus port.json) + the generated references."""
    spec = json.loads(read(port / "port.json"))
    ws = workspace_root(port)
    if not ws:
        raise SystemExit(f"build: no workspace (project.json) above {port}")
    out: dict[str, bytes] = {}
    for f in sorted(port.rglob("*")):
        if f.is_file() and f.name != "port.json" and "__pycache__" not in f.parts:
            out[f.relative_to(port).as_posix()] = f.read_bytes()
    for target, item in spec.get("generate", {}).items():
        parts = []
        for src in item["from"]:
            src = src if isinstance(src, dict) else {"path": src}
            text = method_text(read(ws / src["path"]), {**item, **src}, spec.get("replace", []))
            parts.append((src["heading"] + "\n\n" if src.get("heading") else "") + text)
        head = f"# {item['title']}\n\n{GENERATED_NOTE}\n\n" + (item["intro"].strip() + "\n\n" if item.get("intro") else "")
        out[target] = (head + "\n\n".join(parts).rstrip() + "\n").encode("utf-8")
    return out, spec


def build(port: Path, out_root: Path | None, check_only: bool, vocab: list[str], warn_vocab: list[str]) -> int:
    """market/ports/<name>/ → market/skills/<name>/ (whole folder regenerated), then the S1–S12 check.
    --check: report a package that differs from what the build would write (exit 1), write nothing."""
    files, spec = build_files(port)
    name = spec["name"]
    dst = (out_root or port.parent.parent / "skills") / name
    current = {f.relative_to(dst).as_posix(): f.read_bytes() for f in sorted(dst.rglob("*")) if f.is_file()} \
        if dst.is_dir() else {}
    stale = sorted({k for k in files if current.get(k) != files[k]} | (set(current) - set(files)))
    if check_only:
        for k in stale:
            print(f"  differs: {dst.name}/{k}")
        print(f"build --check: {name} {'current' if not stale else f'{len(stale)} file(s) differ (run build)'}")
        return 1 if stale else 0
    for k in set(current) - set(files):
        (dst / k).unlink()
    for k, data in files.items():
        (dst / k).parent.mkdir(parents=True, exist_ok=True)
        (dst / k).write_bytes(data)
    for d in sorted((p for p in dst.rglob("*") if p.is_dir()), key=lambda p: -len(p.parts)):
        if not any(d.iterdir()):
            d.rmdir()
    print(f"build: {port} → {dst} · {len(files)} file(s), {len(spec.get('generate', {}))} generated, "
          f"{len(stale)} changed")
    found = check(dst, vocab, warn_vocab)
    report(found)
    return 1 if any(f["severity"] == "Error" for f in found) else 0


def report(found: list[dict]) -> None:
    for f in found:
        print(f"  {f['severity']:<8}{f['rule']:<4}{f['file']}: {f['message']}")
    e = sum(f["severity"] == "Error" for f in found)
    print(f"skill_market check: {e} Error · {len(found) - e} Warning")


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("creator")
    si = sub.add_parser("init", help="write a new standalone skill skeleton")
    si.add_argument("name")
    si.add_argument("--path", type=Path, default=Path("market/skills"))
    si.add_argument("--license", required=True, dest="license_id")
    si.add_argument("--author", required=True, help="organisation or role")
    si.add_argument("--version", default="0.1.0")
    sub.add_parser("env", help="print shell exports: claude CLI on PATH and SKILL_CREATOR (use with eval)")
    sb = sub.add_parser("build", help="market/ports/<name>/ → market/skills/<name>/ (generated) + check")
    sb.add_argument("port", type=Path)
    sb.add_argument("--out", type=Path, default=None, help="default: market/skills beside market/ports")
    sb.add_argument("--check", action="store_true", help="report a stale package, write nothing")
    sb.add_argument("--vocab", nargs="*", default=[])
    sb.add_argument("--no-project-vocab", action="store_true")
    for cmd in ("deps", "check", "pack"):
        s = sub.add_parser(cmd)
        s.add_argument("skill", type=Path)
        s.add_argument("--json", action="store_true")
        s.add_argument("--vocab", nargs="*", default=[], help="extra workspace words that must not ship (S3)")
        s.add_argument("--no-project-vocab", action="store_true",
                       help="skip the words read from the workspace's project.json (code, name, client, module ids)")
        if cmd == "pack":
            s.add_argument("--out", type=Path, default=None,
                           help="default: market/dist beside the skill's market/skills/ folder")
            s.add_argument("--creator", type=Path, help="skill-creator folder (default: found automatically)")
    a = ap.parse_args(argv)
    if a.cmd == "init":
        return init(a.name, a.path, a.license_id, a.author, a.version)
    if a.cmd == "env":
        sc, cl = find_creator(), find_claude()
        if sc:
            print(f'export SKILL_CREATOR="{sc}"')
        if cl:
            print(f'export PATH="{cl.parent}:$PATH"')
        for what, got in (("skill-creator", sc), ("claude CLI", cl)):
            if not got:
                print(f"echo 'skill_market env: {what} not found' >&2")
        return 0 if sc and cl else 1
    if a.cmd == "build":
        port = a.port.resolve()
        if not (port / "port.json").is_file():
            print(f"skill_market: no port.json in {a.port}", file=sys.stderr)
            return 2
        hard, soft = ([], []) if a.no_project_vocab else project_vocab(port)
        return build(port, a.out.resolve() if a.out else None, a.check, a.vocab + hard, soft)
    if a.cmd == "creator":
        sc = find_creator()
        print(sc or "skill-creator: not found (set $SKILL_CREATOR)")
        return 0 if sc else 1
    root = a.skill.resolve()
    if not (root / "SKILL.md").is_file():
        print(f"skill_market: no SKILL.md in {a.skill}", file=sys.stderr)
        return 2
    if a.cmd == "deps":
        d = deps(root)
        if a.json:
            print(json.dumps(d, ensure_ascii=False, indent=1))
        else:
            for k, rows in d.items():
                print(f"{k} ({len(rows)})")
                for r in rows:
                    print(f"  {r}")
        return 0
    hard, soft = ([], []) if a.no_project_vocab else project_vocab(root)
    if a.cmd == "check":
        found = check(root, a.vocab + hard, soft)
        if a.json:
            print(json.dumps({"skill": root.name, "findings": found}, ensure_ascii=False, indent=1))
        else:
            report(found)
        return 1 if any(f["severity"] == "Error" for f in found) else 0
    return pack(root, a.out, a.vocab + hard, a.creator, soft)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
