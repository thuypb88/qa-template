<!-- Template: copy to market/skills/<name>/evals/<case>/graders/NN-few-words.md, delete this line (the grader block must be line 1); rules: references/output-rules.md -->
---
type: llm
focus: trace
weight: 1
---

<One verifiable statement about the result, e.g. "The answer lists PFX-01 with its source and evidence state".>
