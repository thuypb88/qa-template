<!-- Template: copy to market/skills/<name>/README.md, delete this line; rules: references/output-rules.md -->
# <Title>

<Two sentences: what it does for whom, and what it never does.>

**Version** <0.1.0> · **Licence** <licence> · **Author** <organisation or role>

## Install

Copy the `<name>/` folder into the skills folder your agent reads. Common places:

| Agent | Personal | In a repository |
| --- | --- | --- |
| Claude Code | `~/.claude/skills/<name>/` | `.claude/skills/<name>/` |
| Codex | `~/.agents/skills/<name>/` | `.agents/skills/<name>/` |
| GitHub Copilot | — | `.github/skills/<name>/` |
| Gemini CLI | `~/.gemini/skills/<name>/` | `.gemini/skills/<name>/` |

On claude.ai or the Claude API, upload the `<name>-<version>.skill` file instead.

Nothing runs on install. No other skill, package or account is needed.

## Use

Ask in your own words, for example: "<trigger phrase>". Or name it: "Use <name> to …".

It returns <output>, items `<PFX>-01…`, each with its source and evidence state, plus the open questions for what
the material does not say.

## Files

| Path | What |
| --- | --- |
| `SKILL.md` | the instructions the agent loads |
| `references/` | rules read on demand |
| `assets/` | the output template |
| `agents/openai.yaml` | metadata for Codex-style catalogues |
| `evals/` | test cases and trigger queries (in the source; not in the `.skill`) |

## Licence

<licence text or a pointer to the LICENSE file in this folder>
