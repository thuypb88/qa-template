<!-- Template: the chat answer of skill-create (not a file); rules: references/output-rules.md -->
**<new | port | pack>** · `market/skills/<name>/` · v<version>

| Check | Result |
| --- | --- |
| `skill_market.py check` | <n> Error · <n> Warning (quoted as printed) |
| Test cases (skill-creator) | <written, not run (why) · iteration N: pass rate with skill x% vs baseline y%> |
| Description optimization | <not run (why) · best test score n/m> |
| Package | <market/dist/<name>-<version>.skill · sha256 <first 12> · not built> |

**Examples → resources:** <request → script / reference / asset, one line each>
**Inlined rules:** <topic → references/<file>.md, or none>
**Open for the owner:** <licence, author, price / listing text, a decision only a person makes>
**Next:** `check-skill` on the package by another agent (standalone profile: checks 1, 4, 5, 7, 8, 10, 12 + S1–S12),
then run the evals, then `pack`.
