<!-- Template: copy to market/skills/<name>/SKILL.md, delete this line (the frontmatter must be line 1), fill every <placeholder>; rules: references/output-rules.md + references/standalone-rules.md -->
---
name: <name: lowercase-hyphen, = folder, ≤ 64 chars>
description: "Use this skill when <the situation, in the user's words>; it <does what> from <inputs> and returns <output with its ID prefix>. Use it even when the user does not name it, e.g. '<phrase>', '<phrase>', '<phrase in another language the users write>'. Not for: <near-miss task> (use a <kind of> skill instead); <near-miss task>."
license: <licence chosen by the owner, e.g. MIT, Apache-2.0, Proprietary>
metadata:
  version: "<0.1.0>"
  author: "<organisation or role>"
---

# <Title: what it produces, in plain words>

<One sentence: the job. One sentence: what it never does (run, approve, invent).>

## When to Use

- <situation 1, with the material the user has>
- <situation 2>
- <a bounded first pass when the material is incomplete>

Not for: <near miss 1>; <near miss 2>. Say so and stop when the request is one of these.

## Inputs

Ask for, or take from the conversation: <input 1>, <input 2>, <optional input 3>. Before any output, write the
input audit: **known** · **missing** · **conflicting** · **stale** · **out of scope** · **assumptions** (each
assumption with its impact). A missing input becomes an open question, never an invented value.

## How to Use

<Body pattern: workflow (Step 1 → Step 2) · task (Quick start → one part per task) · reference (Guidelines →
Specifications) · capabilities (numbered). Imperative, verb first; facts that need depth go to references/.>

1. <Read / restate the objective, scope and success criteria.>
2. <The decision the agent makes, with the method in [references/<method>.md](references/<method>.md) — read it when <condition>.>
3. <Produce the items `<PFX>-01…` in the order of [assets/<output>.md](assets/<output>.md).>
4. <Self-check against the Pre-delivery Check; report what was not run or not verified.>

## Output

Fill [assets/<output>.md](assets/<output>.md) per [references/output-rules.md](references/output-rules.md): facts,
inferences, recommendations and decisions left to a person kept apart; evidence state per item (`VERIFIED` from
supplied evidence · `NOT_RUN` · `BLOCKED` · `UNASSESSED`).

## Core Constraints

- No invention: every item cites the input it comes from; unknowns stay open questions.
- Nothing is reported as run, passed, covered or approved without evidence the user supplied.
- <domain constraint 1>
- <domain constraint 2>

## Pre-delivery Check

- [ ] Input audit written; assumptions carry their impact.
- [ ] Every `<PFX>-nn` has its source, evidence state and next action.
- [ ] Facts, inferences, recommendations and human decisions are apart.
- [ ] <domain check>

## Reference Files

| File | Read when |
| --- | --- |
| [references/output-rules.md](references/output-rules.md) | before writing the output |
| [references/<method>.md](references/<method>.md) | <condition> |

## Common Pitfalls

- <a mistake seen in real use, and what to do instead>
