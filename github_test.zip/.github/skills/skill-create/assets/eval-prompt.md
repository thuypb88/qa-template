<!-- Template: copy to market/skills/<name>/evals/<case>/prompt.md, delete this line (the settings block must be line 1); rules: references/output-rules.md -->
---
tags: [skill-creator]
max_turns: 20
timeout_seconds: 600
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

<The request exactly as a real user would type it, with synthetic material. edge-incomplete-input leaves out one
key fact; edge-scope-boundary asks for what the skill must not do (run, approve, guarantee, invent).>
