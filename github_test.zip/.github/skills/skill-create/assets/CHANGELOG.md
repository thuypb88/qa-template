<!-- Template: copy to market/skills/<name>/CHANGELOG.md, delete this line; top entry = metadata.version; rules: references/output-rules.md -->
# Changelog

## <0.1.0> — <YYYY-MM-DD>

- First release: <what it does, in one line>.
