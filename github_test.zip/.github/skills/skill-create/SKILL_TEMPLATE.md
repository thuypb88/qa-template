---
name: <group>-<objective, a noun or verb; lowercase-hyphen; = folder name>
description: <Group>[ <order>] (<role: writer | reviewer | router>, <level IT / ST>, <packs>): <objective in one clause>. <Verb> <what> from <inputs> and write <output file>. Use for "<trigger in the user's words>", "<another>", or <re-run condition>. Not for: <neighbour case> → <other-skill>; <neighbour case> → <other-skill>.
metadata:
  group: <flow | plan | req | design | check | auto | run | learn | sql | skill — must equal the name prefix>
  order: "<step id in the chain: -1, 0, 1 … 6, A1, A2, A3, E0, E, E+, ST; or - for none>"
---

<!--
SKILL TEMPLATE — not a skill (Claude Code loads only <folder>/SKILL.md). Rules: standards/skill-architecture.md.
0. Pick the profile first. WORKSPACE (default, this skeleton): the skill runs inside a QA workspace, links the shared
   rules and hands off to other skills. STANDALONE (§5b): the skill is released on its own (marketplace, another
   team) and must work after one folder is copied into any agent, with nothing else installed. A workspace skill
   is never edited into a standalone one: the standalone copy is a separate product (own name, version, licence).
1. Pick the group by the question the skill answers (catalog: .claude/skills/README.md). No group fits, or the input,
   output and triggers overlap an existing skill → add a mode (references/<mode>.md) to that skill instead.
2. Copy to .claude/skills/<group>-<objective>/SKILL.md; replace every <placeholder>; delete these comments.
   agentskills.io format (Claude Code, Codex, Copilot, Gemini CLI): name = folder, lowercase-hyphen, ≤ 64 chars.
   Description ≤ 1024 chars: "<Group>: objective" → what (inputs → output) → "Use for …" → "Not for: … → skill".
3. Shared rules live in standards/ (core-rules R1–R10, review-protocol P1–P7, conventions, methods/) and
   packs/<pack>/: link to them, never copy them. Never link into another skill's references/.
4. SKILL.md ≤ ~120 lines. Section order is fixed: contract → Modes (only if any) → Steps → Rules → Pitfalls (only
   with evidence) → Done when (required). Long formats and per-mode detail go to references/, each with a "when".
   Folder layout (agentskills.io): SKILL.md · references/ (read on demand) · assets/ (output templates, copied, never
   read as instructions) · scripts/ (project skills only; template scripts live in scripts/).
4a. Output contract (required): every file or chat answer the skill produces has a template in assets/ (named after
   the output: 1-analysis.md, review.md, answer.md …) and its rules in references/output-rules.md (path and name,
   write mode, required sections and columns, IDs, the check that validates it; shared rules linked, never copied).
   The **Output:** line of the contract links both. A long inline format block in SKILL.md moves there.
4b. Learned from published skill sets (awesome-qa-skills): start from the user's input and state what is known,
   missing, conflicting, stale, out of scope and assumed before any output; keep facts, inferences, recommendations
   and decisions left to a person apart; anything not executed is reported as not run, never as passed; the
   description says what, when, trigger phrases and the near miss; evals cover success, incomplete input and a
   near miss or overclaim. From the open skill-creator guide: start from three concrete requests and, per request,
   the script / reference / asset that stops rework; write for another Claude (non-obvious knowledge only),
   imperative, verb first; each fact in SKILL.md or a reference, never both.
5. Add a row in the group's table of .claude/skills/README.md, template-dev/tests/skill-evals/<name>.json (≥ 3 cases incl. a
   near miss), run python3 scripts/check_skills.py <name> (0 Error, 0 Warning) and python3 scripts/workspace/sync_agents.py and template-dev/tests/selftest.py, then review it with check-skill.
6. STANDALONE profile — differences from this skeleton (standards/skill-architecture.md §5b):
   - Frontmatter: name (no group prefix needed), description starting "Use this skill when …" and ending with the
     near miss, license, metadata.version (semver), metadata.author (organisation or role); no group / order.
   - Nothing outside the folder: no link to standards/, packs/, project/, project.json, workspace scripts or another
     skill; the rules it applies are rewritten into its own references/ in neutral words. "Next" / "Stop if"
     hand-offs become "Not for" in the description and open questions in the output.
   - Sections: When to Use · Inputs · How to Use · Output · Core Constraints · Pre-delivery Check · Reference Files ·
     Common Pitfalls (not In / Out / Rules / Next and Done when, which assume the workspace).
   - Built with Claude's skill-creator (interview, draft, test-case runs, review viewer, description optimization,
     packaging). Ships with agents/openai.yaml (key = name), test cases in skill-creator's layout
     evals/<case>/{prompt.md, case.yaml, graders/} incl. basic-success, edge-incomplete-input, edge-scope-boundary,
     evals/trigger-queries.json (≥ 8 should, ≥ 8 near misses), README.md (install per agent), CHANGELOG.md (top
     entry = version). Description in double quotes, no angle brackets. Scripts: standard library only, nothing
     runs on install, no network.
   - No workspace vocabulary (project code, module, question, lesson, rule or decision IDs, Created / Updated stamps),
     no secrets, synthetic examples. Packaged by skill-creator into one versioned .skill; a released version is never replaced.
-->

# <Group>: <objective>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**In:** <target and files read>. **Out:** <files written; fixed title lines the scripts read>. **Rules:** <R-rules,
pack rules, project rules that start or matter here>. **Next:** `<next-skill>`.
**Stop if** <upstream missing / stale> → `<skill to run first>`. Never fill a gap by guessing.
**Output:** [assets/<output-file>](assets/<output-file>); rules <[references/output-rules.md], linked> — read before writing.
**Modes:** <only when the skill has them: mode → [references/<mode>.md](references/<mode>.md), when to pick it>

Read lean: `slice.py toc` → `section`; never a whole file over ~40 KB. Read the lessons that name this skill.

## Steps

1. <Read …>
2. <Write … with citations>
3. <Run the check script; fix every Error>

## Required sections | Checklist

1. **<Section>.** <content, fixed columns and why>

## Rules

- No invention: unknowns are `Q-xxx: assumed …`.
- IDs stable: never renumber; append.
- Generated files are regenerated, never edited.

## Pitfalls

- <L-Tnn / L-nnn references, plus mistakes seen in past runs>

## Done when

- [ ] <every section / check present>
- [ ] <check script clean; version bumped; `project/status.md` + `log.md` updated>
- [ ] Report <counts>; suggest `<next-skill>`.
