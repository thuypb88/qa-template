---
name: project-training-deck
description: Project (writer, TFM): a training / onboarding slide deck about TFM from parsed client sources. Plan a course-style deck (one module or whole-project overview across AA, AP, AR, BG, GL, PU, cross-module chains P2P / O2C / R2R, controls and roles) in plans/training/<deck>/outline.md, fill deck.json with KEY:line citations, check it, render self-contained HTML and 16:9 PDF in deliverables/training/ (theme ba or magenta), then review it. Modes outline · write · render · review. Use for "make a training deck on GL", "overview of whole project", "whole project training deck", "training deck for all modules", "system overview deck", "cross-module overview deck", "onboarding slides for new testers", "course deck for AP", "slides explaining month-end close", "tạo slide đào tạo", "tổng quan toàn bộ dự án". Not for: a plain-language explainer page → learn-explain; the first-day handbook → plans/onboarding-new-qa.html; a test plan or report document → plan-testplan / run-report.
metadata:
  group: project
  order: "-"
---

# Project: training deck (outline · write · render · review)

> **Created:** 2026-10-30 08:24:04 · **Updated:** 2026-11-11 13:45:00 (UTC+7)

**In:** the request (topic, modules, audience, language, theme, slide budget), `sources/parsed/` (the Blueprints and
BRDs, their `.figures/` flow charts), `project.json` (modules, `document_language`). Nothing else is a content
source — not `test-design/`, `plans/`, `project/` or general knowledge. **Out:** `plans/training/<deck>/outline.md`,
`deck.json`, `deck.html` (generated), `reviews/<date>-<deck>-v<version>.md`;
`deliverables/training/TFM_<Deck-Id>_Training_v<version>.pdf` (generated) and its row in
[deliverables/README.md](../../../deliverables/README.md). **Rules:** core R1 (no invention) applied to every slide,
[conventions](../../../standards/conventions.md) §1, §6, §7, §10, §11. **Next:** the user's sign-off, then the
deliverables row. **Stop if** `sources/parsed/` is empty or older than its source (`python3 scripts/extract_text.py`
first), or the topic is in no parsed source → say so, write nothing.
**Output:** [assets/outline.md](assets/outline.md) · [assets/deck.json](assets/deck.json) · [assets/deck-review.md](assets/deck-review.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Modes — read only what the mode needs

| Mode | When | Read |
|---|---|---|
| **outline** | a new deck, or a deck's scope changes | [references/narrative.md](references/narrative.md) · [references/layouts.md](references/layouts.md) (layout names only) |
| **write** | the outline is approved; fill or change slides | [references/layouts.md](references/layouts.md) (fields, limits) |
| **render** | `deck.json` changed; the user wants the PDF | — (the script) |
| **review** | after render, before the deck is sent | [references/output-rules.md](references/output-rules.md) § Review |

A plain "make a training deck on X" runs outline, stops for approval, then write → render → review.

## Steps

1. **Scope.** Name the deck (`<deck>` = kebab-case id, e.g. `gl-month-end-close` for a module/process, or
   `tfm-operations-overview` / `whole-project` for an all-module overview), audience, language (default
   `project.document_language`), theme (`ba` unless asked; `magenta` on request) and slide budget
   ([narrative.md](references/narrative.md) § Budget: 15–30 single module; 25–40 executive overview of whole project;
   50–90 full system course). For an overview of the whole project, study the completed single-module decks in
   `deliverables/training/` (`AA`, `AP`, `AR`, `BG`, `GL`, `PU`) and synthesize the 4 cross-module business chains (P2P,
   O2C, Budget Commitment, R2R) with 3–4 summary slides per module. List the sources:
   `python3 .agents/skills/project-training-deck/scripts/deck.py sources`; read only the sections the topic needs
   (`python3 scripts/slice.py toc <file>` → `section`).
2. **Outline.** Copy [assets/outline.md](assets/outline.md) to `plans/training/<deck>/outline.md`: the arc from
   narrative.md, one row per slide — layout, the one point it makes, its citations. Show it; **stop for approval**.
3. **Write.** Copy [assets/deck.json](assets/deck.json) to `plans/training/<deck>/deck.json`, keep only the source
   keys used, fill the slides in outline order, a module at a time. In a whole-project overview, include all 6 module
   keys in `sources`; balance module depth within a factor of 3 (3–5 slides each, tagged with `module: "<ID>"`);
   cross-module, architectural (P2P, O2C, R2R) and closing slides omit `module`. Every sentence restates a cited line;
   every figure, count, ID and role is the source's own. What the sources do not say is not on a slide — a needed but
   missing fact stays a `[[GAP: …]]` and goes to the outline's Gaps table.
4. **Check.** `deck.py check plans/training/<deck>/deck.json` → 0 Error; clear every Warning or note why it stays.
5. **Render.** `deck.py pdf plans/training/<deck>/deck.json [--theme magenta]`: it renders `deck.html`, measures
   every slide in headless Chrome (an overflow is an Error: cut or split the slide) and prints the PDF to
   `deliverables/training/`. Look at the PDF (Read it with `pages`) — layout, figures legible, no clipped text.
6. **Review.** Re-open each citation and compare it with the slide; write
   `plans/training/<deck>/reviews/<date>-<deck>-v<version>.md` from [assets/deck-review.md](assets/deck-review.md)
   with TD- findings; fix, bump `deck.version`, re-render.
7. **Issue.** On the user's OK add the deliverables row; a later change is a new version, and the PDF it supersedes
   is archived (`scripts/workspace/archive.py`) in the same change set.

## Rules

- **Sources only.** `deck.sources` lists files under `sources/parsed/` (the script rejects anything else). A slide
  that needs the project's own analysis, a test count or a status is out of scope for this skill.
- **One slide, one point;** a title states it. Text fits the layout's limits; overflow is split, never shrunk.
- **Cite every content slide** (`cite: ["GL:786-791"]`); the footer prints them. Figures come from a
  `.figures/fig-NN.png` of the cited document, captioned with its figure number.
- **Language:** slide text in the deck's language; UI labels, process IDs (ACC-GL-005), document codes and role
  names exactly as the source writes them.
- **Themes are tokens only** (`scripts/themes/<name>.css`); a new theme is a new file, layouts stay shared.

## Pitfalls

- A Blueprint figure is a whole swimlane chart: use it on a `split` slide with the steps restated beside it, never
  as a full-slide image that nobody can read.
- The reference deck was uneven (40 slides for one module, 2 for another): keep modules within the budget's ratio.
- A whole-project overview must not become an unmanageable 150-slide dump of every detail: focus on end-to-end
  integration chains, hand-offs, and 3–4 representative slides per module drawn from `deliverables/training/`.

## Done when

- `deck.py check` shows 0 Error and `deck.py pdf` printed the PDF with no overflow.
- Every slide but the cover cites lines that say what the slide says (review file, 0 open High findings).
- The outline's Gaps table lists every `[[GAP]]` left on a slide; the user approved the outline and the PDF.
