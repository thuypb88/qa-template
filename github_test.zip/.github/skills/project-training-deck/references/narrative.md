# project-training-deck: narrative

> **Created:** 2026-10-30 08:24:04 · **Updated:** 2026-11-11 13:45:00 (UTC+7)

The arc is taken from the reference course deck (`BA-BANKING-PART-1.pdf`, 100 slides): open with the promise and a
map of the course, teach each module through the same rhythm, close with what to remember and where to look things
up. Its marketing slides (registration, satisfaction rates, trainer's message) have no TFM source and are not used.

## Arc

| Part | Slides | Layouts | From the sources |
|---|---|---|---|
| Opening | cover → agenda (one item per module or topic) | `cover`, `agenda` | the Blueprint's title and §1 Objectives |
| Per module | section divider (tag `Module <ID>`, 2–4 cards) | `section` | §1 Objectives, §2 Scope |
| | where it sits (related modules, external systems) | `hub` | §2 Related Modules, integration sections |
| | As-Is → To-Be process map | `table` | §3 Process Map |
| | what changes | `compare` | §5 As-Is Current Situation vs §8 Design Concept |
| | pain points it resolves | `stats` (IDs or counts as values) · `table` | §6 Pain Point Register |
| | per key process: the flow | `split` with the To-Be figure | §8.n To-Be Workflow Diagram |
| | its steps and owners | `process` (3–4) · `steps` · `numbered` · `table` (5+) | §8.n Process Steps |
| | its rules and edge cases | `cards` (accent) · `columns` | §8.n Design Concept, SoD, validations |
| | roles and segregation of duties | `table` · `compare` | §8.n SoD, User Role Matrix appendix |
| | take-aways | `checklist` | restates the module's cited rules |
| Mid-course (system decks) | module journey | `timeline` | the order the sources give |
| Closing | glossary (one or two) | `table` | §4.3 Definitions and Abbreviations |
| | one-line message | `statement` | a design-concept line, quoted or restated |

A one-module deck drops the agenda's per-module items and the timeline; a system deck repeats "Per module" for each.
A practice slide (`cards` outlined, "Case 1 – …") may pose a situation built from one cited rule, with the answer
on the next slide, both cited.

## Whole-Project Overview Deck Arc (All Modules)

When the topic is an overview of the whole project (`tfm-operations-overview` or `whole-project`), the deck synthesizes
across all six business modules (`AA`, `AP`, `AR`, `BG`, `GL`, `PU`), drawing from the completed single-module decks in
`deliverables/training/` and their parsed sources. Its narrative connects individual functions into end-to-end
enterprise operations:

1. **Enterprise Opening & Context (4–6 slides):**
   - `cover`: Project title, scope across all 6 business modules, and operational purpose.
   - `agenda`: Executive roadmap covering enterprise architecture, cross-module chains, module deep-dives, and governance.
   - `hub`: Central ERP data hub connecting Retail Stores/POS, Procurement, Assets, Payables, Receivables, Budget, and GL.
   - `compare`: Enterprise As-Is pain points (manual reconciliations, disconnected Excel spreadsheets, paper approvals) vs To-Be Odoo 19 single source of truth.
2. **Cross-Module End-to-End Business Chains (4–6 slides):**
   - *Procure-to-Pay (P2P):* PR creation & release (PU) → RFQ & PO confirmation (PU) → Physical Receipt (PU GRN) or Service Entry (PU SES) → Asset Capitalization (AA) → 3-Way Matching & ERS (AP) → Payment Run & Bank Clearance (AP/GL).
   - *Order-to-Cash (O2C):* Store Sales & POS feeds → Customer Account & Credit Control (AR) → Collections & Billing (AR) → Bank Deposit Reconciliation (AR/GL Bank of Ayudhya).
   - *Budget & Commitment Lifecycle:* Budget Structure Formulation (BG) → Real-Time Encumbrance at PR/PO (PU/BG) → Invoiced Expense Consumption (AP) → Variance Monitoring & Year-End Carry Forward (BG).
   - *Record-to-Report (R2R) & Period Close:* Unified 7-digit Chart of Accounts → Real-Time Automated Sub-Ledger Posting (subledgers = GL) → Staggered Month-End Close via Lock Dates by User Group and Account Category (CD-GL-06) → Thai Tax Filing (PP 30) → Dynamic Retained Earnings Rollover.
3. **Six Modular Summaries (18–24 slides, 3–4 slides per module):**
   - For each module in operational sequence (`PU` → `BG` → `AP` → `AR` → `AA` → `GL`):
     - `section` or `split`: Module scope, To-Be workflow with key Blueprint flowchart (`fig-NN.png`).
     - `cards` or `table`: Critical business rules, decision controls, and Segregation of Duties.
     - `checklist`: Core operational takeaways and interfaces to neighbor modules.
4. **Enterprise Governance & Segregation of Duties (2–3 slides):**
   - `table`: Cross-module authorization matrix across Purchasing, Asset Management, Cashier/Banking, Accounts Payable, and GL Admin.
   - `cards`: Prohibited SoD role pairs and internal control safeguards.
5. **Closing & Strategic Value (2–3 slides):**
   - `table`: Consolidated enterprise glossary and standard abbreviation dictionary.
   - `statement`: Final takeaway emphasizing financial transparency, automated controls, and accelerated period close.

## Budget

| Deck | Slides | Per module |
|---|---|---|
| One process | 8–15 | — |
| One module | 15–30 | — |
| Whole-project overview (executive / cross-module) | 25–40 | 3–4 slides each, plus opening, E2E chains, and governance |
| Comprehensive system course (all modules deep-dive) | 50–90 | 6–10 slides each, the deepest no more than 3× the thinnest |

## Rhythm

- Alternate dense and light slides; never four of one layout in a row (the check warns).
- Each module ends with a `checklist`; each part opens with a `section` or `agenda`.
- In whole-project overview decks, keep modular slide counts balanced within a factor of 3 (e.g. 3 to 5 slides per module). Cross-module and closing slides omit `module`.
- Titles are statements ("Lock Dates replace the period close"), not labels ("Lock Dates").
