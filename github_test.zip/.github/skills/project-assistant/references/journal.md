# Modes note and log — project notes and work history

> **Created:** 2026-10-22 15:45:00 · **Updated:** 2026-11-11 09:20:19 (UTC+7)

## note → `project/notes.md`

1. **Capture** what the user says, in their words, short. Ask only for what is missing: the date (default today),
   the source (meeting · call · chat · e-mail · observation, and who), tags (module IDs, `ST`, topic).
2. **Classify** and propose the route (table in `project/notes.md`): open point → a `Q-` row; decision → an ADR;
   lesson → `learn-retro`; confirmed requirement → the user saves the confirmed document in `sources/`, then
   `plan-changes`; task → a `FU-` row in `project/status.md`; risk → roadmap §8 via `flow-roadmap update`;
   background → `keep`.
3. **Show the row** ([../assets/note-row.md](../assets/note-row.md)) — `| N-NNN | <date> | <source> | <note> | <tags> | <route> | Open |` with the next free ID
   (`assistant.py status --json` › `next_note_id`) — and, on OK, append it; set the Updated stamp.
4. **Route** when the user agrees: a `Q-` or `FU-` row is written in its register with the next free ID and
   `from N-NNN`; then the note's Route is that ID and its Status **Routed**. ADRs, lessons, risks, sources: name the
   skill or the user's step; the note stays **Open** until that target exists.
5. **Meeting notes:** one N row per point, not one per meeting; a point with an owner and a date is a task or a
   question, not a note.

Never: treat a note as an expected result; write a person's opinion as a decision; drop a note (close it with the
reason instead).

## log → `project/worklog.md`

1. **Draft:** `assistant.py log --draft [--since YYYY-MM-DD]` lists the commits since the last worklog date, one row
   each, with a guessed activity (estimate IDs, else `MGMT`, `MEET`, `STUDY`, `TOOL`, `OTHER`), the module from the
   subject and Hours `?`. With `--estimate`, Hours come from the commit times: the gap to the previous commit of the
   same session, in 0.25 h steps (minimum 0.25), and 0.5 h for the first commit of a session (a gap over 2 h starts a
   new one); Ref gets `hours est. from git`. Work without a commit (meetings, study, reviews in a call) the user tells you.
2. **Ask** the person for the hours per row (or per day, then split as they say), and who they are when the commit
   author is a shared account. **If they don't give them** (they decline, or say to work it out), use the
   `--estimate` hours and the git author as Person, and say the rows are estimates; the person's own figures, given
   later, go in as correction rows. Merge rows of the same day, activity and module when the user prefers one line
   (sum their hours, list every commit in Ref).
3. **Show** the final rows ([../assets/worklog-row.md](../assets/worklog-row.md)) `| <date> | <person> | <hours> | <activity> | <module> | <what> | <ref> |`; on OK
   append them, oldest first; set the Updated stamp.
4. **Report back:** hours this week by activity, and — if the estimate has the activity — its share used
   (`assistant.py analyze effort`).

"What did I do this week / stand-up / timesheet": read the worklog (and `project/log.md` for what changed) and
summarise per day; no writing. An end-of-day note for the team stays with `flow-cadence day`.
