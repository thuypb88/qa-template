<!-- Template: project-knowledge answer (chat). Records from scripts/knowledge.py only. Replace every
<placeholder>; delete this comment. Rules: ../references/output-rules.md. -->
**Knowledge · <skill> · <stage> · data <hash>**

| ID | Layer/kind | Where | Applies? | Action for this task |
| --- | --- | --- | --- | --- |
| <L-NNN \| L-Tnn \| ADR-NNN \| PR-n \| Q-xxx \| DEF-NNN \| term \| path> | <experience/lesson \| decisions/rule \| map/map \| basis/change \| basis/source \| state/status \| …> | <file:line> | <yes \| dropped: words matched, situation did not \| proposed: flagged, not applied> | <one concrete action> |

**Mandatory:** <lesson IDs that name the skill> · rules / ADRs touched: <IDs> · proposed awaiting the lead: <IDs | none>
**Gap:** <none | no stored record applies to <situation>>
**Check:** <not run | 0 Error · <n> Warning>
**Next:** `/<skill> <target>` <or `/learn-retro` for a new lesson>
