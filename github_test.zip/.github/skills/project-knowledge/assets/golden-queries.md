<!-- Template: project-knowledge golden queries → references/golden-queries.md (copied there by scripts/install.py
when the project has none). Replace the stamps, delete this comment, add rows from real situations of this project.
Rules: ../references/output-rules.md. -->
# project-knowledge: golden queries (recall evaluation)

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

Real situations with the record that should come back.
`python3 .claude/skills/project-knowledge/scripts/knowledge.py eval` runs every row against the live registers and
prints hit / miss and the hit rate.

Rules:

- A query is written as someone would ask it at work (task + stage + symptom), never copied from the record.
- Kind: `own words` (shares the record's vocabulary) · `synonym` (says it differently) · a language code for a
  query in another language than the registers.
- **A miss is recorded, never tuned away.** The scorer is not changed to pass a row. The second miss of the same
  record triggers the reopen rule (the module's README.md).
- Scope `—` = no `--scope`. Top-k is the `--k` the hit must fall within. Rows are never renumbered.
- The project's lead approves the list.

| # | Query | Scope | Expected | Top-k | Kind |
| --- | --- | --- | --- | --- | --- |
