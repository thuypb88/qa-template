# project-knowledge: output rules

> **Created:** 2026-11-11 15:30:00 · **Updated:** 2026-11-13 13:41:02 (UTC+7)

Fill [../assets/recall-answer.md](../assets/recall-answer.md). Linked, never copied:
the module's [README.md](../README.md) (contract, binding, register shapes) · the project's core rules (every
statement cited) and its own decision record and rules for this module, where it has them · `learn-retro` (the
writer of lessons, decisions and rules).

| Output | Where | Write mode |
| --- | --- | --- |
| recall / mandatory / check answer | chat | nothing written |
| a recall miss (a real situation and the record it should return) | [golden-queries.md](golden-queries.md), next free `G-nn` row (a new project starts from [../assets/golden-queries.md](../assets/golden-queries.md)) | append; rows are never renumbered; the QA lead approves the list |
| new or changed lesson, ADR, rule | `project/lessons.md`, `project/decisions/`, `project/rules.md` | by `learn-retro` only |
| glossary term · source change · status / log | `project/system-map.md` · `sources/` + `project/change-impact/` · `project/status.md`, `project/log.md` | by `learn-glossary` · the project's source intake · `project-assistant` |

## Rules

- **Every record** named by its ID and `file:line` from the script output, with the `data` hash of the run.
- **Applied vs dropped:** say which hits shaped the task and why a hit was dropped (words matched, situation did not).
- **No invented result:** when nothing fits, write "no stored lesson applies"; a score is never called a confidence.
- **Proposed / intake is never cited:** a `proposed` or `intake` hit is flagged ("awaiting confirmation"), not
  applied as a basis or fact (README › The contract); a `basis/source` hit is a pointer — read the file with `slice.py`.
- **Check:** quote the script's Error / Warning lines and counts as printed. A drain Warning (an Open note at or
  past the limit) is answered by routing the note through its capture skill, never by editing its Status alone.
- **Portable:** nothing in this folder names one project's IDs, people or vocabulary, except
  [golden-queries.md](golden-queries.md), which is this project's own and is never copied by the installer.
