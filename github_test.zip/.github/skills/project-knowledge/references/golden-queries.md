# project-knowledge: golden queries (recall evaluation)

> **Created:** 2026-11-12 08:43:30 · **Updated:** 2026-11-13 13:41:02 (UTC+7)

Real situations with the record that should come back. `python3 .claude/skills/project-knowledge/scripts/knowledge.py eval`
runs every row against the live registers and prints hit / miss and the hit rate
([development plan](../../../../plans/architecture/project-brain-development-plan.md) KB-07).

**Status: draft by the agent, 2026-11-12 — the QA lead has not approved the list yet.** The lead strikes a row that
is not a real situation and adds the ones the agent could not know.

Rules:

- A query is written as someone would ask it at work (task + stage + symptom), never copied from the record.
- Kind: `own words` (shares the record's vocabulary) · `synonym` (says it differently) · `vi` (Vietnamese).
- **A miss is recorded, never tuned away.** The scorer is not changed to pass a row. The second miss of the same
  record triggers the ADR-006 reopen rule: a search-context column, added through `learn-retro`.
- Scope `—` = no `--scope`. Top-k is the `--k` the hit must fall within.

| # | Query | Scope | Expected | Top-k | Kind |
| --- | --- | --- | --- | --- | --- |
| G-01 | negative assertion passes on any build because the page was never the right one | auto-write | L-003 | 5 | own words |
| G-02 | reviewer re-checked the fixes it wrote itself | check-automation | L-005 | 5 | own words |
| G-03 | updated BRD folder shows every file as added | plan-changes | L-006 | 5 | own words |
| G-04 | analysis written from only some of the screens, field negatives missing | design-analysis | L-009 | 5 | own words |
| G-05 | builder route cites a test case step that does something else | auto-design | L-004 | 5 | own words |
| G-06 | guard fails after a script was imported, compiled cache files in the agent copies | — | L-007 | 5 | synonym |
| G-07 | specs collide because they change one global configuration and sign out a common login | auto-write | L-002 | 5 | synonym |
| G-08 | started coding the automated checks before the changed cases were looked at again | auto-write | L-001 | 5 | synonym |
| G-09 | system test study covers a module's internals that the test plan has not taken in yet | design-system | L-008 | 5 | synonym |
| G-10 | sampling a few cases missed a fault present in the whole suite | check-design | L-T06 | 5 | synonym |
| G-11 | which date format does the Odoo screen show | — | PR-2 | 5 | own words |
| G-12 | where does the review file of a plan go | — | PR-5 | 5 | own words |
| G-13 | is openapi.json a test basis | — | ADR-004 | 5 | own words |
| G-14 | may a note from the inbox be cited as a basis | — | PR-9 | 5 | own words |
| G-15 | phân tích chỉ đọc một phần màn hình, thiếu trường hợp âm của trường dữ liệu | design-analysis | L-009 | 5 | vi |
| G-16 | ngày tháng theo Phật lịch trong tài liệu của khách hàng | — | PR-1 | 5 | vi |
| G-17 | khách hàng gửi thư mục tài liệu cập nhật, cần chạy lại những gì | — | PR-7 | 5 | vi |
