#!/usr/bin/env python3
"""install.py: install or upgrade this knowledge module in another project (standard library only).

    python3 .claude/skills/project-knowledge/scripts/install.py --to <project root>            # dry run: the plan
    python3 .claude/skills/project-knowledge/scripts/install.py --to <project root> --apply    # do it, then check

What it does in the target project, and nothing else:
  1. Copies the module folder to <root>/<skills dir>/project-knowledge/ (default skills dir: .claude/skills).
     New and changed files are listed first; the target's own golden queries are never overwritten.
  2. Creates references/golden-queries.md from the empty template when the target has none.
  3. Binds the registers when the target has no binding yet: a `knowledge` block in its project.json, or a
     knowledge.json at the root when it has no project.json. Only registers that exist are bound; a layer with
     none is bound to []. An existing binding is never changed.
  4. Runs `knowledge.py check` in the target and prints the result.

It never writes a register, never touches git, and never installs into the project it runs from.
Exit: 0 done / planned · 1 the target's check has an Error · 2 refused (bad target).
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import knowledge as K  # noqa: E402

MODULE = Path(__file__).resolve().parents[1]
NAME = MODULE.name
GOLDEN = "references/golden-queries.md"
GOLDEN_TEMPLATE = "assets/golden-queries.md"
LIMITS = {"drain_days": 14, "proposed_days": 14, "queue_by_nature": False}


def module_files() -> list[str]:
    return sorted(p.relative_to(MODULE).as_posix() for p in MODULE.rglob("*")
                  if p.is_file() and "__pycache__" not in p.parts and p.relative_to(MODULE).as_posix() != GOLDEN)


def plan_files(dest: Path) -> dict[str, list[str]]:
    plan = {"new": [], "changed": [], "same": []}
    for name in module_files():
        target = dest / name
        state = "new" if not target.exists() else \
            "same" if target.read_bytes() == (MODULE / name).read_bytes() else "changed"
        plan[state].append(name)
    return plan


def installed_version(dest: Path) -> str | None:
    try:
        m = re.search(r'^__version__ = "([^"]+)"', (dest / "scripts/knowledge.py").read_text(encoding="utf-8"), re.M)
    except OSError:
        return None
    return m.group(1) if m else "unknown"


def existing_binding(root: Path) -> str | None:
    """Where the target's binding is, or None."""
    try:
        if isinstance(json.loads((root / "project.json").read_text(encoding="utf-8")).get("knowledge"), dict):
            return "project.json › knowledge"
    except (OSError, ValueError, AttributeError):
        pass
    return "knowledge.json" if (root / "knowledge.json").is_file() else None


def new_binding(root: Path) -> tuple[dict, list[str]]:
    """(the block: default registers that exist in the target, per layer; the defaults that were not found)."""
    block, missing = {}, []
    for layer, paths in K.DEFAULT_KNOWLEDGE.items():
        block[layer] = [p for p in paths if (root / p).exists()]
        missing += [f"{p} ({layer})" for p in paths if not (root / p).exists()]
    block.update(LIMITS)
    return block, missing


def write_binding(root: Path, block: dict) -> str:
    pj = root / "project.json"
    if pj.is_file():
        text = pj.read_text(encoding="utf-8")
        data = json.loads(text)
        data["knowledge"] = block
        m = re.search(r"^( +)\"", text, re.M)
        pj.write_text(json.dumps(data, indent=len(m.group(1)) if m else 2, ensure_ascii=False) + "\n",
                      encoding="utf-8")
        return "project.json › knowledge"
    (root / "knowledge.json").write_text(json.dumps(block, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return "knowledge.json"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--to", required=True, help="root folder of the project to install into")
    ap.add_argument("--skills-dir", default=".claude/skills", help="skills folder inside the target")
    ap.add_argument("--apply", action="store_true", help="write the changes (default: print the plan only)")
    a = ap.parse_args()

    root = Path(a.to).resolve()
    dest = root / a.skills_dir / NAME
    if not root.is_dir():
        print(f"Refused: {root} is not a folder")
        return 2
    if dest == MODULE:
        print(f"Refused: {root} is the project this module runs from")
        return 2

    files = plan_files(dest)
    was, binding = installed_version(dest), existing_binding(root)
    block, missing = new_binding(root)
    golden_new = not (dest / GOLDEN).exists()

    print(f"{'Install' if was is None else 'Upgrade'} {NAME} {K.__version__} → {dest}"
          f"{'' if was is None else f' (installed: {was})'}{'' if a.apply else '  [dry run]'}")
    print(f"  files: {len(files['new'])} new, {len(files['changed'])} changed, {len(files['same'])} unchanged")
    for state in ("new", "changed"):
        for name in files[state]:
            print(f"    {state:<8}{name}")
    print(f"  golden queries: {'created from the empty template' if golden_new else 'kept (the target\'s own)'}")
    if binding:
        print(f"  binding: kept ({binding})")
    else:
        where = "project.json › knowledge" if (root / "project.json").is_file() else "knowledge.json (new file)"
        bound = [p for layer in K.LAYERS for p in block[layer]]
        print(f"  binding: new, in {where}: {len(bound)} register(s) bound"
              f"{': ' + ', '.join(bound) if bound else ''}")
        if (root / "project.json").is_file():
            print("    (project.json is rewritten with its own indent; keys keep their order)")
        for item in missing:
            print(f"    not found, not bound: {item}")
        if missing:
            print('    a register under another name: add {"path": "<path>", "type": "<type>"} to its layer '
                  "(types and shapes: the module's README.md)")
    if not a.apply:
        print("Nothing written. Re-run with --apply.")
        return 0

    for name in files["new"] + files["changed"]:
        (dest / name).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(MODULE / name, dest / name)
    if golden_new:
        (dest / GOLDEN).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(MODULE / GOLDEN_TEMPLATE, dest / GOLDEN)
    if not binding:
        write_binding(root, block)

    run = subprocess.run([sys.executable, "-B", str(dest / "scripts/knowledge.py"), "--root", str(root), "check"],
                         capture_output=True, text=True)
    print("Check in the target:")
    for line in (run.stdout + run.stderr).strip().splitlines():
        print("  " + line)
    print("Next, in the target: read the module's README.md › After installing (the rules to adopt, listing the "
          "skill, the other agents' copies).")
    return 1 if run.returncode else 0


if __name__ == "__main__":
    sys.exit(main())
