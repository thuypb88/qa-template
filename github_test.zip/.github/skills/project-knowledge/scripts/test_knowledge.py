#!/usr/bin/env python3
"""test_knowledge.py: regression tests of knowledge.py on a fixture store (standard library only).

    python3 .claude/skills/project-knowledge/scripts/test_knowledge.py [-v]

The fixture store is built in a temporary folder from the texts below: one file per register shape, invented
neutral content (no client text, no project names). A test that needs a broken register rebuilds the store with
that one file replaced. Nothing in the workspace is read or written.
"""
from __future__ import annotations

import contextlib
import datetime
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.dont_write_bytecode = True  # no __pycache__ in the skill folder (it would be mirrored to the other agents)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import knowledge as K  # noqa: E402
import install as I  # noqa: E402

REAL_BLAME = K.blame_dates  # the fixture stubs K.blame_dates; these tests call the real parser
LESSON_HEAD = "| ID | Where | Lesson | Evidence | Seen | Action |\n|---|---|---|---|---|---|\n"


def lesson(n: int, where: str = "design-x", word: str = "", action: str = "noted", seen: str = "1",
           evidence: str = "review R-1, 2026-01-05", lid: str | None = None) -> str:
    return (f"| {lid or f'L-{n:03d}'} | {where} | **Title {n}.** Lesson text number {n} {word} | {evidence} "
            f"| {seen} | {action} |\n")


LESSONS = "# Lessons\n\n" + LESSON_HEAD + "".join(
    [lesson(n) for n in range(1, 10)]
    + [lesson(10, where="design-x, check-y"),
       lesson(11, word="okapi", action="proposed lesson: awaiting the lead"),
       lesson(12, word="quagga", action="retired 2026-02-01"),
       lesson(13, action="superseded by L-001"),
       lesson(14, where="other-skill", word="zebra", action="proposed → skill other-skill")])

FILES = {
    "project.json": json.dumps({"code": "FIX"}),
    "project/lessons.md": LESSONS,
    "standards/template-lessons.md": (
        "# Template lessons\n\n| ID | Where | Lesson | Evidence |\n|---|---|---|---|\n"
        "| L-T01 | design-x | **Template title.** Template lesson text | ALPHA: review, 2025-12-01 |\n"),
    "project/decisions/ADR-000-template.md": "# ADR-000: Template\n\n- **Status:** proposed\n- **Decision:** none\n",
    "project/decisions/ADR-001-first.md": (
        "# ADR-001: First decision\n\n- **Status:** accepted\n- **Decision:** we keep the gnu rule\n- **Evidence:** x\n"),
    "project/decisions/ADR-002-second.md": (
        "# ADR-002: Second decision\n\n- **Status:** proposed (awaiting the lead)\n- **Decision:** maybe\n"),
    "project/decisions/ADR-003-third.md": (
        "# ADR-003: Third decision\n\n- **Status:** superseded by ADR-001\n- **Decision:** old\n"),
    "project/rules.md": (
        "# Project rules\n\n## PR-1. Dates are ISO\n\nSource: the lead. Dates are written YYYY-MM-DD.\n\n"
        "## PR-2. Draft rule (proposed)\n\nNot in force yet.\n\n## PR-3. Old rule (retired 2026-01-01)\n\nGone.\n"),
    "project/questions.md": (
        "# Questions\n\n| ID | Question / assumption | Evidence | Blocks |\n|---|---|---|---|\n"
        "| Q-001 | Is the limit 5? assumed 5 | spec:10 | TC-001 |\n"
        "| Q-002 | **Answered 2026-01-03:** yes | spec:11 | — |\n"
        "| Q-INIT-003 | **Closed:** dropped | spec:12 | — |\n"
        "| Q-004 | **Withdrawn:** not needed | spec:13 | — |\n"),
    "project/defects.md": (
        "# Defects\n\n| DEF ID | Folder | Title | Status |\n|---|---|---|---|\n"
        "| DEF-001 | M1 | Save fails | Open |\n| DEF-002 | M1 | Typo | Closed 2026-01-02 |\n"
        "| DEF-003 | M1 | Not a bug | Rejected |\n| DEF-004 | M1 | Same as 001 | Duplicate of DEF-001 |\n"),
    "project/system-map.md": (
        "# System map\n\n## Glossary\n\n| Term | Meaning | Source |\n|---|---|---|\n"
        "| GRN | Goods received note | spec:20 |\n| PO | Purchase order *proposed* | spec:21 |\n\n"
        "## Undefined in the sources\n\n| Term | Seen (first cite) |\n|---|---|\n| XYZ | spec:30 |\n\n"
        "## Domain notes (external — verify)\n\n| Term | Note | Verify against |\n|---|---|---|\n"
        "| VAT | a tax | the tax office |\n"),
    "project/change-impact/2026-01-01-first-drop.md": "# Change record: first drop\n\nThe yak section changed.\n",
    "sources/parsed/req/doc_one.md": (
        "# Document one\n\n## Payment terms\n\nThe confidential walrus sentence stays in the file.\n"),
    "sources/parsed/req/INDEX.md": "# Index\n\n## Skipped heading\n",
    "sources/parsed/req/doc_one.figures/fig.md": "# Figure text\n",
    "project/status.md": (
        "# Status\n\n| Folder | Analysis | Cases |\n|---|---|---|\n| M1 | v1 reviewed | — |\n| M2 | — | — |\n"),
    "project/log.md": (
        "# Log\n\n| Date | Where | What | Files |\n|---|---|---|---|\n"
        "| 2026-01-05 | M1, project | analysis v1 written | M1/1-analysis.md |\n"
        "| 2026-01-06 | M2 | scope refreshed | M2/0-scope.md |\n"),
    "project/notes.md": (
        "# Notes\n\n| ID | Date | Source | Note | Tags | Route | Status |\n|---|---|---|---|---|---|---|\n"
        "| N-001 | 2026-01-01 | chat | The ibis remark | env | FU-001 | Routed |\n"
        "| N-002 | 2026-01-02 | call | The heron remark | env | `/learn-retro` | Open |\n"
        "| N-003 | 2026-01-03 | chat | The egret remark | misc | keep | Open |\n"
        "| N-004 | 2026-01-04 | chat | The stork remark | misc | — | Closed |\n"),
}


class Store(unittest.TestCase):
    """Builds the fixture store; `self.build(**{path: text | None})` replaces or removes files."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name)
        self.build()
        self.set_today("2026-01-10")
        self.set_blame(None)

    def set_blame(self, day: str | None, lines: dict[int, str] | None = None):
        """Every register line was committed on `day` (None: not committed); `lines` overrides single lines."""
        class Dates(dict):
            def get(self, key, default=None):
                d = (lines or {}).get(key, day)
                return datetime.date.fromisoformat(d) if d else default
        patcher = mock.patch.object(K, "blame_dates", lambda path: Dates())
        patcher.start()
        self.addCleanup(patcher.stop)

    def set_today(self, day: str):
        patcher = mock.patch.object(K, "TODAY", datetime.date.fromisoformat(day))
        patcher.start()
        self.addCleanup(patcher.stop)

    def build(self, **changes):
        files = dict(FILES)
        files.update(changes)
        for name, text in files.items():
            path = self.root / name
            if text is None:
                path.unlink(missing_ok=True)
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")

    def run_cli(self, *argv) -> tuple[int, str]:
        out = io.StringIO()
        with mock.patch.object(sys, "argv", ["knowledge.py", "--root", str(self.root), *argv]), \
                contextlib.redirect_stdout(out):
            code = K.main()
        return code, out.getvalue()

    def json_cli(self, *argv) -> dict:
        code, out = self.run_cli(*argv, "--json")
        return dict(json.loads(out), _code=code)

    def records(self) -> dict[str, dict]:
        with mock.patch.object(K, "ROOT", self.root):
            recs, problems = K.load()
        self.assertEqual(problems, [])
        return {r["id"]: r for r in recs}

    def check(self) -> dict:
        return self.json_cli("check")


class Parsers(Store):
    def test_lessons(self):
        r = self.records()
        self.assertEqual(r["L-010"]["scope"], ["design-x", "check-y"])
        self.assertEqual((r["L-001"]["layer"], r["L-001"]["kind"], r["L-001"]["title"]),
                         ("experience", "lesson", "Title 1."))
        self.assertEqual(r["L-001"]["source"], "project/lessons.md:5")
        self.assertEqual(r["L-T01"]["kind"], "template-lesson")

    def test_decisions_skip_the_template(self):
        r = self.records()
        self.assertNotIn("ADR-000", r)
        self.assertEqual(r["ADR-001"]["text"], "we keep the gnu rule")
        self.assertEqual(r["ADR-001"]["source"], "project/decisions/ADR-001-first.md:1")

    def test_rules_questions_defects(self):
        r = self.records()
        self.assertEqual((r["PR-1"]["kind"], r["PR-1"]["layer"]), ("rule", "decisions"))
        self.assertIn("YYYY-MM-DD", r["PR-1"]["text"])
        self.assertEqual((r["Q-001"]["evidence"], r["Q-001"]["action"]), ("spec:10", "TC-001"))
        self.assertIn("Q-INIT-003", r)
        self.assertEqual((r["DEF-001"]["scope"], r["DEF-001"]["title"]), (["M1"], "Save fails"))

    def test_map(self):
        r = self.records()
        self.assertEqual((r["GRN"]["layer"], r["GRN"]["evidence"], r["GRN"]["title"]), ("map", "spec:20", "Glossary"))
        self.assertNotIn("spec:20", r["GRN"]["text"])

    def test_basis_changes_and_extracts(self):
        r = self.records()
        self.assertEqual(r["2026-01-01-first-drop"]["kind"], "change")
        doc = r["req/doc_one.md"]
        self.assertEqual((doc["kind"], doc["layer"]), ("source", "basis"))
        self.assertIn("Payment terms", doc["text"])
        self.assertFalse([i for i in r if "INDEX" in i or "fig" in i])

    def test_extract_body_is_never_indexed(self):  # Q-KB-002
        for rec in self.records().values():
            self.assertNotIn("walrus", rec["text"] + rec["title"] + rec.get("_body", ""))
        self.assertEqual(self.json_cli("search", "walrus")["hits"], [])

    def test_state(self):
        r = self.records()
        self.assertEqual(r["board:M1"]["scope"], ["M1"])
        logs = [x for x in r.values() if x["kind"] == "log"]
        self.assertEqual(len(logs), 2)
        self.assertEqual(logs[0]["scope"], ["M1", "project"])

    def test_counts_per_layer(self):
        c = self.check()
        self.assertEqual(c["by_layer"], {"map": 4, "basis": 2, "decisions": 10, "experience": 19, "state": 4,
                                         "intake": 4})


class Status(Store):
    def expect(self, **want):
        r = self.records()
        self.assertEqual({k.replace("_", "-"): r[k.replace("_", "-")]["status"] for k in want},
                         {k.replace("_", "-"): v for k, v in want.items()})

    def test_lessons(self):
        self.expect(L_001="active", L_011="proposed", L_012="retired", L_013="superseded", L_014="active")

    def test_decisions_and_rules(self):
        self.expect(ADR_001="active", ADR_002="proposed", ADR_003="superseded",
                    PR_1="active", PR_2="proposed", PR_3="retired")

    def test_questions_and_defects(self):
        self.expect(Q_001="active", Q_002="retired", Q_INIT_003="retired", Q_004="retired",
                    DEF_001="active", DEF_002="retired", DEF_003="retired", DEF_004="retired")

    def test_map(self):
        self.expect(GRN="active", PO="proposed", XYZ="proposed", VAT="proposed")


class Mandatory(Store):
    def test_every_active_record_naming_the_skill(self):  # a hard filter, never top-k
        m = self.json_cli("mandatory", "design-x")
        self.assertEqual([r["id"] for r in m["lessons"]], [f"L-{n:03d}" for n in range(1, 11)] + ["L-T01"])

    def test_rules_and_decisions_in_force(self):
        m = self.json_cli("mandatory", "design-x")
        self.assertEqual(sorted(r["id"] for r in m["rules_and_decisions"]), ["ADR-001", "PR-1"])

    def test_proposed_listed_separately(self):
        m = self.json_cli("mandatory", "design-x")
        ids = {r["id"] for r in m["proposed"]}
        self.assertEqual({"L-011", "ADR-002", "PR-2", "PO"}, ids)  # XYZ, VAT are proposed by nature
        self.assertEqual(m["proposed_by_nature"], 2)
        self.assertFalse(ids & {r["id"] for r in m["lessons"]})
        self.assertFalse([i for i in ids if i.startswith("N-")])  # intake is not a queue entry

    def test_other_skill_gets_only_its_own(self):
        m = self.json_cli("mandatory", "other-skill")
        self.assertEqual([r["id"] for r in m["lessons"]], ["L-014"])


class Search(Store):
    def ids(self, *argv) -> list[str]:
        return [h["id"] for h in self.json_cli("search", *argv)["hits"]]

    def test_scope_filter_before_ranking(self):
        self.assertEqual(self.ids("zebra"), ["L-014"])
        self.assertEqual(self.ids("zebra", "--scope", "design-x"), [])

    def test_layer_filter(self):
        self.assertEqual(self.ids("payment terms", "--layer", "basis"), ["req/doc_one.md"])
        self.assertEqual(self.ids("zebra", "--layer", "map"), [])

    def test_inactive_only_on_request(self):
        self.assertEqual(self.ids("quagga"), [])
        self.assertEqual(self.ids("quagga", "--include-inactive"), ["L-012"])

    def test_proposed_hit_is_flagged(self):
        code, out = self.run_cli("search", "okapi")
        self.assertEqual(code, 0)
        self.assertIn("L-011", out)
        self.assertIn("NOT citable", out)

    def test_k_limits_the_hits(self):
        self.assertEqual(len(self.ids("lesson text number", "--k", "3")), 3)

    def test_no_match_says_so(self):
        _, out = self.run_cli("search", "nonexistentword")
        self.assertIn("No record matches", out)


class Check(Store):
    def test_clean_store(self):
        c = self.check()
        self.assertEqual((c["errors"], c["warnings"], c["_code"]), ([], [], 0))

    def broken(self, path: str, text: str, needle: str, level: str = "errors"):
        self.build(**{path: text})
        c = self.check()
        hits = [m for m in c[level] if needle in m]
        self.assertEqual(len(hits), 1, c)
        self.assertEqual(c["_code"], 1 if level == "errors" else 0)

    def test_duplicate_id(self):
        self.broken("project/lessons.md", LESSONS + lesson(1), "duplicate ID L-001")

    def test_id_outside_its_scheme(self):
        self.broken("project/lessons.md", LESSONS + lesson(15, lid="L-15"), "ID 'L-15' does not match")

    def test_lesson_without_evidence(self):
        self.broken("project/lessons.md", LESSONS + lesson(15, evidence=""), "L-015 has no Evidence")

    def test_seen_not_a_count(self):
        self.broken("project/lessons.md", LESSONS + lesson(15, seen="often"), "Seen 'often' is not a count")

    def test_action_outside_the_vocabulary(self):
        self.broken("project/lessons.md", LESSONS + lesson(15, action="whatever"), "outside the vocabulary",
                    "warnings")

    def test_adr_without_status(self):
        self.broken("project/decisions/ADR-004-x.md", "# ADR-004: No status\n\n- **Decision:** x\n",
                    "no '**Status:**' line")

    def test_adr_without_heading(self):
        self.broken("project/decisions/ADR-004-x.md", "- **Status:** accepted\n- **Decision:** x\n",
                    "no '# ADR-NNN: <title>' heading")

    def test_question_without_evidence(self):
        self.broken("project/questions.md", FILES["project/questions.md"] + "| Q-005 | Why? |  | — |\n",
                    "Q-005 has no Evidence")

    def test_glossary_term_without_source(self):
        self.broken("project/system-map.md",
                    FILES["project/system-map.md"].replace("| GRN | Goods received note | spec:20 |",
                                                           "| GRN | Goods received note |  |"),
                    "glossary term 'GRN' has no Source")

    def test_supersede_target_missing(self):
        self.broken("project/lessons.md", LESSONS + lesson(15, action="superseded by L-999"),
                    "superseded by L-999, which does not exist")

    def test_wikilink_target_missing(self):
        self.broken("project/lessons.md", LESSONS + lesson(15, word="see [[L-999]] and [[L-001]]"),
                    "links [[L-999]]", "warnings")

    def test_missing_register_is_reported(self):
        self.build(**{"project/defects.md": None})
        c = self.check()
        self.assertEqual(c["_code"], 1)
        self.assertTrue([m for m in c["errors"] if "missing project/defects.md" in m])


NOTES = FILES["project/notes.md"]


class Inbox(Store):
    def test_one_record_per_note(self):
        r = self.records()
        self.assertEqual({i: r[i]["status"] for i in r if i.startswith("N-")},
                         {"N-001": "retired", "N-002": "proposed", "N-003": "proposed", "N-004": "retired"})
        self.assertEqual((r["N-002"]["layer"], r["N-002"]["source"]), ("intake", "project/notes.md:6"))

    def test_open_note_is_found_and_flagged(self):
        code, out = self.run_cli("search", "heron", "--layer", "intake")
        self.assertIn("N-002", out)
        self.assertIn("NOT citable", out)

    def test_routed_note_only_with_inactive(self):
        self.assertEqual(self.json_cli("search", "ibis")["hits"], [])
        self.assertEqual([h["id"] for h in self.json_cli("search", "ibis", "--include-inactive")["hits"]], ["N-001"])

    def test_no_drain_warning_before_the_limit(self):
        self.set_today("2026-01-15")  # N-002 is 13 days old
        c = self.check()
        self.assertEqual((c["warnings"], c["notes_due"], c["notes_open"]), ([], [], ["N-002", "N-003"]))

    def test_drain_warning_at_the_limit_keep_exempt(self):
        self.set_today("2026-03-01")  # N-003 (Route keep) is older than the limit too
        c = self.check()
        self.assertEqual(c["notes_due"], ["N-002"])
        self.assertEqual(len([w for w in c["warnings"] if "drain limit 14" in w]), 1)
        self.assertEqual(c["_code"], 0)

    def test_limit_from_project_json(self):
        self.build(**{"project.json": json.dumps({"knowledge": {"drain_days": 5}})})
        self.assertEqual(self.check()["notes_due"], ["N-002"])  # 8 days old on the fixture day

    def test_unknown_status_and_bad_date(self):
        self.build(**{"project/notes.md": NOTES + "| N-005 | 2026-01-05 | chat | x | t | — | Done |\n"
                                                  "| N-006 | soon | chat | y | t | — | Open |\n"})
        w = self.check()["warnings"]
        self.assertEqual(len([m for m in w if "N-005 Status 'done'" in m]), 1)
        self.assertEqual(len([m for m in w if "N-006 has no valid Date" in m]), 1)

    def test_duplicate_note_id(self):
        self.build(**{"project/notes.md": NOTES + "| N-001 | 2026-01-05 | chat | again | t | — | Closed |\n"})
        self.assertTrue([m for m in self.check()["errors"] if "duplicate ID N-001" in m])

    def test_long_inbox_is_not_cut(self):
        rows = "".join(f"| N-{n:03d} | 2026-01-09 | chat | filler {'word ' * 60} | t | keep | Open |\n"
                       for n in range(5, 60))
        self.build(**{"project/notes.md": NOTES + rows + "| N-060 | 2026-01-09 | chat | The pelican remark | t | keep | Open |\n"})
        self.assertEqual([h["id"] for h in self.json_cli("search", "pelican")["hits"]], ["N-060"])


class Queue(Store):
    def test_undated_records_raise_nothing(self):
        c = self.check()
        self.assertEqual(sorted(q["id"] for q in c["queue"]), ["ADR-002", "L-011", "PO", "PR-2"])
        self.assertEqual({q["age_days"] for q in c["queue"]}, {None})
        self.assertEqual((c["warnings"], c["proposed_by_nature"]), ([], 2))

    def test_no_warning_before_the_limit(self):
        self.set_blame("2025-12-28")  # 13 days before the fixture day
        c = self.check()
        self.assertEqual({q["age_days"] for q in c["queue"]}, {13})
        self.assertEqual(c["warnings"], [])

    def test_warning_at_the_limit(self):
        self.set_blame("2025-12-27")
        c = self.check()
        w = [m for m in c["warnings"] if "is proposed for 14 days (limit 14)" in m]
        self.assertEqual(len(w), 4)
        self.assertEqual(c["_code"], 0)
        self.assertFalse([m for m in w if "XYZ" in m or "VAT" in m])

    def test_limit_from_project_json(self):
        self.set_blame("2026-01-05")
        self.build(**{"project.json": json.dumps({"knowledge": {"proposed_days": 5}})})
        self.assertEqual(len([m for m in self.check()["warnings"] if "(limit 5)" in m]), 4)

    def test_by_nature_rows_join_the_queue_on_request(self):
        self.build(**{"project.json": json.dumps({"knowledge": {"queue_by_nature": True}})})
        c = self.check()
        self.assertEqual((len(c["queue"]), c["proposed_by_nature"]), (6, 0))

    def test_decision_is_dated_by_its_status_line(self):
        self.set_blame("2025-01-01", {3: "2026-01-08"})  # ADR-002: `**Status:** proposed` is line 3
        ages = {q["id"]: q["age_days"] for q in self.check()["queue"]}
        self.assertEqual(ages["ADR-002"], 2)

    def test_mandatory_prints_the_age(self):
        self.set_blame("2025-12-31")
        _, out = self.run_cli("mandatory", "design-x")
        self.assertIn("proposed 10 day(s), since 2025-12-31", out)
        self.assertIn("Proposed by nature", out)

    def test_blame_output_is_parsed(self):
        porcelain = ("a" * 40 + " 1 1 2\nauthor A\nauthor-time 1767225600\n\tline one\n"
                     + "a" * 40 + " 2 2\nauthor A\nauthor-time 1767225600\n\tline two\n"
                     + "0" * 40 + " 3 3 1\nauthor Not Committed Yet\nauthor-time 1767312000\n\tline three\n")
        done = mock.Mock(returncode=0, stdout=porcelain)
        with mock.patch.object(K.subprocess, "run", return_value=done):
            dates = REAL_BLAME(self.root / "project/rules.md")
        self.assertEqual(sorted(dates), [1, 2])
        self.assertEqual(dates[1], datetime.date.fromtimestamp(1767225600))

    def test_no_git_means_no_dates(self):
        with mock.patch.object(K.subprocess, "run", side_effect=OSError):
            self.assertEqual(REAL_BLAME(self.root / "project/rules.md"), {})
        with mock.patch.object(K.subprocess, "run", return_value=mock.Mock(returncode=128, stdout="")):
            self.assertEqual(REAL_BLAME(self.root / "project/rules.md"), {})


GOLDEN = ("# Golden\n\n| # | Query | Scope | Expected | Top-k | Kind |\n|---|---|---|---|---|---|\n"
          "| G-01 | the zebra lesson | — | L-014 | 5 | own words |\n"
          "| G-02 | the zebra lesson | design-x | L-014 | 5 | own words |\n"
          "| G-03 | lesson text number | design-x | L-010 | 2 | synonym |\n"
          "| G-04 | the quagga lesson | — | L-012 | 5 | synonym |\n"
          "| G-05 | anything | — | L-999 | 5 | vi |\n")


class Eval(Store):
    def run_eval(self) -> dict:
        self.build(**{"golden.md": GOLDEN})
        return self.json_cli("eval", "--file", str(self.root / "golden.md"))

    def test_hit_and_miss_per_row(self):
        e = self.run_eval()
        self.assertEqual({x["row"]: x["hit"] for x in e["results"]},
                         {"G-01": True, "G-02": False, "G-03": False, "G-04": False, "G-05": False})
        self.assertEqual((e["rows"], e["hits"], e["_code"]), (5, 1, 0))  # a miss is a result, not a failure

    def test_scope_and_top_k_apply(self):
        r = {x["row"]: x for x in self.run_eval()["results"]}
        self.assertIsNone(r["G-02"]["rank"])      # out of scope
        self.assertGreater(r["G-03"]["rank"], 2)  # ranked, but outside its top-k

    def test_notes_explain_an_impossible_row(self):
        r = {x["row"]: x for x in self.run_eval()["results"]}
        self.assertEqual(r["G-04"]["note"], "expected record is retired")
        self.assertEqual(r["G-05"]["note"], "expected ID is not in the registers")

    def test_by_kind(self):
        self.assertEqual(self.run_eval()["by_kind"], {"own words": "1 of 2", "synonym": "0 of 2", "vi": "0 of 1"})

    def test_missing_or_empty_golden_set(self):
        self.assertEqual(self.run_cli("eval", "--file", str(self.root / "none.md"))[0], 1)
        self.build(**{"empty.md": "# nothing\n"})
        self.assertEqual(self.run_cli("eval", "--file", str(self.root / "empty.md"))[0], 1)

    def test_golden_sets_are_well_formed(self):  # this project's set (may be empty) and the empty template
        for path in (K.GOLDEN, I.MODULE / I.GOLDEN_TEMPLATE):
            tables = [(h, body) for _, h, body in K.all_tables(path.read_text(encoding="utf-8").splitlines())
                      if "Query" in h and "Expected" in h]
            rows = [c for _, body in tables for _, c in body]
            self.assertEqual(len({c[0] for c in rows}), len(rows), path)       # row numbers are unique
            self.assertFalse([c for c in rows if len(c) < 6 or not c[1] or not c[3]], path)
        text = (I.MODULE / I.GOLDEN_TEMPLATE).read_text(encoding="utf-8")
        self.assertIn("| # | Query | Scope | Expected | Top-k | Kind |", text)


class Binding(Store):
    def test_defaults_without_a_knowledge_block(self):
        self.assertIn("L-001", self.records())

    def test_block_is_read(self):
        moved = dict.fromkeys(["project/lessons.md"])
        self.build(**moved, **{
            "kb/lessons.md": LESSONS,
            "project.json": json.dumps({"knowledge": {"experience": ["kb/lessons.md"]}})})
        r = self.records()
        self.assertEqual(r["L-001"]["source"], "kb/lessons.md:5")
        self.assertNotIn("L-T01", r)  # the block replaces the layer's defaults
        self.assertIn("PR-1", r)      # an unnamed layer keeps its defaults

    def test_unknown_register_name_is_an_error(self):
        self.build(**{"kb/odd.md": "# x\n", "project.json": json.dumps({"knowledge": {"map": ["kb/odd.md"]}})})
        c = self.check()
        self.assertTrue([m for m in c["errors"] if "no parser for kb/odd.md" in m])

    def test_typed_entry_for_a_register_with_another_name(self):
        self.build(**{"docs/retro.md": LESSONS, "docs/adr/ADR-001-x.md": FILES["project/decisions/ADR-001-first.md"],
                      "project.json": json.dumps({"knowledge": {
                          "experience": [{"path": "docs/retro.md", "type": "lessons"}],
                          "decisions": [{"path": "docs/adr", "type": "decisions"}],
                          "map": [], "basis": [], "state": [], "intake": []}})})
        r = self.records()
        self.assertEqual(r["L-001"]["source"], "docs/retro.md:5")
        self.assertEqual(r["ADR-001"]["source"], "docs/adr/ADR-001-x.md:1")
        self.assertEqual({x["layer"] for x in r.values()}, {"experience", "decisions"})

    def test_unknown_type_and_wrong_kind_are_errors(self):
        self.build(**{"project.json": json.dumps({"knowledge": {
            "experience": [{"path": "project/lessons.md", "type": "lesons"}],
            "decisions": [{"path": "project/rules.md", "type": "decisions"}]}})})
        e = self.check()["errors"]
        self.assertTrue([m for m in e if "unknown type 'lesons'" in m])
        self.assertTrue([m for m in e if "project/rules.md (decisions) is a file" in m])

    def test_knowledge_json_when_there_is_no_project_json(self):
        self.build(**{"project.json": None,
                      "knowledge.json": json.dumps({"experience": ["project/lessons.md"], "map": [], "basis": [],
                                                    "decisions": [], "state": [], "intake": [], "drain_days": 3})})
        c = self.check()
        self.assertEqual(c["by_layer"], {"experience": 14})
        with mock.patch.object(K, "ROOT", self.root):
            self.assertEqual(K.limit("drain_days"), 3)

    def test_empty_register_is_named(self):
        self.build(**{"project/defects.md": "# Defects\n\nNone yet.\n"})
        c = self.check()
        self.assertEqual((c["empty_registers"], c["errors"]), (["project/defects.md"], []))

    def test_root_from_the_environment(self):
        with mock.patch.dict(os.environ, {"KNOWLEDGE_ROOT": str(self.root)}):
            self.assertEqual(K.find_root(), self.root.resolve())

    def test_golden_path_from_the_binding(self):
        self.build(**{"qa/golden.md": GOLDEN, "project.json": json.dumps({"knowledge": {"golden": "qa/golden.md"}})})
        self.assertEqual(self.json_cli("eval")["rows"], 5)


class Install(Store):
    """Installs the module into the fixture store (a project that has registers and no module yet)."""

    def install(self, *argv) -> tuple[int, str]:
        out = io.StringIO()
        with mock.patch.object(sys, "argv", ["install.py", "--to", str(self.root), *argv]), \
                contextlib.redirect_stdout(out):
            code = I.main()
        return code, out.getvalue()

    def installed(self, *parts) -> Path:
        return self.root.joinpath(".claude/skills", I.NAME, *parts)

    def run_installed(self, *argv) -> subprocess.CompletedProcess:
        env = {k: v for k, v in os.environ.items() if k != "KNOWLEDGE_ROOT"}
        return subprocess.run([sys.executable, "-B", str(self.installed("scripts/knowledge.py")), *argv],
                              capture_output=True, text=True, env=env, cwd=self._tmp.name)

    def test_dry_run_writes_nothing(self):
        before = sorted(p for p in self.root.rglob("*"))
        code, out = self.install()
        self.assertEqual(code, 0)
        self.assertIn("Nothing written", out)
        self.assertEqual(sorted(p for p in self.root.rglob("*")), before)

    def test_apply_copies_binds_and_checks(self):
        code, out = self.install("--apply")
        self.assertEqual(code, 0, out)
        for name in ("SKILL.md", "README.md", "scripts/knowledge.py", "scripts/install.py",
                     "scripts/test_knowledge.py", "references/output-rules.md", "assets/recall-answer.md"):
            self.assertTrue(self.installed(name).is_file(), name)
        block = json.loads((self.root / "project.json").read_text(encoding="utf-8"))
        self.assertEqual(block["code"], "FIX")  # the rest of project.json is kept
        self.assertEqual(block["knowledge"]["experience"],
                         ["project/lessons.md", "standards/template-lessons.md", "project/defects.md"])
        self.assertEqual(block["knowledge"]["drain_days"], 14)
        self.assertIn("0 Error", out)

    def test_installed_copy_finds_its_own_root(self):
        self.install("--apply")
        done = self.run_installed("check", "--json")
        self.assertEqual(done.returncode, 0, done.stdout + done.stderr)
        data = json.loads(done.stdout)
        self.assertEqual(Path(data["root"]), self.root.resolve())
        self.assertEqual(data["by_layer"]["experience"], 19)

    def test_only_existing_registers_are_bound(self):
        self.build(**{"project/defects.md": None, "project/notes.md": None, "sources/parsed/req/doc_one.md": None,
                      "sources/parsed/req/INDEX.md": None, "sources/parsed/req/doc_one.figures/fig.md": None})
        (self.root / "sources/parsed/req/doc_one.figures").rmdir()
        (self.root / "sources/parsed/req").rmdir()
        (self.root / "sources/parsed").rmdir()
        code, out = self.install("--apply")
        block = json.loads((self.root / "project.json").read_text(encoding="utf-8"))["knowledge"]
        self.assertEqual((block["intake"], block["basis"]), ([], ["project/change-impact/"]))
        self.assertNotIn("project/defects.md", block["experience"])
        self.assertIn("not found, not bound: project/notes.md (intake)", out)
        self.assertEqual(code, 0, out)

    def test_project_without_project_json_gets_knowledge_json(self):
        self.build(**{"project.json": None})
        code, out = self.install("--apply")
        self.assertEqual(code, 0, out)
        self.assertTrue((self.root / "knowledge.json").is_file())
        self.assertEqual(self.run_installed("check").returncode, 0)

    def test_golden_set_starts_empty_and_is_never_overwritten(self):
        self.install("--apply")
        golden = self.installed("references/golden-queries.md")
        self.assertEqual(golden.read_text(encoding="utf-8"), (I.MODULE / I.GOLDEN_TEMPLATE).read_text(encoding="utf-8"))
        self.assertEqual(self.run_installed("eval").returncode, 1)  # no query yet: said, not a crash
        golden.write_text(GOLDEN, encoding="utf-8")
        self.install("--apply")
        self.assertEqual(golden.read_text(encoding="utf-8"), GOLDEN)

    def test_upgrade_replaces_changed_files_and_keeps_the_binding(self):
        self.install("--apply")
        binding = json.loads((self.root / "project.json").read_text(encoding="utf-8"))
        binding["knowledge"]["drain_days"] = 30
        (self.root / "project.json").write_text(json.dumps(binding), encoding="utf-8")
        self.installed("SKILL.md").write_text("old\n", encoding="utf-8")
        code, out = self.install("--apply")
        self.assertIn("Upgrade", out)
        self.assertIn("1 changed", out)
        self.assertIn("binding: kept", out)
        self.assertNotEqual(self.installed("SKILL.md").read_text(encoding="utf-8"), "old\n")
        self.assertEqual(json.loads((self.root / "project.json").read_text(encoding="utf-8"))["knowledge"]["drain_days"], 30)

    def test_refuses_a_bad_target(self):
        with mock.patch.object(sys, "argv", ["install.py", "--to", str(self.root / "nowhere")]), \
                contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(I.main(), 2)
        home = I.MODULE.parents[2]  # the project this module runs from
        with mock.patch.object(sys, "argv", ["install.py", "--to", str(home)]), \
                contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(I.main(), 2)


class Portable(unittest.TestCase):
    """The shipped files name no single project (the project's own golden queries excepted)."""

    def test_no_project_specific_reference(self):
        banned = ("ADR-006", "PR-9", "PR-10", "PR-7", "plans/architecture", "project-brain", "TFM", "Odoo")
        for name in I.module_files():
            if name == "scripts/test_knowledge.py":
                continue
            text = (I.MODULE / name).read_text(encoding="utf-8")
            for word in banned:
                self.assertFalse(word in text, f"{name} names {word}")


class Version(Store):
    def version(self) -> str:
        return self.check()["data_version"]

    def test_changes_with_a_register_and_only_then(self):
        v = self.version()
        self.build(**{"unrelated/readme.md": "# not a register\n"})
        self.assertEqual(self.version(), v)
        self.build(**{"project/lessons.md": LESSONS + lesson(15)})
        self.assertNotEqual(self.version(), v)


if __name__ == "__main__":
    unittest.main()
