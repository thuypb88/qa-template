---
applyTo: "automation/**"
---
# Automated tests

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-16 10:50:00 (UTC+7)

The skills are `.github/skills/auto-decide/` and `.github/skills/auto-write/`; conventions in `automation/README.md`.

- Every test name / title carries its TC ID (`TC-E4-012 …`, `test_TC_E7_003_…`, param id `TC_E7_003`) so
  `scripts/run_tests.py` binds results; data-driven rows keep one TC ID each (`automation/tc_binding.py`).
- The assertion reads the pack surface (screen, HTTP response, target data), never a log; hooks only set up state.
- URLs, DSNs and tokens come from the environment; never commit them. No fixed sleeps.
- Never weaken an assertion to make a test pass; a mismatch is a product, test or TC defect to triage.
