#!/usr/bin/env python3
"""QA workspace orchestrator: monitor the whole workspace from one place, and say what to run next.

    O=.claude/skills/project-orchestrator/scripts/qa_orchestrator.py
    python3 $O                       # check: health per area, action queue, changes since the last check
    python3 $O next                  # only the one command to run next
    python3 $O watch                 # re-check every 300 s; print what changed (Ctrl-C to stop)
    python3 $O watch --interval 60 --until-change     # exit 1 at the first change (for a hook, cron or /loop)
    python3 $O history [-n 20]       # the recorded events
    python3 $O [...] --json

Probes (each read-only, each with a timeout; one failing probe never stops the others):
  config     scripts/qa_config.py --validate                         project.json valid
  guard      scripts/workspace/guard.py check                        rules on the working tree (stamps, Excel, sync…)
  git        HEAD, uncommitted files, hooks path                     version history and backup on
  sources    project-source-update/source_pipeline.py --json         drops, changes vs baseline, record / accept gate,
                                                                     estimate + test plan checks, source update board
  pipeline   project-assistant/assistant.py status --json            phase, maturity, folders, deliverables, registers
  glossary   scripts/glossary.py --check                             glossary rows still cite their terms
  tooling    node, pdftotext, soffice, openpyxl                      runners and extractors the packs need
The action queue is project-assistant `todo` (same priorities as flow-next / project-source-update), first 10.

Level per area: FAIL (broken: invalid config, guard problems, a probe that cannot run) · WARN (work waiting or a
risk, incl. an estimate / test plan check failing because the plans are behind) · OK.
Each check writes a snapshot to runs/orchestrator/state.json and appends what changed to
runs/orchestrator/events.jsonl (runs/ is git-ignored: generated, per machine). Nothing else is written.
Exit: 0 all OK · 1 a WARN, or a change in watch --until-change · 2 a FAIL. Standard library only.
"""
import argparse
import datetime as dt
import json
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
PY = [sys.executable, "-B"]
STATE = ROOT / "runs/orchestrator"
SKILLS = ROOT / ".claude/skills"
RANK = {"OK": 0, "WARN": 1, "FAIL": 2}


def run(args: list[str], timeout: int = 180) -> tuple[int, str]:
    try:
        r = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return 124, f"timeout after {timeout} s"
    except OSError as e:
        return 127, str(e)


def as_json(out: str):
    try:
        return json.loads(out[out.index("{"):]) if "{" in out else None
    except json.JSONDecodeError:
        return None


def cnt(x) -> str:
    return str(len(set(x))) if isinstance(x, (list, tuple, set)) else ("—" if x is None else str(x))


def last_line(out: str) -> str:
    lines = [ln.strip() for ln in out.strip().splitlines() if ln.strip()]
    return lines[-1] if lines else "—"


# ---------------------------------------------------------------- probes: each returns {area, level, summary, …}

def p_config() -> dict:
    rc, out = run(PY + ["scripts/qa_config.py", "--validate"])
    return {"area": "config", "level": "OK" if rc == 0 else "FAIL", "summary": last_line(out),
            "run": None if rc == 0 else "fix project.json (plan-setup / plan-scope), then qa_config.py --validate"}


def p_guard() -> dict:
    rc, out = run(PY + ["scripts/workspace/guard.py", "check"])
    probs = [ln.strip() for ln in out.splitlines() if ln.strip().startswith("✗")]
    return {"area": "guard", "level": "OK" if rc == 0 and not probs else "FAIL",
            "summary": last_line(out) if not probs else f"{len(probs)} problem(s): " + " · ".join(p[2:80] for p in probs[:3]),
            "details": probs, "run": None if not probs else "fix each ✗ line, then guard.py check"}


def p_git() -> dict:
    _, head = run(["git", "log", "-1", "--format=%h %ci %s"])
    _, st = run(["git", "status", "--porcelain"])
    _, hooks = run(["git", "config", "core.hooksPath"])
    dirty = [ln for ln in st.splitlines() if ln.strip()]
    level = "WARN" if dirty or "git-hooks" not in hooks else "OK"
    s = f"HEAD {head.strip()[:90]}" + (f" · {len(dirty)} uncommitted" if dirty else " · clean") \
        + ("" if "git-hooks" in hooks else " · hooks OFF")
    return {"area": "git", "level": level, "summary": s, "head": head.split(" ")[0] if head else "",
            "dirty": [d[3:] for d in dirty][:50],
            "run": "commit the change set (CLAUDE.md › Version history)" if dirty else
            ("git config core.hooksPath scripts/workspace/git-hooks" if "git-hooks" not in hooks else None)}


def p_sources() -> dict:
    sp = SKILLS / "project-source-update/scripts/source_pipeline.py"
    if not sp.is_file():
        rc, out = run(PY + ["scripts/trace_changes.py", "--json"])
        d = as_json(out) or {}
        n = len(d.get("changes", []))
        return {"area": "sources", "level": "WARN" if n else "OK", "summary": f"{n} change(s) vs the baseline",
                "run": "/plan-changes" if n else None}
    rc, out = run(PY + [str(sp), "--json"], timeout=300)
    d = as_json(out)
    if d is None:
        return {"area": "sources", "level": "FAIL", "summary": "source_pipeline.py failed: " + last_line(out),
                "run": "run source_pipeline.py by hand and read the error"}
    steps = {s["step"]: s["state"] for s in d.get("steps", [])}
    checks = d.get("checks", [])
    bad = [c for c in checks if c["check"] != "pipeline_status" and (c["rc"] != 0 or re.search(r"[1-9]\d* (problem|Error)", c["result"]))]
    held = d.get("board", {}).get("held", [])
    # a failing estimate / test plan check is waiting plan work (the board's 2c / 2d), not a broken workspace
    level = "WARN" if bad or d.get("gate") or d.get("handoffs") else "OK"
    s = f"{steps.get('0 detect', '—')} · {steps.get('0 trace', '—').splitlines()[0]}"
    if d.get("gate"):
        s += f" · GATE: {d['gate'][:120]}"
    s += f" · board: {len(d.get('handoffs', []))} ready, {len(held)} held"
    if bad:
        s += " · " + " · ".join(f"{c['check']}: {c['result'][:90]}" for c in bad)
    return {"area": "sources", "level": level, "summary": s, "gate": d.get("gate"),
            "ready": [h["run"] for h in d.get("handoffs", [])], "held": held,
            "checks": checks, "run": d["gate"] if d.get("gate") else (d["handoffs"][0]["run"] if d.get("handoffs") else None)}


def p_pipeline() -> dict:
    ap = SKILLS / "project-assistant/scripts/assistant.py"
    rc, out = run(PY + [str(ap), "status", "--json"], timeout=300)
    d = as_json(out)
    if d is None:
        return {"area": "pipeline", "level": "FAIL", "summary": "assistant.py status failed: " + last_line(out)}
    folders = {f["key"]: f.get("next") or "—" for f in d.get("folders", [])}
    dels = [x for x in d.get("deliverables", []) if x.get("status") != "current"]
    q = d.get("questions", {})
    unowned = q.get("by_owner", {}).get("unassigned", 0)
    level = "WARN" if dels or unowned or d.get("defects_open") else "OK"
    s = (f"phase {d.get('phase')} · {d.get('maturity', {}).get('name', '—')} · "
         + ", ".join(f"{k}→{v}" for k, v in folders.items())
         + f" · deliverables to do {len(dels)} · questions open {q.get('open', '—')} (unowned {unowned})"
         + f" · FU {cnt(d.get('followups_open'))} · defects {cnt(d.get('defects_open'))} · risks {cnt(d.get('risks_open'))}")
    return {"area": "pipeline", "level": level, "summary": s, "phase": d.get("phase"),
            "maturity": d.get("maturity", {}).get("name"), "folders": folders,
            "deliverables": [f"{Path(x['file']).name}: {x['status']}" for x in dels],
            "questions_open": q.get("open"), "questions_unowned": unowned, "roadmap": d.get("roadmap")}


def p_glossary() -> dict:
    if not (ROOT / "scripts/glossary.py").is_file():
        return {"area": "glossary", "level": "OK", "summary": "no glossary script"}
    rc, out = run(PY + ["scripts/glossary.py", "--check"])
    m = re.search(r"(\d+) problem", out)
    n = int(m.group(1)) if m else (0 if rc == 0 else 1)
    return {"area": "glossary", "level": "OK" if n == 0 else "WARN", "summary": last_line(out),
            "run": "/learn-glossary check" if n else None}


def p_tooling() -> dict:
    need = {"pdftotext": "extract PDF sources", "soffice": "render / convert .docx"}
    try:
        packs = {m.get("pack") for m in json.loads((ROOT / "project.json").read_text(encoding="utf-8")).get("modules", [])}
    except (OSError, json.JSONDecodeError):
        packs = set()
    if "ui" in packs:
        need["node"] = "Playwright runner (pack ui)"
    missing = [f"{t} ({why})" for t, why in need.items() if not shutil.which(t)]
    rc, _ = run(PY + ["-c", "import openpyxl"])
    if rc != 0:
        missing.append("openpyxl (Excel export)")
    return {"area": "tooling", "level": "WARN" if missing else "OK",
            "summary": "missing: " + "; ".join(missing) if missing else "node, pdftotext, soffice, openpyxl present",
            "run": "python3 scripts/workspace/setup_workspace.py --check (tell the user; no ad hoc installs)" if missing else None}


PROBES = [p_config, p_guard, p_git, p_sources, p_pipeline, p_glossary, p_tooling]


def queue(limit: int = 10) -> list[dict]:
    ap = SKILLS / "project-assistant/scripts/assistant.py"
    rc, out = run(PY + [str(ap), "todo", "--json"], timeout=300)
    d = as_json(out) or {}
    return [{"prio": i.get("prio"), "what": i.get("what"), "run": i.get("run"), "evidence": i.get("evidence")}
            for i in d.get("items", [])[:limit]]


# ---------------------------------------------------------------- snapshot and changes

def snapshot(probes: list[dict]) -> dict:
    by = {p["area"]: p for p in probes}
    return {
        "at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "levels": {p["area"]: p["level"] for p in probes},
        "head": by.get("git", {}).get("head"),
        "dirty": len(by.get("git", {}).get("dirty", [])),
        "gate": by.get("sources", {}).get("gate"),
        "ready": by.get("sources", {}).get("ready", []),
        "held": [h["item"] for h in by.get("sources", {}).get("held", [])],
        "phase": by.get("pipeline", {}).get("phase"),
        "maturity": by.get("pipeline", {}).get("maturity"),
        "folders": by.get("pipeline", {}).get("folders", {}),
        "deliverables": by.get("pipeline", {}).get("deliverables", []),
        "questions_open": by.get("pipeline", {}).get("questions_open"),
        "questions_unowned": by.get("pipeline", {}).get("questions_unowned"),
        "guard": by.get("guard", {}).get("details", []),
    }


def diff(old: dict | None, new: dict) -> list[str]:
    if not old:
        return ["first check: baseline snapshot recorded"]
    out = []
    for k, v in new.items():
        if k == "at" or old.get(k) == v:
            continue
        if isinstance(v, dict):
            for kk in sorted(set(v) | set(old.get(k) or {})):
                a, b = (old.get(k) or {}).get(kk), v.get(kk)
                if a != b:
                    out.append(f"{k}.{kk}: {a} → {b}")
        elif isinstance(v, list):
            added = [x for x in v if x not in (old.get(k) or [])]
            gone = [x for x in (old.get(k) or []) if x not in v]
            out += [f"{k} +{x}" for x in added] + [f"{k} −{x}" for x in gone]
        else:
            out.append(f"{k}: {old.get(k)} → {v}")
    return out


def load_state() -> dict | None:
    f = STATE / "state.json"
    try:
        return json.loads(f.read_text(encoding="utf-8")) if f.is_file() else None
    except json.JSONDecodeError:
        return None


def save(snap: dict, changes: list[str]) -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    (STATE / "state.json").write_text(json.dumps(snap, indent=1, ensure_ascii=False), encoding="utf-8")
    if changes:
        with (STATE / "events.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps({"at": snap["at"], "changes": changes}, ensure_ascii=False) + "\n")


# ---------------------------------------------------------------- commands

def check(with_queue: bool = True) -> dict:
    probes = []
    for fn in PROBES:
        try:
            probes.append(fn())
        except Exception as e:  # a broken probe is reported, never fatal
            probes.append({"area": fn.__name__[2:], "level": "FAIL", "summary": f"probe error: {e}"})
    old = load_state()
    snap = snapshot(probes)
    changes = diff(old, snap)
    save(snap, changes if old is None or changes else [])
    overall = max((p["level"] for p in probes), key=RANK.get)
    q = queue() if with_queue else []
    nxt = next((p["run"] for p in probes if p["level"] == "FAIL" and p.get("run")), None) \
        or (q[0]["run"] if q else None) or next((p["run"] for p in probes if p.get("run")), None)
    return {"at": snap["at"], "overall": overall, "probes": probes, "queue": q, "changes": changes,
            "since": old.get("at") if old else None, "next": nxt}


def show(res: dict) -> None:
    icon = {"OK": "✓", "WARN": "!", "FAIL": "✗"}
    print(f"# QA workspace · {res['at']} · overall {res['overall']}\n")
    print("| Area | Level | Summary |\n|---|---|---|")
    for p in res["probes"]:
        print(f"| {p['area']} | {icon[p['level']]} {p['level']} | {p['summary']} |")
    if res["changes"]:
        print(f"\n**Changed since {res['since'] or 'never'}:**")
        for c in res["changes"][:30]:
            print(f"- {c}")
    elif res["since"]:
        print(f"\nNo change since {res['since']}.")
    fails = [p for p in res["probes"] if p["level"] == "FAIL" and p.get("run")]
    if fails:
        print("\n**Fix first:**")
        for p in fails:
            print(f"- {p['area']}: {p['run']}")
    if res["queue"]:
        print("\n**Action queue** (project-assistant todo):")
        for i in res["queue"]:
            print(f"{i['prio']}. {i['what']} — `{i['run']}`")
    print(f"\n**Next:** {res['next'] or 'nothing waiting'}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", nargs="?", default="check", choices=["check", "next", "watch", "history"])
    ap.add_argument("--interval", type=int, default=300, help="watch: seconds between checks (min 30)")
    ap.add_argument("--until-change", action="store_true", help="watch: exit 1 at the first change")
    ap.add_argument("--max-checks", type=int, default=0, help="watch: stop after N checks (0 = no limit)")
    ap.add_argument("-n", type=int, default=20, help="history: number of events")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    if a.cmd == "history":
        f = STATE / "events.jsonl"
        ev = [json.loads(x) for x in f.read_text(encoding="utf-8").splitlines() if x.strip()] if f.is_file() else []
        ev = ev[-a.n:]
        if a.json:
            print(json.dumps(ev, indent=1, ensure_ascii=False))
        else:
            for e in ev or [{"at": "—", "changes": ["no events yet: run a check"]}]:
                print(f"{e['at']}\n" + "\n".join(f"  - {c}" for c in e["changes"]))
        return 0

    if a.cmd == "next":
        res = check()
        print(json.dumps({"next": res["next"], "overall": res["overall"]}, ensure_ascii=False) if a.json
              else (res["next"] or "nothing waiting"))
        return RANK[res["overall"]]

    if a.cmd == "watch":
        n, interval = 0, max(30, a.interval)
        try:
            while True:
                res = check()  # the queue every time, so Next means the same as in check
                n += 1
                real = [c for c in res["changes"] if not c.startswith("first check")]
                if a.json:
                    print(json.dumps({"at": res["at"], "overall": res["overall"], "changes": res["changes"],
                                      "next": res["next"]}, ensure_ascii=False), flush=True)
                elif n == 1:
                    show(res)
                    print(f"\nWatching every {interval} s (Ctrl-C to stop)…", flush=True)
                elif real:
                    print(f"\n## {res['at']} · overall {res['overall']}", flush=True)
                    for c in real:
                        print(f"- {c}", flush=True)
                    print(f"Next: {res['next'] or 'nothing waiting'}", flush=True)
                if a.until_change and real and n > 1:
                    return 1
                if a.max_checks and n >= a.max_checks:
                    return RANK[res["overall"]]
                time.sleep(interval)
        except KeyboardInterrupt:
            return 0

    res = check()
    if a.json:
        print(json.dumps(res, indent=1, ensure_ascii=False))
    else:
        show(res)
    return RANK[res["overall"]]


if __name__ == "__main__":
    sys.exit(main())
