---
name: project-orchestrator
description: Project (orchestrator, monitor, whole workspace): one command that checks every part of the QA workspace and says what to run next - project.json, guard rules, git, sources (drops, changes vs the baseline, accept gate, the source update board), the pipeline (phase, maturity, next step per folder, deliverables, questions, follow-ups, defects, risks), glossary and tooling - with a level per area (OK / WARN / FAIL), the action queue, what changed since the last check, a watch mode and an event history. scripts/qa_orchestrator.py is read-only except its snapshot in runs/orchestrator/. Use for "monitor the workspace", "health check", "is everything OK", "what changed since this morning", "watch the workspace", "what should run next across everything", "giám sát workspace", "kiểm tra tình trạng dự án". Not for: one folder's next step → flow-next; a status dashboard or task list for a person → project-assistant; a source change pipeline → project-source-update; the roadmap → flow-roadmap.
metadata:
  group: project
  order: "-"
---

# Project: orchestrator (monitor the QA workspace)

> **Created:** 2026-10-26 13:35:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the workspace; the probes' scripts (below). **Out:** a chat answer; the snapshot
`runs/orchestrator/state.json` and the event log `runs/orchestrator/events.jsonl` (git-ignored, per machine).
**Rules:** core R1 (every claim from a probe), the router rule of `flow-next` (one **Next**, never do the work here).
**Next:** the one command the result names, on the user's go-ahead.
**Output:** [assets/report.md](assets/report.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

`O=.claude/skills/project-orchestrator/scripts/qa_orchestrator.py`

| Command | Does |
|---|---|
| `python3 $O` | check: a table of areas with level and summary, what changed since the last check, *Fix first* (FAIL areas), the action queue, **Next** |
| `python3 $O next` | only the next command (exit 0 OK · 1 WARN · 2 FAIL) |
| `python3 $O watch [--interval 300] [--until-change] [--max-checks N]` | re-check on a timer, print only what changed; `--until-change` exits 1 at the first change (for a git hook, cron, or a `/loop`) |
| `python3 $O history [-n 20]` | the recorded changes, newest last |
| add `--json` | machine-readable, for another script or agent |

## Probes

| Area | From | FAIL when | WARN when |
|---|---|---|---|
| config | `scripts/qa_config.py --validate` | project.json invalid | — |
| guard | `scripts/workspace/guard.py check` | any ✗ line (stamps, Excel, agent copies, protected paths…) | — |
| git | `git log / status / config` | — | uncommitted files; hooks off |
| sources | `project-source-update/scripts/source_pipeline.py --json` | the script cannot run | drop folder, change vs baseline, record / accept gate, a ready stage on the board, estimate / test plan check failing because the plans are behind |
| pipeline | `project-assistant/scripts/assistant.py status --json` | the script cannot run | a deliverable not current, unowned questions, open defects |
| glossary | `scripts/glossary.py --check` | — | a glossary row no longer cites its term |
| tooling | `which` / import | — | a runner or extractor the packs need is missing |

The action queue is `assistant.py todo` (priorities: source update → pipeline step and deliverables → roadmap,
questions, follow-ups → housekeeping). **Next** = the first FAIL's fix, else the queue's first item.

## Steps

1. Run `python3 $O` (or `watch` when the user wants to follow the workspace). Name the overall level.
2. Report in one screen from [assets/report.md](assets/report.md) ([references/output-rules.md](references/output-rules.md)).

3. A FAIL comes before any pipeline work (a guard or config problem makes every later step unreliable). A WARN that
   is waiting work is handed to its skill through the queue; a missing tool is reported, never installed ad hoc
   (`setup_workspace.py --check`).
4. Stop. Do not run the next skill here.

## Rules

- **Read-only.** The only files written are the snapshot and the event log under `runs/orchestrator/`.
- **Agree with the scripts.** The table is the probes' output; when a hand-written file disagrees (status board,
  roadmap), say so and name the skill that refreshes it.
- **Monitoring by schedule** (the user asks for it): `watch --until-change` in a terminal, or a cron / `/loop` that runs
  `python3 $O next --json` and acts only on a change of `next` or `overall`.

## Done when

- [ ] The script run; overall level, the area table and the changes reported as the script gave them.
- [ ] FAIL areas listed first with their fixes; one **Next** with its evidence; nothing else run.
