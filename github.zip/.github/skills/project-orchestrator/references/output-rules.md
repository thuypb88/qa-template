# project-orchestrator: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Fill [../assets/report.md](../assets/report.md). Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1 · the router rule of `flow-next` (one Next, never do the work here).

| Output | Where | Write mode |
|---|---|---|
| report | chat, one screen | per run |
| snapshot, events | `runs/orchestrator/state.json`, `runs/orchestrator/events.jsonl` (git-ignored) | by `qa_orchestrator.py` only |

## Rules

- **Area rows** copied from the script unchanged; every claim from a probe.
- **FAIL first:** a guard or config FAIL comes before any pipeline work, each with its fix.
- A missing tool is reported (`setup_workspace.py --check`), never installed ad hoc.
- **One Next**, on the user's go-ahead; stop after the report.
