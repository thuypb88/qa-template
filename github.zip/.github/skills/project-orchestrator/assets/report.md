<!-- Template: project-orchestrator report (chat, one screen). Rows from scripts/qa_orchestrator.py, unchanged. Replace
every <placeholder>; delete this comment. Rules: ../references/output-rules.md. -->
**<CODE> · <time> · overall <OK | WARN | FAIL>** · phase <Pn> · <maturity>

| Area | Level | Summary |
|---|---|---|
| <probe area> | <OK \| WARN \| FAIL> | <from the script> |

**Changed since <last check>:** <lines, or "nothing">
**Fix first:** <FAIL areas, each with its fix>
**Next:** `/<skill> <target>` — <why, from the probe or the queue>
