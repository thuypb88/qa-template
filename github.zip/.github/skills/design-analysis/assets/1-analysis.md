<!-- Template: design-analysis. Copy to <folder>/1-analysis.md, replace every <placeholder>, delete these comments.
Section shapes for §3, §5, §6 and "Observable in" come from packs/<pack>/analysis.md. Rules: ../references/output-rules.md. -->
# <module name as in project.json>: analysis

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

<!-- When a mindmap or test cases already exist: say here that they need re-checking. -->

## 0. Citation keys and source precedence

| Key | File |
|---|---|
| <KEY> | [<document title>](<relative path under sources/parsed/>) — <what it is, version> |

**Precedence:** <project.json › sources.precedence, in order>. Cite as `[KEY:line](path#Lnn)`, `(FR-xxx)` or
`Source: <doc> §x p.n`.

## 1. Overview

**Purpose:** <one or two sentences [KEY:line]> · **Actors:** <roles> · **In scope:** <…> · **Out of scope:** <…>
**Assumptions:** <Q-xxx: assumed …> · **Neighbouring modules:** <in: … · out: …>

### System study diagram

```mermaid
flowchart LR
    %% context: actors, this module, neighbours with their hand-offs
```

```mermaid
flowchart LR
    %% process map: flow steps along the business object's life, with its states
```

## 2. Requirement breakdown

### <REQ-ID> <summary> (priority <Pn>, client ref <ref>, UC <UC-id>)

| Rule | Trigger | Outcome | Actor | Preconditions | Constraint | Exception | Source |
|---|---|---|---|---|---|---|---|
| BR-<req>-1 | <one trigger> | <one outcome> | <role> | <…> | <…> | <… or `missing`> | [KEY:line] |

### Acceptance criteria

| AC ID | Criterion | Source | Requirements |
|---|---|---|---|
| <AC-…> | <observable criterion> | [KEY:line] | <REQ-ID> |

## 3. Inventory: <forms / screens | endpoints | target tables and jobs>

<!-- Pack §3 table. These names become mindmap level 1 and the TC title prefixes. -->

### Variants handled

<!-- Only for flows handling a variant set (R10). -->
| Flow step | Variant | Source |
|---|---|---|

## 4. Functional flow

### 4.<n> <flow name>

| Step | Main / alternate / exception | What happens | Observable at the surface | Source |
|---|---|---|---|---|

```mermaid
flowchart TB
    %% swimlane redrawn from <figure n> [KEY:line]: the source's lanes and step IDs only
```

**Diagram vs text:** <same | the difference, named>

## 5. Data & field rules

### 5.<n> <screen / endpoint / table>

<!-- Pack §5 table; state / transition tables. Every field / parameter / column of the sources. -->

## 6. Integrations as the tester sees them

| External system | Direction | What the tester sees | IT stand-in | ST counterpart | Source |
|---|---|---|---|---|---|

## 7. Non-functional

<Languages, compatibility, security techniques, audit, performance, volume — each cited, or a Q-xxx.>

## 8. Testable conditions

| ID | Condition | Requirement | Type | <Level-1 item> | Observable in |
|---|---|---|---|---|---|
| TCOND-001 | <condition> | <REQ / BR / AC> | <type> | <inventory item> | <screen / response / query> |

### Out of black-box scope

| Check | Requirement | Covering layer |
|---|---|---|

## 9. Gaps, conflicts & open questions

| ID | Kind | Topic | Evidence A | Evidence B | Proposed assumption | Owner | Blocks |
|---|---|---|---|---|---|---|---|
| Q-001 | <missing rule \| missing material \| ambiguous \| conflict \| untestable \| stale> | <topic> | [KEY:line] | <… or —> | <value> | <BA \| client \| DEV> | <TCOND / REQ IDs> |

## 10. Traceability

| Requirement / AC | BR rules | TCONDs | Q refs |
|---|---|---|---|

## 11. Level scope & fixtures

| UC | IT scope | Fixtures | Moved to ST | Source |
|---|---|---|---|---|
| <UC> | <In \| Partly \| Out> | <FX-…> | <… or —> | [KEY:line] |

**Fixtures:** <short name — what it holds — source>
**Baseline preconditions:** <"<Project> <env> is running normally" · "… connected to <system> (mock data)">
**Moved to ST:** <item — why — Source>
