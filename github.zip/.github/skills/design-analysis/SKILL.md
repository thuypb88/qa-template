---
name: design-analysis
description: Design step 1 (writer, IT): the analysis of a module. Analyze one module (any pack - ui / api / etl / sql) from its sources (workflow diagrams and mock-ups included), the client documents and the test plan, and write 1-analysis.md - citation keys, requirement breakdown, acceptance criteria, a system study diagram (context + process map), the pack inventory (screens / endpoints / target tables and jobs), flows with a Mermaid diagram per flow redrawn from the source's workflow diagram, data and field rules, integrations, testable conditions (TCONDs) observable at the pack surface, questions, traceability, level scope and fixtures. Use for "analyze E4", "add the flow diagrams from the BRD to the analysis", "diagram to study the system", or to redo an analysis after the sources change. The system (ST) → design-system; reviewing it → check-design.
metadata:
  group: design
  order: "1"
---

# Design: analysis of a module (IT)

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-30 13:54:26 (UTC+7)

**In:** a module id (target `st` → `design-system`). `0-scope.md`, `sources.json`, the sources it lists, the system
analysis if present.
**Out:** `<folder>/1-analysis.md` (overwrite; title exactly `# <name>: analysis`). **Rules:** core R1, R2, R6.3, R9, R10; the pack's `rules.md` and
`analysis.md` (`packs/<pack>/`, the pack named in `project.json`); project rules. **Next:** `check-design`.
**Stop if** `0-scope.md` is missing or older than `project.json` / the sources → `plan-scope` first.
**Output:** [assets/1-analysis.md](assets/1-analysis.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

Read lean: `slice.py toc` → `section`; open a source at the cited line, never a whole big file. Read
`project/lessons.md` and the L-T rows for `design-analysis` in [standards/template-lessons.md](../../../standards/template-lessons.md).
While writing §2, §8 and §9, follow [standards/methods/requirement-quality.md](../../../standards/methods/requirement-quality.md) (atomic
rules, gap kinds, the seven ambiguity checks, conflicts, testability, closable questions).

## Steps

1. **Scope:** `0-scope.md` (incl. MANUAL block) + `sources.json`.
2. **Neighbours:** the system analysis (`slice.py rows test-design/st/1-analysis.md <id> <refs>`) and the analyses of
   `depends_on` modules: hand-offs, `Q-ST-xxx`. Cite, don't repeat.
3. **Test plan, this level:** the scope row per UC / module, mocking / fixture tables, what is moved to ST.
4. **All sources, images included.** Parsed copies under `sources/parsed/`; pack inventories
   (`sources/parsed/api/…-inventory.md`, `sources/parsed/etl/…-inventory.md`). Figures embedded in a `.docx` / `.pdf`
   (workflow diagrams, mock-ups) are pictures: the flow charts are saved in `sources/parsed/<path>/<doc>.figures/` and
   embedded as `![Fig <n> (flow)](…)` links at the end of the parsed line they follow; `INDEX.md` gives each
   figure's kind, parsed line and heading. Open **every** To-Be figure under the module's sections with Read, flow
   charts and screens alike ([analysis-diagrams.md](../../../standards/methods/analysis-diagrams.md) §1; screens:
   `extract_text.py <doc.docx> --figures`); §0 states how many of how many were read. A screenshot that disagrees
   with the text is a `Q-xxx` (conflict), not a silent correction.
5. **Client documents** (R1): acceptance criteria; layouts, wording, sample data.
6. **Write** with a **citation-key table** first (`Key | File`) and a source-precedence note
   (`project.json › sources.precedence`). Every statement cites `[KEY:line](path#Lnn)`, `(FR-xxx)` or
   `Source: <doc> §x p.n`; links relative to the folder.

## Required sections

Eleven sections in a fixed order, with their columns and ID schemes: copy
[assets/1-analysis.md](assets/1-analysis.md) and follow [references/output-rules.md](references/output-rules.md) — read it
before writing.

## Rules

- **No invention.** Unstated → §9. Exact source values; labels in their language.
- **Completeness.** Every requirement and AC in §2 and §10; every field / parameter / column of the sources in §5.
- **Downstream.** If a mindmap or TCs exist, say in the header they need re-checking; don't edit them.
- **IDs on rewrite.** Keep live TCOND / Q IDs; mark removed TCONDs *retired*; never reuse IDs.
- **Security per technique.** One TCOND per technique the module's `security` value calls for (`full` = every pack
  technique that applies, `limited` = its `security_techniques`); a technique that does not apply gets its reason
  and covering layer in **Out of black-box scope**.
- **Status follows §9.** A TCOND resting on a question whose §9 row has no assumption, or whose assumption excludes
  it, is `(Held: Q-xxx)`; one running on the assumption is `(runs on Q-xxx)`.
- Update `project/questions.md` with the new open questions and a line in `project/log.md`. When the analysis changes
  a requirement's readiness, say so and name `plan-scope <id>` (the `0-scope.md` readiness table is its output).

## Pitfalls

L-T01 (claiming a gap unread), L-T02 (neighbour conflicts), L-T03 (any-variant conditions), L-T07 (invented
fixtures), L-T16 (literal test-plan wording) in [standards/template-lessons.md](../../../standards/template-lessons.md), plus:
- **Text only.** Figures, slides and screen mock-ups hold rules the text lacks (`<doc>.figures/INDEX.md`; `extract_text.py --figures` for screens).
- **Diagram as a new basis.** A flow diagram that adds a step, a lane or an outcome no source shows, or that
  follows the figure where it differs from the step table: draw the step table, mark the figure's node
  `(fig.: …, Q-xxx)`. Naming the difference while drawing the figure still contradicts the analysis's own assumption.
- **Screens left unread.** Building §3 / §5 from the screens that happened to be opened: the unread ones hold the
  fields, statuses and conflicts the review finds later. Read them all (step 4).
- **Platform behaviour as a source rule.** A boundary or default taken from how the product usually behaves (a lock
  date's own day, a timeout, a rounding) is an assumption: `Q-xxx: assumed <value>`, never a cited rule.
- **Inventory by internal names** (table / route / component names) instead of what the surface shows.
- **Vague words accepted as rules** ("fast", "appropriate", "as needed"): no criterion → `untestable` question, not a
  TCOND with an invented threshold.
- **Questions nobody can close** ("please clarify the field"): ask the smallest deciding question, name the owner.

## Done when

- [ ] 11 sections; exact title; every requirement / AC in §2 + §10; every source field in §5.
- [ ] Every To-Be figure opened (flows and screens; §0 says n of n); every screen an **Observable in** names is a §3 row.
- [ ] §1 system study diagram (context + process map); §4 a diagram per flow step with a source diagram or step
  table, each citing its figure, with its **Diagram vs text** line; every Mermaid block renders (Markdown preview).
- [ ] Each BR has one trigger and one outcome; each validated field has mandatory + invalid + boundary TCONDs; each
  state machine has allowed + refused transitions.
- [ ] R6.3, R10 TCONDs complete; one TCOND per security technique (or its reason); **Observable in** everywhere;
  internal-only checks in the sub-table; Held / runs-on marks match §9.
- [ ] §11 baseline preconditions + fixtures + Moved to ST.
- [ ] Every unknown is a `Q-xxx` with kind, owner and Blocks; report counts (BR rules, ACs, fields, TCONDs by type, out of scope, fixtures,
  moved to ST, questions); suggest `check-design`.
