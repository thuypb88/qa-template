# design-analysis: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-30 13:54:26 (UTC+7)

Read before writing `1-analysis.md`. Copy [../assets/1-analysis.md](../assets/1-analysis.md), replace every
`<placeholder>`, delete the template comments. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1, R2, R3.3, R6.3, R9, R10 · `packs/<pack>/rules.md` and `analysis.md` (§3, §5, §6, §8 shapes) ·
[analysis-diagrams.md](../../../../standards/methods/analysis-diagrams.md) ·
[requirement-quality.md](../../../../standards/methods/requirement-quality.md) (§2, §8, §9) ·
[conventions.md](../../../../standards/conventions.md) (stamp, IDs, formats).

| Output | File | Write mode | Checked by |
|---|---|---|---|
| analysis | `<folder>/1-analysis.md`, title exactly `# <name>: analysis` | overwrite (IDs kept) | `check-design` analysis |
| questions | `project/questions.md` (new open questions) · `project/log.md` (one line) | append | — |

## Required sections

1. **Overview.** Purpose, actors, in / out of scope, assumptions, neighbouring modules (in / out), then
   `### System study diagram`: a context diagram (actors, module, neighbours with their hand-offs) and a process map
   (flow steps along the business object's life, with its states) in Mermaid — analysis-diagrams §2.
2. **Requirement breakdown.** Per requirement: summary, priority, client ref, UC, atomic rules `BR-<req>-n` (one
   trigger, one outcome each; actor, preconditions, constraint, exception or `missing`). Then **Acceptance criteria**
   `AC ID | Criterion | Source | Requirements`; a criterion with no observable outcome is also a §9 `untestable`.
3. **Inventory** — the pack's §3 (screens / endpoints / tables + jobs). These names become mindmap level 1 and the
   TC title prefixes. Flows handling a variant set add the **Variants handled** table (R10).
4. **Functional flow.** Main / alternate / exception, each step with what is observable at the surface. Under each
   step that has a source workflow diagram or process-step table, a Mermaid swimlane diagram redrawn from it (the
   source's lanes and step IDs, figure cited) and a **Diagram vs text** line — analysis-diagrams §3. Sources in
   use-case form map course by course (normal → main, `AC.n` → alternate, `EX.n` → exception, postconditions →
   observable results); Given-When-Then criteria give one TCOND per *Then* / *And*.
5. **Data & field rules** — the pack's §5 tables; state / transition tables.
6. **Integrations** — the pack's §6: each external system, its IT stand-in and ST counterpart.
7. **Non-functional.** Languages, compatibility, security (the module's techniques), audit, performance, volume.
8. **Testable conditions** `| ID | Condition | Requirement | Type | <Level-1 item> | Observable in |` (first four
   columns fixed; scripts read them).
   - Type: positive / negative / boundary / ui / localization / compatibility / security / accessibility /
     contract / data-quality / reconciliation / performance / e2e.
   - Per validated field / parameter / column: mandatory + invalid + boundary. Per state machine: allowed + refused.
   - R6.3: one localization TCOND per language per free-text input. R10: valid + invalid TCOND per variant per
     flow step.
   - Not observable at the surface → sub-table **Out of black-box scope** (covering layer; no TCOND ID).
   - Security: one TCOND per technique the module's `security` value calls for (pack `rules.md`); a technique that
     does not apply → **Out of black-box scope** with its reason and covering layer.
   - A TCOND waiting on a question with no usable assumption ends `(Held: Q-xxx)`; one using the assumption ends
     `(runs on Q-xxx)`; the mark matches the §9 row.
9. **Gaps, conflicts & open questions** `ID | Kind | Topic | Evidence A | Evidence B | Proposed assumption | Owner |
   Blocks` (`Q-001…`). Kind: missing rule / missing material / ambiguous / conflict / untestable / stale; an
   ambiguous row gives ≥ 2 readings; Blocks = the TCONDs / requirements waiting on it; ordered by what it blocks.
   Copy relevant `Q-ST` with their IDs; source conflicts (R1.4); unconfirmed values.
10. **Traceability** `Requirement / AC | BR rules | TCONDs | Q refs` — every requirement and AC.
11. **Level scope & fixtures.** Per UC `UC | IT scope (In / Partly / Out) | Fixtures | Moved to ST | Source`; the
    **fixture list** with short names the TCs use (pack §11); **baseline preconditions** (R3.3: one line each);
    **Moved to ST** (no TCOND).

Optional, before §0: a reading guide; after §11: `## Revision log`, link references.

## Rules

- **Template sections** of [1-analysis.md](../assets/1-analysis.md), in order: `## 0. Citation keys and source precedence` · `## 1. Overview` · `## 2. Requirement breakdown` · `## 3. Inventory: <forms / screens | endpoints | target tables and jobs>` · `## 4. Functional flow` · `## 5. Data & field rules` · `## 6. Integrations as the tester sees them` · `## 7. Non-functional` · `## 8. Testable conditions` · `## 9. Gaps, conflicts & open questions` · `## 10. Traceability` · `## 11. Level scope & fixtures`.
- **Figures:** §0 lists the figures that add rules or labels and says how many of the module's To-Be figures (flows and
  screens) were read — all of them; a screenshot that contradicts the text is a §9 conflict.
- **Citations:** a citation-key table first (`Key | File`) and the source-precedence note; every statement cites
  `[KEY:line](path#Lnn)`, `(FR-xxx)` or `Source: <doc> §x p.n`; links relative to the folder.
- **No invention.** Unstated → §9. Exact source values; labels in their language.
- **Completeness.** Every requirement and AC in §2 and §10; every field / parameter / column of the sources in §5.
- **IDs on rewrite.** Keep live TCOND / Q IDs; mark removed TCONDs *retired*; never reuse IDs.
- **Downstream.** If a mindmap or TCs exist, say in the header they need re-checking; don't edit them.
