---
name: sql-cases
description: SQL step 5 (writer, IT or ST; modules with pack sql): write the test cases for stored procedures, functions, views, triggers, jobs and queries. Expand the module's 2-mindmap.md (or, for a single object without a module chain, its sql-study card) into test cases in 3-test-cases/test-cases.json - common fields plus the sql block (object, exact call in the project's dialect, oracle kind, data set, readback query, exact expected rows / OUT values / return code / error) - run the SQL checklist pass (parameters, NULL, zero / one / many, rules per partition, side effects and no collateral change, atomicity, error contract, constraints, triggers, re-run, concurrency, permissions) into checklist-pass.md, then check and export the Excel. Use for "write test cases for usp_transfer", "test cases for this stored procedure / view / function", "SQL test cases for S1", "viết test case cho store procedure". Not for: UI / API / ETL test cases → design-cases; the data scripts → sql-data; automating them → sql-verify.
metadata:
  group: sql
  order: "5"
---

# SQL: test cases for database objects

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `2-mindmap.md` and `1-analysis.md` of a `pack: sql` module, the `sql-study` cards, the DDL and spec.
**Out:** `3-test-cases/test-cases.json`, `3-test-cases/checklist-pass.md`, the generated Excel. **Rules:** core
R1–R10; [packs/sql/rules.md](../../../packs/sql/rules.md), [tc-fields.md](../../../packs/sql/tc-fields.md),
[checklist.md](../../../packs/sql/checklist.md); common TC fields and writing rules in
[standards/methods/test-case-fields.md](../../../standards/methods/test-case-fields.md) (not repeated here). **Next:** `check-design`, then `sql-data` for the
data sets the TCs name.
**Stop if** the module is not `pack: sql` → `design-cases`; no mindmap and no study card → `sql-study` first.
**Output:** [assets/checklist-pass.md](assets/checklist-pass.md) · [assets/test-cases.json](assets/test-cases.json); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Modes

- **Module** (default): the mindmap exists → one or more TCs per scenario, in scenario order.
- **Object** (one object, no module chain yet): build the object's scenario table first in the pack layout
  ([packs/sql/scenarios.md](../../../packs/sql/scenarios.md)) — one scenario per rule partition, boundary, error
  and side effect from the study card — append it to `2-mindmap.md`, then write the TCs. Say that the mindmap was
  written here; `check-design` reviews both.

## Steps

1. Read lean, one object at a time: its mindmap rows, analysis §3 / §5 rows, the study card, existing IDs
   (`slice.py tc <target> --list`).
2. **Each TC** — common fields per [test-case-fields.md](../../../standards/methods/test-case-fields.md) (template
   [assets/test-cases.json](assets/test-cases.json)), and:
   - **steps:** the data set to load, the exact call (dialect of `project.json › sql.dialect`, parameter values
     written out), the readback query when the oracle needs one;
   - **expected_result:** exact rows (columns in order) / "0 rows", OUT values, return code, or error number /
     SQLSTATE + message text — and for writes, the readback rows; for refusals, the readback showing nothing changed;
   - **sql block** per [tc-fields.md](../../../packs/sql/tc-fields.md): `object`, `object_type`, `call`, `oracle`,
     `data_set`, `readback`, `expect`, `verify` (`manual` until `sql-verify` sets `proc` / `script`);
   - values from the spec / DDL; a value only the code shows → `Q-xxx: assumed as implemented` (R-SQL2).
3. **Negative and boundary TCs** change one input from a valid baseline call; the baseline call is the happy-path
   TC's call.
4. **Checklist pass** ([assets/checklist-pass.md](assets/checklist-pass.md)) over every object of the analysis inventory: `Object | SQL-V01 … SQL-X04` with N/A / covered
   (`TC-…`) / new (`new TC-…`). C (concurrency) rows are Manual by default; X rows at IT only where the test database
   allows them (permissions with a test role, volume with a documented target), else Moved to ST.
5. **Check and export** as in `design-cases` §3 (`export_testcases.py <target> --check`, `slice.py tc --patterns`,
   export); bump `version`; `project/status.md` + `project/log.md`; commit `<id> test cases v<version>: <what>`.

## Rules

- Each TC calls the object the way a caller does; never asserts on internals (temp tables, variables, the plan).
- One call per TC (a flow TC may chain calls; each step still has its expected result).
- Data set IDs only from analysis §11 or new ones registered there; no ad-hoc keys inside steps.

## Done when

- [ ] Every scenario has ≥ 1 TC; every TC has a complete `sql` block and decidable expected results.
- [ ] Writes have readbacks; refusals prove no side effect; errors give number + message.
- [ ] Checklist pass written; `--check` 0 Error; `version` bumped; Excel exported; suggest `check-design` and `sql-data`.
