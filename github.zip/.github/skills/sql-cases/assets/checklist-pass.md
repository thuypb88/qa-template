<!-- Template: sql-cases checklist pass. Copy to <folder>/3-test-cases/checklist-pass.md, replace every <placeholder>,
delete this comment. Rules: ../references/output-rules.md. -->
# <module id> SQL checklist pass

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

Source: [packs/sql/checklist.md](<relative path>); inventory: [1-analysis.md §3](../1-analysis.md); suite:
`test-cases.json` v<version>.

Cells: `TC-<MOD>-nnn` = covered · `new TC-<MOD>-nnn` = added by this pass · `Blocked` = waits on its `Q-` · `N/A` ·
`Moved to ST` (X rows the test database cannot hold at IT).

| Object | SQL-V01 | <…> | SQL-X04 |
|---|---|---|---|
| <schema.object> | <N/A \| TC-… \| new TC-… \| Blocked \| Moved to ST> | <…> | <…> |

## Counts

| N/A | Covered | New | Blocked | Moved to ST | New questions |
|---|---|---|---|---|---|

## Notes on N/A

## Questions raised by this pass (registered in project/questions.md)
