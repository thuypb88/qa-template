<!-- Template: run-report. Copy to test-reports/<YYYY-MM-DD>-<slug>.md, replace every <placeholder>, delete this comment.
Counts are recomputed from each test-cases.json, never copied. Rules: ../references/output-rules.md. -->
# Test summary report: <scope>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Period:** <YYYY-MM-DD → YYYY-MM-DD> · **Build(s):** <…> · **Environment(s):** <as in project.json> · **Cycles:** <…> ·
**Audience:** <QA lead | PM | client>

## 1. Summary

<3–5 lines: status, blockers, recommendation. Plain language; IDs in the tables, not here.>

## 2. Scope

**Tested:** <…> · **Not tested:** <… (why: Moved, out of scope, not reached, Blocked by Q-…)>

## 3. Execution

| Folder | TCs | Executed (Auto / Manual) | Passed | Failed | Blocked | Not run | No result |
|---|---|---|---|---|---|---|---|

## 4. Failed and blocked P1 / P2

| TC | P | Result | Defect | Note |
|---|---|---|---|---|

## 5. Defects

| Severity | New | Open | Fixed | Closed | Rejected / Deferred |
|---|---|---|---|---|---|

<Open Critical / Major, each with its status and plan (fix planned, accepted by whom), and age.>

## 6. Exit criteria

| Criterion | Status | Evidence |
|---|---|---|
| <from the test plan / strategy> | <Met \| Not met \| Blocked \| Unknown> | <file, count> |

## 7. Test basis

<Review verdicts per folder; open questions that affected testing; deviations from the plan.>

## 8. Residual risks

- <what could still be wrong in production, and why>

## 9. Recommendation

<Ready | Ready with conditions (each checkable, with owner) | Not ready> — <reasons>. **Decision:** pending (<who>) |
<the recorded decision, who, date>.
