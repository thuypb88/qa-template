---
name: run-report
description: Run: the test summary / exit report (a cycle, a sprint, a level - IT / ST - or a release). Write the test summary / exit report in test-reports/<date>-<slug>.md from evidence only - recorded cycle results in each test-cases.json (automated and manual), the run summaries, project/defects.md, review verdicts and the test plan's exit criteria - with scope tested and not tested, executed vs planned per folder, results by priority, open defects by severity, exit criteria as Met / Not met / Blocked / Unknown, residual risks and a go / no-go recommendation for the people who decide. Use for "write the test report", "test summary report", "exit report for IT", "cycle C2 report", "status report for the client", "release test report". One run's summary → run-tests; release timeline → flow-cadence.
metadata:
  group: run
  order: "E+"
---

# Run: test summary report

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the scope (folders, cycle names, release); each `test-cases.json` (`cycle`, `result`, `executed_on`,
`defect_id`; `slice.py tc <target> --stats`), `runs/run-summary.md`, `project/defects.md`, the review files'
verdicts, `plans/test-strategy.md` / the test plan (exit criteria), regression records. **Out:**
`test-reports/<YYYY-MM-DD>-<slug>.md` (project-owned, in git); the deliverables
`deliverables/test-reports/<CODE>_<scope>_Test_Report_v<n>.docx` (or `.xlsx`) and
`deliverables/dashboard/<CODE>_Test_Progress_Dashboard_<YYYY-MM-DD>.xlsx` (step 9); a `project/log.md` line. **Rules:**
[standards/methods/defect-report.md](../../../standards/methods/defect-report.md) §3 (run summary conclusion).
**Next:** the decision meeting; `learn-retro`; `flow-cadence` window 6 when it is a release.
**Output:** [assets/test-report.md](assets/test-report.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

**Stop if** a folder in scope has unrecorded results the user expects counted (automated: `run_tests.py --record
<cycle>`; manual: `python3 scripts/record_manual.py <target> <filled csv> --cycle <cycle>`). Ask; don't count
`runs/` CSVs that were never recorded.

## Steps

1. **Fix the scope:** folders, cycle(s), build(s), dates, the audience (QA lead, PM, client).
2. **Count from the JSON** per folder (L-T15: recount, never copy an older report): total TCs; executed in the cycle
   (by result: Passed / Failed / Blocked / Not Run / No result) — automated and manual separately; not executed and why
   (Manual not run, Blocked by `Q-xxx`, Deferred, out of this cycle).
3. **Failures first:** every failed or blocked P1 / P2 TC by ID with its defect, before any percentage.
4. **Defects:** from `project/defects.md` — found / fixed / closed / open in the period; open by severity and age; each
   Critical / Major open with its status (fix planned, accepted by whom).
5. **Exit criteria:** each from the test plan / strategy → Met · Not met · Blocked · Unknown, with the evidence (file,
   count). Missing evidence is never Met.
6. **Quality of the test basis:** review verdicts per folder (Pass / with fixes / Rework), open questions that
   affected testing, untested scope (Moved, out of scope, not reached).
7. **Residual risks** — what could still be wrong in production and why (untested, accepted defects, mocks at IT
   that ST did not cover).
8. **Recommendation:** Ready · Ready with conditions (each checkable, with owner) · Not ready, with the reasons. The
   decision belongs to the people the plan names; the report says "decision pending" until recorded.

9. **Deliverables.** The report → `deliverables/test-reports/`, from `test-reports/<date>-<slug>.md`; the progress
   dashboard → `deliverables/dashboard/`, from `scripts/pipeline_status.py`, every `test-cases.json` and
   `project/defects.md`. When `plans/templates/` has the matching template: copy it — never edit it — into
   `deliverables/`, fill it from those files with the column / section mapping in `plans/templates/README.md` (the
   `xlsx` / `docx` skill), and add or update its row in `deliverables/README.md` › Issued. A file whose *Sent to* is empty is a draft: regenerate it in place; once sent it is frozen (new version). A new version archives the one it supersedes in the same change set ([conventions §11](../../../standards/conventions.md#11-archive-dont-delete)).

## Report layout

Copy [assets/test-report.md](assets/test-report.md); title, nine sections, counting and deliverable rules per
[references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- Executed means recorded; planned or tagged Auto is not executed. Nothing ran → status "not executed / not enough
  evidence", never a pass.
- A high pass rate never hides a failed P1. Percentages only next to the counts they come from.
- Plain language for the audience; IDs in tables, not in the summary lines. A second version for another
  audience (director, client, team) → `learn-explain`, from this report's facts.

## Done when

- [ ] Counts recomputed from the JSON for every folder in scope; failures and blocked P1 / P2 listed by ID.
- [ ] Exit criteria with evidence; residual risks; recommendation with reasons; the report and dashboard in
  `deliverables/` (when the templates exist), indexed; `project/log.md` line; commit `test report <slug>`.
