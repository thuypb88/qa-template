# run-report: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 15:44:58 (UTC+7)

Read before writing the report or a deliverable. Copy [../assets/test-report.md](../assets/test-report.md), replace
every `<placeholder>`, delete the template comment. Linked, never copied:
[defect-report.md](../../../../standards/methods/defect-report.md) §3 ·
[conventions.md](../../../../standards/conventions.md) §10 (formats), §11 (archive) · column / section mapping of the
deliverables: `plans/templates/README.md`.

| Output | Template | File | Write mode |
|---|---|---|---|
| report (source) | [test-report.md](../assets/test-report.md) | `test-reports/<YYYY-MM-DD>-<slug>.md` | new dated file |
| report deliverable | a copy of the matching `plans/templates/` file (never edited) | `deliverables/test-reports/<CODE>_<scope>_Test_Report_v<n>.docx` (or `.xlsx`) | draft regenerated in place until *Sent to* is filled; then frozen, a change = a new version, the superseded one archived |
| dashboard | a copy of `plans/templates/*Test_Progress_Dashboard_Template.xlsx` | `deliverables/dashboard/<CODE>_Test_Progress_Dashboard_<YYYY-MM-DD>.xlsx` | as above |
| index | — | `deliverables/README.md` › Issued | add / update the row |
| log | — | `project/log.md` | one line |

## Rules

- **Template sections** of [test-report.md](../assets/test-report.md), in order: `## 1. Summary` · `## 2. Scope` · `## 3. Execution` · `## 4. Failed and blocked P1 / P2` · `## 5. Defects` · `## 6. Exit criteria` · `## 7. Test basis` · `## 8. Residual risks` · `## 9. Recommendation`.
- **Title** `# Test summary report: <scope>`; the nine sections in the template's order.
- **Counts** recomputed from each `test-cases.json` (L-T15); executed means recorded; percentages only next to
  the counts they come from.
- **Failures first:** every failed or blocked P1 / P2 TC by ID (§4) before any percentage; a high pass rate never
  hides a failed P1.
- **Exit criteria** Met · Not met · Blocked · Unknown with the evidence; missing evidence is never Met.
- **Recommendation** Ready · Ready with conditions (checkable, with owner) · Not ready; "Decision: pending (<who>)"
  until a decision is recorded.
- Plain language for the audience; another audience's version → `learn-explain`.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
