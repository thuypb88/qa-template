---
name: run-explore
description: Run: exploratory sessions (manual, IT or ST). Plan and record time-boxed exploratory sessions for risky areas, the manual residue and places the scripted TCs don't reach - a charter (mission, area, risk, data, environment, time box), heuristics to apply, the session log (what was tried, observed, evidence), then the outcome - bugs (to run-defects), questions (to the analysis), and new TC candidates (to design-cases) - in <folder>/exploratory/ET-NNN-<slug>.md. Use for "exploratory testing on E4", "write charters", "test session for the new screen", "explore the approval flow", "session-based testing", "debrief the session". Scripted manual runs → run-tests (manual checklist); writing TCs → design-cases.
metadata:
  group: run
  order: "E"
---

# Run: exploratory sessions

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the folder's analysis (inventory, §9 open questions, risk notes), mindmap (what is already covered), the
manual residue (`runs/<key>/manual-checklist.csv`), `project/defects.md` and `project/lessons.md` (where it broke
before), the user's focus. **Out:** `<folder>/exploratory/ET-NNN-<slug>.md` per session (charter → log → debrief);
hand-overs to other skills. **Rules:** R2 (observe at the surface), R9 (the level's environment and data).
**Next:** `run-defects` for bugs, `design-cases` for new TC candidates, `design-analysis` for new questions.
**Output:** [assets/session.md](assets/session.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## 1. Charters (planning)

The session file starts from [assets/session.md](assets/session.md) (charter → log → debrief); file rules in
[references/output-rules.md](references/output-rules.md).


One charter per risk, not per screen: `Explore <area> with <resources / data / role> to discover <information /
risk>`. Pick areas by risk: new or changed items, items with recent defects, open questions, complex state or
integrations, the manual residue, hand-offs. Each charter: mission, area (inventory items), risks, data / fixtures,
environment and build, time box (45–90 min), what is out of the session.

## 2. Heuristics to choose from

- **Inputs:** boundaries in the field's unit, empty / spaces / very long / Unicode / pasted text, the R6.3 languages.
- **State and sequence:** interrupt mid-flow, Back / Refresh / double submit, two tabs or two users on one item,
  undo / re-open, an expired session.
- **Roles:** each role of the RBAC matrix on the same item; URL / ID swaps.
- **Data life cycle:** create → read → update → delete; then search, export, report.
- **Integrations (IT mocks):** each mock fault scenario; slow answers; repeated messages.
- **Consistency:** the same value on list, detail, export, printout, other module.
- **Claims:** whatever the client documents or help text promise.

## 3. Session log (during)

Timestamped notes: what was tried (steps, data), what was observed, evidence path (screenshot / video / response
under `runs/exploratory/`), and the tag `BUG` · `QUESTION` · `IDEA` (a TC candidate) · `NOTE`. Keep the build and
environment on top. Something blocks the charter → note it and stop the clock (it is a result too).

## 4. Debrief (after)

- **Coverage:** what of the charter was explored, what not (and why); time on charter vs set-up vs bug reporting.
- **Bugs** → `run-defects` (one per symptom, with the log's steps and evidence).
- **Questions** → the analysis §9 via `design-analysis` (or `project/questions.md`).
- **TC candidates** → `design-cases` (append; each with the scenario it extends or a new scenario for
  `design-scenarios`). A behaviour worth repeating every build should become a TC.
- **Follow-up charters** for what the session showed is risky.

## Rules

- A session is evidence only of what was tried and observed; it never marks scripted TCs Passed.
- Notes are written during the session, not reconstructed afterwards.
- No production; data cleaned up per the design-data plan.

## Done when

- [ ] Charter with mission, risk, time box; log with evidence paths; debrief with coverage and hand-overs.
- [ ] Every BUG handed to `run-defects`, every IDEA listed for the writer; `project/log.md` line.
