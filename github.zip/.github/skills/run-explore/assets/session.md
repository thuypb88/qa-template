<!-- Template: run-explore. Copy to <folder>/exploratory/ET-NNN-<slug>.md, replace every <placeholder>, delete this
comment. Write the log during the session, not afterwards. Rules: ../references/output-rules.md. -->
# ET-<NNN>: <charter in a few words>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Environment · build:** <env name as project.json> · <build> · **Tester:** <name> · **Time box:** <45–90> min

## Charter

**Explore** <area> **with** <resources / data / role> **to discover** <information / risk>.

| Area (inventory items) | Risks | Data / fixtures | Out of this session |
|---|---|---|---|

## Session log

| Time | Tag | What was tried (steps, data) | Observed | Evidence |
|---|---|---|---|---|
| <HH:mm> | <BUG \| QUESTION \| IDEA \| NOTE> | <…> | <…> | <runs/exploratory/…> |

## Debrief

**Coverage:** <explored / not explored (why)> · **Time:** charter <n>% · set-up <n>% · bug reporting <n>%

| Hand-over | Item | To |
|---|---|---|
| Bug | <symptom> | `run-defects` |
| Question | <question> | analysis §9 via `design-analysis` / `project/questions.md` |
| TC candidate | <behaviour; scenario it extends or new> | `design-cases` / `design-scenarios` |
| Follow-up charter | <risk> | next session |
