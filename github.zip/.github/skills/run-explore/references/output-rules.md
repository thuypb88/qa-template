# run-explore: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before starting the session file. Copy [../assets/session.md](../assets/session.md), replace every
`<placeholder>`, delete the template comment. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R2, R9 · [conventions.md](../../../../standards/conventions.md) (stamp, §3 IDs, §10 time format).

| Output | File | Write mode |
|---|---|---|
| session | `<folder>/exploratory/ET-NNN-<slug>.md` | one file per session; `ET-NNN` the next free number in the folder |
| evidence | `runs/exploratory/…` | per observation |
| log | `project/log.md` | one line |

## Rules

- **Sections**, in order: header (environment, build, tester, time box) · `## Charter` (one risk, not one screen) ·
  `## Session log` · `## Debrief`.
- **Log rows** written during the session with a time, a tag `BUG` · `QUESTION` · `IDEA` · `NOTE`, and an evidence
  path where something was observed. A blocker is logged and stops the clock.
- **Debrief** states coverage (what was and was not explored, why), the time split, and one hand-over row per BUG,
  QUESTION and IDEA.
- A session never marks scripted TCs Passed.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
