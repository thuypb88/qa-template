# check-testplan: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read when writing the review. Copy [../assets/test-plan-review.md](../assets/test-plan-review.md), replace every
`<placeholder>`, delete the template comment. Shared rules are linked, never copied:
[review-protocol.md](../../../../standards/review-protocol.md) P1–P7 ·
[conventions.md](../../../../standards/conventions.md) §10 (dates, amounts).

| Output | File | Write mode |
|---|---|---|
| review | `plans/test-plan-reviews/<YYYY-MM-DD>-<slug>-v<version>.md`; ours: slug `<project code>-test-plan`, lower case; anyone's: slug from the document title | new file per reviewed version, never overwritten |
| fixes (on approval) | `plans/test-plan.md`, `plans/estimation.json` | edit; bump Version and `estimation.json › version` |

## Rules

- **Title** `# Test plan review — <plan title> v<version>`; header lines Verdict, Reviewed, Script as in the template,
  with the script counts copied in.
- **Sections** in order: `## Findings`, `## Spot-checks (P1.3)` (≥ 8: 3 scope rows, 2 size counts, 2 criteria,
  1 environment / external), `## Fix order`, `## Estimate and schedule`, `## Questions for the PM / client`; after
  fixes, `## Revision log`. Notes that raise no finding may go in `## Checklist notes (no finding)`.
- **Findings** IDs `TPR-001…`, never repeated; every row as many cells as the header.
- **Severity, read for a plan:** **High** — commits the project to something wrong or unworkable (scope against the
  sources, a date that cannot hold, criteria nobody can check, a size or rate error beyond the contingency, another
  project's facts). **Med** — a number or criterion with no source or question, an inconsistency with the strategy
  or `project.json`, a placeholder or empty section, a risk without owner. **Low** — wording, numbering, format.
- **Priority, read for a plan:** P1 before the plan is sent or signed · P2 in this version · P3 next version. Default
  High → P1, Med → P2, Low → P3. **Fix order** by priority, then severity. **Verdict** per review-protocol P3.
- A gap the plan states with its question is not a finding; the same gap unstated is.
- A false positive of the script → a row with **No change** and the reason.
- Never type a corrected date: the fix names the input to change and `test_estimate.py --write`.
- Someone else's plan: findings and questions only; never rewrite their document.

## Checks before done

```bash
python3 scripts/check_testplan.py [<file>] --json     # counts in the header
python3 scripts/test_estimate.py --check              # our plan only
```
