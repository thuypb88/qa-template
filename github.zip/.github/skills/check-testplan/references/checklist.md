# Test plan review checklist

> **Created:** 2026-10-22 11:06:00 · **Updated:** 2026-10-22 11:06:00 (UTC+7)

Load at step 5. The script has already checked shape (placeholders, numbering, dates, drift); these are the
questions it cannot answer. Each "no" is a finding unless the plan states the gap with its question.

## Scope and objectives

- [ ] Every in-scope item (module, requirement range, CD, interface) traces to a source line or `project.json`; the
      ranges match the IDs in the sources (count them for 2 modules).
- [ ] Every out-of-scope item gives the reason and the source or decision; nothing in scope in the strategy is
      silently missing here.
- [ ] Objectives are measurable, each with its evidence; any numeric target (pass rate, coverage %) has a source or
      is marked proposed with a question — never invented.

## Levels, environments, data

- [ ] Level and environment names exactly as `project.json › levels`; IT uses mocks / fixtures, ST the real systems
      (R9); each external system has an IT stand-in and an ST connection, or a question.
- [ ] Levels the plan names but nobody owns (unit, performance, security, BA UAT) are either owned or marked not
      planned with the reason.
- [ ] Data: synthetic or masked, with the policy's source; who provides accounts per role and the external test
      data, with owners.

## Approach per level

- [ ] Each level: responsibility, timing, input, output, execution (manual / automated) consistent with §2 and the
      strategy; what is out of scope at a level says where it is tested instead.
- [ ] Test types match the packs and the risks (money, state, roles first); no type listed that nothing schedules.

## Entry and exit criteria

- [ ] Every criterion is checkable: a count, a state, a document, with the evidence named.
- [ ] Entry of each level = exit of the one before (no gap, no contradiction); thresholds stated once, identically.
- [ ] Customer UAT criteria are the client's, or marked as theirs to set.

## Estimate and schedule

- [ ] Size: counts match the sources (spot-check); actual TC counts used where suites exist; ratios (TCs per
      requirement, ST share) labelled as assumptions.
- [ ] Rates: from history or labelled proposed; contingency and management stated; P80 vs planned — the plan says
      which one a committed date uses.
- [ ] Dependencies the team does not control (builds, environments, accounts, interface specs, UAT start) are
      constraints in the schedule, not assumed to be ready.
- [ ] Capacity: effort ÷ (people × allocation) ≈ duration; nobody over 100 %; holidays from a named calendar.
- [ ] Milestones follow the work they close; each has a deliverable and a gate that points at §8.
- [ ] Scope items not estimated (migration, NFR, automation) are listed as exclusions.

## Resources, risks, defects, deliverables, reporting

- [ ] Team roles cover every activity in the estimate; one person, one full-time role.
- [ ] Every open question that moves a date or the scope is a risk with owner and mitigation; risks are this
      project's, not generic.
- [ ] Defect severity / priority scale, tracker and owner named, or a question.
- [ ] Each deliverable has a when, an audience and a format the pipeline actually produces.
- [ ] Reporting cadence and audience set (or a question); metrics have a formula; targets only when stated.

## Consistency

- [ ] No contradiction with `plans/test-strategy.md` (scope, levels, criteria) or `project.json`.
- [ ] No fact of another project (names, IDs, dates, targets) when the plan reused a template or sample.
- [ ] Version, date and approvers present; document control matches the content.
