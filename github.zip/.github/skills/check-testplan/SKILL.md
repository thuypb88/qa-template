---
name: check-testplan
description: Check (reviewer, project, IT and ST): review a test plan before it is issued or signed - ours (plans/test-plan.md with its estimate and schedule) or anyone's (a .docx / .pdf in sources/). Run scripts/check_testplan.py (placeholders, numbering, dead cross-references, missing sections, impossible dates, schedule and milestone order, one person in two full-time roles, another project's names, drift from the estimate, unknown Q- IDs), then judge scope against the sources, objectives, levels and environments, checkable entry / exit, a realistic estimate and schedule, risks, deliverables and reporting under the review protocol, write the review file and offer the fixes. Use for "review the test plan", "is the test plan ready to send", "check the schedule / estimate", "rà soát kế hoạch kiểm thử". Not for: writing it → plan-testplan; what our strategy needs from a client's plan → plan-strategy review mode; a requirement document → req-review.
metadata:
  group: check
  order: "-1"
---

# Check: test plan

> **Created:** 2026-10-22 11:06:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the plan — default `plans/test-plan.md` (+ `plans/test-estimate.md`, `plans/estimation.json`), or a path
(a `.docx` / `.pdf` under `sources/` is read from its parsed copy); upstream: `plans/test-strategy.md`,
`project.json`, `project/questions.md`, the requirement sources. **Out:** one new file per reviewed version, never
overwritten: `plans/test-plan-reviews/<YYYY-MM-DD>-<slug>-v<version>.md` (ours: slug `<project code>-test-plan`, lower
case; anyone's: from the document title); fixes to `plans/test-plan.md` /
`plans/estimation.json` only when approved. **Rules:** [review protocol](../../../standards/review-protocol.md)
P1–P7 (finding IDs `TPR-`), core R1, R9, conventions §10. **Next:** `plan-testplan` (apply fixes / re-estimate),
`learn-retro` when findings repeat.
**Stop if** the plan does not exist → `plan-testplan`; a `.docx` has no parsed copy → `python3 scripts/extract_text.py`.
**Output:** [assets/test-plan-review.md](assets/test-plan-review.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **Lessons first** (P1.5): `project/lessons.md`, the L-T rows naming a plan or estimate.
2. **Script:** `python3 scripts/check_testplan.py [<file>] --json`. For a plan that reused another project's
   document, add `--forbid "<that project's name, client, system>"`. Copy the counts into the header; each Error is
   a finding (one finding per kind, with all its lines — P2); read each Warning's line before raising it. A false
   positive (a template row that is meant to show `[Name]`) → row with **No change**.
3. **Our plan only:** `python3 scripts/test_estimate.py --check` and `--json`; the estimate is part of the review.
4. **Whole-document scan:** `slice.py toc <file>`; every section of the format
   ([plan-testplan format](../plan-testplan/SKILL.md) step 4) present or marked as a gap with its question.
5. **Checklist** — [references/checklist.md](references/checklist.md), section by section; riskiest first: scope,
   entry / exit, schedule and estimate, then the rest.
6. **Spot-check against the sources** (P1.3): at least 8 claims — 3 scope rows, 2 size counts (open the source and
   count the IDs), 2 criteria, 1 environment / external — each opened at the cited line.
7. **Write** the review file from [assets/test-plan-review.md](assets/test-plan-review.md). **Report and offer fixes** (P5). Applying: edit only the plan or the
   estimate inputs; dates come from `test_estimate.py --write`, never typed in; bump Version and `estimation.json`
   `version`; re-run both scripts; append `## Revision log`.
8. `project/log.md` line; commit `test plan review: <verdict>` (fixes as their own commit).

## Output

Copy [assets/test-plan-review.md](assets/test-plan-review.md); file name, sections, severity and priority read for a
plan, Fix order and verdict per [references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- Review what is written, against its sources; never accept "per the strategy" without opening the strategy.
- A gap the plan states with its question is not a finding; the same gap unstated is.
- Never type a corrected date into the plan: fix the input, regenerate, copy.
- Someone else's plan: findings and questions only; never rewrite their document.

## Done when

- [ ] Script counts in the header; every Error a finding or **No change** with a reason; estimate checked (ours).
- [ ] Checklist done for every section; ≥ 8 spot-checks with source links.
- [ ] Every finding has evidence, severity, priority and a fix; Fix order and verdict written; questions proposed; `project/log.md` line.
