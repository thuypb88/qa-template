<!-- Template: check-testplan review. Copy to plans/test-plan-reviews/<YYYY-MM-DD>-<slug>-v<version>.md (a new file per
reviewed version), replace every <placeholder>, delete this comment. Rules: ../references/output-rules.md. -->
# Test plan review — <plan title> v<version>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Verdict:** <Pass | Pass with fixes | Rework>
**Reviewed:** <YYYY-MM-DD> · **Reviewer:** <agent model> · **Sections:** <present>/<needed> · **Spot-checked:** <n>
**Script:** check_testplan <e> Error · <w> Warning · test_estimate --check <n> problem(s), <n> open input(s)

<One short paragraph: which plan file and version, against which strategy, estimate and sources.>

## Findings

| ID | Severity | Priority | Section | Check | Review comment | Evidence | Suggested fix |
|---|---|---|---|---|---|---|---|
| <TPR-001> | <High \| Med \| Low> | <P1 \| P2 \| P3> | <§n title> | <checklist item> | <what would go wrong> | <source line, script output> | <fix; dates via test_estimate.py --write> |

## Spot-checks (P1.3)

| # | Claim in the plan | Source opened | Result |
|---|---|---|---|
| 1 | <scope row / size count / criterion / environment> | <file:line> | <holds \| finding TPR-…> |

## Fix order

1. <P1 findings, grouped by the fix that clears them>
2. <P2 findings>
3. <P3 findings>

## Estimate and schedule

<Expected / P80 / planned end; the date a client commitment should use; what moves it.>

## Questions for the PM / client

- Q-<xxx> (<sections affected>): <question>
