<!-- Template: check-automation, design mode. Copy to automation/docs/reviews/<YYYY-MM-DD>-<pack>-design.md (a second
review that day: -r2, -r3 …), replace every <placeholder>, delete this comment. Rules: ../references/output-rules.md. -->
# <module or project short name> <PACK> automation design: <review | re-review>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Verdict:** <Pass | Pass with fixes | Rework>
**Reviewed:** <YYYY-MM-DD> · **Reviewer:** <agent model> · **Mode:** design <(re-check of AD-…, commit <sha>)>
**Artifact:** [<pack>-design.md](../<pack>-design.md) (Updated <YYYY-MM-DD HH:mm:ss>), with <test-data.md links>
**Coverage:** specs <a/b> mapped · sets <a/b> built · gaps <n>
**Runner check:** `python3 scripts/run_tests.py <target> --plan` → <result>

## Previous findings

<!-- re-review only -->
| ID | Status | Note |
|---|---|---|
| <AD-001> | <Fixed \| Open \| Partly fixed> | <what changed> |

## Findings

| ID | Severity | Priority | Item / section | Check | Rule | Review comment | Evidence | Suggested fix |
|---|---|---|---|---|---|---|---|---|
| <AD- (ST SAD-)001> | <High \| Med \| Low> | <P1 \| P2 \| P3> | <§n, spec, component> | <D1–D12> | <R-n / pack rule> | <where it would break> | <design §, plan row> | <fix for auto-design> |

## Spot-check

| Spec | TC walked | Flow → component → builder → hook | Breaks at |
|---|---|---|---|
| <spec> | <TC-…> | <path> | <where, or "—"> |

## Fix order

1. <P1> · 2. <P2> · 3. <P3>

**Re-check after fixing:** <sections to re-read; auto-design, then this review again>

## Questions for BA / client

- Q-<xxx> (<items affected>): <question>
