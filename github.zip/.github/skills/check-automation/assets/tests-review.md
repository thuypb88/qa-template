<!-- Template: check-automation, tests mode. Copy to <folder>/3-test-cases/automation-review.md, replace every
<placeholder>, delete this comment. Rules: ../references/output-rules.md. -->
# <module name | ST: project name>: automated test review (<spec | wave n | all>)

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Verdict:** <Pass | Pass with fixes | Rework>
**Reviewed:** <YYYY-MM-DD> · **Reviewer:** <agent model> (check-automation, tests mode) · **Items checked:** <n tests, n
specs, n support files (commit `<sha>`)> · **Spot-checked:** <n> (P1 first)
**Coverage:** tests <a/b> bound · Strong <a> · Weak <b> · Fake <c>
**Script:** `python3 scripts/run_tests.py <target> --plan` → <bound / unbound Auto TCs, or the BLOCKED reason>

## Strength per test

| Test | TC | Strength | Smallest wrong build that would still pass |
|---|---|---|---|
| <file::test name> | <TC-…> | <Strong \| Weak \| Fake> | <the build, or "none found"> |

## Findings

| ID | Severity | Priority | Item / section | Check | Rule | Review comment | Evidence | Suggested fix |
|---|---|---|---|---|---|---|---|---|
| <AR- (ST SAR-)001> | <High \| Med \| Low> | <P1 \| P2 \| P3> | <file::test, TC-…> | <check 1–12> | <R-n / pack rule> | <what is wrong; which defect it would miss> | <file:line> | <fix, aimed at auto-write / sql-verify, or **Fix upstream** in design-cases> |

## Fix order

1. <P1 findings, grouped by the fix that clears them; Fix upstream first, naming the writer>
2. <P2 findings>
3. <P3 findings>

**Re-check after fixing:** `python3 scripts/run_tests.py <target> --grep <ids>`; <tests to re-read>

## Missing items

- <Ready TCs with no test, components missing, or "None.">

## Out of black-box scope

- <a check that would peek below the pack surface, or "None.">

## Questions for BA / client

- Q-<xxx> (<items affected>): <question>
