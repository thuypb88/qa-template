---
name: check-automation
description: Check A4 automation for IT or ST, every pack. Design mode reviews automation/docs/<pack>-design.md against the plan, data plan and inventory and writes a dated review with AD- findings. Tests mode reviews TC binding, strength (Strong / Weak / Fake), surface, source values, side effects, locators, waits, fixtures, isolation, secrets and SQL verification; it writes automation-review.md with AR- findings (ST SAR-). Use for “review the automation design”, “check wave 1”, or “why is this test always green?”. Design review follows auto-design and precedes auto-write. Test fixes → auto-write (SQL: sql-verify); TC fixes → design-cases; failed runs → run-tests.
metadata:
  group: check
  order: "A4"
---

# Check: automation design and automated tests

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-11-05 08:38:02 (UTC+7)

**Modes:** **design** (the user says design / framework, or `automation/docs/<pack>-design.md` changed after its
latest review) · **tests** (default once tests exist).
**In:** a target (module id, `st`) and optionally a spec / wave of its `automation-plan.md`; design mode: the design
doc, the plan, `test-data.md`, analysis §3; tests mode: the test files under `automation/<pack>/` and the TCs they
name. **Out:** design mode: `automation/docs/reviews/<YYYY-MM-DD>-<pack>-design.md` (dated, kept); tests mode:
`3-test-cases/automation-review.md` (overwrite); fixes only on the user's OK. **Rules:** [standards/review-protocol.md](../../../standards/review-protocol.md) P1–P7; core R2, R9; pack
rules. **Next:** design mode: `auto-design` (design findings), then `auto-write`; tests mode: `auto-write` (test
defects) or `design-cases` (TC defects), then `run-tests`.
**Stop if** no automation plan → `auto-decide`; design mode without a design doc → `auto-design`; tests mode
without automated tests for the target → `auto-write`.
**Output:** [assets/design-review.md](assets/design-review.md) · [assets/tests-review.md](assets/tests-review.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Design mode

Lessons first (P1.5), then the checklist [references/design.md](references/design.md) (D1–D13). Spot-check ≥ 5
spec rows, P1-heavy first: walk one TC per spec through the design (spec → flow → component → builder → hook) and
say where it would break. Write the dated review from [assets/design-review.md](assets/design-review.md) (coverage line
`specs a/b mapped · sets a/b built · gaps n`); fixes go to `auto-design`. Board row, log, commit
`automation design review: <pack>: <verdict>`.

## Tests mode

1. **Lessons first** (P1.5): `project/lessons.md` and the L-T rows naming `auto-write` or `check-automation`.
2. **Binding scan:** `python3 scripts/run_tests.py <target> --plan` — copy the numbers (bound / unbound Auto TCs)
   into the header; every unbound Ready row is a finding.
3. **Checklist:** [references/automation.md](references/automation.md) — twelve checks (12 = SQL verifications); strength (check 2) for
   every test, the others where they apply.
4. **Spot-check** ≥ 10 tests, all P1 first: open the TC (`slice.py tc <target> --ids …`) next to the test and write
   the smallest wrong build that would still pass it.
5. **Write** the review file from [assets/tests-review.md](assets/tests-review.md) with the
   coverage line `tests a/b bound · Strong a · Weak b · Fake c`.
6. **Report and offer fixes** (P5): a test defect goes to `auto-write` (SQL verifications: `sql-verify`); a TC that is itself vague or wrong goes to
   `design-cases` as **Fix upstream**. Re-run `run_tests.py <target> --grep <ids>` after fixes.
7. `project/status.md` board row + `project/log.md`; commit `<id> automation review: <verdict>`.

## Rules

- Green is not evidence: a test that cannot fail for a product reason is **Fake**, whatever its run history.
- Judge against the TC and its source, never against today's build output.
- Review only; the writer applies the fixes (writer ≠ reviewer).

## Done when

- [ ] Binding numbers in the header; every test classified Strong / Weak / Fake.
- [ ] ≥ 10 tests spot-checked (P1 first), each with its smallest wrong build.
- [ ] Every finding has evidence, severity, priority (review protocol P2: High / Med / Low · P1 / P2 / P3; a Priority
  column after Severity) and a fix aimed at `auto-write` or `design-cases`; Fix order by priority, then severity.
