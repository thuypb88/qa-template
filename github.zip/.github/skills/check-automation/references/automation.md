# Review checklist: automated tests (automation/<pack>/…)

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-11-05 00:00:00 (UTC+7)

Checklist of `check-automation`, per spec or wave. The question is not "does it run green" but **would it fail
on a wrong build?** A passing test that cannot fail gives false confidence, which is worse than no test.

```bash
python3 scripts/run_tests.py <target> --plan     # what is bound to which TC; unbound Auto TCs
python3 scripts/slice.py tc <target> --ids …     # the TCs behind the tests under review
```

Read the spec / test file and, per test, the TC it names. Review file: `3-test-cases/automation-review.md`.

1. **Binding.** Every test names its TC ID; every Ready row of the plan has a test or is reported missing; one test
   does not claim two TCs unless it is a data-driven row per TC.
2. **Strength (per test).** Write the **smallest wrong build that would still pass** it. Then classify:
   - **Strong** — asserts the TC's expected result exactly (text, state, status code, body value, row count / diff);
     a realistic defect fails it.
   - **Weak** — checks something, but misses a value the TC states (only the status code, only "element visible",
     only "no exception", only the row count when the TC gives values).
   - **Fake** — cannot fail for a product reason: asserts on the mock's own canned answer, on the value it just
     typed, on `true`, in a `try` that swallows the failure, or has no assertion.
   Weak on a P1 / P2 TC = High; Fake = High; Weak on P3 / P4 = Med.
3. **Surface (R2).** The assertion reads what the TC's surface shows: UI — the page; API — the HTTP response; ETL —
   query results. A hook may set up state; a UI test that asserts a DB row or an internal API call is a finding.
4. **Expected values from the source,** not from the build: a value copied from today's actual output (snapshot,
   recorded response) without checking it against the TC is a finding. A snapshot is fine only when reviewed and
   holding business fields.
5. **Refusals check the absence of a side effect** where the TC says so (read back, list, count), not only the
   message.
6. **Locators (UI).** By role + accessible name or label as the TC names them, or a stable test id the DEV team
   agreed; scoped inside the business container (the row, the dialog) when the page has duplicates. Findings: CSS /
   XPath copied from devtools, positional selectors, `.first()` / `nth()` used to hide that the locator matches
   several elements, text that changes per language without the language being part of the test.
7. **Waits.** Wait on the observable state the next step needs (element enabled, row shown, status text, response
   received for *this* request); never a fixed sleep. A wait that retries an action must not submit twice. Timeouts
   come from configuration, not literals spread through the code.
8. **Mocks and fixtures (IT).** The mock answers in the shape the contract / analysis documents (fields, status codes,
   error model, timing); a difference is either a documented simplification or a finding with a `Q-xxx`. The system
   under test itself is never mocked. Fixture names match analysis §11.
9. **Data and isolation.** Each test creates or resets its own data (unique per run, e.g. a run prefix), cleans up,
   and does not depend on another test's result or order; it can run alone with `--grep` and in parallel.
10. **Secrets and environments (R9).** URLs, DSNs, accounts and tokens from environment variables only; nothing that
    can point an IT run at UAT / production.
11. **Data-driven rows.** One row per TC ID; every row's data is the TC's `test_data`; the row id is the TC ID.

12. **SQL verifications (pack sql).** Each TC block calls the object exactly as the TC's `call`; asserts the TC's
    literal `expect` values (not a value recomputed by a copy of the object's logic); undoes its own changes as the
    dialect template does ([packs/sql/dialects.md](../../../../packs/sql/dialects.md)); returns exactly one row per
    TC, also on an unexpected error (FAIL with the error text); expected-error TCs check the number *and* message;
    nothing is created outside schema `qa`.

13. **UI flow level ownership (R9).** IT tests use `flows/it/<module>/`, ST tests use `flows/st/`, and helpers shared
    across levels use `flows/shared/`. An IT flow importing an ST flow (or vice versa) is a finding.

Severity and priority per P2 of the protocol (a Priority column after Severity). Header coverage line: `tests a/b bound · Strong a · Weak b · Fake c`. Fixes go to
`auto-write` (test defect) or to the writer (TC defect — the TC itself is vague or wrong).
