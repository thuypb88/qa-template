# check-automation: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 15:44:58 (UTC+7)

Read when writing either review. Copy the template of the mode, replace every `<placeholder>`, delete the template
comments. Shared rules are linked, never copied: [review-protocol.md](../../../../standards/review-protocol.md) P1–P7 ·
[conventions.md](../../../../standards/conventions.md) (header stamp, formats).

| Mode | Template | File | Write mode | Finding IDs |
|---|---|---|---|---|
| design | [../assets/design-review.md](../assets/design-review.md) | `automation/docs/reviews/<YYYY-MM-DD>-<pack>-design.md` (`-r2`, `-r3` for another review the same day) | new file per review, kept | `AD-` (ST `SAD-`) |
| tests | [../assets/tests-review.md](../assets/tests-review.md) | `<folder>/3-test-cases/automation-review.md` | overwrite | `AR-` (ST `SAR-`) |

## Rules

- **Template sections** of [design-review.md](../assets/design-review.md), in order: `## Previous findings` · `## Findings` · `## Spot-check` · `## Fix order` · `## Questions for BA / client`.
- **Template sections** of [tests-review.md](../assets/tests-review.md), in order: `## Strength per test` · `## Findings` · `## Fix order` · `## Missing items` · `## Out of black-box scope` · `## Questions for BA / client`.
- **Header lines** Verdict (Pass · Pass with fixes · Rework), Reviewed, Coverage, plus the runner line, as in the
  template. Coverage: design `specs a/b mapped · sets a/b built · gaps n`; tests `tests a/b bound · Strong a · Weak
  b · Fake c`.
- **Findings table** `ID | Severity | Priority | Item / section | Check | Rule | Review comment | Evidence |
  Suggested fix`; every row as many cells as the header. Severity High / Med / Low, Priority P1 / P2 / P3
  (review-protocol P2); IDs from 001, never repeated.
- **Tests mode:** `## Strength per test` lists every reviewed test as Strong / Weak / Fake with its smallest wrong
  build; a Fake test is at least High. A test defect is fixed by `auto-write` (SQL: `sql-verify`); a vague or wrong TC
  is **Fix upstream** in `design-cases`.
- **Design mode:** a re-review starts with `## Previous findings` (each earlier ID: Fixed / Open / Partly fixed);
  `## Spot-check` walks ≥ 5 spec rows (spec → flow → component → builder → hook). Fixes go to `auto-design`.
- **Fix order** by priority, then severity, grouped by the edit that clears them; ends with **Re-check after fixing**.
- **Questions:** `- Q-xxx (items affected): <question>`.
- A dated design review is never overwritten (conventions: reviews kept).
