# Review checklist: automation codebase design (automation/docs/&lt;pack&gt;-design.md)

> **Created:** 2026-10-23 14:20:00 · **Updated:** 2026-11-05 00:00:00 (UTC+7)

Design mode of `check-automation`, before `auto-write`. The question: **can a second module and a second wave be
added without copying code, and can every test still fail on a wrong build?**

```bash
python3 scripts/run_tests.py <target> --plan     # the Auto TCs the design must carry
python3 scripts/slice.py tc <target> --stats     # items, priorities, automation tags
```

| # | Check | Finding when |
|---|---|---|
| D1 | **Coverage of the plan** | a spec row of `automation-plan.md` has no mapping in §10, or a Ready TC has no spec |
| D2 | **Layers** | a lower layer asserts, a spec calls a hook or the DB directly, or the direction of dependency is broken |
| D3 | **Shared components** | a component appears in two page objects, or an inventory element that repeats across modules has no owner |
| D4 | **Locators** | devtools CSS or index-based locators planned; a repeated label with no scoping container; the test ids to request from DEV not listed |
| D5 | **Surface (R2)** | a hook client or mock is used as an oracle; the screen the spec reads after a hook is not named |
| D6 | **Data** | a named set of `test-data.md` with no builder, no cleanup, no fresh-copy rule, or no place in the run order; an open-question value outside the constants file |
| D7 | **Roles** | a role a TC signs in as has no authenticated state, or role switches inside a TC are not supported |
| D8 | **Level (R9)** | IT reaching a real external system, or ST using a mock |
| D9 | **Waits, binding, reporting** | fixed sleeps, titles not starting with the TC ID, no JUnit for `run_tests.py`, no trace on failure |
| D10 | **Dependencies, CI, secrets** | version ranges, secrets or URLs in the repo, waves with no CI schedule |
| D11 | **Gaps** | a blocking gap (hook, test id, fixture) with no owner, or one the plan calls Ready |
| D12 | **Diagrams** ([design-diagrams.md](../../../../standards/methods/design-diagrams.md) §4) | a layer diagram, run-phase flow or required builder chain missing; a node, arrow or name that disagrees with its table; a data plan without its set dependency and run order diagram |
| D13 | **UI flow level ownership (R9)** | an IT flow is outside `flows/it/<module>/`, an ST flow is outside `flows/st/`, a cross-level helper is outside `flows/shared/`, or an IT flow imports an ST flow (or vice versa) |

Priority per P2 of the protocol (column after Severity; default High → P1, Med → P2, Low → P3). Severity: **High** = a Ready spec can't be written from the design, or the design makes a test unable to fail (D5);
**Med** = a rule break that costs copying or rework later (D2, D3, D6); **Low** = wording, missing detail.
Review file: `automation/docs/reviews/<YYYY-MM-DD>-<pack>-design.md` (dated, kept), finding IDs `AD-` (ST `SAD-`), from [../assets/design-review.md](../assets/design-review.md) ([output-rules.md](output-rules.md)) with the coverage line `specs a/b mapped · sets a/b built · gaps n`.
