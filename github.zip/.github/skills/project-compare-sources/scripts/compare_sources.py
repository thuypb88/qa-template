#!/usr/bin/env python3
"""Compare two folders of client documents (an old drop vs a new drop) for the project-compare-sources skill.

    python3 .claude/skills/project-compare-sources/scripts/compare_sources.py <old_dir> <new_dir>            # summary
    python3 .claude/skills/project-compare-sources/scripts/compare_sources.py <old_dir> <new_dir> --diff     # + text diffs
    python3 .claude/skills/project-compare-sources/scripts/compare_sources.py <old_dir> <new_dir> --json     # machine output
        --max-lines N   cap each printed diff (default 200; 0 = no cap)
        --context N     unified-diff context lines (default 2)
    python3 .claude/skills/project-compare-sources/scripts/compare_sources.py <original> <updated> --merge            # plan only
    python3 .claude/skills/project-compare-sources/scripts/compare_sources.py <original> <updated> --merge --apply    # do it
        --backup-dir D  where the backup zip goes (default ../<project code>-backups/)

Merge (original = the folder the analyses cite, updated = the client's new drop): back up every file of <original>
into <backup-dir>/<CODE>-<folder>-original-<YYYY-MM-DD>[-n].zip, verify it byte for byte, then copy into <original>
each only-in-new file and each changed file of the same name (overwrite; the old bytes are in the zip and git). A file
matched by version (V01R03 → V01R04) is added beside the old one, which is reported as superseded: retire it with
scripts/workspace/archive.py only after plan-changes, because analyses cite its path. Identical, renamed and
only-in-original files are left alone; nothing is deleted. Without --apply it prints the plan and writes nothing.

Pairs every file of new_dir with one of old_dir: same name, else the same name with version / date / status tokens
removed (V01R03, 20261001, -Confirmed, "(V.Deliver)", _v2 ...), else the same content (a rename). Each pair is
identical (same SHA-256), renamed (same content, new name) or changed; the rest is only-in-old / only-in-new. For a
changed pair it extracts both sides with scripts/extract_text.py (docx, xlsx, pptx, pdf, text) and diffs the text:
lines added / removed and the headings whose sections changed. Writes nothing: the skill turns the result into a
record via plan-changes. Unlike scripts/trace_changes.py (path vs the accepted baseline), this matches by content and
by document name, so a copied or re-versioned file is not reported as new. Standard library only (openpyxl optional,
pdftotext for PDF text).
"""
import argparse
import difflib
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "scripts"))
try:
    import extract_text  # noqa: E402  (workspace extractor)
except Exception:  # pragma: no cover - extractor missing or broken
    extract_text = None

TOKENS = [
    r"\(v\.?\s*deliver\)",            # (V.Deliver)
    r"v\d+r\d+",                      # V01R03
    r"(?<![a-z])v\d+(?:\.\d+)*",      # v2, v1.3
    r"r\d{2,}",                       # R03
    r"(?<!\d)20\d{6}(?!\d)",          # 20261001
    r"(?<!\d)20\d{2}[-_.]\d{2}[-_.]\d{2}(?!\d)",  # 2026-10-01
    r"-?(?:confirmed|final|draft|signed|approved|updated)",
]


def sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def key(name: str) -> str:
    """Document identity: the name without version, date and status tokens."""
    stem, dot, ext = name.lower().rpartition(".")
    if not dot:
        stem, ext = name.lower(), ""
    for t in TOKENS:
        stem = re.sub(t, "", stem)
    stem = re.sub(r"[\s_\-.()]+", "_", stem).strip("_")
    return f"{stem}.{ext}"


def files(d: Path) -> list[Path]:
    return sorted(p for p in d.rglob("*") if p.is_file() and not p.name.startswith((".", "~$")))


def text(p: Path) -> list[str] | None:
    if extract_text is None:
        return None
    try:
        lines = extract_text.extract(p)
    except Exception:
        return None
    if lines is None:
        return None
    # drop the extractor's own header lines that carry hash / generation time
    return [l for l in lines if not re.match(r"^>?\s*\**(generated on|source hash|sha256)", l, re.I)]


def text_diff(old: Path, new: Path, context: int) -> dict:
    a, b = text(old), text(new)
    if a is None or b is None:
        return {"available": False, "reason": "text not extractable (format or missing tool)"}
    diff = list(difflib.unified_diff(a, b, f"old/{old.name}", f"new/{new.name}", n=context, lineterm=""))
    added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
    removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
    # headings whose section changed: the nearest preceding heading of each changed new-side line
    heads, cur, changed = [], None, []
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    head_at = {}
    for i, l in enumerate(b):
        if l.startswith("#"):
            cur = l.lstrip("#").strip()
        head_at[i] = cur
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag != "equal":
            h = head_at.get(min(j1, len(b) - 1)) if b else None
            if h and h not in changed:
                changed.append(h)
    return {"available": True, "lines_old": len(a), "lines_new": len(b), "added": added, "removed": removed,
            "editorial_only": added == 0 and removed == 0, "sections_changed": changed, "diff": diff}


def compare(old_dir: Path, new_dir: Path, context: int, want_diff: bool) -> dict:
    old, new = files(old_dir), files(new_dir)
    old_h = {p: sha(p) for p in old}
    new_h = {p: sha(p) for p in new}
    left = set(old)
    rows = []

    def take(n: Path, o: Path, how: str):
        left.discard(o)
        same = old_h[o] == new_h[n]
        status = ("identical" if o.name == n.name else "renamed") if same else "changed"
        row = {"status": status, "matched_by": how, "old": str(o.relative_to(old_dir)),
               "new": str(n.relative_to(new_dir)), "old_size": o.stat().st_size, "new_size": n.stat().st_size,
               "old_sha": old_h[o][:16], "new_sha": new_h[n][:16]}
        if not same:
            d = text_diff(o, n, context)
            if not want_diff:
                d.pop("diff", None)
            row["text"] = d
        rows.append(row)

    pending = []
    for n in new:  # 1) same relative path / name
        o = next((o for o in left if o.relative_to(old_dir) == n.relative_to(new_dir)), None) \
            or next((o for o in left if o.name == n.name), None)
        if o:
            take(n, o, "name")
        else:
            pending.append(n)
    rest = []
    for n in pending:  # 2) same content
        o = next((o for o in left if old_h[o] == new_h[n]), None)
        if o:
            take(n, o, "content")
        else:
            rest.append(n)
    for n in rest:  # 3) same document identity (version / date stripped)
        cands = [o for o in left if key(o.name) == key(n.name)]
        if len(cands) == 1:
            take(n, cands[0], "version")
        else:
            rows.append({"status": "only-in-new", "new": str(n.relative_to(new_dir)), "new_size": n.stat().st_size,
                         "new_sha": new_h[n][:16],
                         "note": f"{len(cands)} old candidates share its name key" if cands else ""})
    for o in sorted(left):
        rows.append({"status": "only-in-old", "old": str(o.relative_to(old_dir)), "old_size": o.stat().st_size,
                     "old_sha": old_h[o][:16]})
    counts = {}
    for r in rows:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    return {"old_dir": str(old_dir), "new_dir": str(new_dir), "counts": counts, "files": rows}


ORDER = ["changed", "only-in-new", "only-in-old", "renamed", "identical"]


def show(res: dict, want_diff: bool, max_lines: int) -> None:
    print(f"# Compare sources\n\nold: {res['old_dir']}\nnew: {res['new_dir']}\n")
    print("Counts: " + " · ".join(f"{k} {res['counts'].get(k, 0)}" for k in ORDER) + "\n")
    print("| Status | Old | New | Matched by | Size old → new | Text |")
    print("|---|---|---|---|---|---|")
    for r in sorted(res["files"], key=lambda r: (ORDER.index(r["status"]), r.get("new") or r.get("old"))):
        t = r.get("text")
        if t is None:
            tx = "—"
        elif not t["available"]:
            tx = t["reason"]
        elif t["editorial_only"]:
            tx = "same text (binary / formatting only)"
        else:
            tx = f"+{t['added']} / -{t['removed']} lines"
        size = f"{r.get('old_size', '—')} → {r.get('new_size', '—')}"
        print(f"| {r['status']} | {r.get('old', '—')} | {r.get('new', '—')} | {r.get('matched_by', '—')} | {size} "
              f"| {tx}{' · ' + r['note'] if r.get('note') else ''} |")
    for r in res["files"]:
        t = r.get("text")
        if not t or not t.get("available") or t["editorial_only"]:
            continue
        print(f"\n## {r['new']}\n\nSections changed ({len(t['sections_changed'])}): "
              + ("; ".join(t["sections_changed"][:40]) or "(before the first heading)"))
        if want_diff:
            d = t["diff"]
            cap = d if not max_lines else d[:max_lines]
            print("\n```diff\n" + "\n".join(cap) + "\n```")
            if len(cap) < len(d):
                print(f"... {len(d) - len(cap)} more diff lines (raise --max-lines)")


def merge_plan(res: dict) -> tuple[list[tuple[str, str, str]], list[str]]:
    """(action, updated rel path, original rel path) to copy, and the superseded originals."""
    acts, superseded = [], []
    for r in res["files"]:
        if r["status"] == "only-in-new":
            acts.append(("add", r["new"], r["new"]))
        elif r["status"] == "changed" and r["matched_by"] == "name":
            acts.append(("overwrite", r["new"], r["old"]))
        elif r["status"] == "changed":
            acts.append(("add (new version)", r["new"], r["new"]))
            superseded.append(r["old"])
    return acts, superseded


def backup(orig: Path, backup_dir: Path) -> Path:
    import datetime as dt
    import zipfile
    code = "PROJECT"
    try:
        cfg = json.loads((ROOT / "project.json").read_text(encoding="utf-8"))
        code = (cfg.get("project") or {}).get("code") or cfg.get("code") or code
    except Exception:
        pass
    backup_dir.mkdir(parents=True, exist_ok=True)
    base = f"{code}-{orig.name}-original-{dt.date.today().isoformat()}"
    z, n = backup_dir / f"{base}.zip", 2
    while z.exists():
        z, n = backup_dir / f"{base}-{n}.zip", n + 1
    src = files(orig)
    rel = lambda p: str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p.relative_to(orig.parent))
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as f:
        for p in src:
            f.write(p, rel(p))
    with zipfile.ZipFile(z) as f:
        for p in src:
            if hashlib.sha256(f.read(rel(p))).hexdigest() != sha(p):
                raise SystemExit(f"backup verify failed for {p}; nothing merged")
    return z


def merge(a) -> int:
    import shutil
    orig, upd = a.old_dir.resolve(), a.new_dir.resolve()
    res = compare(orig, upd, a.context, False)
    acts, superseded = merge_plan(res)
    print(f"# Merge {upd.name} → {orig.name}\n")
    print("Counts: " + " · ".join(f"{k} {res['counts'].get(k, 0)}" for k in ORDER) + "\n")
    if not acts:
        print("Nothing to merge: every file of the update is already in the original.")
        return 0
    bdir = a.backup_dir or ROOT.parent / f"{ROOT.name}-backups"
    print("| Action | From (updated) | To (original) |\n|---|---|---|")
    for act, s, d in acts:
        print(f"| {act} | {s} | {d} |")
    for s in superseded:
        print(f"\nSuperseded (kept; retire with scripts/workspace/archive.py after plan-changes): {s}")
    if not a.apply:
        print(f"\nPlan only. Backup would go to {bdir}/. Re-run with --apply to back up and merge.")
        return 0
    z = backup(orig, bdir)
    print(f"\nBackup: {z} ({len(files(orig))} files, verified)")
    for _, s, d in acts:
        dst = orig / d
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(upd / s, dst)
    after = compare(orig, upd, a.context, False)
    clean = not after["counts"].get("changed") and not after["counts"].get("only-in-new")
    print(f"Merged {len(acts)} file(s). Re-check: " + " · ".join(f"{k} {v}" for k, v in after["counts"].items())
          + ("" if clean else "  ← not clean: re-run without --merge and read the table"))
    return 0 if clean else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("old_dir", type=Path)
    ap.add_argument("new_dir", type=Path)
    ap.add_argument("--diff", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--max-lines", type=int, default=200)
    ap.add_argument("--context", type=int, default=2)
    ap.add_argument("--merge", action="store_true")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--backup-dir", type=Path)
    a = ap.parse_args()
    for d in (a.old_dir, a.new_dir):
        if not d.is_dir():
            print(f"not a folder: {d}", file=sys.stderr)
            return 2
    if a.apply and not a.merge:
        print("--apply needs --merge", file=sys.stderr)
        return 2
    if a.merge:
        return merge(a)
    res = compare(a.old_dir.resolve(), a.new_dir.resolve(), a.context, a.diff or a.json)
    if a.json:
        print(json.dumps(res, indent=1, ensure_ascii=False))
    else:
        show(res, a.diff, a.max_lines)
    return 0


if __name__ == "__main__":
    sys.exit(main())
