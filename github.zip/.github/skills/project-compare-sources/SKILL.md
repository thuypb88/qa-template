---
name: project-compare-sources
description: Project (both levels, every pack): take in a client's updated document drop - compare the updated folder (e.g. sources/requirements/BRD_updated_<date>) with the original folder the analyses cite (e.g. sources/requirements/BRD), back up the original, merge the update into it, and hand off to plan-changes. Pairs files by name, content or document identity (version / date / status tokens stripped), classifies identical / renamed / changed / only-in-original / only-in-new, diffs the changed text. Modes compare (read-only) and merge (verified backup zip, then copy). Use for "compare the BRD folders", "check the latest BRD vs the old one", "what's different in the new drop", "backup BRD and merge the update", "merge BRD_updated into BRD", "so sánh tài liệu", "so sánh BRD", "cập nhật BRD". Not for: the whole pipeline after a drop → project-source-update; the impact on analyses / TCs and the change record → plan-changes; one file vs the accepted baseline → plan-changes.
metadata:
  group: project
  order: "0"
---

# Project: compare and merge an updated source drop

> **Created:** 2026-10-26 08:58:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** two folders under `sources/`: the **original** (the one `project.json` and the analyses cite, e.g.
`sources/requirements/BRD`) and the **updated** drop the client sent (e.g. `sources/requirements/BRD_updated_<YYYYMMDD>`).
**Out:** compare → a chat answer only; merge → a verified backup zip in `../<CODE>-backups/`, the original folder
updated. **Rules:** core R1 (every figure from the script; no assumed meaning for a new file),
[conventions §11](../../../standards/conventions.md#11-archive-dont-delete) (archive, never delete). **Next:** `plan-changes` (stage 1 of `project-source-update`).
**Stop if** a folder is missing / empty, or it is unclear which folder is the original → ask the user.
**Output:** [assets/compare-answer.md](assets/compare-answer.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

Why this exists: `scripts/trace_changes.py` keys on paths against the accepted baseline, so a new folder that copies
or re-versions old files shows every file as *added*. This script matches by content and by document name.

Script: `S=.claude/skills/project-compare-sources/scripts/compare_sources.py` (original first, updated second).

## Pipeline

1. **Compare** (read-only): `python3 $S <original> <updated>` → counts and one row per file; `--diff` for the text
   diffs (capped by `--max-lines`), `--json` for machine output. Report per status:
   - **identical / renamed:** no content change; the duplicate copy is housekeeping, not a requirement change.
   - **changed:** read *Sections changed* and the diff, not the whole document (`slice.py` for context). A pair
     matched by `version` is a new document version: confirm the pairing before trusting the diff. "Same text" on
     a changed binary = formatting / images only.
   - **only-in-new:** what it is from its name and first page only (`extract_text.py <file>` → `slice.py toc`), and
     whether a module reads it (`trace_changes.py` › read_by). Not a test basis until `plan-changes` accepts it.
   - **only-in-original:** dropped from the new set; ask whether it is withdrawn or just not re-sent.
2. **Merge plan:** `python3 $S <original> <updated> --merge` prints the actions (add · overwrite · add new version)
   and the superseded files, writing nothing. Show it to the user.
3. **Back up and merge** on the user's OK: `python3 $S <original> <updated> --merge --apply`. It zips every file of
   the original to `../<CODE>-backups/<CODE>-<folder>-original-<date>[-n].zip`, verifies each file byte for byte
   (on failure nothing is merged), copies the files, then re-compares; exit 1 = not clean, read the table.
   The original's old bytes are also in git (`git log -- <original>`).
4. **Superseded versions** (V01R03 beside a new V01R04) stay in place: analyses cite their path. They are retired
   with `python3 scripts/workspace/archive.py <file> --reason "superseded by <new>" --ref <change-impact record>`
   only after `plan-changes`, on the user's OK.
5. **The updated folder** is now a duplicate. Offer to retire it with `archive.py` (moves it to `archive/`, indexed);
   never `rm` it.
6. **Answer** from [assets/compare-answer.md](assets/compare-answer.md): the comparison table, the backup path, what was merged, the open questions, and **Next:**
   `/plan-changes` (extract the new / changed files, trace the impact, write the record, accept the baseline).
   Commit only when the user asks: `sources/<folder>: merge <updated> (<n> added, <n> overwritten)`.

## Rules

- Never write under `sources/` without the merge plan shown and the user's OK; never delete there.
- A changed value is never called editorial without reading the diff lines.
- Do not accept the source baseline or edit analyses / TCs here; that is `plan-changes` and the writers it names.

## Done when

- [ ] Compare run; every row of the answer traced to its output; each changed / new / dropped file has a
      conclusion or a question.
- [ ] Merge (if asked): plan shown and agreed; backup zip verified; re-check clean (no changed / only-in-new left);
      superseded files and the duplicate updated folder listed for archiving, not removed.
- [ ] One **Next** named (`plan-changes`), not run.
