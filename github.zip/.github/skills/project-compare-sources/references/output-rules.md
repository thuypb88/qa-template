# project-compare-sources: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Fill [../assets/compare-answer.md](../assets/compare-answer.md). Linked, never copied:
[core-rules.md](../../../../standards/core-rules.md) R1 ·
[conventions.md](../../../../standards/conventions.md) §11 (archive, never delete) ·
[ADR-002](../../../../project/decisions/ADR-002-updated-source-drops-merge-into-original.md).

| Output | Where | Write mode |
|---|---|---|
| comparison | chat | compare mode: nothing written |
| backup | `../<CODE>-backups/<CODE>-<folder>-original-<date>[-n].zip` | by `compare_sources.py --merge --apply` only, verified byte for byte |
| merged folder | the original `sources/<folder>` | by the script, on the user's OK |
| retired files | `archive/<date>-<slug>/` | `archive.py` only, on the user's OK; never `rm` |

## Rules

- **Every figure** from the script; a new file's meaning only from its name and first page, never assumed.
- The merge plan is shown before `--apply`; superseded versions stay in place until `plan-changes`.
- Commit only when the user asks: `sources/<folder>: merge <updated> (<n> added, <n> overwritten)`.
