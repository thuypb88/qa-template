<!-- Template: project-compare-sources answer (chat). Figures from scripts/compare_sources.py only. Replace every
<placeholder>; delete this comment. Rules: ../references/output-rules.md. -->
**Compare** `<original>` ↔ `<updated>` · identical <n> · renamed <n> · changed <n> · only-in-new <n> · only-in-original <n>

| File | Status | What changed (sections / first page) | Read by |
|---|---|---|---|
| <file> | <identical \| renamed \| changed \| only-in-new \| only-in-original> | <…> | <modules or —> |

**Merge:** <plan only (add <n> · overwrite <n> · new version <n>) | applied — backup `../<CODE>-backups/<zip>` verified, re-compare clean>
**Superseded (kept until plan-changes):** <files>
**Questions:** <only-in-original: withdrawn or not re-sent? · pairings to confirm>
**Next:** `/plan-changes`
