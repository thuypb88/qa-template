<!-- Template: project-overview-poster report (chat). Replace every <placeholder>; delete this comment. Rules: ../references/output-rules.md. -->
**Poster:** <link>
**File:** plans/architecture/<topic>-overview-poster.html
**Main message:** <one sentence>
**Left out:** <what, and why>
**Assumed:** <scope, audience, assumptions>
**Check before sharing:** <assumed rules, open question IDs, approximate numbers>
**Sharing:** the link is private until you share it from the page's Share menu; the file isn't committed yet, and once it is, everyone with the repo can read it.
