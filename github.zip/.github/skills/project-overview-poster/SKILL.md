---
name: project-overview-poster
description: "Project (writer, both levels, every pack): one simple, one-page infographic poster of a module, the system test, the automation, a flow or project status, from the workspace's real facts, published as a private design canvas and saved to plans/architecture/. Use for \"poster\", \"infographic\", \"one-pager\", \"visual overview\", \"big picture\", \"overview like this image\", \"explain AP on one page\", \"show the framework simply\". Not for: a slide deck → project-training-deck; a roadmap or next step → flow-roadmap or flow-next; a test report → run-report."
metadata:
  group: project
  order: "-"
---

# Project: overview poster

> **Created:** 2026-11-02 13:27:46 · **Updated:** 2026-11-02 15:43:58 (UTC+7)

**In:** a topic (`AA`, `AP`, `AR`, `BG`, `GL`, `PU`, `st`, `automation`, `workspace` or a named flow), and optionally a sample image for style. **Out:** one private design canvas with one artboard, its standalone copy `plans/architecture/<topic>-overview-poster.html`, and both in chat. **Rules:** [core-rules.md](../../../standards/core-rules.md) R1; project values from `project.json`. **Next:** none.
**Stop if** the topic can't be identified → ask the user. Never fill a gap by guessing.
**Output:** [assets/poster.dc.html](assets/poster.dc.html), [assets/poster-answer.md](assets/poster-answer.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

Read lean: `slice.py toc` → `section`; never a whole file over ~40 KB. Read the lessons that name this skill.

## Simple means

A reader gets the main idea in 30 seconds and each panel in 10, so choosing what to leave out is the main job.

- One headline message, in one sentence, chosen before any design. Every panel supports it.
- Six panels by default, nine at most. If more seem needed, narrow the topic or offer a second poster.
- Under about 30 words a panel. Prefer a flow, small table or number to a paragraph.
- At most five headline numbers, and only ones that change a decision.
- No code, config or long file trees, unless the poster is about them; then 8 lines at most.

## Infographic means

The picture carries the message and the words only label it.

- Each panel is built around one visual: a to-scale bar, a split bar, a numbered flow, a layer stack, an icon number or status chips. A panel that is only sentences becomes one of these or goes.
- Choose the visual by what the data does: stages that shrink → funnel bars · parts of one whole → split bar · order of work → numbered flow · structure → layer stack · one figure → icon number · state → status chips.
- At least one chart is drawn to scale from the real numbers, and it sits high on the poster.
- Every value is printed beside its mark, so nobody has to estimate it from the shape.

## Steps

1. **Fix the scope:** topic, audience (QA lead, client BA, developer, new tester) and headline message. Decide reasonable gaps yourself and state them in the reply.
2. **Gather facts from the source, not memory.** Read only what the topic needs:

   | Topic | Read |
   |---|---|
   | Module | `python3 scripts/pipeline_status.py <id>`, `python3 scripts/slice.py tc <id> --stats`, the toc of its `test-design/it/MOD-*/1-analysis.md` and `0-scope.md`, its rows in `project/status.md` and `project/questions.md` |
   | System test | `python3 scripts/pipeline_status.py st`, the toc of `test-design/st/1-analysis.md`, its rows in `project/status.md` |
   | Automation | `automation/README.md`, `automation/docs/<pack>-design.md`, the latest `automation/docs/reviews/`, `python3 scripts/run_tests.py all --plan` |
   | Workspace or project | `README.md`, `project.json`, `project/index.md`, `project/status.md`, `python3 scripts/roadmap_status.py` |

   Compute counts with a script rather than copying them from a document that may be out of date.
3. **Choose the panels and each one's visual,** starting with what the reader most needs: what it is · where it fits · main flow · parts or layers · who does what · key rules · data · integrations · status today · risks or blockers · next steps.
4. **Check each claim:** can you point to the file or command behind it? Keep today and target apart with the status labels in the output rules. Mark unsure numbers "approximate" or leave them out. If two status sources disagree, read both, recommend one, and say so in the reply.
5. **Build it.** Use the `Artifact` tool: `action: "quickstart"`, `intent: "design"`, and follow what it returns. Start from the template: fill the header and numbers, compute each bar's width from its value, keep only the visuals you need, and set the frame to fit the content (default 1600 × 1500). With no canvas type or `Artifact` tool, skip the canvas and write the file of step 6 directly.
6. **Save the copy** to `plans/architecture/<topic>-overview-poster.html`: the same content, as plain HTML that opens alone (shape in the output rules). If Playwright is available, render it once at the frame size and look for clipped text.
7. **Report** with [assets/poster-answer.md](assets/poster-answer.md).

## Rules

- Open points stay open on the poster, with their question ID. A poster decides nothing.
- A sample image is a style cue. Drop any tool or practice the project doesn't use, even if the sample shows it.
- Present it as a QA working document, never as an official client or vendor publication.
- The leave-out list in the output rules applies unless the user asks otherwise, because posters get shared.

## Pitfalls

- **Too much (2026-11-02).** A 14-panel framework poster with config and a file tree was accurate but too dense for a quick read. When in doubt, cut.
- **One status source (2026-11-02).** A status script and the project notes named different next steps for one module, and the notes changed the headline. Read both.
- **Text in boxes (2026-11-02).** The first automation poster was accurate, but most of its panels were lines of text in cards, and it showed a shrinking funnel as equal-sized tiles, which hid how steep the drop was. Draw numbers to scale.

## Done when

- [ ] The headline message is one sentence, and the poster shows it.
- [ ] 9 panels or fewer, each under about 30 words, except a compact table or flow.
- [ ] Each panel is built around one visual, at least one chart is to scale, and every charted value is printed.
- [ ] Every number and claim traces to a file or command from this run, and the as-of date is shown.
- [ ] Today and target are clearly separate.
- [ ] Nothing from the leave-out list appears without the user's request.
- [ ] The copy in `plans/architecture/` opens alone and matches the canvas.
- [ ] The link, the file path, the assumptions and the sharing note are in the reply.
