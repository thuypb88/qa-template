# project-overview-poster: output rules

> **Created:** 2026-11-02 13:27:46 · **Updated:** 2026-11-02 15:43:58 (UTC+7)

Fill [../assets/poster.dc.html](../assets/poster.dc.html) and [../assets/poster-answer.md](../assets/poster-answer.md). Linked, never copied: [core-rules.md](../../../../standards/core-rules.md) R1.

| Output | Where | Write mode |
|---|---|---|
| poster | a private design canvas (none available: the file below only) | new canvas per poster; update the same one for a revision |
| poster copy | `plans/architecture/<topic>-overview-poster.html`, `<topic>` in lower case (`aa`, `st`, `automation`, a flow's slug) | new file per topic; replace it for a revision, git keeps the earlier version |
| report | chat | nothing written |

## Rules

- **Facts only.** No invented numbers, features or dates. Unknown → a labelled gap such as `[not confirmed]`.
- **As-of date** in the header, because status goes out of date quickly.
- **Status labels,** with words so meaning never rests on colour alone:

  | Label | Means |
  |---|---|
  | `BUILT` | exists, with evidence |
  | `NEEDS FIX` | exists, with a known defect or stale basis |
  | `PLANNED` | doesn't exist yet |
  | `BLOCKED` | waits on someone else, with the owner named nearby |

- **Charts:**
  - Bar widths and split-bar segments are computed from the values, never drawn by eye. A tiny value keeps a 4px stub; a zero draws nothing. No pie, 3D or second axis.
  - Split-bar colours, in this order: `#2A78D6`, `#EB6834`, `#1BAF7A`, `#6250D6` (checked for colour blindness). Four parts at most; fold the rest into "Other". `#1BAF7A` is under 3:1 on white, so the legend with its values always stays.
  - Text is never in a chart colour. Values and labels stay in the text colours.
- **Icons:** inline stroke SVG, one per number, showing what the number counts. No emoji or decoration.
- **Leave out by default:** the client's name and branding, real or customer data, staff IDs, internal URLs, credentials, and detailed business rules or form contents. Add them only when the user asks. Project name and code come from `project.json`, never hard-coded.
- **Language:** `project.json › project.document_language`. UI labels stay exactly as shown.
- **Poster copy shape:** the artboard's `.dc.html` needs the editor to render, so the copy keeps its content and inline styles and drops the editor parts: `<helmet>` contents move to `<head>`, the root `<div>` goes directly in `<body>`, and `support.js`, `<x-dc>` and the `data-dc-script` block go. Under the doctype, one comment: `<!-- Created: YYYY-MM-DD HH:mm:ss · Updated: YYYY-MM-DD HH:mm:ss (<timezone>). Standalone copy of the design canvas <link>. Status as of YYYY-MM-DD. -->` (no canvas: leave out the sentence that names it).
- **Index:** `plans/README.md` › Records has one row for all posters; nothing to add per poster.
- **Commit:** the copy goes in git with the user's next change set, when they ask. It's readable by everyone with the repo, so the leave-out list matters as much as for the link.
