<!-- Template: req-review. Copy to plans/requirement-reviews/<YYYY-MM-DD>-<slug>.md, replace every <placeholder>, delete
this comment. Rules: ../references/output-rules.md. -->
# Requirement review — <document title> v<version>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

## Summary

**Reviewed:** <documents and versions> · **Requirements walked:** <n> · **Findings:** <n> (missing rule <n> · missing
material <n> · ambiguous <n> · conflict <n> · untestable <n> · stale <n>; P1 <n> · P2 <n> · P3 <n>)

**Ask first:**
1. RQ-<NNN>: <question>

**Cannot start until answered:** <test design items blocked>

## Findings

| RQ | Requirement | Quoted phrase (cited) | Kind | Readings / Evidence A–B | Impact on testing | Priority | Question | Owner | Blocks |
|---|---|---|---|---|---|---|---|---|---|
| RQ-001 | <REQ-ID> | "<phrase>" [KEY:line] | <kind> | <A: … · B: …> | <what cannot be tested> | <P1 \| P2 \| P3> | <smallest deciding question, with options> | <owner> | <IDs> |

## Clean requirements

<Requirements with no finding, listed so the reader knows they were walked.>
