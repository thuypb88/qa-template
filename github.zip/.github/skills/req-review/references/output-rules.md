# req-review: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing the review. Copy [../assets/requirement-review.md](../assets/requirement-review.md), replace every
`<placeholder>`, delete the template comment. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1 · [requirement-quality.md](../../../../standards/methods/requirement-quality.md) (§2 kinds, §6 questions, §8 stories,
§9 use cases) · [conventions.md](../../../../standards/conventions.md) (stamp).

| Output | File | Write mode |
|---|---|---|
| review | `plans/requirement-reviews/<YYYY-MM-DD>-<slug>.md` | new dated file per review, kept |
| questions | `project/questions.md` (Folder = the module or `project`; the RQ ID in Topic) | on the user's OK |
| log | `project/log.md` | one line |

## Rules

- **Summary first:** documents and versions, counts by kind and priority, the 3–5 questions to ask first, what cannot
  start until they are answered.
- **Findings** one per root problem, IDs `RQ-NNN` from 001; columns fixed as in the template. Kind one of missing
  rule / missing material / ambiguous / conflict / untestable / stale; an ambiguous row gives ≥ 2 readings; a
  conflict cites both sides.
- **Priority** by what it blocks: P1 = blocks a P1 behaviour's tests or a hand-off.
- Proposed wording only as an option for the owner; the client's text is never rewritten.
- Clean requirements are listed as clean; no manufactured findings.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
