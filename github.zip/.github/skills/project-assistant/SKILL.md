---
name: project-assistant
description: Project (assistant): the QA's front door - map and explain the workspace, show where the project stands, list what to do, analyse project data, keep notes and the work log. Modes discover (map the workspace, what changed since) · ask (a file, rule, ID or skill) · status (phase, folders, deliverables, questions, defects, risks, hours) · todo (prioritised tasks, each to one skill or person) · analyze (questions, effort vs estimate, trend, risks) · note (project/notes.md, routed) · log (project/worklog.md, drafted from git). Use for "discover this workspace", "what's in this project", "what changed since Monday", "project dashboard", "monitor the project", "my task list", "analyse the questions", "note this", "log 3h on AA", "what did I do this week", "trợ lý dự án", "việc cần làm", "ghi chú", "nhật ký công việc". Not for: the one next pipeline step → flow-next; the roadmap → flow-roadmap; a day / sprint / release → flow-cadence; explaining to another audience → learn-explain; a formal report → run-report.
metadata:
  group: project
  order: "-"
---

# Project: assistant (discover · ask · status · todo · analyze · note · log)

> **Created:** 2026-10-22 15:45:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `python3 .claude/skills/project-assistant/scripts/assistant.py <discover [--since] [--path] | status | todo | analyze
[topic] | log --draft> [--json]` (read-only; it calls `pipeline_status.py`, `roadmap_status.py`, `test_estimate.py` and git), `project.json`,
`project/` (index, status, questions, defects, notes, worklog, lessons), `plans/roadmap.md`, `plans/estimation.json`,
`CLAUDE.md`, `USER-GUIDE-TFM.md`, `USER-GUIDE.md`, `.claude/skills/README.md`, `standards/conventions.md`. **Out:** a chat answer; only
modes note and log write — `project/notes.md`, `project/worklog.md` — and only after the user confirms the rows; on
request `plans/insights/<date>-<slug>.md` (analyze). **Rules:** core R1 (no invention: every figure from the script or
a file opened), [conventions](../../../standards/conventions.md) §1–2, §10 (dates, formats), stamps. **Next:** the
one skill an item names, only on the user's go-ahead.
**Stop if** there is no workspace yet (`project.json` missing, `project.code` is `CHANGE-ME`, no modules) →
`plan-setup`.
**Output:** [assets/analyze-answer.md](assets/analyze-answer.md) · [assets/ask-answer.md](assets/ask-answer.md) · [assets/discover-answer.md](assets/discover-answer.md) · [assets/note-row.md](assets/note-row.md) · [assets/status-answer.md](assets/status-answer.md) · [assets/todo-answer.md](assets/todo-answer.md) · [assets/worklog-row.md](assets/worklog-row.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Modes — read only the one you run

| Mode | When | Reference |
|---|---|---|
| **discover** | "discover / map the workspace", "what's in this project", "what's in plans/", "what changed since …", back after time away | [references/discover.md](references/discover.md) |
| **ask** | "how does …", "what is …", "where is …", "which skill …", a new team member | [references/ask.md](references/ask.md) |
| **status** | "project dashboard", "status board", "monitor the project" (the one next step → `flow-next`) | [references/monitor.md](references/monitor.md) |
| **todo** | "my task list", "what's pending", "tasks this week" (a day plan → `flow-cadence`) | [references/monitor.md](references/monitor.md) |
| **analyze** | "analyse", "how many questions per owner", "effort vs estimate", "trend", "risks" | [references/analyze.md](references/analyze.md) |
| **note** | "note this", "meeting notes", "the PM said …", "remember for the project" | [references/journal.md](references/journal.md) |
| **log** | "log 2h …", "what did I do this week", "timesheet", "fill my worklog" | [references/journal.md](references/journal.md) |

Infer the mode from the request; several in one request run in the order above. Say which mode you run.

## Steps

1. **Workspace?** Check the Stop-if. Read `project/index.md` › Now (what scripts can't see).
2. **Evidence:** run the script for the mode (`discover`, `status`, `todo`, `analyze <topic>`, `log --draft`); for ask, open the
   files the reference names. Read lean: `python3 scripts/slice.py toc` → `section`; never a file over ~40 KB whole.
3. **Run the mode** from its reference.
4. **Write** (note, log only): show the exact rows first; write on the user's OK with the next free ID, set the
   Updated stamp, add a `project/log.md` line only when a note was routed into another register.
5. **Answer and hand off:** the result in the reference's format, then at most one **Next:** `/<skill> <target>`
   (or the person to ask). Do not run the next skill here.

## Rules

- **Read-only by default.** Only notes and the worklog are written here; every other register belongs to its skill
  (questions → the writer that found them, ADRs → `learn-retro`, roadmap → `flow-roadmap`, defects → `run-defects`).
  A note that belongs elsewhere is *routed* — copied there with a back-reference — never left to stand in for it.
- **Agree with the scripts.** The top pipeline item of todo is what `flow-next` would say (same `pipeline_status.py`);
  a gate or phase is what `roadmap_status.py` says. When a hand-written file disagrees (roadmap §4 lists done work, a
  stale count), say so and name the skill that refreshes it.
- **A note is never a test basis** (R1). A requirement heard in a meeting becomes a test basis only through
  `sources/` → `plan-changes`.
- **Hours are the person's.** The script drafts rows from git with Hours `?`; never fill hours, a person's name or
  their pronouns by guess. Rows are appended, never edited (a correction is a new row).
- **Shared memory.** Notes and worklog live in `project/` (git) for every agent and person; personal agent memory
  keeps at most a pointer.

## Done when

- [ ] Mode named; its script run (or, for ask, the files opened) and every figure traced to it.
- [ ] Note / log: rows shown, confirmed, appended with the next free ID; Updated stamp set; routed notes carry the
      target ID.
- [ ] One **Next** (skill + target, or a person), with its evidence; nothing else run.
