# Mode discover — map the workspace

> **Created:** 2026-10-22 17:30:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

For a QA who wants to see what is in the workspace before asking about any one part: a newcomer, someone back after
time away, or anyone asking "what's in `plans/`?". Discover shows **what exists and who owns it**; status shows
**progress**; ask explains **one thing**.

## Run

| Request | Command |
|---|---|
| The whole workspace | `python3 .claude/skills/project-assistant/scripts/assistant.py discover` |
| What changed since a date ("since Monday", "since I was away") | `… discover --since YYYY-MM-DD` (default: 7 days) |
| One folder ("what's in plans/", a module folder) | `… discover --path <folder>` |

Add `--json` to read the fields. The script reads only tracked files (`git ls-files`); it lists untracked ones
separately.

## What the script gives

- **Areas:** each top-level folder with file count, size, owner mix, last change and purpose. Owners follow
  [conventions §1](../../../../standards/conventions.md#1-folder-ownership): `template` (change in the template, or here
  first in a template-first project), `project`, `client` (`sources/`, never edited), `generated` (made by a script —
  never edited by hand), `archive`.
- **Client documents:** each file in `sources/`, size, whether it has a parsed copy, the date it was added.
- **Test design:** per level folder, which chain files exist and which are still missing; TC count and version.
- **Registers:** row counts of questions, decisions, rules, follow-ups, lessons, defects, notes, worklog, log,
  change-impact records, glossary terms, risks.
- **Skills and scripts:** template skills by group, project skills, QA scripts.
- **Recent:** commits since the date, hand-written files changed per area (generated copies left out), the latest
  five commits.
- **Empty or not started** and **large files** (over 40 KB: read them with `scripts/slice.py`, never whole).

## Answer

Turn the map into a guided view; don't paste the whole output.

Fill [../assets/discover-answer.md](../assets/discover-answer.md); rules: [output-rules.md](output-rules.md).

- **Order by the reader's need:** a newcomer gets work areas first (`sources/`, `project/`, `plans/`, `test-design/`,
  `deliverables/`), plumbing last (`scripts/`, `.claude/`, mirrors). Someone back after time away gets **Changed
  since** first.
- **Say what not to touch:** generated and client files, with what to do instead (the guard table in
  `USER-GUIDE-TFM.md` §12).
- **One folder (`--path`):** list its files by purpose (headings from the script's `title`), mark generated ones, and
  name the skill that writes each kind of file (the folder's `README.md` or conventions §1).
- Empty registers are normal early on: say which phase fills them (e.g. defects in execution), not that they are
  missing.
