# Mode analyze — project data analysis

> **Created:** 2026-10-22 15:45:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

Run `python3 .claude/skills/project-assistant/scripts/assistant.py analyze <topic> [--json]`, topic `questions`,
`effort`, `trend`, `risks` or `all`. The script counts; you interpret — and say what the counts can't show.

| Topic | Script gives | What to look for | Usual hand-off |
|---|---|---|---|
| **questions** | open / answered, by owner, by module, age (first seen in git), unassigned, blocking design | owners with many open items; modules whose analysis is next but carry many open questions; questions with no owner or date; old questions that block TCs | QA lead: give owners and dates; `req-review` to batch them for the BA |
| **effort** | per estimate activity: planned PD (with contingency), actual PD from `project/worklog.md`, % used; planned-by-today from the schedule | an activity over ~80 % used before its phase ends; work in `MGMT` / `TOOL` / `OTHER` the estimate doesn't carry; actual far below planned-by-today (late start or unlogged hours) | `plan-testplan estimate` (re-estimate with measured rates, Q- on the rates) |
| **trend** | roadmap §6 rows, change in the last row, current metrics | open questions rising while TCs stay flat; defects opened faster than closed; pending source changes that stay | `flow-roadmap update` (adds the row), `flow-roadmap health` |
| **risks** | open risks by owner and phase, questions each risk waits on | risks with owner TBD; risks whose phase has started; risks waiting on the same questions (one answer closes several) | `flow-roadmap health` |

Coverage (requirement → TC, TCOND → TC) is not computed here: for a suite use the Excel's RTM sheet or
`python3 scripts/slice.py rows <analysis> <ID>`; once suites exist, read `scripts/export_testcases.py <id> --check`.

## Answer format

Fill [../assets/analyze-answer.md](../assets/analyze-answer.md); rules: [output-rules.md](output-rules.md).

On request ("save it", "for the meeting") write `plans/insights/<YYYY-MM-DD>-<slug>.md` with the docs header and the
same content; a chart only when asked (load the `dataviz` skill first). Numbers only from the script or files.
