# Modes status and todo — trace and monitor the project

> **Created:** 2026-10-22 15:45:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

## status

Run `python3 .claude/skills/project-assistant/scripts/assistant.py status` (`--tracks` for the full board, `--json` to
read fields). It joins
`roadmap_status.py` (phases, maturity, milestones), `pipeline_status.py` (folders, deliverables, source changes) and
the `project/` registers.

Answer in this shape (one screen):

Fill [../assets/status-answer.md](../assets/status-answer.md); rules: [output-rules.md](output-rules.md).

Each design stage carries its manual / auto split, rolled up from the TC tags by `scripts/tracks.py` (design:
`plans/architecture/stage-model-manual-auto.md`): **Auto** = TCONDs / scenarios / TCs with an automated part,
**Manual** = with a manual part, **Ready** = automated part all Ready (`automation_readiness`; a suite tagged before that field falls back to
the plan's waves). "not decided" = untagged TCs or no plan → `auto-decide`.

On "auto vs manual", "tracks", "how much is automated", or when the lead plans testers and DEV in parallel, show the
**full board** (`status --tracks`): per folder a *review* row, then **Auto** (per stage, then Decide · Design ·
Written / Ready · Run), **Manual** (per stage, then Run / TCs with a manual part) and **Waiting** (by readiness: hook,
data, rewrite, question). The review row's Next is the one `flow-next` names; the track rows' Next is information.

**Watch** picks what a lead must know: a Rework verdict, a stale review, a deliverable that is stale or sent-stale,
pending source changes, questions with no owner, a risk whose phase has started, a roadmap older than its
milestones, a count that differs between the script and a hand-written file (name both).

## todo

Run `assistant.py todo`. Priorities are fixed:

| Prio | Items |
|---|---|
| 1 | Source changes pending or a `*_updated_<date>` drop folder, or a source update not through (`project-source-update`, PR-7); any Rework verdict (the writer again) |
| 2 | The pipeline's next step (= `flow-next`); deliverables not current; open defects |
| 3 | Roadmap §4 plan lines; questions to chase, per owner (unassigned → the QA lead gives owner and date); open follow-ups; the domain study due before the next analysis |
| 4 | Housekeeping: roadmap update, `learn-retro` for reviews not harvested, project / tech study topics |
| 5 | Unrouted notes; days with commits but no worklog row |

Then judge the list before you show it:

- **Drop or mark done** what a file shows is already done (e.g. a roadmap §4 line for a review whose file exists) —
  and add "roadmap §4 is behind → `/flow-roadmap update`".
- **Group per person** when the user asks "my tasks": QA lead (owners, dates, decisions, reviews), tester (design,
  execution), PM / partner (questions they own). Names only as the files write them.
- **Today / this week:** at most 5 items for a day, 10 for a week; the rest under "Later".

Fill [../assets/todo-answer.md](../assets/todo-answer.md); rules: [output-rules.md](output-rules.md).
