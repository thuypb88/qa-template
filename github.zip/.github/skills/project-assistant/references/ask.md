# Mode ask — explain the workspace

> **Created:** 2026-10-22 15:45:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

For a QA who wants to understand the workspace: a folder, a file, an ID, a rule, a skill, a check, "why was I
blocked". Answer the person who asks, at their level; for another audience ("explain to my PM") hand over to
`learn-explain`.

## Where the answer lives

| Question about | Open first | Then |
|---|---|---|
| A folder or file, where something goes | `CLAUDE.md` › Where things are | `standards/conventions.md` §1–2 (folders, names), the folder's `README.md` |
| An ID (`TCOND-`, `TS-`, `TC-`, `Q-`, `FU-`, `RK-`, `SP-`, `ADR-`, `DEF-`; `N-` notes) | `standards/conventions.md` (IDs); `N-`: `project/notes.md` | the register that holds it: `python3 scripts/slice.py rows <file> <ID>` |
| A rule (R1–R10, R-UI…, PR-n, P1–P7) | `standards/core-rules.md`, `packs/<pack>/rules.md`, `project/rules.md`, `standards/review-protocol.md` | an example in this project's artifacts |
| Which skill, in what order | `.claude/skills/README.md`, `CLAUDE.md` › The pipeline | the skill's `SKILL.md` description (its "Use for" / "Not for") |
| How to do a task step by step | `USER-GUIDE-TFM.md` (sections 2–11, 15 Recipes); the generic `USER-GUIDE.md` for template features | the skill it names |
| A script, a check, a blocked edit | `USER-GUIDE-TFM.md` §12, §16 › Scripts | `python3 <script> --help` |
| A project term or role code | `project/system-map.md` › Glossary | the cited source line in `sources/parsed/` |
| Why the project chose something | `project/decisions/`, `project/log.md` | the commit (`git log --oneline -- <file>`) |
| This project in one page | `README.md`, `project/index.md` › Now, `plans/roadmap.md` §1–2 | mode status |

## Answer format

Fill [../assets/ask-answer.md](../assets/ask-answer.md); rules: [output-rules.md](output-rules.md).

- Quote the workspace's own words for rules; link, don't paraphrase a rule into something new.
- Nothing in the files → say "not stated in the workspace" and, if it matters for testing, offer a `Q-` question.
- A newcomer asking "where do I start" → the SP-04 study row (roadmap §10) and `/flow-next`; offer a guided tour:
  `project.json` → `project/index.md` → one module folder → `USER-GUIDE-TFM.md` §1, §7.
