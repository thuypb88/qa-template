# project-assistant: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before answering or writing. The template of each mode is in [../assets/](../assets/). Linked, never copied:
[core-rules.md](../../../../standards/core-rules.md) R1 · [conventions.md](../../../../standards/conventions.md) §1–2,
§10, stamps.

| Mode | Template | Where | Write mode |
|---|---|---|---|
| discover | [discover-answer.md](../assets/discover-answer.md) | chat | — |
| ask | [ask-answer.md](../assets/ask-answer.md) | chat | — |
| status | [status-answer.md](../assets/status-answer.md) | chat | — |
| todo | [todo-answer.md](../assets/todo-answer.md) | chat | — |
| analyze | [analyze-answer.md](../assets/analyze-answer.md) | chat; on request `plans/insights/<YYYY-MM-DD>-<slug>.md` with the header stamp | new dated file |
| note | [note-row.md](../assets/note-row.md) | `project/notes.md` (+ the routed register: `Q-` / `FU-` row with `from N-NNN`) | append after the user's OK; next free `N-NNN` |
| log | [worklog-row.md](../assets/worklog-row.md) | `project/worklog.md` | append, oldest first, after the user's OK; never edit a row (a correction is a new row) |

## Rules

- **Every figure** from the mode's script or a file opened in this turn; a hand-written file that disagrees with a
  script is named, with the skill that refreshes it.
- **One Next** at the end: `/<skill> <target>` or a person to ask.
- **Rows shown before they are written;** Updated stamp set on `notes.md` / `worklog.md`; a routed note carries the
  target ID and Status **Routed**.
- **Hours, names and pronouns** are the person's; never filled by guess (Hours `?` in a draft).
- A note is never a test basis (R1).
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
