#!/usr/bin/env python3
"""Project assistant: one read-only view of the whole QA workspace for the project-assistant skill.

    python3 .claude/skills/project-assistant/scripts/assistant.py discover [--since YYYY-MM-DD] [--path DIR]   # map the workspace
    python3 .claude/skills/project-assistant/scripts/assistant.py status [--tracks] # one-screen board (--tracks: auto / manual rows)
    python3 .claude/skills/project-assistant/scripts/assistant.py todo              # prioritised task list, one skill each
    python3 .claude/skills/project-assistant/scripts/assistant.py analyze [topic]   # questions | effort | trend | risks | all
    python3 .claude/skills/project-assistant/scripts/assistant.py log --draft [--since YYYY-MM-DD]   # worklog rows from git
    add --json to any command for machine output

Reads scripts/pipeline_status.py --json, scripts/roadmap_status.py --json, scripts/test_estimate.py --json, git, and the
Markdown tables in project/ (questions, status, defects, notes, worklog, lessons) and plans/roadmap.md. Writes nothing:
the skill writes project/notes.md and project/worklog.md after the user confirms. Standard library only.
"""
import argparse
import datetime as dt
import fnmatch
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
CLOSED_DEFECT = {"closed", "rejected", "duplicate", "deferred"}
EXTRA_ACTIVITIES = {
    "MGMT": "Management, coordination, meetings with the team",
    "MEET": "Client / partner meetings, workshops",
    "STUDY": "Study: project, tech, domain (roadmap §10)",
    "TOOL": "Workspace, template, scripts, skills",
    "OTHER": "Anything else (say what)",
}


# ── helpers ──────────────────────────────────────────────────────────────────────────────────────────────────────────

def project_cfg():
    return json.loads((ROOT / "project.json").read_text(encoding="utf-8"))


def today(cfg):
    m = re.match(r"UTC([+-]\d{1,2})(?::?(\d{2}))?", cfg.get("project", {}).get("timezone", "UTC+0"))
    off = dt.timedelta(hours=int(m.group(1)), minutes=int(m.group(2) or 0)) if m else dt.timedelta()
    return dt.datetime.now(dt.timezone(off)).date()


def run_json(*args):
    try:
        out = subprocess.run([sys.executable, *args, "--json"], cwd=ROOT, capture_output=True, text=True, timeout=120)
        return json.loads(out.stdout) if out.stdout.strip() else {}
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return {}


def git(*args):
    try:
        return subprocess.run(["git", *args], cwd=ROOT, capture_output=True, text=True, timeout=60).stdout
    except OSError:
        return ""


def read(rel):
    p = ROOT / rel
    return p.read_text(encoding="utf-8") if p.exists() else ""


def cells(line):
    return [c.strip() for c in line.strip().strip("|").split("|")]


def table(text, first_header):
    """Rows (dicts) of the first Markdown table whose first header cell is `first_header`."""
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.lstrip().startswith("|") and cells(line)[0] == first_header:
            head = cells(line)
            rows = []
            for row in lines[i + 2:]:
                if not row.lstrip().startswith("|"):
                    break
                c = cells(row)
                if len(c) > len(head):  # a pipe inside the last cell
                    c = c[:len(head) - 1] + [" | ".join(c[len(head) - 1:])]
                rows.append(dict(zip(head, c + [""] * (len(head) - len(c)))))
            return [r for r in rows if any(r.values())]
    return []


def section(text, number):
    m = re.search(rf"^## {number}\. .*?$(.*?)(?=^## \d+\. |\Z)", text, re.M | re.S)
    return m.group(1) if m else ""


def module_ids(cfg):
    return [m["id"] for m in cfg.get("modules", [])]


def modules_in(text, ids):
    return sorted({i for i in ids if re.search(rf"(?<![A-Za-z]){re.escape(i)}(?![a-z])", text)})


def last_commit_date(rel):
    """ISO commit time of the last commit touching rel (comparable as text within one time zone)."""
    out = git("log", "-1", "--format=%cI", "--", rel).strip()
    return out or None


# ── collectors ───────────────────────────────────────────────────────────────────────────────────────────────────────

def questions(cfg):
    rows = []
    for r in table(read("project/questions.md"), "ID"):
        text = " ".join(r.values())
        q = r.get("Question / assumption", "")
        owner = re.search(r"Owner:\s*([^.|\n]+)", text)
        rows.append({
            "id": r.get("ID", ""),
            "answered": q.startswith("**Answered") or "**Answered" in q[:40],
            "owner": owner.group(1).strip() if owner else "unassigned",
            "blocks": r.get("Blocks", ""),
            "modules": modules_in(text, module_ids(cfg)),
            "text": re.sub(r"\*\*", "", q)[:160],
        })
    return rows


def question_age(qid):
    out = git("log", "--reverse", "--format=%ad", "--date=short", "-S", qid, "--", "project/questions.md").split()
    return out[0] if out else None


def followups():
    return [r for r in table(section(read("project/status.md"), 2), "ID")]


def defects():
    rows = table(read("project/defects.md"), "DEF ID")
    return [r for r in rows if r.get("Status", "").lower() not in CLOSED_DEFECT]


def notes():
    rows = table(read("project/notes.md"), "ID")
    return rows


def worklog():
    rows = []
    for r in table(read("project/worklog.md"), "Date"):
        try:
            h = float(r.get("Hours", "0").replace(",", "."))
        except ValueError:
            h = 0.0
        rows.append({**r, "hours": h})
    return rows


def roadmap():
    text = read("plans/roadmap.md")
    return {
        "text": text,
        "trend": table(section(text, 6), "Date"),
        "history": table(section(text, 7), "Date"),
        "risks": table(section(text, 8), "ID"),
        "plan": [ln.strip()[2:].strip("`") for ln in section(text, 4).splitlines() if ln.strip().startswith("- `")],
        "study": table(section(text, 10), "ID"),
    }


def next_id(rows, prefix, width=3):
    nums = [int(m.group(1)) for r in rows for m in [re.match(rf"{prefix}-(\d+)", r.get("ID", ""))] if m]
    return f"{prefix}-{(max(nums) + 1 if nums else 1):0{width}d}"


def reviews_after(date):
    files = [p for p in ROOT.glob("test-design/**/*review*.md")] + list(ROOT.glob("plans/*review*.md")) + \
        list(ROOT.glob("plans/*-reviews/*.md")) + list((ROOT / "test-design").glob("**/automation-review.md"))
    out = []
    for p in sorted(set(files)):
        rel = p.relative_to(ROOT).as_posix()
        d = last_commit_date(rel)
        if d and (date is None or d > date):
            out.append({"file": rel, "date": d[:10]})
    return out


# ── views ────────────────────────────────────────────────────────────────────────────────────────────────────────────

def gather():
    cfg = project_cfg()
    return {
        "cfg": cfg,
        "today": today(cfg).isoformat(),
        "pipeline": run_json("scripts/pipeline_status.py"),
        "roadmap_status": run_json("scripts/roadmap_status.py"),
        "questions": questions(cfg),
        "followups": followups(),
        "defects": defects(),
        "notes": notes(),
        "worklog": worklog(),
        "roadmap": roadmap(),
    }


def status_view(g):
    rs, pl, rm = g["roadmap_status"], g["pipeline"], g["roadmap"]
    q_open = [q for q in g["questions"] if not q["answered"]]
    hist_commits = {r.get("Commit") for r in rm["history"]}
    new_ms = [m for m in rs.get("milestones", []) if m.get("commit") and m["commit"] not in hist_commits]
    week_start = (dt.date.fromisoformat(g["today"]) - dt.timedelta(days=6)).isoformat()
    return {
        "project": g["cfg"]["project"].get("code"),
        "today": g["today"],
        "phase": rs.get("current_phase"),
        "phases": [{"id": p["id"], "name": p["name"], "status": p["status"]} for p in rs.get("phases", [])],
        "maturity": rs.get("maturity", {}),
        "folders": [{"key": f["key"], "level": f["level"],
                     "steps": {k: ("✓" + (f" {v['verdict']}" if v.get("verdict") else "")
                                   + (" · stale" if v.get("stale_review") else "") if v["exists"] else "·")
                               for k, v in f["steps"].items()},
                     "next": f["next"], "why": f["why"], "warnings": f.get("warnings", []),
                     "tracks": f.get("tracks")}
                    for f in pl.get("folders", [])],
        "source_changes": pl.get("source_changes", 0),
        "deliverables": pl.get("deliverables", []),
        "questions": {"total": len(g["questions"]), "open": len(q_open),
                      "by_owner": count(q["owner"] for q in q_open)},
        "followups_open": len(g["followups"]),
        "defects_open": len(g["defects"]),
        "defects_by_severity": count(d.get("Severity", "?") for d in g["defects"]),
        "risks_open": [r["ID"] for r in rm["risks"] if r.get("Status", "").lower().startswith("open")],
        "notes_open": [n["ID"] for n in g["notes"] if n.get("Status", "").lower() == "open"],
        "worklog_hours_7d": round(sum(w["hours"] for w in g["worklog"] if w.get("Date", "") >= week_start), 2),
        "roadmap": {"updated": stamp(rm["text"]), "last_trend": (rm["trend"] or [{}])[-1].get("Date"),
                    "milestones_not_in_history": len(new_ms)},
        "next_note_id": next_id(g["notes"], "N"),
    }


def stamp(text):
    m = re.search(r"\*\*Updated:\*\*\s*([\d-]+ [\d:]+)", text)
    return m.group(1) if m else None


def count(items):
    out = {}
    for i in items:
        out[i] = out.get(i, 0) + 1
    return dict(sorted(out.items(), key=lambda kv: (-kv[1], kv[0])))


def todo_view(g):
    st = status_view(g)
    items = []

    def add(prio, area, what, run, evidence):
        items.append({"prio": prio, "area": area, "what": what, "run": run, "evidence": evidence})

    if st["source_changes"]:
        add(1, "sources", f"{st['source_changes']} source file(s) differ from the accepted baseline", "/project-source-update",
            "pipeline_status.py")
    else:  # a traced source update whose plans / test design are still behind (PR-7)
        su = ROOT / ".claude/skills/project-source-update/scripts/source_update.py"
        if su.is_file():
            try:
                out = subprocess.run([sys.executable, "-B", str(su), "--json"], cwd=ROOT, capture_output=True,
                                     text=True, timeout=60)
                b_ = json.loads(out.stdout)
                behind = [i for i in b_["items"] if not i["done"] and not i["stage"].startswith("4")]
                if behind:
                    held = sum(1 for i in behind if i.get("held"))
                    nxt = b_.get("next") or {}
                    add(1, "sources", f"source update {Path(b_['record']).stem}: {len(behind)} item(s) behind "
                        f"({held} held on questions); ready: {', '.join(i.split(':')[0] for i in b_['ready']) or '—'}",
                        "/project-source-update", f"source_update.py · next {nxt.get('run', '—')}")
            except (OSError, ValueError, KeyError, subprocess.SubprocessError):
                pass
    order = module_ids(g["cfg"])
    folders = sorted(st["folders"], key=lambda f: (f["level"] != "IT", order.index(f["key"]) if f["key"] in order else 99))
    rework = [f for f in folders if "Rework" in json.dumps(f["steps"])]
    for f in rework:
        add(1, "pipeline", f"{f['key']}: a review says Rework", f"/{f['next']} {f['key']}", f["why"])
    first = next((f for f in folders if f["next"] and f not in rework), None)
    if first:
        add(2, "pipeline", f"{first['key']}: {first['why']}", f"/{first['next']} {first['key'].lower() if first['key'] == 'ST' else first['key']}",
            "pipeline_status.py (same answer as /flow-next)")
    for d in st["deliverables"]:
        if d.get("status") != "current":
            add(2, "deliverable", f"{d['file']} is {d['status']}", f"/{d['next']}", d.get("why") or d["source"])
    for line in g["roadmap"]["plan"]:
        parts = [p.strip() for p in line.split("·")]
        skill = next((p for p in parts if re.match(r"^[a-z]+-[a-z]+", p)), "")
        add(3, "roadmap §4", parts[1] if len(parts) > 1 else line, f"/{skill.split()[0]}" if skill else "—", parts[0])
    for owner, n in st["questions"]["by_owner"].items():
        ids = [q["id"] for q in g["questions"] if not q["answered"] and q["owner"] == owner]
        listed = ", ".join(ids[:8]) + (" …" if len(ids) > 8 else "")
        if owner == "unassigned":
            add(3, "questions", f"Give an owner and a date to {n} open question(s)", "person: QA lead", listed)
        else:
            add(3, "questions", f"Chase {n} open question(s) with {owner}", "person: " + owner, listed)
    for r in g["followups"]:
        add(3, "follow-up", f"{r.get('ID')}: {r.get('What to do', '')}", r.get("Run with", "—"), r.get("Folder / file", ""))
    if g["defects"]:
        add(2, "defects", f"{len(g['defects'])} open defect(s) {st['defects_by_severity']}", "/run-defects", "project/defects.md")
    if st["roadmap"]["milestones_not_in_history"]:
        add(4, "roadmap", f"{st['roadmap']['milestones_not_in_history']} milestone(s) since the last roadmap update",
            "/flow-roadmap update", f"roadmap Updated {st['roadmap']['updated']}")
    lessons_date = last_commit_date("project/lessons.md")
    lessons_rows = table(read("project/lessons.md"), "ID")
    fresh = reviews_after(lessons_date)
    if fresh:
        add(4, "learn", f"{len(fresh)} review(s) not harvested since lessons.md changed ({len(lessons_rows)} lesson(s))",
            "/learn-retro", ", ".join(r["file"] for r in fresh[:3]))
    phase_idx = int((st["phase"] or "P0")[1:]) if (st["phase"] or "").startswith("P") else 0
    analysis_next = [f["key"] for f in folders if f["level"] == "IT" and f["next"] == "design-analysis"]
    due_study = []
    for r in g["roadmap"]["study"]:
        if r.get("Status", "").lower().startswith("done"):
            continue
        track, topic = r.get("Track", ""), r.get("Topic", "")
        if track == "Domain" and analysis_next and topic.startswith(analysis_next[0] + ":"):
            add(3, "study", f"{r.get('ID')} {topic[:70]} — before /design-analysis {analysis_next[0]}",
                "/learn-explain", "roadmap §10")
        elif track in ("Project", "Tech") and phase_idx >= 3:
            due_study.append(r.get("ID"))
    if due_study:
        add(4, "study", f"{len(due_study)} project / tech topic(s) due during P0–P2, still open",
            "/learn-explain or /learn-glossary", ", ".join(due_study))
    for n in g["notes"]:
        if n.get("Status", "").lower() == "open" and not n.get("Route", "").strip("— "):
            add(5, "notes", f"{n.get('ID')} not routed: {n.get('Note', '')[:60]}", "/project-assistant note", "project/notes.md")
    commit_days = set(git("log", "--since=14 days ago", "--format=%ad", "--date=short").split())
    logged_days = {w.get("Date") for w in g["worklog"]}
    gap = sorted(commit_days - logged_days)
    if gap:
        add(5, "worklog", f"{len(gap)} day(s) with commits but no worklog row ({gap[0]} … {gap[-1]})",
            "/project-assistant log", "git log vs project/worklog.md")
    items.sort(key=lambda i: i["prio"])
    return {"today": g["today"], "phase": st["phase"], "items": items}


def analyze_view(g, topic):
    out = {}
    if topic in ("questions", "all"):
        qs = g["questions"]
        open_q = [q for q in qs if not q["answered"]]
        for q in open_q:
            q["first_seen"] = question_age(q["id"])
        t = dt.date.fromisoformat(g["today"])
        out["questions"] = {
            "total": len(qs), "answered": len(qs) - len(open_q), "open": len(open_q),
            "by_owner": count(q["owner"] for q in open_q),
            "by_module": count(m for q in open_q for m in (q["modules"] or ["project-wide"])),
            "age_days": count(f"{(t - dt.date.fromisoformat(q['first_seen'])).days // 7 * 7}+ d" if q["first_seen"] else "unknown"
                              for q in open_q),
            "unassigned": [q["id"] for q in open_q if q["owner"] == "unassigned"],
            "blocking_design": [q["id"] for q in open_q if re.search(r"TC|scope|analysis|design", q["blocks"], re.I)],
        }
    if topic in ("effort", "all"):
        est = run_json("scripts/test_estimate.py")
        hpd = json.loads(read("plans/estimation.json") or "{}").get("hours_per_day", 8)
        cont = est.get("summary", {}).get("contingency", 0)
        planned = {}
        for r in est.get("rows", []):
            planned[r["activity"]] = planned.get(r["activity"], 0) + r["e"] * (1 + cont)
        actual = {}
        for w in g["worklog"]:
            a = w.get("Activity", "OTHER") or "OTHER"
            actual[a] = actual.get(a, 0) + w["hours"] / hpd
        t = dt.date.fromisoformat(g["today"])
        due = 0.0
        for task in est.get("tasks", []):
            if not task.get("start") or not task.get("end"):
                continue
            s, e = dt.date.fromisoformat(task["start"]), dt.date.fromisoformat(task["end"])
            frac = 1.0 if t >= e else 0.0 if t < s else ((t - s).days + 1) / ((e - s).days + 1)
            due += task.get("effort", 0) * frac
        acts = sorted(set(planned) | set(actual), key=lambda a: -planned.get(a, 0))
        out["effort"] = {
            "unit": f"person-days ({hpd} h)", "estimate_version": est.get("version"),
            "planned_total": round(est.get("summary", {}).get("planned", 0), 1),
            "planned_by_today": round(due, 1),
            "actual_total": round(sum(actual.values()), 1),
            "rows": [{"activity": a, "planned": round(planned.get(a, 0), 1), "actual": round(actual.get(a, 0), 1),
                      "used": f"{actual.get(a, 0) / planned[a]:.0%}" if planned.get(a) else "not in estimate"}
                     for a in acts],
            "note": "no worklog rows yet: start with `assistant.py log --draft`" if not g["worklog"] else "",
        }
    if topic in ("trend", "all"):
        tr = g["roadmap"]["trend"]
        keys = ["Suites", "TCs", "Open Q", "Open defects", "Pending source changes"]
        delta = {}
        if len(tr) >= 2:
            for k in keys:
                try:
                    delta[k] = int(tr[-1].get(k, 0)) - int(tr[-2].get(k, 0))
                except ValueError:
                    pass
        out["trend"] = {"rows": tr, "delta_last": delta,
                        "now": g["roadmap_status"].get("metrics", {})}
    if topic in ("risks", "all"):
        risks = g["roadmap"]["risks"]
        open_r = [r for r in risks if r.get("Status", "").lower().startswith("open")]
        out["risks"] = {
            "open": len(open_r), "total": len(risks),
            "by_owner": count(r.get("Owner", "TBD") or "TBD" for r in open_r),
            "by_phase": count(r.get("Phase", "?") for r in open_r),
            "linked_questions": {r["ID"]: re.findall(r"Q-[A-Z]*-?\d+(?:…\d+)?", r.get("Mitigation", "")) for r in open_r},
        }
    return out


def guess_activity(subject):
    s = subject.lower()
    if re.match(r"(\w+ on )?template\b", s):
        return "TOOL"
    rules = [(r"test plan|strategy|estimat|roadmap|schedule", "PLAN"), (r"analysis", "ANA"),
             (r"mindmap|scenario", "SCN"), (r"test cases?.*review|review fixes tr-", "TCR"), (r"test cases?", "TCD"),
             (r"test data|fixture", "DATA"), (r"automat|playwright|spec\b", "AUTO"), (r"cycle|run-|execut", "EXE"),
             (r"defect|def-\d", "DEF"), (r"glossary|onboarding|study|discovery", "STUDY"),
             (r"template|readme|guide|skill|workspace|agents", "TOOL")]
    return next((a for pat, a in rules if re.search(pat, s)), "OTHER")


def log_draft(g, since):
    if not since:
        dates = sorted(w.get("Date", "") for w in g["worklog"] if w.get("Date"))
        since = dates[-1] if dates else (dt.date.fromisoformat(g["today"]) - dt.timedelta(days=7)).isoformat()
    logged = {(w.get("Date"), w.get("Ref", "")) for w in g["worklog"]}
    raw = git("log", f"--since={since} 00:00", "--reverse", "--date=short", "--format=%h%x09%ad%x09%an%x09%s")
    ids = module_ids(g["cfg"])
    rows = []
    for line in raw.splitlines():
        h, d, author, subj = (line.split("\t") + ["", "", "", ""])[:4]
        if any(h in ref for (_, ref) in logged):
            continue
        rows.append({"Date": d, "Person": author, "Hours": "?", "Activity": guess_activity(subj),
                     "Module": ", ".join(modules_in(subj, ids)) or "—", "What": subj, "Ref": h})
    return {"since": since, "rows": rows, "activities": activity_list()}


def activity_list():
    est = json.loads(read("plans/estimation.json") or "{}")
    acts = {a["id"]: a["name"] for a in est.get("activities", [])}
    return {**acts, **EXTRA_ACTIVITIES}


# ── discover: map the workspace ──────────────────────────────────────────────────────────────────────────────────────

AREAS = {
    "sources": "Client documents (read-only) + parsed/ text copies with line numbers, trace/ change baseline",
    "project": "Shared memory: questions, decisions, rules, status, lessons, defects, notes, worklog, log, glossary",
    "plans": "Strategy, test plan, estimate, roadmap, discovery, reviews, templates in the organisation's formats",
    "test-design": "Test basis per level: 0-scope → 1-analysis → 2-mindmap → 3-test-cases (SIT per module, ST)",
    "deliverables": "Documents sent out: test plan .docx, test case / dashboard workbooks, reports",
    "automation": "Automated tests per pack, named with TC IDs",
    "test-reports": "Test summary / exit reports",
    "archive": "Retired files with the reason (never deleted)",
    "standards": "Rules for every project: core rules, review protocol, conventions, methods, template lessons",
    "packs": "Rules, checklists and layouts per test type (ui, api, etl, sql)",
    "scripts": "QA tools (status, checks, export, slicer, runner) and workspace/ plumbing (guard, sync, backup)",
    ".claude": "Claude Code settings (hooks, permissions) and the skills (source)",
    ".agents": "Codex copy of the skills (generated)",
    ".github": "Copilot instructions, skills copy (generated), path rules",
    ".gemini": "Gemini CLI copy of the skills (generated)",
    ".harness": "Ratcheted checker errors (generated)",
}
GENERATED_RX = [r"^sources/(parsed|trace)/", r"^test-design/it/INDEX\.md$", r"/sources\.json$", r"^test-design/.*\.xlsx$",
                r"^(AGENTS|GEMINI)\.md$", r"^\.agents/", r"^\.gemini/", r"^\.github/(skills/|copilot-instructions\.md)",
                r"^plans/test-estimate\.(md|xlsx)$", r"^\.harness/"]
STEP_FILES = [("scope", "0-scope.md"), ("analysis", "1-analysis.md"), ("analysis review", "1-analysis-review.md"),
              ("mindmap", "2-mindmap.md"), ("mindmap review", "2-mindmap-review.md"),
              ("test cases", "3-test-cases/test-cases.json"), ("TC review", "3-test-cases/test-cases-review.md"),
              ("automation plan", "3-test-cases/automation-plan.md")]


def glob_match(rel, pat):
    if pat.endswith("/**"):
        base = pat[:-3]
        return fnmatch.fnmatchcase(rel, base + "/*") if any(c in base for c in "*?[") else rel.startswith(base + "/")
    return fnmatch.fnmatchcase(rel, pat)


def owner_of(rel, manifest):
    if any(re.search(rx, rel) for rx in GENERATED_RX):
        return "generated"
    if rel.startswith("archive/"):
        return "archive"
    if rel.startswith("sources/"):
        return "client"
    if any(glob_match(rel, pat) for pat in manifest.get("project_owned", [])):
        return "project"
    if any(glob_match(rel, pat) for pat in manifest.get("template_owned", [])):
        return "template"
    return "project"


def title_of(path):
    if path.suffix == ".html":
        m = re.search(r"<title>(.*?)</title>", path.read_text(encoding="utf-8", errors="replace")[:8192], re.S)
        return m.group(1).strip() if m else ""
    if path.suffix != ".md":
        return ""
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines()[:15]:
        if line.startswith("# "):
            return line[2:].strip()
    return ""


def tc_summary(path):
    try:
        d = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "unreadable"
    tcs = next((v for k, v in d.items() if isinstance(v, list) and k.lower() in ("test_cases", "testcases", "tcs", "cases")), [])
    return f"v{d.get('version', '?')}, {len(tcs)} TC(s)"


def register_rows(rel, first_header, sec=None):
    text = read(rel)
    return len(table(section(text, sec) if sec else text, first_header))


def discover_view(cfg, since, path):
    manifest = json.loads(read("template-manifest.json") or "{}")
    files = [f for f in git("ls-files").splitlines() if f]
    untracked = [f for f in git("ls-files", "--others", "--exclude-standard").splitlines() if f]
    t = today(cfg)
    since = since or (t - dt.timedelta(days=7)).isoformat()
    if path:
        base = path.strip("/")
        rows = []
        for f in files:
            if f == base or f.startswith(base + "/"):
                fp = ROOT / f
                rows.append({"file": f, "owner": owner_of(f, manifest), "kb": round(fp.stat().st_size / 1024, 1) if fp.exists() else 0,
                             "changed": (last_commit_date(f) or "")[:10], "title": title_of(fp) if fp.exists() else ""})
        return {"path": base, "purpose": AREAS.get(base.split("/")[0], ""), "files": rows}

    areas = {}
    for f in files:
        top = f.split("/")[0] if "/" in f else "(root)"
        a = areas.setdefault(top, {"area": top, "files": 0, "kb": 0.0, "owners": {}})
        a["files"] += 1
        fp = ROOT / f
        a["kb"] += fp.stat().st_size / 1024 if fp.exists() else 0
        o = owner_of(f, manifest)
        a["owners"][o] = a["owners"].get(o, 0) + 1
    area_rows = []
    for k, a in sorted(areas.items(), key=lambda kv: (kv[0].startswith("."), kv[0])):
        area_rows.append({"area": k + ("/" if k != "(root)" else ""), "files": a["files"], "kb": round(a["kb"]),
                          "owner": ", ".join(f"{o} {n}" for o, n in sorted(a["owners"].items(), key=lambda kv: -kv[1])),
                          "changed": (last_commit_date(k) or "")[:10] if k != "(root)" else "",
                          "purpose": AREAS.get(k, "project.json, README, CLAUDE.md, guide, changelog" if k == "(root)" else "")})

    parsed = {f for f in files if f.startswith("sources/parsed/")}
    sources = []
    for f in files:
        if f.startswith("sources/") and not f.startswith(("sources/parsed/", "sources/trace/")) and not f.endswith(("README.md", ".gitkeep")):
            sources.append({"document": f, "kb": round((ROOT / f).stat().st_size / 1024), "parsed": any(p.startswith("sources/parsed/" + f[len("sources/"):]) for p in parsed),
                            "added": (git("log", "--diff-filter=A", "--format=%ad", "--date=short", "--", f).split() or [""])[-1]})

    folders = []
    levels = cfg.get("levels", {})
    it_dir = ROOT / levels.get("IT", {}).get("folder", "test-design/it")
    st_dir = ROOT / levels.get("ST", {}).get("folder", "test-design/st")
    level_dirs = sorted(p for p in it_dir.glob("MOD-*") if p.is_dir()) + ([st_dir] if st_dir.exists() else [])
    for d in level_dirs:
        have = [name for name, fn in STEP_FILES if (d / fn).exists()]
        steps = [n for n, _ in STEP_FILES if "review" not in n and n != "automation plan" and not (d == st_dir and n == "scope")]
        tc = d / "3-test-cases/test-cases.json"
        folders.append({"folder": d.relative_to(ROOT).as_posix(), "has": ", ".join(have) or "—",
                        "missing": ", ".join(n for n in steps if n not in have) or "—",
                        "test cases": tc_summary(tc) if tc.exists() else "—"})

    registers = [
        {"register": "project/questions.md", "rows": register_rows("project/questions.md", "ID"), "holds": "questions Q-…"},
        {"register": "project/decisions/", "rows": len([p for p in (ROOT / "project/decisions").glob("ADR-*.md") if "ADR-000" not in p.name]), "holds": "decisions ADR-…"},
        {"register": "project/rules.md", "rows": len(re.findall(r"^## PR-\d+", read("project/rules.md"), re.M)), "holds": "project rules PR-n"},
        {"register": "project/status.md", "rows": register_rows("project/status.md", "ID", 2), "holds": "open follow-ups FU-…"},
        {"register": "project/lessons.md", "rows": register_rows("project/lessons.md", "ID"), "holds": "lessons L-…"},
        {"register": "project/defects.md", "rows": register_rows("project/defects.md", "DEF ID"), "holds": "defects DEF-…"},
        {"register": "project/notes.md", "rows": register_rows("project/notes.md", "ID"), "holds": "notes N-…"},
        {"register": "project/worklog.md", "rows": register_rows("project/worklog.md", "Date"), "holds": "work log rows"},
        {"register": "project/log.md", "rows": register_rows("project/log.md", "Date"), "holds": "change sets"},
        {"register": "project/change-impact/", "rows": len(list((ROOT / "project/change-impact").glob("*.md"))), "holds": "source change records"},
        {"register": "project/system-map.md › Glossary", "rows": register_rows("project/system-map.md", "Term"), "holds": "glossary terms"},
        {"register": "plans/roadmap.md §8", "rows": len(roadmap()["risks"]), "holds": "risks RK-…"},
    ]
    skills = sorted(p.parent.name for p in (ROOT / ".claude/skills").glob("*/SKILL.md"))
    by_group = count(s.split("-")[0] for s in skills if not s.startswith("project-"))

    raw = git("log", f"--since={since} 00:00", "--name-only", "--format=@@%h %ad %s", "--date=short")
    commits, changed, latest = 0, {}, []
    for line in raw.splitlines():
        if line.startswith("@@"):
            commits += 1
            if len(latest) < 5:
                latest.append(line[2:])
        elif line.strip() and owner_of(line.strip(), manifest) != "generated":
            top = line.split("/")[0] if "/" in line else "(root)"
            changed[top] = changed.get(top, 0) + 1
    empty = [r["register"] for r in registers if r["rows"] == 0]
    empty += [f"{f['folder']}: no {f['missing']}" for f in folders if f["missing"] != "—"]
    big = sorted(({"file": f, "kb": round((ROOT / f).stat().st_size / 1024)} for f in files
                  if f.endswith((".md", ".json")) and not f.startswith("archive/") and (ROOT / f).exists()
                  and (ROOT / f).stat().st_size > 40 * 1024), key=lambda r: -r["kb"])
    return {
        "project": cfg["project"].get("code"), "today": t.isoformat(), "template_version": cfg.get("template_version"),
        "tracked_files": len(files), "untracked": untracked[:20], "areas": area_rows, "sources": sources,
        "folders": folders, "registers": registers,
        "skills": {"template": len([s for s in skills if not s.startswith("project-")]), "by_group": by_group,
                   "project": [s for s in skills if s.startswith("project-")]},
        "scripts": sorted(p.name for p in (ROOT / "scripts").glob("*.py")),
        "recent": {"since": since, "commits": commits, "latest": latest,
                   "files_by_area": dict(sorted(changed.items(), key=lambda kv: -kv[1]))},
        "empty": empty, "large_files": big,
        "entry_points": ["README.md", "project/index.md", "USER-GUIDE.md", "CLAUDE.md", ".claude/skills/README.md"],
    }


def print_discover(d):
    if "path" in d:
        print(f"Map of {d['path']}/ — {d['purpose'] or 'project files'}\n")
        print(md(d["files"], ["file", "owner", "kb", "changed", "title"]))
        return
    print(f"Workspace map · {d['project']} · {d['today']} · template {d['template_version']} · {d['tracked_files']} tracked file(s)"
          + (f" · {len(d['untracked'])} untracked" if d["untracked"] else "") + "\n")
    print(md(d["areas"], ["area", "files", "kb", "owner", "changed", "purpose"]))
    print("\n## Client documents\n")
    print(md(d["sources"], ["document", "kb", "parsed", "added"]))
    print("\n## Test design\n")
    print(md(d["folders"], ["folder", "has", "missing", "test cases"]))
    print("\n## Registers\n")
    print(md(d["registers"], ["register", "rows", "holds"]))
    s = d["skills"]
    print(f"\nSkills: {s['template']} template ({', '.join(f'{k} {v}' for k, v in s['by_group'].items())})"
          + (f" + project: {', '.join(s['project'])}" if s["project"] else ""))
    print(f"Scripts: {len(d['scripts'])} in scripts/ ({', '.join(d['scripts'])})")
    r = d["recent"]
    print(f"\nSince {r['since']}: {r['commits']} commit(s); hand-written files changed by area: "
          + (", ".join(f"{k} {v}" for k, v in r["files_by_area"].items()) or "none"))
    for c in r["latest"]:
        print(f"  {c}")
    print("\nEmpty or not started: " + ("; ".join(d["empty"]) or "none"))
    print("Large files (read with scripts/slice.py): " + (", ".join(f"{b['file']} {b['kb']} KB" for b in d["large_files"]) or "none"))
    print("Start reading at: " + " → ".join(d["entry_points"]))


# ── text output ──────────────────────────────────────────────────────────────────────────────────────────────────────

def md(rows, cols):
    if not rows:
        return "  (none)"
    out = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    out += ["| " + " | ".join(str(r.get(c, "")) for c in cols) + " |" for r in rows]
    return "\n".join(out)


def stage_cell(step, f, stage):
    """Compact: the review state, then Auto / Manual / Ready counts, rolled up from the TC tags (tracks.py)."""
    tr = f.get("tracks")
    if not tr or step == "·":
        return step
    x = tr["stages"].get(stage, {})
    if not tr["decided"]:
        return f"{step} · not decided"
    return f"{step} · Auto {x.get('auto', 0)} · Manual {x.get('manual', 0)} · Ready {x.get('ready', 0)}"


def track_rows(f):
    """Full board: one row per track under the folder's review row (stage-model-manual-auto.md §5)."""
    tr = f.get("tracks")
    if not tr:
        return []
    sg, au, mn, nx = tr["stages"], tr["auto"], tr["manual"], tr.get("next", {})

    def cell(stage, k, extra=True):
        x = sg.get(stage, {})
        if k == "auto":
            return f"{x.get('auto', 0)} · Ready {x.get('ready', 0)}" + (f" · part {x['part']}" if x.get("part") else "")
        if k == "manual":
            return f"{x.get('manual', 0)}" + (f" (only {x.get('manual_only', 0)})" if extra and x.get("manual") else "")
        return str(x.get("waiting", 0))
    nxt = lambda k: " — ".join(v for v in nx.get(k, ["—"]) if v and v != "—") or "—"  # noqa: E731
    return [
        {"Folder": "", "Track": "Auto", "Analysis": cell("analysis", "auto"), "Scenarios": cell("scenarios", "auto"),
         "Test-Cases": cell("test-cases", "auto"), "Decide": "plan ✓" if au["plan"] else "·",
         "Design": "✓" if au["design"] else "·", "Written": f"{au['written']} / {au['ready']}",
         "Run": str(au["results"]), "Next": nxt("auto")},
        {"Folder": "", "Track": "Manual", "Analysis": cell("analysis", "manual"),
         "Scenarios": cell("scenarios", "manual"), "Test-Cases": cell("test-cases", "manual"),
         "Decide": "residue ✓" if au["plan"] else "·", "Design": "n/a", "Written": "n/a",
         "Run": f"{mn['results']} / {mn['tcs']}", "Next": nxt("manual")},
        {"Folder": "", "Track": "Waiting", "Analysis": cell("analysis", "w"), "Scenarios": cell("scenarios", "w"),
         "Test-Cases": " · ".join(f"{k} {n}" for k, n in tr["waiting"].items()) or "0",
         "Decide": "", "Design": "", "Written": "", "Run": "", "Next": f"readiness from {tr['readiness_source']}"},
    ]


def print_status(s):
    m = s["maturity"]
    print(f"Status · {s['project']} · {s['today']} · phase {s['phase']} · maturity {m.get('name', '?')} → "
          f"{m.get('next', '?')} needs: {'; '.join(m.get('missing_for_next', [])) or '—'}\n")
    print("Phases: " + " · ".join(f"{p['id']} {p['status']}" for p in s["phases"]) + "\n")
    if s.get("full"):
        cols = ["Folder", "Track", "Analysis", "Scenarios", "Test-Cases", "Decide", "Design", "Written", "Run", "Next"]
        rows = []
        for f in s["folders"]:
            rows.append({"Folder": f["key"], "Track": "review", **{k.title(): v for k, v in f["steps"].items()},
                         "Next": f"{f['next']} — {f['why']}"})
            rows += track_rows(f)
        print(md(rows, cols))
        print("\nAuto = TCOND / TS / TC with an automated part (Ready = all its TCs Ready) · Manual = with a manual part "
              "(only = no automated part) · Written = Ready TCs bound to a test · Run = results recorded")
    else:
        print(md([{"Folder": f["key"], **{k.title(): stage_cell(v, f, k) for k, v in f["steps"].items()},
                   "Next": f["next"], "Why": f["why"]}
                  for f in s["folders"]], ["Folder", "Analysis", "Scenarios", "Test-Cases", "Next", "Why"]))
        print("\nAuto = has an automated part · Manual = has a manual part · Ready = automated part ready to write "
              "(rolled up from the TC tags: scripts/tracks.py; the full board: status --tracks)")
    print(f"\nSource changes pending: {s['source_changes']}")
    print("Deliverables: " + (", ".join(f"{Path(d['file']).name} {d['status']}" for d in s["deliverables"]) or "none"))
    q = s["questions"]
    print(f"Questions: {q['open']} open of {q['total']} · by owner: " + ", ".join(f"{k} {v}" for k, v in q["by_owner"].items()))
    print(f"Follow-ups open: {s['followups_open']} · defects open: {s['defects_open']} {s['defects_by_severity'] or ''}")
    print(f"Risks open: {len(s['risks_open'])} ({', '.join(s['risks_open'])})")
    print(f"Notes open: {len(s['notes_open'])} · worklog hours, last 7 days: {s['worklog_hours_7d']}")
    r = s["roadmap"]
    print(f"Roadmap: Updated {r['updated']}, last trend row {r['last_trend']}, "
          f"{r['milestones_not_in_history']} milestone(s) not yet in §7")


def print_todo(t):
    print(f"To do · {t['today']} · phase {t['phase']} · priority 1 = first\n")
    print(md(t["items"], ["prio", "area", "what", "run", "evidence"]))


def print_analyze(a):
    for k, v in a.items():
        print(f"\n## {k}\n")
        if k == "effort":
            print(f"Estimate v{v['estimate_version']} · {v['unit']} · planned {v['planned_total']} · planned by today "
                  f"{v['planned_by_today']} · actual {v['actual_total']}  {v['note']}")
            print(md(v["rows"], ["activity", "planned", "actual", "used"]))
        elif k == "trend":
            print(md(v["rows"], list(v["rows"][0].keys()) if v["rows"] else ["Date"]))
            print(f"\nChange in the last row: {v['delta_last'] or '—'} · now: {json.dumps(v['now'], ensure_ascii=False)}")
        else:
            for kk, vv in v.items():
                print(f"- {kk}: {vv}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["discover", "status", "todo", "analyze", "log"])
    ap.add_argument("topic", nargs="?", default="all", choices=["questions", "effort", "trend", "risks", "all"])
    ap.add_argument("--draft", action="store_true", help="log: draft worklog rows from git (default for log)")
    ap.add_argument("--since", help="log / discover: first date (log: the last worklog date; discover: 7 days ago)")
    ap.add_argument("--path", help="discover: map one folder (e.g. plans, test-design/it/MOD-AA-…)")
    ap.add_argument("--tracks", action="store_true", help="status: the full board, one row per track (auto / manual)")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if a.command == "discover":
        res = discover_view(project_cfg(), a.since, a.path)
        print(json.dumps(res, ensure_ascii=False, indent=1, default=str)) if a.json else print_discover(res)
        return
    g = gather()
    if a.command == "status":
        res, pr = {**status_view(g), "full": a.tracks}, print_status
    elif a.command == "todo":
        res, pr = todo_view(g), print_todo
    elif a.command == "analyze":
        res, pr = analyze_view(g, a.topic), print_analyze
    else:
        res = log_draft(g, a.since)
        pr = lambda r: (print(f"Worklog draft since {r['since']} — fill Hours, fix Person / Activity, then add the rows "
                              f"to project/worklog.md\n"), print(md(r["rows"], ["Date", "Person", "Hours", "Activity",
                                                                               "Module", "What", "Ref"])),
                        print("\nActivities: " + ", ".join(r["activities"])))
    if a.json:
        print(json.dumps(res, ensure_ascii=False, indent=1, default=str))
    else:
        pr(res)


if __name__ == "__main__":
    main()
