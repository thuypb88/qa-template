<!-- Template: project-assistant, log mode. Rows appended to project/worklog.md, oldest first, after the user's OK. Hours
and person come from the person, never guessed. Replace every <placeholder>; delete this comment.
Rules: ../references/output-rules.md. -->
| <YYYY-MM-DD> | <person> | <hours, from the person> | <estimate activity ID \| MGMT \| MEET \| STUDY \| TOOL \| OTHER> | <module> | <what> | <commit / file / —> |
