<!-- Template: project-assistant, analyze mode (chat). Replace every <placeholder>; delete this comment.
Rules: ../references/output-rules.md. -->
**<topic> · <date> · <one-line finding>**

<one small table from the script>

**Reading:** <2–4 bullets: pattern, so-what, each with its evidence>
**Limits:** <what the data can't tell — e.g. no worklog rows yet, questions carry no dates>
**Next:** `/<skill>` or **ask <person>** — <why>
