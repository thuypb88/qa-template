<!-- Template: project-assistant, note mode. One row per point, appended to project/notes.md after the user's OK; the
next free ID from `assistant.py status --json` › next_note_id. Replace every <placeholder>; delete this comment.
Rules: ../references/output-rules.md. -->
| N-<NNN> | <YYYY-MM-DD> | <meeting · call · chat · e-mail · observation, and who> | <the point, in the user's words, short> | <module IDs, ST, topic> | <Q-… \| FU-… \| ADR \| learn-retro \| sources/ → plan-changes \| roadmap §8 \| keep> | <Open \| Routed \| Closed: reason> |
