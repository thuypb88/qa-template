<!-- Template: project-assistant, todo mode (chat). Replace every <placeholder>; delete this comment.
Rules: ../references/output-rules.md. -->
**To do · <date> · phase <Pn>**

1. <what> — `/<skill> <target>` (or **ask <person>**) · <evidence>
2. …

**Later:** <one line each>
**Next:** `/<skill> <target>`
