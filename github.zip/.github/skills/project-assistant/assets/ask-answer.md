<!-- Template: project-assistant, ask mode (chat). Replace every <placeholder>; delete this comment.
Rules: ../references/output-rules.md. -->
**<the answer in one or two sentences>**

<at most 6 lines or one small table: what it is, where it lives, who writes it (skill), how it is checked (script)>

Source: [<file>](<path>#L<line>) · <second source if any>
Try: `<one command or skill to see it for yourself>`
