<!-- Template: project-assistant, status mode (chat). Replace every <placeholder>; delete this comment.
Rules: ../references/output-rules.md. -->
**<CODE> · <date> · phase <Pn name> · maturity <Ln> → <next> needs <what>**

| Folder | Analysis | Scenarios | Test cases | Next |   ← from the script, verdicts as written
|---|---|---|---|---|
| AA | ✓ Pass with fixes · stale · Auto 140 · Manual 4 · Ready 92 | … | ✓ … · Auto 200 · Manual 4 · Ready 133 | `check-design` |

| Area | State |
|---|---|
| Sources | <n> pending changes |
| Deliverables | <file status, …> |
| Questions | <open> of <total> · by owner … |
| Follow-ups · defects · risks | <n> · <n by severity> · <n open> |
| Notes · hours (7 days) | <n open> · <h> |
| Roadmap | Updated <stamp>; <n> milestones not in §7 |

**Watch:** <at most 3 lines: what changed or is drifting, each with its evidence>
**Next:** `/<skill> <target>` — <why>
