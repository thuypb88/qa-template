<!-- Template: project-assistant, discover mode (chat). Replace every <placeholder>; delete this comment.
Rules: ../references/output-rules.md. -->
**<CODE> workspace · <date> · <n> tracked files · template <version>**

| Area | What it holds | Owner | State |          ← 6–10 rows: the areas a QA works in first
|---|---|---|---|

**What's here:** <3–5 bullets: sources, how far test design is, which registers are in use, what is empty>
**Changed since <date>:** <the commits that matter, grouped: plans, project, test design, template — or "nothing">
**Read next:** <2–3 files, in order, each with why> — e.g. `README.md` → `project/index.md` → the folder you'll work in
**Next:** `/<skill>` — <why>  (often mode status, `/flow-next`, or ask about one area)
