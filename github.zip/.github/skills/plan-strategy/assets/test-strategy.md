<!-- Template: plan-strategy, write mode. Copy to plans/test-strategy.md, replace every <placeholder>, delete these
comments. Rules: ../references/output-rules.md. -->
# Test strategy — <project name>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Version:** <0.1> · **Basis:** <client test plan / requirement documents, project.json> · **Status:** <proposal | accepted (ADR-…)>

## 1. Objectives and scope

**Quality outcome.** <from the documents, cited>

| Module / interface / NFR area | In / out | Source |
|---|---|---|

**Shallow by design.** <what, why>

## 2. Risk-based priorities

| Area | Risk (impact × likelihood × detectability) | Why (source) | Depth | Level |
|---|---|---|---|---|

## 3. Levels and environments

| Level | Environment (exact name) | Externals | Entry | Exit |
|---|---|---|---|---|
| IT | <env> | <mocks / fixtures> | <…> | <…> |
| ST | <env> | <real systems> | <…> | <…> |

## 4. Approach per pack

| Pack | Surface (R2) | Techniques by rule shape | Checklist | Automated by default | Manual |
|---|---|---|---|---|---|

## 5. Test data

<Synthetic or masked only; who provides fixtures and mocks; reset / cleanup; personal data rules.>

## 6. Entry and exit criteria

| Level | Entry | Exit | Evidence | Source / Q |
|---|---|---|---|---|

## 7. Defects and reporting

<Severity scale, tracker, retest and regression rules; report cadence and audience.>

## 8. Automation direction

<Runner per pack; smoke and regression content; hooks the DEV team must provide.>

## 9. Transition

<Data migration, parallel run, cutover and rollback rehearsal, users / roles, training material — or "None applies:
<reason>".>

## 10. Roles, schedule and dependencies

| Role | Responsibility |
|---|---|

| Milestone / dependency | Date / owner | Blocks |
|---|---|---|

## 11. Risks, assumptions and open questions

| ID | Risk / assumption / question | Owner | Blocks |
|---|---|---|---|

<!-- Section mode: append
## <Sprint n | Release name>
Scope delta · risks · levels and environments · entry / exit · regression set · dates. -->
