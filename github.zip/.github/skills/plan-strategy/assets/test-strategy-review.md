<!-- Template: plan-strategy, review mode. Copy to plans/test-strategy-review.md, replace every <placeholder>, delete this
comment. Rules: ../references/output-rules.md. -->
# Test strategy review — <client plan title> v<version>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Reviewed:** <YYYY-MM-DD> · **Plan:** <path under sources/> · **Against:** requirement documents, project.json

| Section | Present / Partly / Missing | Evidence (§, page) | Gap | Question (owner) |
|---|---|---|---|---|
| 1. Objectives and scope | <…> | <…> | <… or —> | <Q-… (owner) or —> |

## Contradictions

- <plan §x vs <document> line: Q-… citing both>

## Questions

- Q-<xxx> (<owner>): <question>
