# plan-strategy: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 15:44:58 (UTC+7)

Read before writing. Write mode: copy [../assets/test-strategy.md](../assets/test-strategy.md); review mode: copy
[../assets/test-strategy-review.md](../assets/test-strategy-review.md); section mode: add the sprint / release section
from the strategy template's last block. Replace every `<placeholder>`, delete the template comments. Linked, never
copied: [core-rules.md](../../../../standards/core-rules.md) R1, R2, R9 ·
[test-techniques.md](../../../../standards/methods/test-techniques.md) ·
[requirement-quality.md](../../../../standards/methods/requirement-quality.md) §7 (transition) ·
[conventions.md](../../../../standards/conventions.md) (stamp, formats).

| Mode | File | Write mode |
|---|---|---|
| write | `plans/test-strategy.md`, title `# Test strategy — <project name>` | edit; bump the version in the header |
| review | `plans/test-strategy-review.md` | overwrite |
| section | `plans/test-strategy.md` › `## Sprint <n>` / `## Release <name>` | append |
| all | new `Q-INIT-NNN` / `Q-ST-NNN` in `project/questions.md`; a decision → ADR | append |

## Required sections (write mode)

1. **Objectives and scope.** What quality outcome matters (from the documents); in scope / out of scope per module,
   interface and non-functional area, each citing its source; what is deliberately shallow.
2. **Risk-based priorities.** `Area | Risk (impact × likelihood × detectability, qualitative) | Why (source) |
   Depth | Level`. Money, state, security, data loss, hand-offs, legal text first. No numeric score unless the project
   has a risk model.
3. **Levels and environments.** Per level from `project.json › levels`: environment (exact name), externals (mock /
   real), entry and exit. IT = per module with mocks; ST = whole system with the real systems (R9).
4. **Approach per pack.** UI / API / ETL / SQL: surface (R2), techniques by rule shape (techniques reference of
   `design-scenarios`), checklists, what is automated by default and what stays manual.
5. **Test data.** Synthetic or masked only; who provides fixtures and mocks; reset / cleanup; personal data rules
   (→ `design-data`).
6. **Entry / exit criteria.** From the client plan when it has them (cite); else proposed and marked `Q-xxx: proposed
   …` for the QA lead. Each one checkable (e.g. "all P1 TCs executed, none failed without an accepted defect"), with
   its evidence source. Never invent a pass-rate threshold.
7. **Defects and reporting.** Severity scale, the tracker, retest and regression rules (→ `run-defects`),
   report cadence and audience (→ `run-report`).
8. **Automation direction.** Runner per pack, what goes into smoke and regression, hooks the DEV team must provide
   (from `auto-decide` when it has run).
9. **Transition.** When the release changes an existing system: data migration (counts, reconciliation, rejected
   rows), parallel run, cutover and rollback rehearsal, users / roles to migrate, training material checks — or a line
   saying none applies (requirement-quality reference §7 of `design-analysis`).
10. **Roles, schedule, dependencies.** Who does what (roles, not names unless given), milestones, the dependencies
   that block testing (builds, mocks, data, access).
11. **Risks, assumptions, open questions.** Each with an owner and what it blocks.

## Review table (review mode)

Walk the eleven sections against the client plan: `Section | Present / Partly / Missing | Evidence (§, page) | Gap |
Question (owner)`. Contradictions with the requirement documents or `project.json` → questions citing both. A gap the
team can live with is noted, not inflated.

## Rules

- **Template sections** of [test-strategy.md](../assets/test-strategy.md), in order: `## 1. Objectives and scope` · `## 2. Risk-based priorities` · `## 3. Levels and environments` · `## 4. Approach per pack` · `## 5. Test data` · `## 6. Entry and exit criteria` · `## 7. Defects and reporting` · `## 8. Automation direction` · `## 9. Transition` · `## 10. Roles, schedule and dependencies` · `## 11. Risks, assumptions and open questions` · `## <Sprint n | Release name>`.
- Every line traces to this project's documents, `project.json` or a user answer; no textbook filler.
- Proposals are labelled as proposals until the QA lead / client accepts them (then an ADR).
- Tables, one screen per section.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
