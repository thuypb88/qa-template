---
name: plan-strategy
description: Plan: the test strategy (project, sprint or release). Write or review the QA test strategy in plans/test-strategy.md - objectives, scope in / out, risk-ordered areas, levels (IT with mocks, ST with real systems) and packs, techniques and depth per risk, environments and data, entry / exit criteria, automation direction, defect and reporting flow, roles, schedule dependencies, open risks - from the client's test plan and documents; or review the client's test plan against them and list the gaps. Use for "write the test strategy", "we have no test plan", "review the client's test plan against our strategy", "what are the entry / exit criteria", "test approach for release X". project.json set-up → plan-setup; one module's scope → plan-scope; the formal test plan document, schedule and estimation → plan-testplan; a quality review of a test plan before it is issued → check-testplan.
metadata:
  group: plan
  order: "-1"
---

# Plan: test strategy

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `sources/testing/` (the client's test plan, if any), the requirement documents (`slice.py toc` → `section`),
`project.json` (levels, modules, externals, runners), `project/system-map.md`, `project/questions.md`. **Out:**
`plans/test-strategy.md` (project-owned; or `plans/test-strategy-review.md` in review mode); new `Q-INIT-NNN` /
`Q-ST-NNN` in `project/questions.md`; a decision → ADR. **Rules:** core R1, R2, R9. **Next:** `plan-setup` (if
`project.json` is still the skeleton) or the first `design-analysis`.
**Output:** [assets/test-strategy-review.md](assets/test-strategy-review.md) · [assets/test-strategy.md](assets/test-strategy.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

**Modes:** *write* (no client plan, or the user asks for our own); *review* (a client plan exists: check it against
the required sections, write gaps as questions — never rewrite the client's plan); *section* (add a sprint or release
section to an existing strategy, for `flow-cadence` / `flow-cadence`).

## Required sections

Eleven sections (write mode), the review table (review mode) and the sprint / release section: copy the template
in [assets/](assets/) and follow [references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- Tailored or nothing; proposals labelled until accepted; tables, one screen per section (detail in
  [references/output-rules.md](references/output-rules.md)).

## Done when

- [ ] Eleven sections (or the review table) with citations; exit criteria checkable with an evidence source.
- [ ] Questions in `project/questions.md` with owners; `project/log.md` line; commit `test strategy v<n>`.
