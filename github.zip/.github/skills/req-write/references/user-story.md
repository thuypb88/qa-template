# req-write mode: user stories and acceptance criteria

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the story / feature text (from `sources/requirements/`, a ticket the user pastes, or `plans/discovery/…`), the
related sources, `project/system-map.md` (roles, glossary). **Out:** `plans/stories/<YYYY-MM-DD>-<slug>.md` (status
**Proposed**); open questions into `project/questions.md` on the user's OK. **Rules:** core R1;
[standards/methods/requirement-quality.md](../../../../standards/methods/requirement-quality.md) §8 (INVEST, criteria).
**Next:** the PO / BA confirms → the user saves the confirmed version under `sources/requirements/` →
`plan-changes` → `design-analysis`.

**Modes:** *write* (from a feature description) · *refine* (review existing stories / criteria and propose fixes) ·
*complete* (a story exists, criteria are missing or thin). Infer the mode from the input and say which one you use.

## Steps

1. **Four facts before writing:** persona (role and state), goal, business value, the module / feature it belongs
   to. Missing → ask (at most three questions); never invent a persona or a value.
2. **Story:** `US-<code>-NNN` (or the client's ID) · title · **As a** <specific persona> **I want** <one concrete
   action> **so that** <outcome that differs from the action>.
3. **INVEST check** — a row per letter with ✅ / ⚠️ and why. Small fails → propose a split (by CRUD operation,
   persona, workflow step, business rule, data type or channel), each part valuable on its own. Estimable fails →
   suggest a spike first.
4. **Criteria** (Given-When-Then), numbered `AC1…`:
   - at least one happy path, one edge (limit, boundary in the field's unit, timing, concurrency, empty / maximum)
     and one negative (invalid input, refused permission, external failure); more as the rules require, ~8 at most
     (more → split the story);
   - *Given* checkable state; one *When*; *Then* the exact message / status / value the user sees; *And* nothing else
     changed when a refusal must not leave traces;
   - values come from the sources; unknown → `TBD-n` with a question, not a "usual" number.
5. **Refine mode:** a findings table `Story / AC | Problem (INVEST letter or criterion rule) | Why it matters for
   testing | Proposed fix`, then the rewritten story marked as a proposal.
6. **Notes:** dependencies, assumptions, open questions (owner, what they block).

## Output (`plans/stories/<date>-<slug>.md`)

Template [../assets/user-stories.md](../assets/user-stories.md); file rules [output-rules.md](output-rules.md).

Header with **Status: Proposed — awaiting PO / BA confirmation**, source of the input, date. Then per story: the
three lines, metadata (epic, priority as the project scores it, dependencies), INVEST table, AC1…n, notes. Language:
`project.json › project.document_language`.

## Rules

- QA proposes; the PO decides. A proposed criterion never becomes a test basis or an expected result until it is in
  a confirmed source (R1) — until then `design-analysis` may only use it as `Q-xxx: assumed …`.
- No implementation details (endpoints, tables, frameworks) and no pixel-level UI in criteria.
- One scenario per criterion; no "etc."; no vague adjectives.

## Done when

- [ ] Every story has a specific persona, a distinct *so that*, an INVEST table and ≥ 3 criteria (happy, edge, negative).
- [ ] Unknown values are TBDs with questions; status Proposed; next step named (confirmation → sources → `plan-changes`).
