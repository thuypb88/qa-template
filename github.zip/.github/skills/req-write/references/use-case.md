# req-write mode: use case specifications

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-16 10:29:00 (UTC+7)

**In:** the feature / BRD / SRS text (`slice.py section`), existing use cases in `sources/`, `project/system-map.md`
(actors, systems, glossary), `project.json › external_systems`. **Out:** `plans/use-cases/<UC-ID>_<slug>.md` per use
case (status **Proposed**) and `plans/use-cases/README.md` (the list); in review mode
`plans/use-cases/review-<date>.md`; open questions into `project/questions.md` on the user's OK. **Rules:** core R1;
[standards/methods/requirement-quality.md](../../../../standards/methods/requirement-quality.md) §9 (use cases).
**Next:** confirmation → `sources/` → `plan-changes` → `design-analysis`; for test design, `design-scenarios` (techniques
§10).

**Modes:** *list* (split a feature into use cases first) · *write* (one use case) · *review* (the client's use
cases: the 20-point check only) · *section* (one part, e.g. the exceptions). Vague input → ask at most three
questions: the primary actor, the goal, the system / module.

## 1. Scope (list mode, and before writing)

- Find candidates three ways: **goals** per actor; **events** (user actions, schedules, incoming messages / files);
  **CRUD** per business entity. Merge duplicates.
- Keep **user-goal level**: one primary actor, one goal, one session, a result worth stopping for. Too small (a step
  such as "enter OTP") → an *include*; too big (a life cycle) → several use cases.
- System boundary: steps are actor ↔ system interactions; internals are design, not use case.
- List table `UC ID | Name (verb + object) | Primary actor | Goal | Trigger | Priority`; confirm it with the user
  before writing the details.

## 2. Write (the 13 fields)

IDs `UC-<module>-NN` unless the client has a scheme. Name verb + object; actor primary / secondary (systems from
`external_systems`); description why + what + outcome; preconditions checkable; postconditions as end states;
priority in the project's scale with one reason; frequency as a number (or TBD); **normal course** numbered, one
action per step, actor / system alternating, no if / else; **alternative courses** `UC-…AC.n`: "at step N, if …",
steps Na…, "continue at step M"; **exceptions** `UC-…EX.n`: trigger, response, final state — cover invalid input,
rule violation, external failure / timeout, permission, concurrency, session timeout where they apply; includes
(existing use cases only); special requirements (non-functional only); assumptions (not preconditions); TBDs with
owner. Labels on screens in **bold** as shown; the actor names of the glossary throughout.

## 3. The 20-point check (write and review modes)

Scope (name verb + object · user-goal level · unique ID · one actor + one goal · clear boundary) · context
(specific actor · why + what + outcome · frequency quantified) · conditions (preconditions checkable · postconditions
complete · preconditions ≠ assumptions) · normal course (numbered, one action · actor / system alternate · no branches
inside · trigger to postcondition) · alternatives and exceptions (step anchor + condition + rejoin · trigger +
response + final state · common failures covered) · completeness (includes exist · special requirements not
functional). Output `# | Check | ✅ / ❌ / ⚠️ | Note`; fix or flag every ❌.

## 4. Test seeds (for `design-scenarios`)

`Course | Scenario seed | Expected (postcondition / final state) | Q` — one row for the normal course, each alternative
and each exception; missing failure paths listed as gaps with a `TBD` / `Q`.

## Rules

- Proposals until confirmed by the BA / client; never a test basis on their own (R1).
- In review mode, findings only — the client's text is not rewritten; proposed wording is an option.
- No implementation detail (endpoints, tables, components) unless the use case is an interface spec.

## Done when

- [ ] Use cases at user-goal level with all 13 fields; the 20-point table; ❌ fixed or flagged.
- [ ] Test seeds per course; TBDs with owners; status Proposed; README list updated.
