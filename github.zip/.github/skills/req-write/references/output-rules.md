# req-write: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing. Copy the form's template, replace every `<placeholder>`, delete the template comments. Linked,
never copied: [core-rules.md](../../../../standards/core-rules.md) R1 ·
[requirement-quality.md](../../../../standards/methods/requirement-quality.md) §8 (stories), §9 (use cases) · the
form's reference ([user-story.md](user-story.md), [use-case.md](use-case.md)) for the content rules.

| Form | Template | File | Write mode |
|---|---|---|---|
| story | [user-stories.md](../assets/user-stories.md) | `plans/stories/<YYYY-MM-DD>-<slug>.md` | new dated file |
| use case | [use-case.md](../assets/use-case.md) | `plans/use-cases/<UC-ID>_<slug>.md` + a row in `plans/use-cases/README.md` (`UC ID \| Name \| Primary actor \| Goal \| Trigger \| Priority`) | one file per use case |
| questions | — | `project/questions.md` | on the user's OK |

## Rules

- **Header** `**Status: Proposed — awaiting PO / BA confirmation**`, the input source and the form / mode, on every
  file. A proposal is never a test basis until it is in a confirmed source (R1).
- **IDs:** `US-<code>-NNN` / `UC-<module>-NN` unless the client has a scheme; never reused.
- **Unknowns** are `TBD-n` with question, owner and what it blocks; never a "usual" number.
- Labels on screens in **bold** as shown; actor names from the glossary.
- No implementation detail (endpoints, tables, components) unless the spec is an interface spec.
- Language: `project.json › project.document_language`.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
