<!-- Template: req-write, use-case form. Copy to plans/use-cases/<UC-ID>_<slug>.md and add its row to
plans/use-cases/README.md. Replace every <placeholder>, delete these comments. Rules: ../references/output-rules.md. -->
# <UC-<module>-NN>: <verb + object>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Status: Proposed — awaiting PO / BA confirmation** · **Input:** <source> · **Form / mode:** use-case · <write | section>

| Field | Value |
|---|---|
| 1. ID | <UC-<module>-NN> |
| 2. Name | <verb + object> |
| 3. Actors | Primary: <glossary actor> · Secondary: <systems from external_systems> |
| 4. Description | <why + what + outcome> |
| 5. Preconditions | <checkable> |
| 6. Postconditions | <end states> |
| 7. Priority | <project scale> — <one reason> |
| 8. Frequency | <number or TBD-n> |
| 9. Includes | <existing use cases only> |
| 10. Special requirements | <non-functional only> |
| 11. Assumptions | <…> |
| 12. TBDs | TBD-1: <question> (owner, blocks) |

## 13. Courses

**Normal course**

1. <Actor> <one action>.
2. System <one response>.

**Alternative courses**

- **<UC-…>AC.1** — at step <N>, if <condition>: <N>a. … ; continue at step <M>.

**Exceptions**

- **<UC-…>EX.1** — trigger: <…> · response: <…> · final state: <…>

## 20-point check

| # | Check | ✅ / ❌ | Note |
|---|---|---|---|

## Test seeds

<For design-scenarios: courses → scenario seeds.>
