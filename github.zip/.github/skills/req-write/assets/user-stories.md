<!-- Template: req-write, story form. Copy to plans/stories/<YYYY-MM-DD>-<slug>.md, replace every <placeholder>, delete
these comments. Language: project.json › project.document_language. Rules: ../references/output-rules.md. -->
# User stories: <feature>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Status: Proposed — awaiting PO / BA confirmation** · **Input:** <source path / ticket / discovery file> ·
**Form / mode:** story · <write | refine | complete>

## US-<code>-001 · <title>

**As a** <specific persona> **I want** <one concrete action> **so that** <outcome that differs from the action>.

**Epic:** <…> · **Priority:** <project's scale> · **Dependencies:** <…>

| INVEST | ✅ / ⚠️ | Why |
|---|---|---|
| Independent | <…> | <…> |
| Negotiable | <…> | <…> |
| Valuable | <…> | <…> |
| Estimable | <…> | <…> |
| Small | <…> | <…> |
| Testable | <…> | <…> |

**Acceptance criteria**

- **AC1 (happy):** *Given* <checkable state> *When* <one action> *Then* <exact message / status / value>
- **AC2 (edge):** *Given* … *When* … *Then* …
- **AC3 (negative):** *Given* … *When* … *Then* … *And* <nothing else changed>

**Notes:** <dependencies · assumptions · TBD-n: question (owner, blocks)>

<!-- Refine mode, before the rewritten story:
| Story / AC | Problem (INVEST letter or criterion rule) | Why it matters for testing | Proposed fix |
|---|---|---|---| -->
