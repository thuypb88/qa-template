---
name: plan-testplan
description: Plan (writer, project, IT and ST, every pack): the formal test plan with its schedule and estimation. Size the work from the sources and the suites, estimate effort (three-point, per activity and module), lay the phases on a working-day calendar with team, milestones and planned burn-up - scripts/test_estimate.py from plans/estimation.json into plans/test-estimate.md (+ .xlsx) - then write plans/test-plan.md in the organisation's format, the default template in plans/templates/ first (document control, scope, objectives, levels, environments, data, approach per level, defects, schedule, resources, entry / exit, risks, deliverables, reporting), from plans/test-strategy.md. Modes plan, estimate, schedule. Use for "write the test plan", "test schedule", "test estimation", "how many man-days", "when can testing finish", "re-estimate after the test cases", "kế hoạch kiểm thử", "ước lượng". Not for: the test approach itself → plan-strategy; a sprint or release timeline → flow-cadence; the roadmap → flow-roadmap.
metadata:
  group: plan
  order: "-1"
---

# Plan: test plan, schedule and estimation

> **Created:** 2026-10-22 10:55:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `plans/test-strategy.md` (the approach), `project.json`, `project/questions.md`, `project/decisions/`,
the **default template** `plans/templates/*Test_Plan_Template.docx` with `plans/templates/README.md` (the
organisation's format adapted to this project); without one, the organisation's sample in `sources/testing/`
(format only); `plans/estimation.json`, `python3 scripts/test_estimate.py [--json | --check]`.
**Out:** `plans/estimation.json` (inputs, versioned), `plans/test-estimate.md` + optional `.xlsx` (generated),
`plans/test-plan.md` (versioned); in plan mode the deliverable `deliverables/test-plan/<CODE>_Test_Plan_v<version>.docx`
filled from a copy of the template; questions; an ADR when the QA lead accepts the estimate.
**Rules:** core R1 (no invention), R9 (levels), conventions §10 (formats).
**Next:** `check-testplan` (before the plan is sent), `design-analysis` (first module), `flow-roadmap update` (targets from the milestones).
**Stop if** `plans/test-strategy.md` is missing → `plan-strategy` first (the plan states the approach, it does not
invent it); `project.json` has no modules → `plan-setup`.
**Output:** [assets/test-plan.md](assets/test-plan.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Modes

| Mode | When | Does |
|---|---|---|
| **estimate** | "how many man-days", first plan, or after suites are written (actual TC counts replace estimates) | steps 1–3 |
| **schedule** | dates, team or constraints changed; "when can we finish" | steps 2–3 (inputs: calendar, team, constraints) |
| **plan** | "write / update the test plan" | steps 1–5 |

## Steps

1. **Inputs.** No `plans/estimation.json` → `python3 scripts/test_estimate.py --init`, then tailor it (format:
   [references/estimation-model.md](references/estimation-model.md)): one size entry per module, counted from the
   sources with an `ids` regex (open the parsed source to find the ID scheme; `glossary.py` lists ID schemes), plus
   custom items (custom developments, interfaces, reports) each with a `tc_per` rate; team, calendar, holidays,
   constraint dates (build ready per module, ST environment, UAT start). Every value keeps a `source`; a number
   nobody gave stays `proposed — …` or `Q-…: assumed …`.
2. **Run** `python3 scripts/test_estimate.py` and read the errors, the schedule lines and the open inputs. Sanity-check
   against the strategy: a phase the strategy excludes has no activity; a level it adds (NFR, migration, BA UAT) gets
   one (`references/estimation-model.md` › extending).
3. **Write** `python3 scripts/test_estimate.py --write` (add `--xlsx` when openpyxl is present). Bump `version` in
   the inputs on every change. Check: `--check` → 0 problems.
4. **Test plan.** Pick the format: the default template in `plans/templates/` when there is one (its section
   numbers, headings, table columns and the organisation's standard text listed in its README win), else
   [references/test-plan-format.md](references/test-plan-format.md). Write `plans/test-plan.md` section by section
   in that order, with the template's table columns; the source of each row is in test-plan-format.md › "Where each
   section comes from": the strategy supplies scope, levels, approach, data, criteria, defects; `project.json`
   supplies modules, environments, externals; the estimate supplies §6 schedule, milestones and §7 effort (copy the
   tables, cite `test-estimate.md` with its inputs version). Standard text the template README marks as the
   organisation's is kept; every `[placeholder]` is filled from a source or written as a gap with its question,
   never left in and never filled from the sample. §7.2 tools and §10 deliverables name the workbook templates in
   `plans/templates/` (test cases, progress dashboard) when they exist.
   **Deliverable (plan mode):** copy the template to `deliverables/test-plan/<CODE>_Test_Plan_v<version>.docx`
   and fill it from `plans/test-plan.md`, section by section (the `docx` skill); add or update its row in
   `deliverables/README.md` › Issued. The Markdown stays the source; the template is never edited; a sent copy is
   frozen (a change → a new version). A new version archives the one it supersedes in the same change set
   ([conventions §11](../../../standards/conventions.md#11-archive-dont-delete)).
5. **Questions and record.** Each open input that changes a date or the total by more than the contingency → a
   question with its owner (dates and team: client / PM; rates: QA lead). `project/log.md` line; commit
   `test plan v<n>: …` / `estimation v<n>: …`.

## Rules

- **The template is the default format; the sample is not a basis.** `plans/templates/` holds the organisation's
  format already cleaned for this project, so use it before any sample. A test plan from another project (another
  client, system, IDs) gives section order, table shapes and wording style only; none of its scope, dates, names,
  targets or IDs are copied. A template change (new section, renamed table) is made in `plans/templates/` and its
  README, not only in `plans/test-plan.md`.
- **Proposed until accepted.** Rates, team, contingency and criteria are proposals; once the QA lead / PM accepts
  the estimate, record an ADR and change the sources to cite it.
- **Re-estimate with actuals.** After `design-cases`, the script counts real TCs; re-run `--write` and update §6 / §7
  (the plan cites the inputs version it used).
- Dates `YYYY-MM-DD`, working days, the project timezone; never a pass-rate or coverage target nobody stated
  (`Q-…: proposed`).

## Done when

- [ ] `test_estimate.py --check` → 0 problems; open inputs listed in `test-estimate.md` §9 and raised as questions.
- [ ] `plans/test-plan.md` (plan mode): every section of the format (the default template when present) present
      or marked as a gap with its question; no `[placeholder]` left; §6 / §7 match the current `test-estimate.md`;
      Version and Updated stamp bumped; `deliverables/test-plan/<CODE>_Test_Plan_v<version>.docx` matches it and is
      indexed in `deliverables/README.md`.
- [ ] `project/log.md` line; report total PD (expected / P80 / planned), start → finish, open inputs; suggest the
      next skill.
