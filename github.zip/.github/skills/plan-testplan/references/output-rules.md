# plan-testplan: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 15:44:58 (UTC+7)

Read before writing any output. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md) R1, R9 ·
[conventions.md](../../../../standards/conventions.md) §10 (formats), §11 (archive) · section sources and pre-issue
checks: [test-plan-format.md](test-plan-format.md) · estimate inputs: [estimation-model.md](estimation-model.md).

| Output | Template | File | Write mode |
|---|---|---|---|
| estimate inputs | `python3 scripts/test_estimate.py --init` | `plans/estimation.json` | edit; bump `version` on every change; every value keeps a `source` |
| estimate | generated | `plans/test-estimate.md` (+ `.xlsx`) | `test_estimate.py --write [--xlsx]` only, never by hand |
| test plan | [test-plan.md](../assets/test-plan.md), or the organisation's template in `plans/templates/` (wins) | `plans/test-plan.md` | edit; bump Version and the Document control row |
| deliverable (plan mode) | a copy of `plans/templates/*Test_Plan_Template.docx` | `deliverables/test-plan/<CODE>_Test_Plan_v<version>.docx` + its row in `deliverables/README.md` › Issued | new file per version; the superseded one archived in the same change set; a sent copy is frozen |
| decision | `project/decisions/ADR-000-template.md` | `project/decisions/ADR-NNN-<slug>.md` | when the QA lead accepts the estimate |

## Rules

- **Template sections** of [test-plan.md](../assets/test-plan.md), in order: `## Document control` · `## 1. Introduction` · `## 2. Test strategy` · `## 3. Test environments` · `## 4. Approach by level` · `## 5. Defect management` · `## 6. Test schedule` · `## 7. Resources` · `## 8. Entry and exit criteria` · `## 9. Risks and mitigation` · `## 10. Deliverables` · `## 11. Reporting and metrics` · `## Open questions`.
- **Every section** of the format present, or a gap `— (Q-…: <what is missing>, owner)`; no `[placeholder]` left.
- **§6 / §7** copy the tables of the current `test-estimate.md` and cite its inputs version; never type a date.
- Dates `YYYY-MM-DD`, working days, the project timezone; amounts per conventions §10.
- **No invented targets:** a pass-rate or coverage target nobody stated is `Q-…: proposed`.
- **Sample plans** give format only: none of another project's scope, dates, names, targets or IDs.
- Rates, team, contingency and criteria are proposals until accepted (then an ADR).
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.

## Checks before done

```bash
python3 scripts/test_estimate.py --check     # 0 problems
python3 scripts/check_testplan.py            # before handing to check-testplan
```
