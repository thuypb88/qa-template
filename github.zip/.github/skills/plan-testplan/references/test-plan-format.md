# Test plan format

> **Created:** 2026-10-22 10:55:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

Load in **plan** mode, step 4. The section order and table shapes follow the organisation's fixed-cost test plan
(a Word document: cover, document control, sections 1–11). When the project has a default template
(`plans/templates/*Test_Plan_Template.docx` + README), its numbering, headings and table columns win over the
skeleton below; the source table still says where each section's content comes from. Fill each row from the
workspace source named in the right-hand column; when the source has nothing, write the row as a gap:
`— (Q-…: <what is missing>, owner)`.

## Skeleton of `plans/test-plan.md`

The skeleton is the skill's output template: [../assets/test-plan.md](../assets/test-plan.md) (cover table, document
control, sections 1–11, open questions). File rules: [output-rules.md](output-rules.md).

## Where each section comes from

| Section | Table / content | Source in the workspace |
|---|---|---|
| Cover, control | project, client, version, approvers (roles; names only when given) | `project.json › project`, the strategy §10 roles |
| 1.2 Scope | in scope per module / interface; out of scope with the reason | strategy §1, `project.json › modules`, `0-scope.md` |
| 1.3 Objectives | `# · Objective · Measurable target` | strategy §1 + §6; a target nobody stated → `Q-…: proposed` |
| 1.4 Definitions | terms used in this plan | `project/system-map.md` › Glossary (cite it, don't redefine) |
| 2.2 Levels | `Level · Scope · Responsibility · Environment · Automation` | strategy §3, `project.json › levels` (exact env names) |
| 2.3 Types | `Test type · Description · When applied` | strategy §4, packs, `design-nfr` plan if any |
| 3.1–3.2 | `Environment · Purpose · Data · Managed by`; data strategy, PII, refresh | strategy §3, §5; `test-data.md` |
| 3.3 Client data | `# · Data / account · Components · Purpose · Owner` | Q-… on accounts and data; `design-data` needs |
| 3.5 Externals | `System · IT (mock / fixture) · ST (real)` | `project.json › external_systems` |
| 4.x per level | responsibility, timing, input, output, scope, what is out of scope for the level and where it is tested instead | strategy §3–4, analysis §level scope |
| 5 Defects | severity / priority scales, life cycle, template | strategy §7, `run-defects` |
| 6.1 Phases | `Phase · Activities · Start · End · Duration · Depends on` | `test-estimate.md` §5 |
| 6.2 Milestones | `Milestone · Target date · Deliverable · Gate criteria` | `test-estimate.md` §7 |
| 6.3 Effort | totals (expected / P80 / planned), by phase and role, main assumptions | `test-estimate.md` §1, §4, §9 |
| 7.1 Team | `Role · Name · Responsibilities · Allocation · Location` | `estimation.json › team`, strategy §10 |
| 7.2 Tools | `Category · Tool · Purpose` | `project.json › runners`, strategy §7–8 |
| 8 Criteria | `Level · Entry · Exit` | strategy §6 (cite its question if still proposed) |
| 9 Risks | `# · Risk · Impact · Likelihood · Mitigation` | strategy §11, roadmap §8 |
| 10 Deliverables | `Deliverable · Description · When · Audience · Format` | the pipeline outputs (TCs + Excel, reports, RTM) |
| 11 Reporting | cadence and metrics with formula and target | `run-report`, `flow-cadence`; targets only when stated |

## Check before issuing

Seen in sample plans; each one makes a plan look unfinished or contradict itself:

- Placeholders left in (`[Name]`, `[Date]`, `[N days]`, `[Target %]`) — replace or mark as a gap with its question.
- Duplicate or skipped section numbers; cross-references to sections that do not exist ("Section 3.5" with no 3.5).
- Milestone dates that come before the phase they close, or a test-plan approval after test design ended.
- Entry / exit headings with no criteria under them; one criterion stated two ways in two sections.
- Durations that do not match the start and end dates; the same person in two full-time roles.
- Facts of another project (client, system name, requirement IDs) left in after reusing a plan as a template.
