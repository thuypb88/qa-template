# Estimation model — `plans/estimation.json`

> **Created:** 2026-10-22 10:55:00 · **Updated:** 2026-11-02 08:43:25 (UTC+7)

Load in **estimate** / **schedule** mode, step 1, and when extending the model. The script is
`scripts/test_estimate.py`; its docstring has the formulas.

## Value shape

Every input is `{"value": …, "source": "…"}` (or `{"ids": "<regex>", "source": "…"}` for a size counted from the
sources). A source is a document line (`AP:152`), an ADR, measured history (`cycle C1 of release 1: 22 TC/day`), or
`proposed — <why>` / `Q-…: assumed …`. The script lists the last kind as **open inputs**; they are the estimate's
assumptions, stated in the plan.

## Sections

| Key | Holds | Notes |
|---|---|---|
| `version` | `"0.1"` | bump on every change; `test-estimate.md` cites it |
| `hours_per_day` | 8 | one person-day (PD) |
| `calendar` | `start`, `workdays` (`"mon-fri"` or `"mon,tue,…"`), `holidays` `[{"date","name","source"}]` | holidays from the client / company calendar, never from memory |
| `team` | `[{"role","title","count","allocation","source"}]` | `role` is what activities name (`lead`, `tester`, `automation`, …) |
| `size.modules.<id>` | named items (`requirements`, `custom_developments`, `interfaces`, …) + `complexity` | every `project.json` module needs one |
| `size.tc_per.<item>` | TCs per unit of an item | used until the module has a real suite |
| `size.st` | `tc` (given) or `tc_ratio_of_it`; extra ST items (e.g. `e2e_flows`) | the real ST suite count wins |
| `factors` | `cycles` (share of TCs per cycle), `defect_rate`, `automation_share`, `regression_share`, `regression_runs`, `management`, `contingency` | ratios 0–1 |
| `progress` | `<module>.design_done`, `ST.partial_suite` | work already done: design dropped from effort and schedule; a partial ST suite sized for the whole system |
| `constraints` | `build_ready.<module>`, `st_env_ready`, `uat.start`, `uat.duration_days` | dates gate when a phase may start |
| `activities` | `[{"id","name","phase","role","per","hours":[o,m,p],"source"}]` | one role per phase |

**Phases** (fixed order and dependencies): `plan` → `it-design` (per module, one person) → `automation` (per module)
→ `it-execute` (per module, after its design and its `build_ready`) → `st-design` (after every IT design) →
`st-execute` (after every IT execution, ST design and `st_env_ready`) → `regression` → `uat-support` (fixed duration).

**`per` quantities:** module phases — any size item, `tc`, `tc_runs` (TCs × Σ cycles), `defects`, `auto_tc`, `fixed`;
ST phases — `tc`, `tc_runs`, `defects`, ST items, `fixed`; project phases — `fixed`, `modules`, `tc_total`,
`regression_tc_runs`, `uat_days`.

## Method

- Three-point per unit: E = (o + 4m + p) / 6, σ = (p − o) / 6, multiplied by units and module complexity.
- P80 = E + 0.84 σ_total (activities independent); planned = E × (1 + contingency) drives the calendar.
- Use P80 when committing a date to the client; planned for the internal schedule. Say which one a date is.
- Rates come, in order of preference, from: this project's recorded cycles (`run-report` actuals) → the team's
  history on a similar system → the proposed defaults (rules of thumb, labelled as such).

## Re-estimating

| Event | Change | Effect |
|---|---|---|
| `design-cases` wrote a suite | nothing — the script counts it | that module's TCs become `actual` |
| A module's design is reviewed and more modules wait | `progress.<module>.design_done` with the review as source | its design leaves the effort and the schedule |
| The ST suite covers only some modules | `progress.ST.partial_suite` | ST sized from the ratio; design only for the TCs not written |
| A cycle was recorded | replace `EXE` / `STE` hours with the measured TC/day (`8 / rate`), cite the cycle | execution effort |
| New build / UAT dates | `constraints` | the schedule; milestones move |
| Team change | `team` | durations |
| Change request | the module's size items (re-count) — after `plan-changes` | everything downstream |

## Extending

A level or activity the strategy adds (performance, migration verification, BA UAT, exploratory sessions): add an
activity to the closest phase with its own `per` (`fixed`, `modules`, an ST item such as `migration_objects`), or ask
for a new phase in the template (`check-skill` → template issue). Never fold it silently into contingency.
