<!-- Template: plan-testplan, plan mode. Copy to plans/test-plan.md. When plans/templates/*Test_Plan_Template.docx exists,
its numbering, headings and table columns win over this skeleton. Fill each section from the source named in
../references/test-plan-format.md › Where each section comes from; a section with no source is a gap:
`— (Q-…: <what is missing>, owner)`. Delete these comments. Rules: ../references/output-rules.md. -->
# Test plan — <project name>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

| Project name | Client | Document ID | Related documents | Version | Date | Classification |
|---|---|---|---|---|---|---|
| <name> | <client> | <id> | <documents> | <0.1> | <YYYY-MM-DD> | <classification> |

## Document control

| Version | Date | Author | Reviewer | Changes |
|---|---|---|---|---|

| Role | Name | Organization | Signature | Date |
|---|---|---|---|---|

**Referenced documents:** <list>

## 1. Introduction

### 1.1 Purpose
### 1.2 Scope (in / out)
### 1.3 Quality objectives
### 1.4 Definitions

## 2. Test strategy

### 2.1 Approach
### 2.2 Test levels overview
### 2.3 Test types

## 3. Test environments

### 3.1 Environments
### 3.2 Test data management
### 3.3 Data and accounts the client provides
### 3.4 Browser / device matrix
### 3.5 External systems: mocks (IT) and real (ST)

## 4. Approach by level

### 4.<n> <level>

| Responsibility | Timing | Environment | Execution | Input | Output |
|---|---|---|---|---|---|

<Scope of this level.>

## 5. Defect management

<Severity · priority · life cycle · report template.>

## 6. Test schedule

### 6.1 Phases and timeline
### 6.2 Key milestones
### 6.3 Effort estimate

<Tables copied from plans/test-estimate.md (inputs v<n>), never typed.>

## 7. Resources

### 7.1 Test team
### 7.2 Tools and infrastructure

## 8. Entry and exit criteria

## 9. Risks and mitigation

| Risk | Impact | Likelihood | Mitigation | Owner |
|---|---|---|---|---|

## 10. Deliverables

## 11. Reporting and metrics

### 11.1 Cadence
### 11.2 Key metrics

## Open questions

| ID | Question | Owner | Sections |
|---|---|---|---|
