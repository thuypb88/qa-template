# design-data: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-29 09:15:29 (UTC+7)

Read before writing the data plan. Copy [../assets/test-data.md](../assets/test-data.md), replace every
`<placeholder>`, delete the template comments. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R6, R6.3, R9, R10 · [test-techniques.md](../../../../standards/methods/test-techniques.md) §6 (pairwise) ·
[conventions.md](../../../../standards/conventions.md) (stamp, §10 formats).

| Output | File | Write mode |
|---|---|---|
| data plan | `<folder>/3-test-cases/test-data.md` | overwrite (TDR and set names kept) |
| data files (on request) | `automation/<pack>/fixtures/…`, `automation/etl/fixtures/<ETL-FX-…>.sql` | overwrite; reproducible (fixed seed) |
| TCs with non-concrete `test_data` | "Raise to the writer" list in the report | — |

## Rules

- **Sections**, in order: header line (folder, TC version, analysis, level) · `## Data requirements` ·
  `## Data sets` · `## Pairwise sets` (when factors combine) · `## Isolation` · `## Set-up and run order` ·
  `## Cleanup` · `## Blockers and questions`; `## Revision log` on later versions.
- **TDR IDs** `TDR-NNN`, never renumbered or reused. Every TC is in a TDR group or listed as "no data needed".
- **Set names** are the analysis §11 fixture names (`<KIND>-<name>`); a set the analysis lacks is a proposal with a
  `Q-xxx`, never an invented ID, account or name (L-T07).
- **Valid and invalid apart:** an invalid row breaks one constraint and names it; every other value stays valid.
- **Pairwise:** list factors and constraints so the set can be recomputed.
- **Values:** boundaries in the field's unit and step; each language with its special characters; dates relative to
  "today" with the timezone; amounts in the currency's minor unit, written per conventions §10.
- **Privacy:** synthetic or masked only, never production copies.
- **Generated files** start with a short header naming the TDR and TCs they serve, and the seed.
- **Diagrams** per [design-diagrams.md](../../../../standards/methods/design-diagrams.md) §3 (Mermaid): the set dependency
  and run order under `## Set-up and run order` (always); pairwise factors under `## Pairwise sets` only when that
  section has sets. Node names are the plan's set names and `TDR-` IDs; changed in the same edit as the tables.
