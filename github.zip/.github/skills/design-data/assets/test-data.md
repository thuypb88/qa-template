<!-- Template: design-data. Copy to <folder>/3-test-cases/test-data.md, replace every <placeholder>, delete these
comments. Rules: ../references/output-rules.md. -->
# <module name | ST: project name>: test data plan

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Folder:** `<folder>` · **Test cases:** `test-cases.json` v<version> · **Analysis:** §5, §11 (Updated <stamp>) ·
**Level:** <IT: mocks / fixtures | ST: data the test plan provides>

## Data requirements

| TDR | TCs | Entities / fields | State / role / relation needed | Value classes | Source of values | Set-up | Cleanup | Blocker |
|---|---|---|---|---|---|---|---|---|
| TDR-001 | <TC-… ranges> | <entity.field> | <state, role, relation> | <valid, invalid, boundary, language, variant> | <analysis §5 row \| fixture> | <how> | <how> | <Q-xxx or —> |

## Data sets

| Set | Kind | Valid / invalid | Rows | TCs | File |
|---|---|---|---|---|---|
| <KIND-name from analysis §11> | <fixture \| builder \| request body \| SQL> | <Valid \| Invalid: breaks <one constraint>> | <n> | <TC-…> | <path or —> |

## Pairwise sets

<!-- Only when factors combine. -->
**Factors:** <factor: values> · **Constraints:** <illegal combinations>

| Row | <factor> | <factor> | TCs |
|---|---|---|---|

## Isolation

<Per-run prefix / namespace for created records; who may run it in a shared environment; privacy: synthetic or
masked only, generator and seed.>

## Set-up and run order

1. <set, in dependency order>

```mermaid
flowchart TD
  base["<BASE fixture / seeded master>"] --> set1["<SET name>"] --> tdr1["TDR-001"]
  ext1["<owner>: <reset / lock / window>"]:::ext --> tdr1
  classDef ext stroke-dasharray:4
```

## Cleanup

1. <reset, in reverse dependency order>

## Blockers and questions

- Q-<xxx> (<TDR / TCs>): <question> — assumed <value>
