---
name: design-data
description: Design: test data (after design-cases, before automation or execution; IT or ST, every pack). Turn a folder's test cases into a test data plan in 3-test-cases/test-data.md - data requirements per TC group (entities, states, roles, relations, value classes), named data sets and fixtures (analysis §11 names), valid vs deliberately invalid rows (each naming the one constraint it breaks), pairwise sets for factor combinations, localisation values, set-up order, reset and cleanup, synthetic / masked only - and, on request, generate the data files under automation/<pack>/fixtures/. Use for "prepare test data for E4", "what data do we need", "generate fixtures", "pairwise data sets", "data for the ST cycle". Writing TCs → design-cases; SQL insert / cleanup scripts for the planned sets → sql-data; project-specific generators stay project skills.
metadata:
  group: design
  order: "5+"
---

# Design: test data

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-29 09:15:29 (UTC+7)

**In:** `3-test-cases/test-cases.json` (`slice.py tc <target> --stats`, then `--form "<item>"`), analysis §5 (field
rules) and §11 (fixtures, baseline), `project.json › variant_sets / languages / externals`, the pack's TC block
(`api.request`, `etl.fixture`). **Out:** `3-test-cases/test-data.md`; on request, files under
`automation/<pack>/fixtures/` (and `automation/etl/fixtures/<ETL-FX-…>.sql`); TCs whose `test_data` is not concrete →
"Raise to the writer". **Rules:** core R6 (concrete data), R9 (IT fixtures / ST real data), R10, R6.3; diagrams per [design-diagrams.md](../../../standards/methods/design-diagrams.md) §3. **Next:**
`auto-decide` → `auto-design` (data builders) → `auto-write`, or `run-tests` for manual runs.
**Output:** [assets/test-data.md](assets/test-data.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **Group the TCs** by the data they need (same item, same state, same role). Per group write a data requirement:

   `TDR-NNN | TCs | Entities / fields | State / role / relation needed | Value classes (valid, invalid, boundary,
   language, variant) | Source of values (analysis §5 row, fixture) | Set-up | Cleanup | Blocker`

2. **Name the data sets** with the fixture names of analysis §11 (`<KIND>-<name>`); a needed set the analysis lacks →
   a new fixture proposal and a `Q-xxx` for the QA lead / DEV (L-T07: never invent IDs, accounts, names).
3. **Valid and invalid apart.** A valid set holds only valid rows. Each invalid row breaks **one** constraint, names
   it, and keeps every other value valid, so the expected outcome has one cause.
4. **Combinations:** factors from variant sets, roles, channels, languages → the smallest pairwise set over the legal
   combinations (techniques reference §6 of `design-scenarios`), plus the higher-order ones a risk points at; list
   the factors so it can be recomputed.
5. **Values:** boundaries in the field's unit and step; each project language with its special characters (R6.3);
   dates relative to "today" with the timezone when a rule depends on the date; amounts in the currency's minor unit.
6. **Privacy:** synthetic or masked data only; no real customer data, even in UAT. Personal-looking values come from a
   generator with a fixed seed, never copied from production.
7. **Isolation and cleanup:** per-run prefix / namespace for created records; reset (fixture reload, API delete,
   SQL truncate of the test schema) in reverse dependency order; who may run it in a shared environment. Draw the set dependency and run order
   (design-diagrams §3.1): bases → derived sets → TDR groups, with the shared-state steps between them.
8. **Generate on request:** data files per pack (JSON request bodies, CSV, SQL inserts) with a fixed seed so the same
   command gives the same data; a short header in each file naming the TDR and TCs it serves.

## Output

Copy [assets/test-data.md](assets/test-data.md); sections, IDs and value rules per
[references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- Every value traces to the analysis, a fixture or a `Q-xxx` assumption; TCs and data agree (a TC whose
  `test_data` changes → the writer, not here).
- IT data lives in mocks / fixtures; ST uses the data the test plan provides in UAT — never production copies.

## Done when

- [ ] Every TC belongs to a TDR group or is marked "no data needed"; every TDR has a set or a blocker.
- [ ] Invalid rows each name their broken constraint; pairwise sets list factors and constraints.
- [ ] Privacy and cleanup stated; generated files reproducible; report sets, blockers, new questions.
- [ ] Set dependency and run order diagram under `## Set-up and run order`, agreeing with the sets and steps (design-diagrams §3.1).
