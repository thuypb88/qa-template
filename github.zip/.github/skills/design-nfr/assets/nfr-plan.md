<!-- Template: design-nfr. Copy to test-design/st/nfr-plan.md, replace every <placeholder>, delete these comments.
Rules: ../references/output-rules.md. -->
# <project name>: non-functional test plan

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Sources:** <NFR requirement IDs, test plan §, ST analysis §7> · **Environment:** <as named in project.json> ·
**Open questions:** <n>

## Scope and sources

| Key | File |
|---|---|
| <KEY> | [<document>](<relative path>) |

<In scope / out of scope, cited.>

## NFR items

| NFR | Area | Requirement / source | Target (sourced or Q) | Method / tool | Data / environment | Evidence | Pass / fail rule | Blocker |
|---|---|---|---|---|---|---|---|---|
| NFR-001 | <Performance \| Security \| Accessibility \| Compatibility> | <REQ-ID [KEY:line]> | <value + unit, or Q-ST-xxx> | <method, tool> | <data set, environment> | <report, log, screenshot> | <rule> | <Q or —> |

## Workload model

| Transaction | Users / rate | Volume | Think time | Source |
|---|---|---|---|---|

## Security scope and authorisation

<What may be tested, by whom, authorised by whom and when; techniques; what is out.>

## Accessibility and compatibility

| Target | Standard / level | Pages / flows | Source |
|---|---|---|---|

| Browser / device / OS | Version | Priority | Source |
|---|---|---|---|

## Open questions

- Q-ST-<xxx> (<NFR items>): <question> — assumed <value>
