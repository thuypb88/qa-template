# design-nfr: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing the NFR plan. Copy [../assets/nfr-plan.md](../assets/nfr-plan.md), replace every `<placeholder>`,
delete the template comments. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md) R1, R9 ·
[conventions.md](../../../../standards/conventions.md) (stamp, IDs, §10 formats).

| Output | File | Write mode |
|---|---|---|
| NFR plan | `test-design/st/nfr-plan.md` | overwrite (NFR IDs kept) |
| scenarios | `test-design/st/2-mindmap.md`, Non-functional group | by `design-scenarios st` (append), not here |

## Rules

- **Sections**, in order: header line · `## Scope and sources` · `## NFR items` · `## Workload model` ·
  `## Security scope and authorisation` · `## Accessibility and compatibility` · `## Open questions`.
- **IDs** `NFR-NNN`, never renumbered or reused; a dropped item is marked *retired* with the reason.
- **Targets** come from a source (cited) or are a `Q-ST-xxx` with an assumed value; a vague source word ("fast")
  is an `untestable` question, never an invented threshold.
- Every NFR requirement and every pack `X` checklist row has an `NFR-NNN` or a stated reason.
- **Workload model** in units with sources; **security** only authorised, defensive testing, with who authorised it.
- **Environment** names exactly as `project.json` (R9: real environment).
