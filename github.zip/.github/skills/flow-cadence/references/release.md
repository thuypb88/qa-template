# flow-cadence mode: release

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the release name, date, scope and candidate build (from the user / release notes), `plans/test-strategy.md`
(exit criteria), the test plan, `project/defects.md`, `pipeline_status.py`, recorded cycles. **Out:**
`plans/releases/<release>.md`; `project/log.md`; follow-ups. **Next:** the skill the current window names.

## Windows and gates (relative to release day T; compress, never drop)

| Window | Goal | Primary skill | Gate (checkable) |
|---|---|---|---|
| 1. Planning (T-N) | Scope, risks, environments, data | `plan-strategy` (release section) | Scope + **not-in-this-release** list; owners; exit criteria named |
| 2. Freeze | Stop moving targets | `plan-changes` | Changes after freeze listed and traced; each accepted or refused by the release owner |
| 3. Regression on the RC | The release candidate | `run-select` → `run-tests` | Regression set run on the RC build; every failure triaged |
| 4. Non-functional | Performance, security, accessibility as planned | `design-nfr` → `run-tests` | Each planned NFR check has a result; open High risks listed |
| 5. Stabilise | Clear blockers | `run-defects` | No open Critical defect without written acceptance |
| 6. Go / no-go | Recommendation | `run-report` (release report) | Evidence pack complete (below); recommendation stated |
| 7. After go-live | Confirm in production | this skill (§ Post-release) | Post-release smoke done; watch list and escalation path in place |

**Hotfix:** windows 1–6 can shrink to an hour, but keep: impact (`plan-changes`), the targeted regression, the
rollback path, and a named decision maker.

## Evidence pack (window 6)

- Scope shipped = scope planned (or each difference approved).
- Results: regression and NFR runs on the RC build, by recorded cycle; manual results recorded (`record_manual.py`).
- Defects: open by severity, each Critical / Major either fixed and retested or accepted in writing (who, when).
- Exit criteria of the test plan / strategy: Met · Not met · Blocked · Unknown, each with evidence.
- Residual risks and the untested scope.
- **Recommendation:** Go · Go with conditions (each condition checkable, with who checks it and what happens if it
  fails) · No-go. The decision is made and recorded by the release owner; until then it is "pending decision".

## Post-release (window 7)

1. **Read-only checks first** (pages load, lists show, reports open, an API GET), then only the low-risk writes the
   release owner approved, with approved test accounts and cleanable data.
2. **Stop conditions** agreed beforehand (an error on a P1 journey, wrong data) → stop and escalate; never "fix
   forward" by testing more in production.
3. Watch list for the first days (journeys, reports, interfaces to watch; who is on call).

## The record (`plans/releases/<release>.md`)

Copy [../assets/release-record.md](../assets/release-record.md); rules: [output-rules.md](output-rules.md).

## Rules

- Never a pass from a plan: missing or unrun evidence stays Unknown / Not run, and counts against Go.
- An incomplete NFR check stays red; it is not silently dropped from the gate.
- Production actions only with the release owner's explicit scope.

## Done when

- [ ] Record with scope, exclusions, current window and gate board; **Next:** one skill.
- [ ] At T: evidence pack complete; recommendation with reasons; decision recorded or "pending decision".
- [ ] After go-live: smoke log, watch list, escalation path.
