# flow-cadence: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 15:44:58 (UTC+7)

Read before writing the mode's record. Linked, never copied: [conventions.md](../../../../standards/conventions.md)
(stamp, §10 formats); the gates of each mode in its own reference.

| Mode | Template | Where | Write mode |
|---|---|---|---|
| day | [day-plan.md](../assets/day-plan.md) | chat; `project/index.md` › Now at EOD | per day |
| sprint | [sprint-record.md](../assets/sprint-record.md) | `plans/sprints/<sprint>.md` | one file per sprint; gate board updated at each stage |
| release | [release-record.md](../assets/release-record.md) | `plans/releases/<release>.md` | one file per release; post-release log appended |
| all | — | `project/log.md` | one line |

## Rules

- **Template sections** of [release-record.md](../assets/release-record.md), in order: `## Scope` · `## Gate board` · `## Evidence pack` · `## Recommendation and decision` · `## Post-release log`.
- **Gate status** Met · Not met · Blocked · Unknown, each with evidence (file, script output); no evidence → Unknown
  (AMBER "not checked"), never Met.
- **Queue lines** `P<n> · item · skill · done when <condition>`, risk-ordered, one skill each.
- **Recommendation, not decision:** "pending (<owner>)" until the people the plan names decide.
- A gate dropped under time pressure is written as an accepted risk with its owner.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
