<!-- Template: flow-cadence, day mode (chat). Replace every <placeholder>; delete this comment. At EOD also update
project/index.md › Now. Rules: ../references/output-rules.md. -->
**Day plan <YYYY-MM-DD>** · Build <version or unknown> · Start gate: <GREEN | AMBER | RED> (<why>)

| P | Item | Skill | Done when |
|---|---|---|---|
| <P1> | <item> | `<skill>` | <condition> |

**Not today:** <…> · **Blockers:** <blocker → owner, since> · **Next:** `/<skill> <target>`

<!-- EOD: -->
**EOD <YYYY-MM-DD>** · Done: <…> · Carried over: <…> (why) · New defects: <DEF-…> · Blockers: <…> · Tomorrow top 3: 1. <…> 2. <…> 3. <…>
