<!-- Template: flow-cadence, release mode. Copy to plans/releases/<release>.md, replace every <placeholder>, delete this
comment. Rules: ../references/output-rules.md. -->
# Release <release>: test record

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Release:** <name> · **Date T:** <YYYY-MM-DD> · **RC build:** <…> · **Owner:** <who decides>

## Scope

**In this release:** <…> · **Not in this release:** <…>

## Gate board

| Window | Gate | Status (Met / Not met / Blocked / Unknown) | Evidence | Date |
|---|---|---|---|---|

## Evidence pack

<Window 6: the items references/release.md › Evidence pack lists, each with its file.>

## Recommendation and decision

**Recommendation:** <go | go with conditions | no-go> — <reasons> · **Decision:** pending (<owner>) | <decision, who, date>

## Post-release log

| Date | Event | Evidence | Action |
|---|---|---|---|
