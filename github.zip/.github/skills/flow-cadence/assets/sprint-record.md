<!-- Template: flow-cadence, sprint mode. Copy to plans/sprints/<sprint>.md, replace every <placeholder>, delete this
comment. Rules: ../references/output-rules.md. -->
# Sprint <name>: test record

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Goal:** <…> · **Dates:** <YYYY-MM-DD → YYYY-MM-DD> · **Build(s):** <…>

## Scope

| Story / CR / module | In / out | Risk (P) | Folder(s) | Owner |
|---|---|---|---|---|

## Gate board

| Gate | Status (Met / Not met / Blocked / Unknown) | Evidence | Date |
|---|---|---|---|

## Carry-over and accepted risks

| Item | Why | Owner | Next sprint? |
|---|---|---|---|
