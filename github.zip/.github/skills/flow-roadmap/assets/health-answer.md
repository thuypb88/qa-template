<!-- Template: flow-roadmap, health mode (chat). Replace every <placeholder>; delete this comment. New risks also go to
§8 of plans/roadmap.md. Rules: ../references/output-rules.md. -->
**Health:** <GREEN | AMBER | RED> — <one line why>
**Phase / maturity:** <Pn> · <Ln> (target <Lx> by <date | TBD>)
**Top risks:** 1. <risk> (<evidence>) → `/<skill>`  2. <…>  3. <…>
**Next:** `/<skill> <target>`
