<!-- Template: flow-roadmap. Copy to plans/roadmap.md, replace every <placeholder>, delete these comments.
Rules: ../references/output-rules.md. -->
# QA roadmap — <project name>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

QA lead: <name> · Joined: <YYYY-MM-DD> · Target: <L-level> by <date | TBD> · Status from `python3 scripts/roadmap_status.py`

## 1. Project at a glance

<Client · levels and environments (as project.json names them) · modules (id, pack) · external systems · key dates.>

## 2. Where we are

Current phase <Pn> · maturity <Ln> → next level needs: <script's missing list> · top 3 items (skill each).

## 3. Phases

| Phase | Goal | Skills | Exit gate | Status | Evidence | Owner | Target |
|---|---|---|---|---|---|---|---|
| P0 | <…> | <…> | <…> | <from the script> | <from the script> | <lead's or TBD> | <lead's or TBD> |

## 4. Plan: current and next phase

- `P<n> · <item> · <skill> · done when <condition>`

## 5. Progress board

| Folder | Next | Why |
|---|---|---|

## 6. Metrics trend (append one row per update)

| Date | Phase | Maturity | Suites | TCs | Reviews P / PwF / R | Results Passed / Failed / Blocked | Open Q | Open defects | Pending source changes |
|---|---|---|---|---|---|---|---|---|---|

## 7. Milestone history (append; never rewrite)

| Date | Commit | Kind | Event |
|---|---|---|---|

## 8. Risks and blockers

| ID | Risk / blocker | Phase | Owner | Since | Mitigation | Status |
|---|---|---|---|---|---|---|

## 9. Decisions needed

- <Q-… / ADR-NNN> — <who decides>

## 10. Study plan (project · tech · domain)

| ID | Track | Topic | Why it matters for testing | Learn from | Check of understanding | Status | Target |
|---|---|---|---|---|---|---|---|
