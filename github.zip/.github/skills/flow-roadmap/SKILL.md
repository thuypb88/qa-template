---
name: flow-roadmap
description: Flow (router, whole project): the QA lead's roadmap for a whole engagement, from joining a project to an automated, measured QA practice, and its history (never does the work). Mode start - orient, then build plans/roadmap.md: phases P0-P8 (join, set-up, baseline and strategy, IT design, ST and NFR, automation, execution, report and release, improvement), each with skills, a checkable exit gate, owner and target, the maturity ladder L1-L4, a study plan (project, tech, domain). Mode update - recompute gates with scripts/roadmap_status.py, append the metrics trend and milestone history (from git), flag slips. Mode health - risks and gaps, each to one skill. Use for "I'm joining a new project", "QA roadmap", "onboarding plan", "where is the whole project", "project health", "milestone history", "study plan for project / tech / domain", "lộ trình QA". Not for: the one next step → flow-next; a day, sprint or release → flow-cadence; the strategy → plan-strategy; project.json → plan-setup.
metadata:
  group: flow
  order: "-1"
---

# Flow: roadmap (start · update · health)

> **Created:** 2026-10-22 09:50:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `python3 scripts/roadmap_status.py [--json] [--since <date>] [--history <n>]` (read-only: phase gates,
maturity, metrics, milestones from git, study seeds), `project.json`, `project/index.md` › Now, `project/status.md`,
`project/questions.md`, `project/defects.md`, `plans/test-strategy.md`, what the QA lead says (team, dates, client
expectations). **Out:** `plans/roadmap.md`; a `project/log.md` line; chat summary. **Rules:** core R1 (no invention),
[conventions](../../../standards/conventions.md) §1–2 (where files go), stamps. **Next:** the one skill the current
phase names.
**Stop if** there is no workspace yet (no `project.json`, or `project.code` is `CHANGE-ME`) → mode **start** stops
after P0 and hands to `plan-setup`; the roadmap is written once P1 is Met.
**Output:** [assets/health-answer.md](assets/health-answer.md) · [assets/roadmap.md](assets/roadmap.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Modes — read only the one you run

| Mode | When | Reference |
|---|---|---|
| **start** | joining a project; no `plans/roadmap.md` yet | [references/start.md](references/start.md) (phases, step-by-step guide, roadmap format) |
| **update** | weekly, after a milestone (suite reviewed, cycle recorded, release) | [references/update.md](references/update.md) |
| **health** | before a steering meeting, a release, or when the lead asks "how healthy are we" | [references/health.md](references/health.md) |

Infer the mode: no roadmap → start; a roadmap whose last trend row is older than the latest milestone → update;
"health", "risks", "are we on track" → health. Say which mode you run.

## Steps

1. **Status:** run `python3 scripts/roadmap_status.py --json`. Its gates, maturity and milestones are the evidence;
   never mark a gate Met that the script reports open. Read `project/index.md` › Now for what scripts can't see.
2. **Study plan:** every mode keeps roadmap §10 — topics in three tracks (project · tech · domain), seeded
   from the script's `study` block and the sources, each with where to learn it and how understanding is checked.
   What is learned goes into `project/system-map.md` (glossary, roles, interfaces) with citations.
3. **Run the mode** from its reference; write or update `plans/roadmap.md` from
   [assets/roadmap.md](assets/roadmap.md) per [references/output-rules.md](references/output-rules.md).
4. **History:** append, never rewrite — new milestone rows since the last one in §7, one metrics row in §6, a
   `gate` row when a phase turned Met. Rows already there stay as written (like IDs: never renumbered).
5. **Hand off:** answer with the current phase, maturity, the top 3 items and **Next:** `/<skill> <target>`. Do not
   do the items here.

## Rules

- **Evidence only.** A gate is Met only when the script says so; a date is a target until the milestone exists in git.
- **Targets and owners are the lead's.** Ask for them; until given they read `TBD` — never invent a date.
- **One hand-off.** One primary skill per answer; the queue lists the rest with their skill.
- **Shared memory.** The roadmap is in git for every agent and person; personal agent memory keeps only a pointer.
- **Study is not a test basis.** Topics come from the sources and `project.json`; an outside reference (vendor docs,
  a regulation, a standard) is marked `external — verify` and becomes a requirement only through `sources/` (R1).
- A phase may be N/A only when `project.json` says so (no ST level, no modules) or the lead decides it (an `ADR-NNN`).

## Done when

- [ ] Mode named; `roadmap_status.py` run; current phase and maturity stated with its evidence.
- [ ] `plans/roadmap.md` has every section of the format, incl. §10 study plan; history rows appended, none rewritten; Updated stamp set.
- [ ] Top items each with one skill and a done condition; **Next:** one skill; `project/log.md` line.
