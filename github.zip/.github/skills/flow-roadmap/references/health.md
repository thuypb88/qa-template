# Mode health — how healthy is the QA effort

> **Created:** 2026-10-22 09:50:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

Read when: mode **health** (steering meeting, before a release, "are we on track").

## Checks (each from a script or a file; else "unknown")

| Area | Evidence | Red flag | Hand to |
|---|---|---|---|
| Phase vs target | §3 Target, script status | target passed, not Met | lead (new target) · §8 risk |
| Basis | `source_changes_pending`, `plans/test-strategy.md` | pending changes; no strategy | `plan-changes` · `plan-strategy` |
| Questions | `project/questions.md` open rows, asked date | open blocking questions older than 10 working days | the owner named in the row; `learn-explain` to escalate |
| Design quality | `pipeline_status.py`: Rework, stale reviews, unreviewed steps | any Rework or stale review | the writer skill · `check-design` |
| Coverage | folders without test cases; ST / NFR missing | a module with no suite near its test phase | `design-analysis` · `design-nfr` |
| Automation | suites without a plan; tests untagged | plan older than the TCs | `auto-decide` |
| Execution | results by value; Failed and Blocked counts | Blocked > Failed (environment problem) | `run-tests` triage |
| Defects | `project/defects.md` open by severity and age | open Critical / High near a release | `run-defects` |
| Learning | `project/lessons.md` Seen ≥ 2 with Action `noted` | repeated lesson not turned into a fix | `learn-retro` |
| Study | roadmap §10 statuses, script `study.plan_done` | a module in design or later whose Domain topic is not Done | `learn-explain` · `sql-study` · the module's sources |
| Maturity | script › maturity, lead's target | below target with no plan | §4 items for the next level |

## Answer

Fill [../assets/health-answer.md](../assets/health-answer.md); rules: [output-rules.md](output-rules.md).

RED = a Critical / High defect open near a release, or a P1-blocking question with no owner, or a passed target
on the current phase. AMBER = any other red flag. GREEN = none. Add new risks to §8 of the roadmap.

## Done when (mode health)

- [ ] Every row of the table checked or marked unknown; colour with its reason; top three risks each with one skill.
- [ ] New risks in roadmap §8; `project/log.md` line.
