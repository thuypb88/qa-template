# Mode update — refresh the roadmap from evidence

> **Created:** 2026-10-22 09:50:00 · **Updated:** 2026-10-22 09:56:00 (UTC+7)

Read when: mode **update** (weekly, after a milestone, or when the last §6 row is older than the newest milestone).

## Steps

1. `python3 scripts/roadmap_status.py --json --since <date of the last §7 row>`.
2. **§3 Phases:** set Status and Evidence from the script. A phase that turned Met since the last update → append a
   §7 row with kind `gate` (`P<n> <name> Met`), the date of the milestone that closed it and its commit.
3. **§7 History:** append the script's milestones newer than the last row (skip any already there: same commit and
   event). Never edit or delete an existing row; a wrong row gets a correcting row below it.
4. **§6 Trend:** append one row from `metrics` (date, current phase, maturity, suites, TCs, reviews, results, open
   questions, open defects, pending source changes).
5. **Study (§10):** set a row `Done (<evidence>)` only when its check left evidence (system-map rows, a
   `learn-explain` session, a `sql-study` card, questions raised); add rows for new modules, interfaces or documents
   the script now seeds. A module about to enter P3 with its Domain row not Done → a §8 risk.
6. **Slips:** a phase whose Target date has passed and is not Met → a §8 risk row (`RK-NNN`, owner, mitigation) or
   update the existing one; ask the lead for a new target, never move it yourself.
7. **§2, §4, §5:** rewrite from the script (these are "now" sections, not history).
8. Updated stamp; `project/log.md` line: `<date> · plans · roadmap update · <phase> <maturity> · RK refs`.

## Done when (mode update)

- [ ] Every §3 status matches the script; new gates and milestones appended to §7, nothing rewritten.
- [ ] §10 study statuses backed by evidence; one new §6 row; slips have a §8 row with an owner; **Next:** one skill.
