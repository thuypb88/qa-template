# Mode start — joining a project, building the roadmap

> **Created:** 2026-10-22 09:50:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

Read when: mode **start** (no `plans/roadmap.md`), and for the roadmap format in every mode.

## 1. Orient first (one turn, before any file)

Ask the lead, at most five questions, only what the files don't already answer:

1. Client, project, your role and team (QA lead, testers, automation engineers), and who you report to.
2. Dates: start, test phases (IT / ST / UAT), go-live; fixed or moving?
3. Documents received and where (requirements, API contracts, mappings, test plan); who owns them (BA, PO).
4. Environments and access: test environments, tracker, repository, test data; what is still missing.
5. What the client expects from QA (deliverables, reports, sign-off) and the target maturity (L1–L4, §3).

## 2. Phases and the step-by-step guide

Each phase: goal, the steps in order (each with its skill or command), the exit gate `roadmap_status.py` checks.
Work the phases in order; P3–P6 overlap per module (one module can be in execution while the next is in design).

| Phase | Goal | Steps (skill / command) | Exit gate (script) |
|---|---|---|---|
| **P0 Join and orient** | Know the project, the people and the documents | (1) the §1 questions; (2) copy the documents into `sources/`; (3) `python3 scripts/extract_text.py`; (4) `req-elicit` for a request without a document; (5) `learn-explain` to brief yourself or the team | documents in `sources/`, extracted, questions register in use |
| **P1 Workspace set-up** | A QA workspace from the template, under version control | (1) `python3 scripts/workspace/template_sync.py --new <dir>` (from the template); (2) `python3 scripts/workspace/setup_workspace.py --check`; (3) `plan-setup` → `project.json`, `project/`, Q-INIT questions; (4) confirm with the lead, then `python3 scripts/init_project.py`; (5) first commit | `project.json` filled in and valid, module folders built, git hooks on |
| **P2 Baseline and strategy** | An agreed test basis and approach | (1) `req-review` on each raw requirement document; (2) `plan-strategy` (or review the client's plan); (3) `plan-changes` whenever a document arrives; accept the baseline | strategy, source baseline accepted with no pending change, requirements reviewed or elicited |
| **P3 IT design per module** | Reviewed test cases per module | per module in `project.json` order: `plan-scope` → `design-analysis` → `check-design` → `design-scenarios` → `check-design` → `design-cases` (pack sql: `sql-cases`) → `check-design`; `design-data` | every module: analysis, scenarios, test cases reviewed, no Rework, not stale |
| **P4 ST and NFR design** | End-to-end and non-functional coverage | `design-system` → `check-design` → `design-e2e` → `design-scenarios st` → `design-cases st` (+ reviews); `design-nfr` | ST chain reviewed; NFR plan |
| **P5 Automation** | A maintained automated regression | `auto-decide` per suite → `auto-design` → `check-automation` (design) → `auto-write` by wave → `check-automation`; `python3 scripts/run_tests.py <target> --plan` | automation plan per suite; codebase design reviewed; automated tests written |
| **P6 Execution and defects** | Evidence that the build works | `run-select` → `run-tests` (record cycles) → `run-defects`; `run-explore` for the manual residue; `flow-cadence` day / sprint for the rhythm | results recorded in every suite; defect register in use |
| **P7 Report and release** | A go / no-go the decision makers can trust | `run-report`; `flow-cadence release` (freeze, RC regression, evidence pack, after go-live) | test summary report; release record |
| **P8 Continuous improvement** | The project learns; the template learns | `learn-retro` after reviews and runs; decisions as `ADR-NNN`; `check-skill` on project needs; promote lessons to the template | lessons recorded; decisions recorded |

## 3. Maturity ladder (from scratch to advanced)

| Level | Means | Criteria (`roadmap_status.py` › maturity) |
|---|---|---|
| L1 Basic | Workspace, sources, manual test cases with Excel | P1 Met; one suite with its Excel |
| L2 Managed | Writer → reviewer everywhere, traceable basis, change control | P2, P3, P4 Met |
| L3 Automated | Automated regression, recorded cycles, defect flow | P5, P6 Met |
| L4 Optimised | Reports and releases from evidence; lessons feed back | P7, P8 Met |

The lead sets the **target level and date**; the roadmap shows the gap to it.

## 4. Study plan — project · tech · domain

The lead has to understand the project before testing it. Build §10 from the script's `study` seeds, then read the
sources' tables of contents (`slice.py toc`) to add what they name. One row per topic; split a module deep-dive per
process when the module is large.

| Track | Covers | Typical topics | Learn from |
|---|---|---|---|
| **Project** | why the project exists and how it runs | goals and scope, stakeholders and roles, timeline and phases, documents and owners, environments and access, ways of working (tracker, cadence, sign-off), the QA workspace | `project/index.md`, `project.json`, `plans/discovery/`, kick-off notes, `USER-GUIDE.md` |
| **Tech** | what is built and how we reach it | platform and version, architecture, customisations / custom developments, integrations and interfaces, data and migration, the test surface and tools per pack (Playwright, pytest, SQL dialect), CI, environments | solution design, interface specs, `project/system-map.md` › Interfaces, `packs/<pack>/`, `sql-study` for database code |
| **Domain** | the business the system serves | processes per module (as-is → to-be), business rules and calculations, roles and segregation of duties, regulation (tax, privacy, industry), reports, glossary | requirement documents per module, `project/system-map.md` › Glossary, Roles |

Order: week 1 — every Project topic and a Domain overview; week 2 — Tech; then each module's Domain deep-dive is
due **before** its `design-analysis` (P3). Each topic has a **check of understanding** that leaves evidence:
an explain-back with `learn-explain` to a named audience, glossary rows from `learn-glossary` (roles / interface
rows) added to the system map with citations, a `sql-study` card, a walkthrough of the screen in the test environment noted in the log, or the
questions it raised in `project/questions.md`. Status: `Not started` · `Learning` · `Done (<evidence>)`.

## 5. Write the roadmap

After P1 is Met (or at once, when joining a running workspace): run `roadmap_status.py --json`, fill the format
below, seed §6 with one row and §7 with every milestone the script returns. First-week queue = P0–P2 items still
open, then the first module of P3.

## Roadmap format (`plans/roadmap.md`)

Copy [../assets/roadmap.md](../assets/roadmap.md); sections, fixed tables and append-only history per
[output-rules.md](output-rules.md).

## Done when (mode start)

- [ ] §1 questions asked (or answered from the files); unknowns are `TBD`, not guesses.
- [ ] Study plan §10 seeded in all three tracks, each row with a source and a check of understanding.
- [ ] `plans/roadmap.md` written with all ten sections; §6 one row; §7 seeded from git.
- [ ] First-week queue in §4; **Next:** one skill (usually `plan-setup` or the first open P2 item).
