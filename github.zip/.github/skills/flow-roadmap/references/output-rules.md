# flow-roadmap: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 15:44:58 (UTC+7)

Read before writing the roadmap or the health answer. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1 · [conventions.md](../../../../standards/conventions.md) §1–2, stamps, §10 formats.

| Mode | Template | Where | Write mode |
|---|---|---|---|
| start | [roadmap.md](../assets/roadmap.md) | `plans/roadmap.md` | create once P1 is Met |
| update | — | `plans/roadmap.md` | edit §2–§5, §8–§10; **append** §6 (one row per update) and §7 (new milestones; a `gate` row when a phase turned Met) |
| health | [health-answer.md](../assets/health-answer.md) | chat; new risks into §8 | per request |
| all | — | `project/log.md` | one line |

## Rules

- **Template sections** of [roadmap.md](../assets/roadmap.md), in order: `## 1. Project at a glance` · `## 2. Where we are` · `## 3. Phases` · `## 4. Plan: current and next phase` · `## 5. Progress board` · `## 6. Metrics trend (append one row per update)` · `## 7. Milestone history (append; never rewrite)` · `## 8. Risks and blockers` · `## 9. Decisions needed` · `## 10. Study plan (project · tech · domain)`.
- **Sections** §1–§10 in the template's order, each present; §10 study plan always kept.
- **Phases** P0–P8; Status and Evidence from `roadmap_status.py` only; Owner and Target from the lead, else `TBD`.
- **History is append-only:** rows in §6 and §7 are never rewritten or renumbered.
- **IDs:** risks `RK-NNN`, study topics `SP-NN`, never reused. Milestone kind one of setup · sources · baseline ·
  requirements · design · review · version · automation · execution · release · decision · gate.
- **Study rows** are due before the phase that needs them (Project and Tech in P0–P2, a module's Domain before
  its P3). Track = Project · Tech · Domain; outside references marked `external — verify`, never a test basis.
- **Health:** RED = a Critical / High defect open near a release, a P1-blocking question with no owner, or a passed
  target on the current phase; AMBER = any other red flag; GREEN = none.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
