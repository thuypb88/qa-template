-- Template: sql-data, one data set. Copy to <folder>/3-test-cases/sql/data/<MOD>-DS-<nn>.sql; replace every <placeholder>
-- and delete these two template lines. Rules: ../references/output-rules.md (dialect forms: packs/sql/dialects.md).
-- Data set: <MOD>-DS-<nn> · Dialect: <dialect> · Used by: <TC-… ranges>
-- Rows:
--   <row group>: <why it exists (state, role, relation, boundary)>
--   <invalid row>: breaks <one constraint>, every other value valid
-- Run marker: <key prefix S1- | created_by = 'QA-<MOD>'> · Synthetic values only.

-- 1. Idempotent: remove this set's rows first (children before parents), or use the dialect's upsert.
DELETE FROM <child_table> WHERE <key> LIKE '<marker>%';
DELETE FROM <parent_table> WHERE <key> LIKE '<marker>%';

-- 2. Parents before children; dates as unambiguous literals; no now() unless the TC is about the current time.
INSERT INTO <parent_table> (<columns>) VALUES (<'marker-…'>, <values>);
INSERT INTO <child_table> (<columns>) VALUES (<'marker-…'>, <values>);
