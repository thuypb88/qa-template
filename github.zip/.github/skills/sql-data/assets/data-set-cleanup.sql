-- Template: sql-data cleanup. Copy to <folder>/3-test-cases/sql/data/<MOD>-DS-<nn>-cleanup.sql; replace every
-- <placeholder> and delete these two template lines. Rules: ../references/output-rules.md.
-- Cleanup of data set <MOD>-DS-<nn> · Dialect: <dialect> · Deletes exactly the marked rows, children first.
DELETE FROM <child_table> WHERE <key> LIKE '<marker>%';
DELETE FROM <parent_table> WHERE <key> LIKE '<marker>%';
