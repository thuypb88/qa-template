---
name: sql-data
description: SQL (after sql-cases or design-data; IT or ST, any pack that seeds a database): write the test data scripts. Turn the data sets the test cases and the data plan name into idempotent SQL scripts in the project's dialect - 3-test-cases/sql/data/<MOD>-DS-<nn>.sql plus a matching cleanup script - parents before children, run-marker keys, one row per partition and boundary the TCs need, deliberately invalid rows that break exactly one constraint, synthetic values only, a header saying which TCs use each row - then prove them by running each twice and the cleanup once on the test database, and link them from the TCs' sql.data_script. Use for "create test data script", "seed script for S1", "insert scripts for these test cases", "SQL fixtures", "tạo script dữ liệu test", "script insert data test". Not for: deciding what data is needed (data plan, pairwise sets) → design-data; ETL fixture sets → design-data with the etl pack.
metadata:
  group: sql
  order: "5+"
---

# SQL: test data scripts

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `3-test-cases/test-cases.json` (the `data_set` / `test_data` of each TC), `3-test-cases/test-data.md` when
`design-data` ran, analysis §11, the DDL (types, NULL, defaults, keys, FKs, checks, identity / sequences, triggers);
the dialect. **Out:** `3-test-cases/sql/data/<MOD>-DS-<nn>.sql` and `…-cleanup.sql`; `sql.data_script` /
`cleanup_script` set in the TCs (bump `version`); a run log line in `project/log.md`. **Rules:** core R1, R9;
[packs/sql/rules.md](../../../packs/sql/rules.md) R-SQL4; [tc-fields.md](../../../packs/sql/tc-fields.md) › Data
scripts; [packs/sql/dialects.md](../../../packs/sql/dialects.md) (upsert, identity). **Next:** `sql-verify` or
`run-tests`.
**Stop if** a TC needs a value the sources don't give → assumed value + `Q-xxx` (never a "realistic" invented one
for a business rule); no DDL → ask for it.
**Output:** [assets/data-set-cleanup.sql](assets/data-set-cleanup.sql) · [assets/data-set.sql](assets/data-set.sql); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **Collect** per data set: the TCs that use it, the rows each TC needs (state, role, relations, boundary values),
   the rows that must exist but stay untouched (for "no collateral change" checks).
2. **Order** tables by foreign keys (parents first); note triggers that insert rows of their own and identity /
   sequence columns (fixed keys need `IDENTITY_INSERT` / explicit values in the dialect's way).
3. **Write the script** in the dialect, from [assets/data-set.sql](assets/data-set.sql)
   ([references/output-rules.md](references/output-rules.md)):
   - header comment: data set ID, dialect, the TCs that use it, one line per row group on why it exists;
   - idempotent: delete this set's rows by run marker first, or upsert (`MERGE` / `ON CONFLICT` / `ON DUPLICATE
     KEY`); re-running gives the same state;
   - every key carries the run marker (`S1-…`) or the rows carry an owner column value (`created_by = 'QA-S1'`);
   - values: synthetic, inside the DDL limits except the deliberate invalid rows, each of which breaks **one**
     constraint and is named in the header;
   - dates written as literals in an unambiguous format; no `now()` unless the TC is about the current time.
4. **Cleanup script** ([assets/data-set-cleanup.sql](assets/data-set-cleanup.sql)): deletes exactly the marked rows, children first; it must not touch unmarked data.
5. **Prove it** on the test database (`SQL_DSN`): run the script twice and compare row counts per table, run the
   cleanup, confirm the counts are back to the start. No database available → say the scripts are unexecuted.
6. Link the scripts from the TCs; `export_testcases.py <target> --check`; commit `<id> sql data <sets>`.

## Rules

- Synthetic only: no production rows, real names, card or account numbers (masked copies only if the project rules
  allow and say how).
- A data script never creates or alters schema objects, and never disables constraints or triggers to get rows in;
  if rows cannot be inserted legally, that is a finding (or a `Q-xxx`).
- One data set serves many TCs; don't duplicate rows per TC.

## Done when

- [ ] A script and a cleanup per data set, idempotent, FK-ordered, marked, with a header.
- [ ] Run twice + cleanup proved on the test database (or stated as unexecuted).
- [ ] TCs link their scripts; `version` bumped; `--check` 0 Error.
