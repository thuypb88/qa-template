# sql-data: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing scripts. Copy [../assets/data-set.sql](../assets/data-set.sql) and
[../assets/data-set-cleanup.sql](../assets/data-set-cleanup.sql). Linked, never copied:
[packs/sql/tc-fields.md](../../../../packs/sql/tc-fields.md) › Data scripts · [packs/sql/rules.md](../../../../packs/sql/rules.md)
R-SQL4 · [packs/sql/dialects.md](../../../../packs/sql/dialects.md) (upsert, identity) ·
[core-rules.md](../../../../standards/core-rules.md) R1, R9.

| Output | File | Write mode |
|---|---|---|
| data script | `<folder>/3-test-cases/sql/data/<MOD>-DS-<nn>.sql` | one per data set; overwrite |
| cleanup | `<folder>/3-test-cases/sql/data/<MOD>-DS-<nn>-cleanup.sql` | one per data set; overwrite |
| TC links | `sql.data_script` / `cleanup_script` in `test-cases.json` | edit; bump `version`; `export_testcases.py --check` |
| log | `project/log.md` | one line (with the run-twice + cleanup result, or "unexecuted") |

## Rules

- **Header comment:** data set ID, dialect, the TCs that use it, one line per row group on why it exists, each
  invalid row with the one constraint it breaks, the run marker.
- **Idempotent** (delete-then-insert or the dialect's upsert); running twice gives the same state.
- **FK order:** parents before children on insert, reverse on delete; identity / sequence columns per the dialect.
- **Marked rows only:** every key carries the run marker or the rows carry the owner column value; the cleanup
  deletes exactly those rows.
- **Synthetic values** within the DDL limits; dates as unambiguous literals; no `now()` unless the TC is about time.
- Never create or alter schema objects, disable constraints or triggers; rows that cannot be inserted legally are
  a finding or a `Q-xxx`.
- One data set serves many TCs; no duplicated rows per TC.
