<!-- Template: project-training-deck review → plans/training/<deck>/reviews/<YYYY-MM-DD>-<deck>-v<version>.md (new
file per reviewed version). Replace every <placeholder>; delete this comment. Rules: ../references/output-rules.md
§ Review; severity and verdict: standards/review-protocol.md. -->
# <Deck title>: training deck review

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (UTC+7)

| Reviewed | Value |
|---|---|
| Deck | [deck.json](../deck.json) v<version> · <n> slides · theme <theme> |
| PDF | [<file>](../../../../deliverables/training/<file>) |
| Verdict | <Pass \| Pass with fixes \| Rework> |

## Script results

```text
<deck.py check output>
<deck.py pdf output>
```

## Findings

| ID | Severity | Check | Slide | Finding | Evidence | Fix |
|---|---|---|---|---|---|---|
| TD-001 | <High \| Medium \| Low> | <Fidelity \| Coverage \| Clarity \| Terms \| Layout> | <S..> | <what is wrong> | <KEY:line says …> | <the change> |

## Fixes applied

| ID | Change | Version |
|---|---|---|
| <TD-…> | <what changed, or "open"> | <v…> |
