<!-- Template: project-training-deck outline → plans/training/<deck>/outline.md. Replace every <placeholder>; delete
this comment. Rules: ../references/output-rules.md § Outline; arc and budget: ../references/narrative.md. -->
# <Deck title>: training deck outline

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (UTC+7)

| Fact | Value |
|---|---|
| Deck id | `<deck>` |
| Title | <title> |
| Audience | <who, what they already know> |
| Language | <English \| Vietnamese \| …> |
| Theme | <ba \| magenta> |
| Version | <0.1> |
| Slide budget | <n> (<one process \| one module \| several modules>) |
| Sources | `<KEY>` [<file name>](../../../sources/parsed/<path>) · … |

## Slide plan

| # | Slide | Module | Layout | Point (one sentence) | Cite |
|---|---|---|---|---|---|
| 1 | S01 | — | cover | <the promise of the deck> | <KEY:line> |
| 2 | S02 | — | agenda | <what the session covers> | <KEY:a-b> |
| <n> | S<nn> | <module id> | <layout> | <the one point> | <KEY:a-b> |

## Gaps

| Gap | Slide | Question to ask |
|---|---|---|
| <[[GAP: …]] text, or "None"> | <S..> | <who / what to ask> |
