# project-training-deck: narrative

> **Created:** 2026-10-30 08:24:04 · **Updated:** 2026-10-30 08:24:04 (UTC+7)

The arc is taken from the reference course deck (`BA-BANKING-PART-1.pdf`, 100 slides): open with the promise and a
map of the course, teach each module through the same rhythm, close with what to remember and where to look things
up. Its marketing slides (registration, satisfaction rates, trainer's message) have no TFM source and are not used.

## Arc

| Part | Slides | Layouts | From the sources |
|---|---|---|---|
| Opening | cover → agenda (one item per module or topic) | `cover`, `agenda` | the Blueprint's title and §1 Objectives |
| Per module | section divider (tag `Module <ID>`, 2–4 cards) | `section` | §1 Objectives, §2 Scope |
| | where it sits (related modules, external systems) | `hub` | §2 Related Modules, integration sections |
| | As-Is → To-Be process map | `table` | §3 Process Map |
| | what changes | `compare` | §5 As-Is Current Situation vs §8 Design Concept |
| | pain points it resolves | `stats` (IDs or counts as values) · `table` | §6 Pain Point Register |
| | per key process: the flow | `split` with the To-Be figure | §8.n To-Be Workflow Diagram |
| | its steps and owners | `process` (3–4) · `steps` · `numbered` · `table` (5+) | §8.n Process Steps |
| | its rules and edge cases | `cards` (accent) · `columns` | §8.n Design Concept, SoD, validations |
| | roles and segregation of duties | `table` · `compare` | §8.n SoD, User Role Matrix appendix |
| | take-aways | `checklist` | restates the module's cited rules |
| Mid-course (system decks) | module journey | `timeline` | the order the sources give |
| Closing | glossary (one or two) | `table` | §4.3 Definitions and Abbreviations |
| | one-line message | `statement` | a design-concept line, quoted or restated |

A one-module deck drops the agenda's per-module items and the timeline; a system deck repeats "Per module" for each.
A practice slide (`cards` outlined, "Case 1 – …") may pose a situation built from one cited rule, with the answer
on the next slide, both cited.

## Budget

| Deck | Slides | Per module |
|---|---|---|
| One process | 8–15 | — |
| One module | 15–30 | — |
| Several modules / the system | 30–100 | 8–15 each, the deepest no more than 3× the thinnest |

## Rhythm

- Alternate dense and light slides; never four of one layout in a row (the check warns).
- Each module ends with a `checklist`; each part opens with a `section` or `agenda`.
- Titles are statements ("Lock Dates replace the period close"), not labels ("Lock Dates").
