# project-training-deck: layouts

> **Created:** 2026-10-30 08:24:04 · **Updated:** 2026-10-30 08:24:04 (UTC+7)

Seventeen layouts, each drawn from a slide type of the reference course deck. Every slide has `id`, `layout`,
`cite`, optional `module`; most take an optional `tag` (small pill above the title), `lead` (≤ 330 chars) and
`callout` (`{"kind": "note" | "success" | "warn", "text": "…"}`, ≤ 220 chars). Titles ≤ 90 chars. "Text" limits are
per item; the script warns above them and the PDF render fails on real overflow. Icons: `book layers settings chart
clipboard users check flag file link shield cart truck calendar money database bank alert note target box lock
refresh search`.

| Layout | Use for | Fields | Items | Item title / text |
|---|---|---|---|---|
| `cover` | the first slide | `title`, `subtitle`, `tags[]` (first is filled) | 0–4 tags | — |
| `agenda` | course map | `items[{icon, title, text}]` | 3–9 | 48 / 90 |
| `section` | module divider | `tag`, `lead`, `cards[{title, text}]` | 2–4 | 48 / 150 |
| `text` | a concept in prose | `paragraphs[]`, `quote{text, by}`, `image{src, caption}` | 1–3 paragraphs | — / 420 |
| `steps` | numbered chevrons (stages) | `steps[{title, text}]`, `callout` | 3–4 | 40 / 200 |
| `columns` | three icon columns | `items[{icon, title, text}]` | 3 | 48 / 200 |
| `compare` | As-Is vs To-Be, old vs new | `left{title, items[]}` (filled), `right{title, items[]}` | 1–5 bullets a side | 60 / 110 |
| `cards` | rules, cases, FAQ | `style` `gradient` (icon bubble) · `accent` (left bar) · `outlined`, `items[{icon?, title, text}]` | 2–4 | 56 / 260 |
| `numbered` | 2–4 numbered points | `items[{title, text}]` | 2–4 | 56 / 220 |
| `table` | process maps, roles, glossary | `columns[]` (≤ 5), `rows[[…]]`, `zebra` | 1–8 rows | — / 110 per cell |
| `split` | figure or table beside text | `blocks[{heading, text}]` + one of `image{src, caption}` · `columns`+`rows` · `panel{title, items[], ordered, note}`; `side: "left"` puts it left | 1–3 blocks | — / 300 |
| `process` | 3–4 stages on a wave | `stages[{title, text}]`, `callout` | 3–4 | 32 / 70 |
| `checklist` | take-aways | `items[{title, text}]` | 2–4 | 80 / 170 |
| `timeline` | journey of 3–9 steps | `nodes[{label, title}]` (above / below in turn) | 3–9 | label 12 / title 36 |
| `stats` | 2–4 figures in rings | `items[{value, percent?, title, text}]` (no `percent` = full ring) | 2–4 | 36 / 130 |
| `hub` | a system and its neighbours | `center{title, text}`, `nodes[{title, text, edge}]` | 3–5 | 36 / 70 |
| `statement` | the one-line message | `lead`, `statement` (≤ 120), `footnote` | — | — |

Choosing: a sequence → `process` (≤ 4, short) or `steps`; 5+ steps → `table`. Two sides of a change → `compare`.
Independent rules → `cards` accent. A Blueprint figure → `split` with `image`. A number on a `stats` ring is the
source's own count or ID, never a derived percentage.
