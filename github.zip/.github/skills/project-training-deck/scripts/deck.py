#!/usr/bin/env python3
"""Training deck: check a deck spec, render it to HTML, print it to PDF (project-training-deck).

    python3 .claude/skills/project-training-deck/scripts/deck.py sources            # parsed sources: key, lines, path
    python3 .claude/skills/project-training-deck/scripts/deck.py check <deck.json>   # schema, limits, citations, images
    python3 .claude/skills/project-training-deck/scripts/deck.py stats <deck.json>   # slides per module and layout
    python3 .claude/skills/project-training-deck/scripts/deck.py html  <deck.json> [--theme ba|magenta] [--out f.html]
    python3 .claude/skills/project-training-deck/scripts/deck.py pdf   <deck.json> [--theme …] [--out f.pdf] [--force]

html writes deck.html beside deck.json (generated, self-contained: theme CSS, icons and images inline).
pdf renders the HTML, measures every slide in headless Chrome (overflow = Error), then prints 1280x720 pages to
deliverables/training/<CODE>_<Deck-Id>_Training_v<version>.pdf. Exit 1 on any Error. Standard library only.
"""
from __future__ import annotations

import argparse
import base64
import html
import json
import math
import mimetypes
import re
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
THEMES = HERE / "themes"
PARSED = ROOT / "sources/parsed"
CITE = re.compile(r"^([A-Z][A-Z0-9]*):(\d+)(?:-(\d+))?$")

# Layout contract: required fields, list field (min, max items), character budgets. Mirrors references/layouts.md.
LAYOUTS = {
    "cover":     dict(req=["title"], lst=("tags", 0, 4), t=0, x=0),
    "agenda":    dict(req=["title", "items"], lst=("items", 3, 9), t=48, x=90),
    "section":   dict(req=["title", "cards"], lst=("cards", 2, 4), t=48, x=150),
    "text":      dict(req=["title", "paragraphs"], lst=("paragraphs", 1, 3), t=0, x=420),
    "steps":     dict(req=["title", "steps"], lst=("steps", 3, 4), t=40, x=200),
    "columns":   dict(req=["title", "items"], lst=("items", 3, 3), t=48, x=200),
    "compare":   dict(req=["title", "left", "right"], lst=None, t=60, x=110),
    "cards":     dict(req=["title", "items"], lst=("items", 2, 4), t=56, x=260),
    "numbered":  dict(req=["title", "items"], lst=("items", 2, 4), t=56, x=220),
    "table":     dict(req=["title", "columns", "rows"], lst=("rows", 1, 8), t=0, x=110),
    "split":     dict(req=["title", "blocks"], lst=("blocks", 1, 3), t=48, x=300),
    "process":   dict(req=["title", "stages"], lst=("stages", 3, 4), t=32, x=70),
    "checklist": dict(req=["title", "items"], lst=("items", 2, 4), t=80, x=170),
    "timeline":  dict(req=["title", "nodes"], lst=("nodes", 3, 9), t=36, x=0),
    "stats":     dict(req=["title", "items"], lst=("items", 2, 4), t=36, x=130),
    "hub":       dict(req=["title", "center", "nodes"], lst=("nodes", 3, 5), t=36, x=70),
    "statement": dict(req=["title", "statement"], lst=None, t=0, x=0),
}
LIMITS = {"title": 90, "subtitle": 220, "lead": 330, "statement": 120, "footnote": 160, "callout": 220, "quote": 240}
CARD_STYLES = {"gradient", "accent", "outlined"}
CALLOUTS = {"note", "success", "warn"}
UNCITED_OK = {"cover"}

ICONS = {
    "book": '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    "layers": '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
    "settings": '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1 7 17M17 7l2.1-2.1"/>',
    "chart": '<path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/>',
    "clipboard": '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
    "users": '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    "check": '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
    "flag": '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>',
    "file": '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="14" y2="17"/>',
    "link": '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    "shield": '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
    "cart": '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
    "truck": '<rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
    "calendar": '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    "money": '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 12h.01M18 12h.01"/>',
    "database": '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',
    "bank": '<path d="M3 21h18M5 21V10M9.5 21V10M14.5 21V10M19 21V10M2 10l10-7 10 7z"/>',
    "alert": '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    "note": '<path d="M15.5 3H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2V8.5L15.5 3Z"/><path d="M15 3v6h6"/>',
    "target": '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    "box": '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>',
    "lock": '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    "refresh": '<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
    "search": '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
}


# ---------- loading and checking ----------

def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def line_count(p: Path) -> int:
    with p.open(encoding="utf-8", errors="replace") as f:
        return sum(1 for _ in f)


def strings(obj):
    """Every string inside a slide, for placeholder and length scans."""
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for k, v in obj.items():
            if k not in ("cite", "src", "icon", "layout", "id", "module", "style", "kind", "percent"):
                yield from strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from strings(v)


def text_of(item) -> str:
    return item if isinstance(item, str) else str(item.get("text", "")) if isinstance(item, dict) else ""


def check(deck: dict, deck_path: Path) -> tuple[list[str], list[str]]:
    E, W = [], []
    meta = deck.get("deck", {})
    for k in ("id", "title", "audience", "language", "version"):
        if not meta.get(k):
            E.append(f"deck.{k} missing")
    if meta.get("theme") and not (THEMES / f"{meta['theme']}.css").exists():
        E.append(f"deck.theme '{meta['theme']}' unknown (themes: {', '.join(sorted(p.stem for p in THEMES.glob('*.css')))})")
    keys = {}
    for k, rel in deck.get("sources", {}).items():
        p = ROOT / rel
        if not p.exists():
            E.append(f"sources.{k}: {rel} not found")
        elif not str(p.resolve()).startswith(str(PARSED.resolve())):
            E.append(f"sources.{k}: {rel} is not under sources/parsed/ (content comes from the sources only)")
        else:
            keys[k] = line_count(p)
    slides = deck.get("slides", [])
    if not slides:
        E.append("no slides")
    ids = Counter(s.get("id") for s in slides)
    for i, n in ids.items():
        if n > 1:
            E.append(f"slide id {i} used {n} times")
    run, prev = 0, None
    for n, s in enumerate(slides, 1):
        sid = s.get("id") or f"#{n}"
        lay = s.get("layout")
        spec = LAYOUTS.get(lay)
        if not spec:
            E.append(f"{sid}: unknown layout '{lay}' (one of {', '.join(LAYOUTS)})")
            continue
        for f in spec["req"]:
            if not s.get(f):
                E.append(f"{sid} ({lay}): '{f}' missing")
        if spec["lst"]:
            f, lo, hi = spec["lst"]
            items = s.get(f) or []
            if f in s and not lo <= len(items) <= hi:
                E.append(f"{sid} ({lay}): {len(items)} {f}, allowed {lo}–{hi}")
            for it in items:
                if spec["x"] and len(text_of(it)) > spec["x"]:
                    W.append(f"{sid} ({lay}): {f} text {len(text_of(it))} chars > {spec['x']}: '{text_of(it)[:40]}…'")
                if spec["t"] and isinstance(it, dict) and len(str(it.get("title", ""))) > spec["t"]:
                    W.append(f"{sid} ({lay}): {f} title > {spec['t']} chars: '{it['title'][:40]}…'")
                if isinstance(it, dict) and it.get("icon") and it["icon"] not in ICONS:
                    E.append(f"{sid}: icon '{it['icon']}' unknown (one of {', '.join(ICONS)})")
        for f, lim in LIMITS.items():
            v = s.get(f)
            v = v.get("text", "") if isinstance(v, dict) else v
            if isinstance(v, str) and len(v) > lim:
                W.append(f"{sid}: {f} {len(v)} chars > {lim}")
        if lay == "compare":
            for side in ("left", "right"):
                bullets = (s.get(side) or {}).get("items", [])
                if not 1 <= len(bullets) <= 5:
                    E.append(f"{sid} (compare): {side} has {len(bullets)} items, allowed 1–5")
                for b in bullets:
                    if len(b) > spec["x"]:
                        W.append(f"{sid} (compare): {side} item {len(b)} chars > {spec['x']}: '{b[:40]}…'")
        if lay == "cards" and s.get("style", "gradient") not in CARD_STYLES:
            E.append(f"{sid}: style '{s.get('style')}' (one of {', '.join(sorted(CARD_STYLES))})")
        if isinstance(s.get("callout"), dict) and s["callout"].get("kind", "note") not in CALLOUTS:
            E.append(f"{sid}: callout kind (one of {', '.join(sorted(CALLOUTS))})")
        if lay == "table":
            cols = len(s.get("columns", []))
            if cols > 5:
                E.append(f"{sid}: {cols} columns, allowed ≤ 5")
            for r in s.get("rows", []):
                if len(r) != cols:
                    E.append(f"{sid}: a row has {len(r)} cells, the table {cols} columns")
                for c in r:
                    if len(str(c)) > spec["x"]:
                        W.append(f"{sid} (table): cell {len(str(c))} chars > {spec['x']}: '{str(c)[:40]}…'")
        if lay == "timeline":
            for nd in s.get("nodes", []):
                if len(str(nd.get("label", ""))) > 12:
                    W.append(f"{sid} (timeline): label > 12 chars: '{nd['label']}'")
        for img in [s.get("image")] + [b.get("image") for b in s.get("blocks", []) if isinstance(b, dict)]:
            if isinstance(img, dict) and img.get("src") and not (ROOT / img["src"]).exists():
                E.append(f"{sid}: image {img['src']} not found")
        cites = s.get("cite") or []
        if not cites and lay not in UNCITED_OK:
            E.append(f"{sid} ({lay}): no 'cite' — every content slide names its source lines")
        for c in cites:
            m = CITE.match(c)
            if not m:
                E.append(f"{sid}: cite '{c}' is not KEY:line or KEY:a-b")
            elif m[1] not in keys:
                if m[1] not in deck.get("sources", {}):
                    E.append(f"{sid}: cite key '{m[1]}' not in deck.sources")
            elif max(int(m[2]), int(m[3] or 0)) > keys[m[1]]:
                E.append(f"{sid}: cite {c} beyond the last line ({keys[m[1]]}) of {m[1]}")
        holes = [t for t in strings(s) if "[[" in t]
        if holes:
            W.append(f"{sid}: {len(holes)} open placeholder(s) [[…]] — fill from the sources or keep as a gap")
        run = run + 1 if lay == prev else 1
        prev = lay
        if run == 4:
            W.append(f"{sid}: 4 '{lay}' slides in a row — vary the layout")
    per_mod = Counter(s.get("module") for s in slides if s.get("module"))
    if len(per_mod) > 1 and max(per_mod.values()) > 3 * min(per_mod.values()):
        W.append(f"uneven depth per module: {dict(per_mod)} (narrative.md: within a factor of 3)")
    return E, W


# ---------- rendering ----------

def md(t) -> str:
    """Escape, then **bold** and line breaks."""
    t = html.escape(str(t or ""))
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    return t.replace("\n", "<br>")


def icon(name, cls="ic") -> str:
    if not name:
        return ""
    return (f'<svg class="{cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" '
            f'stroke-linecap="round" stroke-linejoin="round">{ICONS.get(name, "")}</svg>')


def data_uri(rel: str) -> str:
    p = ROOT / rel
    mime = mimetypes.guess_type(p.name)[0] or "image/png"
    return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"


def head(s) -> str:
    out = ""
    if s.get("tag"):
        out += f'<div class="tag">{md(s["tag"])}</div>'
    out += f'<h1>{md(s["title"])}</h1>'
    if s.get("lead"):
        out += f'<p class="lead">{md(s["lead"])}</p>'
    return out


def callout(s) -> str:
    c = s.get("callout")
    if not c:
        return ""
    c = {"text": c} if isinstance(c, str) else c
    kind = c.get("kind", "note")
    ic = {"note": "note", "success": "check", "warn": "alert"}[kind]
    return f'<div class="callout {kind}">{icon(ic)}<div>{md(c["text"])}</div></div>'


def item_html(it, cls="item", show_icon=True, icon_cls="ic") -> str:
    ic = icon(it.get("icon"), icon_cls) if show_icon else ""
    return f'<div class="{cls}">{ic}<h3>{md(it.get("title"))}</h3><p>{md(it.get("text"))}</p></div>'


def image_html(img, cls="figure") -> str:
    if not img:
        return ""
    if not img.get("src"):
        return f'<div class="{cls} placeholder">[[image: {md(img.get("caption", ""))}]]</div>'
    cap = f'<figcaption>{md(img["caption"])}</figcaption>' if img.get("caption") else ""
    return f'<figure class="{cls}"><img src="{data_uri(img["src"])}" alt="{html.escape(img.get("caption", ""))}">{cap}</figure>'


def r_cover(s, d):
    tags = "".join(f'<span class="pill{" solid" if i == 0 else ""}">{md(t)}</span>' for i, t in enumerate(s.get("tags", [])))
    sub = f'<p class="subtitle">{md(s.get("subtitle"))}</p>' if s.get("subtitle") else ""
    meta = " · ".join(x for x in (d.get("audience"), d.get("date"), "v" + str(d.get("version", ""))) if x)
    return f'<div class="cover"><h1 class="display">{md(s["title"])}</h1>{sub}<div class="pills">{tags}</div><p class="meta">{md(meta)}</p></div>'


def r_agenda(s, d):
    items = s["items"]
    cols = 3 if len(items) in (3, 6, 9) else 4 if len(items) in (4, 8) else 3
    cells = "".join(f'<div class="ag">{icon(it.get("icon"))}<div class="rule"></div><h3>{md(it.get("title"))}</h3><p>{md(it.get("text"))}</p></div>' for it in items)
    return head(s) + f'<div class="grid c{cols} agenda">{cells}</div>'


def r_section(s, d):
    n = len(s["cards"])
    return head(s) + f'<div class="grid c{2 if n in (2, 4) else 3}">' + "".join(item_html(c, "card gradient") for c in s["cards"]) + "</div>"


def r_text(s, d):
    body = "".join(f"<p>{md(p)}</p>" for p in s["paragraphs"])
    q = s.get("quote")
    if q:
        q = {"text": q} if isinstance(q, str) else q
        by = f'<span class="by">— {md(q["by"])}</span>' if q.get("by") else ""
        body += f'<blockquote>{md(q["text"])}{by}</blockquote>'
    img = image_html(s.get("image"), "figure wide")
    return head(s) + img + f'<div class="prose">{body}</div>' + callout(s)


def r_steps(s, d):
    n = len(s["steps"])
    cells = "".join(f'<div class="step"><div class="chev">{i}</div><h3>{md(st.get("title"))}</h3><p>{md(st.get("text"))}</p></div>' for i, st in enumerate(s["steps"], 1))
    cols = 2 if n == 4 and s.get("wrap") else n
    return head(s) + f'<div class="grid c{cols} steps">{cells}</div>' + callout(s)


def r_columns(s, d):
    return head(s) + '<div class="grid c3">' + "".join(item_html(it, "col", icon_cls="ic big") for it in s["items"]) + "</div>" + callout(s)


def r_compare(s, d):
    def side(x, cls, mark):
        lis = "".join(f"<li>{md(i)}</li>" for i in x.get("items", []))
        return f'<div class="{cls}"><h3>{mark} {md(x.get("title"))}</h3><ul>{lis}</ul></div>'
    return head(s) + '<div class="grid c2 compare">' + side(s["left"], "solid", "✕") + side(s["right"], "plain", "✓") + "</div>" + callout(s)


def r_cards(s, d):
    n, style = len(s["items"]), s.get("style", "gradient")
    cells = "".join(item_html(it, f"card {style}", icon_cls="ic bubble" if style == "gradient" else "ic") for it in s["items"])
    return head(s) + f'<div class="grid c{2 if n in (2, 4) else 3}">{cells}</div>' + callout(s)


def r_numbered(s, d):
    n = len(s["items"])
    cells = "".join(f'<div class="num"><span class="badge">{i}</span><div><h3>{md(it.get("title"))}</h3><p>{md(it.get("text"))}</p></div></div>' for i, it in enumerate(s["items"], 1))
    return head(s) + f'<div class="grid c{2 if n != 3 else 3}">{cells}</div>' + callout(s)


def table_html(s) -> str:
    th = "".join(f"<th>{md(c)}</th>" for c in s["columns"])
    trs = "".join("<tr>" + "".join(f"<td>{md(c)}</td>" for c in r) + "</tr>" for r in s["rows"])
    zebra = " zebra" if s.get("zebra") else ""
    return f'<table class="tbl{zebra}"><thead><tr>{th}</tr></thead><tbody>{trs}</tbody></table>'


def r_table(s, d):
    return head(s) + table_html(s) + callout(s)


def r_split(s, d):
    blocks = "".join(f'<div class="blk">{f"<h2>{md(b.get('heading'))}</h2>" if b.get("heading") else ""}<p>{md(b.get("text"))}</p></div>' for b in s["blocks"])
    if s.get("image"):
        other = image_html(s["image"])
    elif s.get("columns"):
        other = table_html(s)
    elif s.get("panel"):
        p = s["panel"]
        lis = "".join(f"<li>{md(i)}</li>" for i in p.get("items", []))
        tag = "ol" if p.get("ordered") else "ul"
        other = f'<div class="panel"><h3>{md(p.get("title"))}</h3><{tag}>{lis}</{tag}>{f"<p>{md(p.get("note"))}</p>" if p.get("note") else ""}</div>'
    else:
        other = ""
    left, right = (other, blocks) if s.get("side") == "left" else (blocks, other)
    return head(s) + f'<div class="split"><div>{left}</div><div>{right}</div></div>' + callout(s)


def r_process(s, d):
    st = s["stages"]
    n = len(st)
    W, base, x0 = 1104, 150, 40
    w = (W - 2 * x0) / n
    r = w / 2
    path = f"M{x0 - 20},{base} H{x0}"
    labels = ""
    for i, g in enumerate(st):
        a, b = x0 + i * w, x0 + (i + 1) * w
        up = i % 2 == 0
        path += f" A{r:.1f},{r * 0.9:.1f} 0 0 {1 if up else 0} {b:.1f},{base}"
        top = base - r * 0.62 if up else base + r * 0.12
        labels += (f'<div class="pl" style="left:{a + w * 0.12:.0f}px;width:{w * 0.76:.0f}px;top:{top:.0f}px">'
                   f'<h3>{md(g.get("title"))}</h3><p>{md(g.get("text"))}</p></div>')
    path += f" H{W - 10}"
    svg = (f'<svg class="wave" width="{W}" height="300" viewBox="0 0 {W} 300"><defs><linearGradient id="wg" x1="0" x2="1">'
           f'<stop offset="0" stop-color="var(--a1)"/><stop offset="1" stop-color="var(--a2)"/></linearGradient></defs>'
           f'<path d="{path}" fill="none" stroke="url(#wg)" stroke-width="4"/><circle cx="{x0 - 20}" cy="{base}" r="9" fill="var(--a1)"/>'
           f'<path d="M{W - 26},{base - 12} L{W - 10},{base} L{W - 26},{base + 12}" fill="none" stroke="var(--a2)" stroke-width="4"/></svg>')
    return head(s) + f'<div class="process">{svg}{labels}</div>' + callout(s)


def r_checklist(s, d):
    n = len(s["items"])
    cells = "".join(f'<div class="chk"><span class="box"></span><div><h3>{md(it.get("title"))}</h3><p>{md(it.get("text"))}</p></div></div>' for it in s["items"])
    return head(s) + f'<div class="grid c{2 if n != 3 else 3}">{cells}</div>' + callout(s)


def r_timeline(s, d):
    nodes = s["nodes"]
    n = len(nodes)
    cells = ""
    for i, nd in enumerate(nodes):
        pos = "up" if i % 2 == 0 else "down"
        cells += (f'<div class="tn {pos}"><div class="lbl"><b>{md(nd.get("label", i + 1))}</b><span>{md(nd.get("title"))}</span></div>'
                  f'<div class="stem"></div><div class="node">{i + 1}</div></div>')
    return head(s) + f'<div class="timeline" style="grid-template-columns:repeat({n},1fr)">{cells}</div>' + callout(s)


def r_stats(s, d):
    cells = ""
    C = 2 * 3.14159 * 88
    for k, it in enumerate(s["items"]):
        pct = it.get("percent", 100)
        dash = C * max(0, min(100, float(pct))) / 100
        cells += (f'<div class="stat"><svg viewBox="0 0 200 200" width="190" height="190"><defs><linearGradient id="sg{k}" x1="0" y1="0" x2="1" y2="1">'
                  f'<stop offset="0" stop-color="var(--a1)"/><stop offset="1" stop-color="var(--a2)"/></linearGradient></defs>'
                  f'<circle cx="100" cy="100" r="88" fill="none" stroke="var(--track)" stroke-width="16"/>'
                  f'<circle cx="100" cy="100" r="88" fill="none" stroke="url(#sg{k})" stroke-width="16" stroke-dasharray="{dash:.1f} {C:.1f}" transform="rotate(-90 100 100)"/>'
                  f'<text x="100" y="114" text-anchor="middle" class="sv">{html.escape(str(it.get("value")))}</text></svg>'
                  f'<h3>{md(it.get("title"))}</h3><p>{md(it.get("text"))}</p></div>')
    return head(s) + f'<div class="grid c{len(s["items"])} stats">{cells}</div>' + callout(s)


def r_hub(s, d):
    nodes, c = s["nodes"], s["center"]
    W, H, cx, cy = 1104, 400, 552, 200
    spots = {3: [(552, 62), (190, 290), (914, 290)], 4: [(552, 58), (170, 200), (934, 200), (552, 345)],
             5: [(552, 58), (170, 150), (934, 150), (300, 340), (804, 340)]}[len(nodes)]
    def edge(x, y, rx, ry):  # offset from an ellipse's centre to its rim, along the ray centre → (x, y)
        dx, dy = x - cx, y - cy
        k = 1 / math.sqrt((dx / rx) ** 2 + (dy / ry) ** 2)
        return dx * k, dy * k
    lines, labels = "", ""
    for n, (x, y) in zip(nodes, spots):
        sx, sy = edge(x, y, 125, 72)
        ex, ey = edge(x, y, 110, 54)
        x1, y1, x2, y2 = cx + sx, cy + sy, x - ex, y - ey
        lines += f'<line x1="{x1:.0f}" y1="{y1:.0f}" x2="{x2:.0f}" y2="{y2:.0f}" stroke="var(--a1)" stroke-width="2.5" marker-end="url(#ah)"/>'
        if n.get("edge"):
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            lx, ly = (mx + 8, my - 10) if abs(x2 - x1) < 60 else (mx - 70, my - 30)  # beside a vertical line, above the others
            labels += f'<div class="edge" style="left:{lx:.0f}px;top:{ly:.0f}px">{md(n["edge"])}</div>'
    bubbles = "".join(f'<div class="hn" style="left:{x - 105}px;top:{y - 50}px"><h3>{md(n.get("title"))}</h3><p>{md(n.get("text"))}</p></div>' for n, (x, y) in zip(nodes, spots))
    svg = (f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}"><defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">'
           f'<path d="M0,0 L10,5 L0,10 z" fill="var(--a1)"/></marker></defs>{lines}</svg>')
    center = f'<div class="hc" style="left:{cx - 120}px;top:{cy - 70}px"><h3>{md(c.get("title"))}</h3><p>{md(c.get("text"))}</p></div>'
    return head(s) + f'<div class="hub">{svg}{bubbles}{center}{labels}</div>' + callout(s)


def r_statement(s, d):
    lead = f'<p class="lead">{md(s["lead"])}</p>' if s.get("lead") else ""
    foot = f'<p class="foot">{md(s["footnote"])}</p>' if s.get("footnote") else ""
    return f'<h1>{md(s["title"])}</h1>{lead}<div class="statement">{md(s["statement"])}</div>{foot}'


RENDER = {k: globals()[f"r_{k}"] for k in LAYOUTS}


def render(deck: dict, theme: str) -> str:
    meta = deck["deck"]
    css = (THEMES / "base.css").read_text(encoding="utf-8") + "\n" + (THEMES / f"{theme}.css").read_text(encoding="utf-8")
    slides = deck["slides"]
    total = len(slides)
    pages = []
    for n, s in enumerate(slides, 1):
        cites = ", ".join(s.get("cite") or [])
        foot = (f'<footer><span class="src">{"Source: " + html.escape(cites) if cites else ""}</span>'
                f'<span class="pg">{html.escape(meta.get("title", ""))} · {n} / {total}</span></footer>')
        pages.append(f'<section class="slide l-{s["layout"]}" data-id="{html.escape(s.get("id", str(n)))}">'
                     f'<div class="content">{RENDER[s["layout"]](s, meta)}</div>{foot if s["layout"] != "cover" else ""}</section>')
    probe = ("<script>addEventListener('load',()=>{document.fonts.ready.then(()=>{const o=[];"
             "document.querySelectorAll('.slide').forEach(s=>{const c=s.querySelector('.content');c.style.justifyContent='flex-start';"
             "if(c.scrollHeight>c.clientHeight+2||c.scrollWidth>c.clientWidth+2)o.push(s.dataset.id+':'+Math.max(c.scrollHeight-c.clientHeight,c.scrollWidth-c.clientWidth));"
             "c.style.justifyContent=''});"
             "document.body.setAttribute('data-overflow',o.join(' ')||'none')})})</script>")
    lang = {"vietnamese": "vi", "thai": "th"}.get(str(meta.get("language", "")).lower(), "en")
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return (f'<!doctype html><html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=1280">'
            f'<!-- Generated on {stamp} by .claude/skills/project-training-deck/scripts/deck.py from deck.json v{html.escape(str(meta.get("version")))}. Do not edit; re-run the script. -->'
            f'<title>{html.escape(meta.get("title", "Training deck"))}</title>'
            '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?'
            'family=Source+Sans+3:wght@400;600;700&family=Source+Serif+4:opsz,wght@8..60,600;8..60,700&family=Noto+Sans+Thai:wght@400;600&display=swap">'
            f'<style>{css}</style></head><body>{"".join(pages)}{probe}</body></html>')


# ---------- commands ----------

def chrome() -> str:
    for c in ("google-chrome", "chromium", "chromium-browser", "google-chrome-stable"):
        if shutil.which(c):
            return c
    sys.exit("Error: no Chrome / Chromium on PATH (run python3 scripts/workspace/setup_workspace.py --check)")


def theme_of(deck, arg) -> str:
    t = arg or deck["deck"].get("theme") or "ba"
    if not (THEMES / f"{t}.css").exists():
        sys.exit(f"Error: theme '{t}' unknown")
    return t


def rel(p: Path) -> str:
    return str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p)


def report(E, W) -> None:
    for e in E:
        print(f"Error   {e}")
    for w in W:
        print(f"Warning {w}")
    print(f"{len(E)} Error · {len(W)} Warning")


def cmd_sources(_):
    for p in sorted(PARSED.rglob("*.md")):
        if p.name == "INDEX.md" or ".figures" in str(p.parent):
            continue
        figs = p.parent / (p.name[:-3] + ".figures")
        nf = len(list(figs.glob("fig-*.png"))) if figs.exists() else 0
        print(f"{line_count(p):>6} lines · {nf:>3} figures · {p.relative_to(ROOT)}")


def cmd_check(a):
    deck = load(a.deck)
    E, W = check(deck, a.deck)
    report(E, W)
    return 1 if E else 0


def cmd_stats(a):
    deck = load(a.deck)
    sl = deck.get("slides", [])
    print(f"{len(sl)} slides · theme {deck['deck'].get('theme', 'ba')} · v{deck['deck'].get('version')}")
    print("per module:", dict(Counter(s.get("module") or "—" for s in sl)))
    print("per layout:", dict(Counter(s.get("layout") for s in sl).most_common()))
    print("citations:", sum(len(s.get("cite") or []) for s in sl), "· keys", sorted({c.split(":")[0] for s in sl for c in s.get("cite") or []}))
    return 0


def write_html(a) -> tuple[dict, Path, str]:
    deck = load(a.deck)
    E, W = check(deck, a.deck)
    if E and not getattr(a, "force", False):
        report(E, W)
        sys.exit(1)
    theme = theme_of(deck, a.theme)
    out = Path(a.out) if getattr(a, "out", None) and str(a.out).endswith(".html") else a.deck.parent / "deck.html"
    out.write_text(render(deck, theme), encoding="utf-8")
    return deck, out, theme


def cmd_html(a):
    _, out, theme = write_html(a)
    print(f"Wrote {rel(out)} (theme {theme})")
    return 0


def overflow(html_path: Path) -> list[str]:
    with tempfile.TemporaryDirectory() as tmp:
        r = subprocess.run([chrome(), "--headless=new", "--disable-gpu", f"--user-data-dir={tmp}", "--window-size=1280,720",
                            "--virtual-time-budget=8000", "--dump-dom", html_path.resolve().as_uri()],
                           capture_output=True, text=True, timeout=180)
    m = re.search(r'<body[^>]*data-overflow="([^"]*)"', r.stdout)
    if not m:
        return ["(not measured: Chrome did not report; check the page by eye)"]
    return [] if m[1] == "none" else m[1].split()


def cmd_pdf(a):
    a.out_html = None
    deck, html_path, theme = write_html(a)
    over = overflow(html_path)
    if over and not over[0].startswith("(not"):
        for o in over:
            sid, px = o.rsplit(":", 1)
            print(f"Error   {sid}: content overflows the slide by {px}px — cut text or split the slide")
        if not a.force:
            return 1
    elif over:
        print(f"Warning {over[0]}")
    meta = deck["deck"]
    code = json.loads((ROOT / "project.json").read_text(encoding="utf-8"))["project"]["code"]
    slug = "-".join(w.capitalize() for w in re.split(r"[-_\s]+", meta["id"]) if w)
    out = Path(a.out) if a.out else ROOT / f"deliverables/training/{code}_{slug}_Training_v{meta['version']}.pdf"
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run([chrome(), "--headless=new", "--disable-gpu", f"--user-data-dir={tmp}", "--no-pdf-header-footer",
                        "--virtual-time-budget=8000", f"--print-to-pdf={out}", html_path.resolve().as_uri()],
                       capture_output=True, text=True, timeout=300, check=True)
    print(f"Wrote {rel(html_path)} and {rel(out)} "
          f"({len(deck['slides'])} slides, theme {theme}, {out.stat().st_size // 1024} KB)")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("sources")
    for name in ("check", "stats", "html", "pdf"):
        p = sub.add_parser(name)
        p.add_argument("deck", type=Path)
        if name in ("html", "pdf"):
            p.add_argument("--theme")
            p.add_argument("--out")
            p.add_argument("--force", action="store_true", help="render despite Errors (draft preview only)")
    a = ap.parse_args()
    if hasattr(a, "deck"):
        a.deck = a.deck.resolve()
    return {"sources": cmd_sources, "check": cmd_check, "stats": cmd_stats, "html": cmd_html, "pdf": cmd_pdf}[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
