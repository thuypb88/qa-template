// Template: auto-write, UI (Playwright). Copy to automation/ui/tests/<id>/<item>.spec.ts. Imports, fixtures, page
// objects and flows come from automation/docs/ui-design.md (it wins over this skeleton). Rules: ../references/output-rules.md.
import { test, expect } from '<fixtures module named in ui-design.md>';
import { <PageObject> } from '<page object path named in ui-design.md>';

test('<TC-MOD-nnn> [<Level-1 item>] <title as in test-cases.json>', { tag: ['@wave<n>', '@p<n>'] }, async ({ <fixtures> }) => {
  // Precondition: <this TC's special precondition>, built by <builder / set from test-data.md>.
  const page = new <PageObject>(<signed-in page for the role>);

  await test.step('Step 1: <step 1 of the TC>', async () => {
    // <action>
    await expect(<locator by role / label / agreed test id>).toHaveText('<exact expected text of step 1>');
  });

  await test.step('Step 2: <step 2 of the TC>', async () => {
    // <action>
    await expect(<locator>).<assertion on the observable state of step 2>;
  });
});
