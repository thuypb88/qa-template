"""Template: auto-write, API (pytest), a hand-written multi-request test (write → read back). Single-request TCs use the
data-driven runner instead: copy automation/api/test_example_api.py → test_<id>_api.py and set MODULE.
Copy to automation/api/test_<id>_<item>.py. Rules: ../references/output-rules.md.
"""
from api_client import check_expect


def test_TC_<MOD>_<nnn>_<what>(api, token, fixture_body):
    """<TC-MOD-nnn> [<Level-1 item>] <title as in test-cases.json>"""
    # Step 1: <step 1 of the TC>
    resp = api.request("<METHOD>", "<endpoint>", token=token("<TOKEN-role>"), body=fixture_body("<fixtures/api/….json>"))
    check_expect(resp, {"status": <status of step 1>})

    # Step 2: <read back, as the TC's last step asks>
    resp = api.request("GET", "<endpoint>/<id>", token=token("<TOKEN-role>"))
    check_expect(resp, {"status": 200, "body": {"$.<field>": "<exact expected value>"}})
