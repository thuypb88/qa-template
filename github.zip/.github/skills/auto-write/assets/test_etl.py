"""Template: auto-write, ETL (pytest), a dedicated test for a history / rule / custom reconciliation. count, sum and
row_diff TCs use the data-driven runner instead: copy automation/etl/test_example_etl.py → test_<id>_etl.py and set
MODULE. Copy to automation/etl/test_<id>_<table>.py. Rules: ../references/output-rules.md.
"""
import reconcile


def test_TC_<MOD>_<nnn>_<what>(src, tgt, load_fixture, run_job):
    """<TC-MOD-nnn> [<target table>] <title as in test-cases.json>"""
    # Step 1: load the fixture set and run the job
    load_fixture("<ETL-FX-…>")
    run_job("<job>")

    # Step 2: <the TC's check, with a reconcile helper: null_check / duplicate_check / ri_check / rows / scalar>
    result = reconcile.<helper>(tgt, "<table>", ["<column>"])
    assert result.ok, result.detail  # <exact expectation from the TC's etl.expect>
