---
name: auto-write
description: Automation A3: write the automated tests. Once the test case review is current and the codebase design (auto-design) is reviewed, write the automated tests for one spec or wave of a folder's automation-plan.md - Playwright specs and page objects (UI), pytest tests on api_client (API), pytest tests on reconcile.py with fixture sets and SQL (ETL) - each test named with its TC ID, data-driven where the plan says, then run them once with scripts/run_tests.py and report. Use for "automate wave 1 of E4", "write the API tests for E7", "automate the DIM_CUSTOMER reconciliation", "write the Playwright spec for the Sign In screen". Deciding what to automate → auto-decide; the codebase structure → auto-design; running a regression → run-tests; SQL verification procedures (pack sql) → sql-verify.
metadata:
  group: auto
  order: "A3"
---

# Automation: write the tests

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-11-05 00:00:00 (UTC+7)

**In:** `3-test-cases/automation-plan.md` (the spec row(s) to write), the TCs (`slice.py tc <target> --ids …`),
`automation/docs/<pack>-design.md` (layout, components, builders, hook clients for this folder), the analysis §11
fixtures, `automation/README.md`, the pack's runner in `project.json`. **Out:** test files, page objects,
fixtures and SQL under `automation/<pack>/`; a run via `run_tests.py`. **Rules:** R2 (the assertion is at the surface),
R9 (the base URL / DSN of the level). **Next:** `run-tests`.
**Stop if** (gates, in order):
1. the plan is missing or older than the TCs → `auto-decide`;
2. the folder's test case review (`3-test-cases/test-cases-review.md`) is missing, Rework, older than the TC content
   (not counting the `automation` fields), or Pass with fixes without its revision log → `check-design` (or the writer
   first). Tests written against TCs that are still changing get written twice;
3. `automation/docs/<pack>-design.md` is missing, or doesn't cover this folder → `auto-design`; its latest review in
   `automation/docs/reviews/` is missing, Rework, or older than the design → `check-automation` design mode.

**Output:** [assets/test_api.py](assets/test_api.py) · [assets/test_etl.py](assets/test_etl.py) · [assets/ui.spec.ts](assets/ui.spec.ts); rules [references/output-rules.md](references/output-rules.md) — read before writing.

`python3 scripts/pipeline_status.py <target>` shows which gate is open. Spec rows that are not Ready → skip them and
say why.

## Steps

1. **Pick the rows:** the wave or spec the user named; Ready rows only.
2. **Bind every test to its TC:** test name / title starts with the TC ID (`TC-E4-012 …`, `test_TC_E7_003_…`, a param
   id `TC_E7_003`). Data-driven: one row per TC ID ([automation/tc_binding.py](../../../automation/tc_binding.py)).
3. **Per pack** (skeletons in [assets/](assets/), file rules in [references/output-rules.md](references/output-rules.md)):
   - **Follow the design.** Files, layers, components, builders and hook clients go where
     `automation/docs/<pack>-design.md` puts them. A component or helper the design lacks → `auto-design` extends
     the design first; never an ad hoc helper in a spec.
   - **UI:** scaffold `automation/ui/` on first use, as the design's layout and dependencies say (see its README). One
     spec per level-1 item; page objects and shared components where the design puts them; locators by role / label text as the TC names them, or a test id the DEV team agreed (never CSS from
     devtools); scope a locator inside its row / dialog when the page has duplicates — never `.first()` / `nth()` to
     hide that it matches several; fixtures for login per role and seeded data. Keep flows under `flows/it/<module>/`
     or `flows/st/` to match the target level in `project.json`; cross-level helpers go in `flows/shared/`, and IT / ST
     flows never import from each other. Assert the exact text / state the expected result gives.
   - **API:** prefer the data-driven runner (copy `test_example_api.py` → `test_<id>_api.py`, set `MODULE`). Hand-write
     only multi-request TCs; use `api_client.check_expect` for the `expect` block. Request bodies in `api/fixtures/`.
   - **ETL:** prefer the data-driven runner (`test_example_etl.py` → `test_<id>_etl.py`); fixture sets as
     `etl/fixtures/<ETL-FX-…>.sql`, queries as `etl/sql/{src,tgt}/<rule>.sql`; history / rule / custom kinds as
     dedicated tests with `reconcile.py` helpers.
4. **Secrets and URLs** from the environment only; document new variables in `automation/README.md`.
   **Data:** each test creates or resets its own data (a per-run prefix), cleans up, and runs alone (`--grep`) and in
   any order. **Mocks (IT):** answer in the contract's shape (fields, status codes, error model); a simplification the
   contract doesn't allow → `Q-xxx`.
5. **Self-check each test before running it:** write down the smallest wrong build that would still pass it. If one
   is easy (only the status code checked, only "visible", the mock's own answer asserted, a value copied from today's
   output, a refusal without the read-back the TC asks for), strengthen the assertion.
6. **Run once:** `python3 scripts/run_tests.py <target> --plan`, then the run. Every new failure: product defect, test
   defect (fix it), TC defect (raise to the writer) or environment. Never weaken an assertion to go green.
7. Update the plan's readiness column (Ready → Automated); commit `<id> automation: <spec> (<n> TCs)`.

## Rules

- No TC without a test silently: a TC the plan lists that you did not automate stays "No result" and is reported.
- No sleeps for waiting; wait on the observable state the next step needs (this request's response, the row, the
  enabled button). A retried wait never re-submits an action.
- A hook may set up state; the assertion never reads a log, a DB row (UI / API) or an internal API (UI).

## Done when

- [ ] Every chosen spec row has its tests, each bound to its TC ID; the run executed; failures triaged.
- [ ] Gates checked (TC review current, design reviewed); code placed as the design says.
- [ ] Self-check done per test; no fixed sleeps, no devtools selectors, no secrets in code.
- [ ] Report tests written per pack, TCs covered, results, new hooks or questions; suggest `check-automation` for a
  first wave or a P1-heavy spec, then `run-tests`.
