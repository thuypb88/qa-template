# auto-write: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing tests. Start from the pack skeleton in [../assets/](../assets/); **`automation/docs/<pack>-design.md`
wins** over a skeleton (imports, fixtures, page objects, builders, file places). Linked, never copied:
[core-rules.md](../../../../standards/core-rules.md) R2, R9 · `automation/README.md` ·
[tc_binding.py](../../../../automation/tc_binding.py).

| Pack | Skeleton | File | Data-driven alternative |
|---|---|---|---|
| UI | [ui.spec.ts](../assets/ui.spec.ts) | `automation/ui/tests/<id>/<item>.spec.ts` | rows of one parametrised test per TC ID |
| API | [test_api.py](../assets/test_api.py) (multi-request only) | `automation/api/test_<id>_<item>.py` | `test_example_api.py` → `test_<id>_api.py`, set `MODULE` |
| ETL | [test_etl.py](../assets/test_etl.py) (history / rule / custom only) | `automation/etl/test_<id>_<table>.py` | `test_example_etl.py` → `test_<id>_etl.py`, set `MODULE` |
| SQL | — (`sql-verify`) | `automation/sql/verify/…` | — |

Also written: request bodies in `automation/api/fixtures/`; ETL fixture sets `automation/etl/fixtures/<ETL-FX-…>.sql`,
queries `automation/etl/sql/{src,tgt}/<rule>.sql`; the plan's readiness column (Ready → Automated); new environment
variables documented in `automation/README.md`.

## Rules

- **Binding:** every test's title / name starts with its TC ID (`TC-E4-012 …`, `test_TC_E7_003_…`, a param id
  `TC_E7_003`); one row per TC ID when data-driven. A TC the plan lists and you did not automate stays "No result"
  and is reported.
- **One step block per TC step**, each asserting that step's expected result: the exact text, state, status or value
  the TC gives, at the surface (R2). A refusal reads back what the TC asks.
- **Locators** by role / label as the TC names them, or an agreed test id; scoped inside the row / dialog; never
  devtools CSS, `.first()` / `nth()` to hide duplicates.
- **No fixed sleeps;** wait on the observable state the next step needs; a retried wait never re-submits.
- **Data:** each test creates or resets its own (per-run prefix), cleans up, runs alone and in any order.
- **Secrets and URLs** from the environment only.
- Never weaken an assertion to go green.

## Checks before done

```bash
python3 scripts/run_tests.py <target> --plan    # every chosen Ready TC bound
python3 scripts/run_tests.py <target>           # run once; triage every failure
```
