---
name: learn-glossary
description: Learn (writer, project-wide, every pack): build and keep the project glossary - project terms, domain terms, role codes, ID schemes, conflicts - from the sources, every row cited. Run scripts/glossary.py (definition tables, inline "Long Name (ABBR)", role registers, ID patterns, acronyms used but defined nowhere, conflicts, spelling variants), write the cited rows into project/system-map.md › Glossary, raise each conflict or undefined term the tests depend on as a question, and add plain-language domain notes marked external - verify (never a test basis). Mode build (first time), refresh (after a source change: add, flag changed meanings, never delete), check (every row's link still names the term). Use for "make a glossary", "glossary for this project / domain", "what does <term> mean here", "refresh the glossary", "check the glossary", "thuật ngữ dự án". Not for: a whole module analysis → design-analysis; explaining a term to an audience → learn-explain; what changed in a document → plan-changes.
metadata:
  group: learn
  order: "-"
---

# Learn: project glossary

> **Created:** 2026-10-22 10:07:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `python3 scripts/glossary.py [--json] [--check] [--min-count N]` (read-only), the parsed sources it cites,
`project/system-map.md` › Glossary, `project/questions.md`, `project.json` (modules, `document_language`).
**Out:** `project/system-map.md` › `## Glossary` (format: [assets/glossary.md](assets/glossary.md)); questions in `project/questions.md` on the user's OK;
a `project/log.md` line. **Rules:** core R1 (no invention: a meaning comes from a cited line), conventions §7
(citations) and §10 (formats). **Next:** `learn-explain` for a briefing; `design-analysis` uses the glossary.
**Stop if** `sources/parsed/` is empty → `python3 scripts/extract_text.py` (or `plan-setup`) first.
**Output:** [assets/glossary.md](assets/glossary.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Modes

| Mode | When | Does |
|---|---|---|
| **build** | no glossary rows yet, or "make a glossary" | steps 1–6 for every term |
| **refresh** | after `plan-changes`, a new document, or `new` > 0 in the script | steps 1–6 for the script's `new`, `conflicts`, `undefined` only |
| **check** | before a review or release; after sources were re-extracted | `glossary.py --check`; fix each problem (re-cite, or mark the row `superseded`) |

## Steps

1. **Run** `python3 scripts/glossary.py --json`. Trust it for what it finds (rows, lines, counts); read the cited
   lines yourself only to write a meaning the script could not (an inline explanation, a role description).
2. **Terms.** One row per term: Term, Meaning (from the source, shortened, never widened), Source (links
   `[KEY:line](../sources/parsed/…#Lnn)`). Two Blueprints / documents with the same meaning → one row, both cites.
   Terms used but undefined (`undefined`): open the first cited lines; a line that explains the term gives a row;
   none does → leave it out of the table and list it under **Undefined** with a `Q-…` when a test needs it.
3. **Role codes.** From `roles`: Code, Module / document, Role, Source. A code with `clash` (one code, several
   roles) → write it with its module everywhere (`AP·ACC`) and note it under Conflicts.
4. **ID schemes.** From `ids`: what each prefix numbers (read one cited line), pattern, example, source.
5. **Conflicts and variants.** From `conflicts` / `variants` and anything found in steps 2–4: Topic, what each
   source says (cited), Status (`Q-…`, or "same thing; noted"). Never pick a side (R1).
6. **Domain notes** (only when the user asks for the domain, or a term needs it for testing): Term, plain
   explanation, why it matters for testing, reference to verify — every row marked **external — verify**. These help
   people learn; they are not requirements and no test cites them.

Then write the section, keep rows sorted A–Z, set the Updated stamp, propose the questions, add the log line.

## Format of `## Glossary` in `project/system-map.md`

Use [assets/glossary.md](assets/glossary.md); table order, citation and append rules per
[references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- **Cited or absent.** A row without a source line is not written; general knowledge goes only to Domain notes.
- **Append, don't rewrite.** Refresh adds rows and flags changed meanings (old row → `superseded by …`); IDs and
  existing rows are not renumbered or deleted.
- **Language:** `project.document_language`; terms exactly as the source spells them (UI labels as shown).
- One term, two meanings across documents is a question for the client, not a choice.

## Done when

- [ ] `glossary.py --json` run; every `new` term written or listed as Undefined; every conflict and clash has a
      Status; role codes and ID schemes tables filled.
- [ ] `glossary.py --check` reports 0 problems; Updated stamp; questions proposed; `project/log.md` line.
- [ ] Report counts (terms, roles, IDs, conflicts, undefined, domain notes); suggest `learn-explain` or the next skill.
