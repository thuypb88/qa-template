# learn-glossary: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing the glossary. Use [../assets/glossary.md](../assets/glossary.md). Linked, never copied:
[core-rules.md](../../../../standards/core-rules.md) R1 · [conventions.md](../../../../standards/conventions.md) §7
(citations), §10 (formats).

| Output | File | Write mode |
|---|---|---|
| glossary | `project/system-map.md` › `## Glossary` | build: write the section; refresh: append rows, mark changed ones `superseded by …`; never delete or renumber |
| questions | `project/questions.md` | on the user's OK |
| log | `project/log.md` | one line |

## Rules

- **First table** `Term | Meaning | Source` (the one the scripts read), then the sub-sections in the template's order:
  Role codes · ID schemes in the sources · Conflicts and variants · Undefined in the sources · Domain notes (external
  — verify).
- **Cited or absent:** a row without a source line is not written; general knowledge goes only to Domain notes,
  every row there marked **external — verify**, never a test basis.
- **Rows sorted A–Z;** one term with the same meaning in two documents = one row, both cites.
- **Clashing role codes** are written with their module everywhere (`AP·ACC`) and listed under Conflicts.
- **Conflicts** never pick a side: Status is a `Q-…` or "same thing; noted".
- Terms exactly as the source spells them; UI labels as shown; language `project.document_language`.
- Updated stamp of `project/system-map.md` set.

## Checks before done

```bash
python3 scripts/glossary.py --check     # 0 problems
```
