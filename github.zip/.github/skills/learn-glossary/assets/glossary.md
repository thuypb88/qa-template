<!-- Template: learn-glossary. The ## Glossary section of project/system-map.md (replace the section, keep the rest of
the file). Rows sorted A–Z; every row cited. Replace every <placeholder>, delete this comment.
Rules: ../references/output-rules.md. -->
## Glossary

<What it covers.> Add a row only with a source line, never from memory (`learn-glossary`, `python3 scripts/glossary.py --check`).

| Term | Meaning | Source |
|---|---|---|
| <term as the source spells it> | <meaning from the source, shortened, never widened> | [<KEY>:<line>](../sources/parsed/<file>.md#L<line>) |

### Role codes

| Code | Module | Role | Source |
|---|---|---|---|

### ID schemes in the sources

| ID | Pattern | Example | Source |
|---|---|---|---|

### Conflicts and variants

| Topic | What the sources say | Status |
|---|---|---|

### Undefined in the sources

| Term | Seen (count, first cite) | Q / why it is left out |
|---|---|---|

### Domain notes (external — verify)

| Term | Plain explanation | Why it matters for testing | Verify against |
|---|---|---|---|
