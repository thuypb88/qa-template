---
name: sql-study
description: SQL (reader, IT or ST): study database code before testing it. Inventory the objects of a schema, package or module (tables, procedures, functions, views, triggers, jobs) from the SQL source in sources/ or read-only catalog queries, then write one study card per object - interface (parameters, result set, OUT params, return codes), reads and writes, business rules found in the code with file:line, errors raised, transaction handling, dynamic SQL, dependencies, risks and test hints - plus a map with the dependency graph in <folder>/sql-study/. Rules found only in the code become questions, never expected results. Use for "study this stored procedure", "what does usp_X do", "map the schema / package", "which tables does this proc touch", "đọc hiểu store procedure", "phân tích SQL". Not for: explaining one query to someone → sql-explain; a failing or slow query → sql-debug; the module analysis → design-analysis (it reads these cards).
metadata:
  group: sql
  order: "1-"
---

# SQL: study database code

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** a target (module id with `pack: sql`, or a path / object list for ad-hoc study); SQL source under `sources/`
(DDL, procedure files, packages; `slice.py toc` → `section` for large files) or, when only a database is available,
the read-only catalog queries in [references/catalog-queries.md](references/catalog-queries.md); the spec documents.
**Out:** `<folder>/sql-study/<object>.md` (one card per object) and `<folder>/sql-study/README.md` (map); ad-hoc
without a module: `plans/sql-study/<slug>/`. Questions into `project/questions.md` on the user's OK. **Rules:** core R1;
[packs/sql/rules.md](../../../packs/sql/rules.md) R-SQL2 (code is evidence, not the oracle); dialect:
`project.json › sql.dialect`, [packs/sql/dialects.md](../../../packs/sql/dialects.md). **Next:** `design-analysis`
(module) or `sql-cases` (single object).
**Stop if** neither the source code nor catalog access is available → ask for the files; never reconstruct an object
from its name.
**Output:** [assets/object-card.md](assets/object-card.md) · [assets/study-map.md](assets/study-map.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **Inventory.** List every object in scope: `Object | Type | File:line (or catalog) | Purpose (spec ref or "none
   found")`. Follow calls one level out of scope and mark those objects *external*.
2. **One card per object** ([assets/object-card.md](assets/object-card.md)). Read the whole body; for a long one, outline its blocks first, then read
   block by block. Cite every finding as `file:line`.
3. **Rules found in the code.** Each `IF` / `CASE` / `WHERE` that encodes a business decision becomes a row
   `SR-<obj>-nn | Condition | Effect | file:line | Spec says (ref) | Status`. Status: *confirmed* (the spec states
   it), *differs* (spec says otherwise → `Q-xxx`, likely defect), *code-only* (`Q-xxx: assumed as implemented`).
4. **Risk scan** per object: NULL handling, implicit conversions, `SELECT INTO` / scalar subqueries that assume one
   row, partial commits, swallowed errors (`CATCH` / `WHEN OTHERS` without re-raise), dynamic SQL built from
   parameters, hard-coded dates / codes, missing `ORDER BY` where order matters, cursor loops on large sets,
   triggers that assume one row. Each risk names the checklist ID it feeds ([packs/sql/checklist.md](../../../packs/sql/checklist.md)).
5. **Map** (`README.md`): object table, a Mermaid `flowchart` of calls and table reads / writes, the tables each
   object writes (for side-effect tests), the open questions.
6. `project/log.md` line; commit `<id> sql study (<n> objects)`.

## Card layout (`<object>.md`)

Copy [assets/object-card.md](assets/object-card.md) per object and [assets/study-map.md](assets/study-map.md) for the map;
sections and citation rules per [references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules found    | SR ID | Condition | Effect | file:line | Spec says | Status |
## Errors         | Raised where | Number / SQLSTATE | Message | Transaction state after |
## Transactions   own / caller's; commit points; savepoints; what a failure in the middle leaves
## Dependencies   called objects, triggers fired, sequences, linked servers / DB links
## Risks & test hints   risk → checklist ID → suggested scenario
## Questions      Q-xxx …
```

## Rules

- Read, never run: no `EXEC` / `CALL` of the objects under study; catalog queries are `SELECT` only.
- What the code does is not what it should do: code-only rules stay questions (R-SQL2).
- Name tables and columns exactly as in the DDL; no guessed meanings — unknown → "meaning not documented".

## Done when

- [ ] Every in-scope object has a card with interface, data touched, flow, rules (with status), errors, transactions.
- [ ] Every finding cites `file:line`; code-only and differing rules have `Q-xxx`.
- [ ] Map with dependency graph and written tables; next step named (`design-analysis` or `sql-cases`).
