<!-- Template: sql-study, one card per object. Copy to <folder>/sql-study/<object>.md (ad hoc: plans/sql-study/<slug>/),
replace every <placeholder>, delete this comment. Every finding cites file:line. Rules: ../references/output-rules.md. -->
# <schema.object> (<procedure | function | view | trigger | package | job>)

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Source:** <file:lines | catalog> · **Spec:** <ref or "none found"> · **Dialect:** <dialect>

## Interface

| Parameter / column | Dir | Type | Null | Default | Meaning |
|---|---|---|---|---|---|

<Result set columns, return codes.>

## Data touched

| Table | Read / Insert / Update / Delete | Columns | Condition |
|---|---|---|---|

## Flow

1. <validation → reads → decisions → writes → output, in execution order, file:line>

## Rules found

| SR ID | Condition | Effect | file:line | Spec says | Status |
|---|---|---|---|---|---|
| SR-<obj>-01 | <IF / CASE / WHERE> | <effect> | <file:line> | <ref or —> | <confirmed \| differs (Q-xxx) \| code-only (Q-xxx: assumed as implemented)> |

## Errors

| Raised where | Number / SQLSTATE | Message | Transaction state after |
|---|---|---|---|

## Transactions

<Own / caller's; commit points; savepoints; what a failure in the middle leaves.>

## Dependencies

<Called objects, triggers fired, sequences, linked servers / DB links; out-of-scope ones marked *external*.>

## Risks & test hints

| Risk | Checklist ID | Suggested scenario |
|---|---|---|

## Questions

- Q-<xxx>: <question>
