<!-- Template: sql-study map. Copy to <folder>/sql-study/README.md, replace every <placeholder>, delete this comment.
Rules: ../references/output-rules.md. -->
# <module name>: SQL study map

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Dialect:** <dialect, version> · **Sources:** <files | catalog>

| Object | Type | File:line (or catalog) | Purpose (spec ref or "none found") | Card |
|---|---|---|---|---|
| <schema.object> | <type> | <file:line> | <…> | [<object>.md](<object>.md) |

```mermaid
flowchart LR
    %% calls between objects, and table reads / writes
```

## Tables written (side-effect tests)

| Table | Written by | Operation |
|---|---|---|

## Open questions

- Q-<xxx> (<object>): <question>
