# sql-study: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing cards. Copy [../assets/object-card.md](../assets/object-card.md) per object and
[../assets/study-map.md](../assets/study-map.md) for the map. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1 · [packs/sql/rules.md](../../../../packs/sql/rules.md) R-SQL2 · [packs/sql/checklist.md](../../../../packs/sql/checklist.md)
(checklist IDs) · [packs/sql/dialects.md](../../../../packs/sql/dialects.md).

| Output | File | Write mode |
|---|---|---|
| card | `<folder>/sql-study/<object>.md` (ad hoc: `plans/sql-study/<slug>/<object>.md`) | one per object; overwrite on re-study |
| map | `<folder>/sql-study/README.md` | overwrite |
| questions | `project/questions.md` | on the user's OK |
| log | `project/log.md` | one line |

## Rules

- **Card sections** in the template's order: Interface · Data touched · Flow · Rules found · Errors · Transactions ·
  Dependencies · Risks & test hints · Questions.
- **Every finding cites `file:line`** (or the catalog query).
- **Rules found** `SR-<obj>-nn`; Status confirmed (spec states it) · differs (`Q-xxx`, likely defect) · code-only
  (`Q-xxx: assumed as implemented`). Code is evidence, never the oracle (R-SQL2).
- **Risks** each name the checklist ID they feed.
- Tables and columns named exactly as in the DDL; unknown meaning → "meaning not documented".
- **Map:** object table, a Mermaid `flowchart` of calls and table reads / writes, tables written, open questions.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
