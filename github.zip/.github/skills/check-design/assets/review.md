<!-- Template: check-design review file. Copy to 1-analysis-review.md | 2-mindmap-review.md |
3-test-cases/test-cases-review.md, replace every <placeholder>, delete this comment and the sections marked (test cases)
when reviewing an analysis or a mindmap. Rules: ../references/output-rules.md. Checked by scripts/check_review.py. -->
# <module name | ST: project name>: <analysis | system analysis | test mindmap | test case> review

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Verdict:** <Pass | Pass with fixes | Rework>
**Reviewed:** <YYYY-MM-DD> · **Reviewer:** <agent model> · **Items checked:** <n> · **Spot-checked:** <n>
**Coverage:** <requirements a/b> · <ACs a/b> · <TCONDs / scenarios a/b> · **Script:** <e> Error · <w> Warning

<One short paragraph: what was reviewed (version, against which upstream), and the overall state. Say here when the
artifact is older than its upstream.>

## Findings

| ID | Severity | Priority | Item / section | Check | Rule | Review comment | Evidence | Suggested fix |
|---|---|---|---|---|---|---|---|---|
| <RV- / MR- / TR- (ST SR- / SMR- / STR-)001> | <High \| Med \| Low> | <P1 \| P2 \| P3> | <TC-…, TS-…, §n> | <checklist ID> | <R-n / P-n / PR-n> | <what is wrong; which defect it would miss> | <file:line or requirement ID> | <one fix form from the rules> |

## Fix order

1. <P1 findings, grouped by the fix that clears them; Fix upstream ones first, naming the writer>
2. <P2 findings>
3. <P3 findings>

**Re-check after fixing:** <the script(s) to re-run, the items to re-read, the downstream skill to re-run>

## Missing items

- <coverage that should exist and does not, or "None.">

## Out of black-box scope

<!-- (test cases) only -->
- <a check below the pack surface, and why it is not a TC, or "None.">

## Questions for BA / client

- Q-<xxx> (<items affected>): <question> <"new" when raised by this review>
