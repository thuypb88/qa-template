# check-design: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read when writing the review file. Copy [../assets/review.md](../assets/review.md), replace every `<placeholder>`,
delete the template comments. Shared rules are linked here, never copied:
[review-protocol.md](../../../../standards/review-protocol.md) P1–P7 ·
[conventions.md](../../../../standards/conventions.md) (header stamp, formats).

| Artifact | Review file (in the level folder) | Title words | Finding IDs | Write mode |
|---|---|---|---|---|
| analysis | `1-analysis-review.md` | `analysis` (ST `system analysis`) | `RV-` (ST `SR-`) | overwrite |
| scenarios | `2-mindmap-review.md` | `test mindmap` | `MR-` (ST `SMR-`) | overwrite |
| test cases | `3-test-cases/test-cases-review.md` | `test case` | `TR-` (ST `STR-`) | overwrite |
| all modules | `test-design/it/test-cases-review-summary.md` (test cases only) + chat table | — | — | overwrite |

## Rules

- **Title** exactly `# <module name>: <title words> review` (ST: the project name). Header lines **Verdict**,
  **Reviewed**, **Coverage** as in the template; the script numbers copied into **Coverage**.
- **Sections**, in order: `## Findings`, `## Fix order`, `## Missing items`, `## Out of black-box scope` (test cases
  only), `## Questions for BA / client`; after fixes are applied, `## Revision log`.
- **Every table row** has as many cells as its header, separator row included (a narrower row does not render).
  Escape a `|` inside a cell as `\|`.
- **Severity** High / Med / Low and **Priority** P1 / P2 / P3 per review-protocol P2: severity = how wrong, priority =
  how soon (default High → P1, Med → P2, Low → P3; a lowered one says why).
- **Finding IDs** use the prefix above, numbered from 001, never repeated within the file.
- **Review comment:** what is wrong and which defect it would miss, or why it can't run.
- **Evidence:** a source line, requirement ID or script output; never "see the artifact".
- **Suggested fix**, ready to apply, one of: `<field>: "<new value>"` · **Split** into A + B · **Add note**
  "Q-xxx: assumed …" · **Mark Blocked** until Q-xxx · **Delete / merge** with … · **Fix upstream** in `<file>` ·
  **No change** (a script Warning that is a false positive).
- One rule broken in many places = one finding with the count and the IDs (P2).
- **Item / section** names every TC the finding concerns (`TC-E4-012, 014…016`), so `--review-comments` reaches the
  workbook.
- **Fix order** follows priority, then severity (never a P2 before a P1, never a Low before a High in one priority),
  groups the findings one edit clears, and ends with **Re-check after fixing**.
- **Questions:** one bullet each, `- Q-xxx (items affected): <question>`; a question raised by this review says "new".
- **Revision log** (when fixes are applied): one row per applied finding with the date and the new artifact version.

## Checks before done

```bash
python3 scripts/check_review.py <target> <analysis|scenarios|test-cases>   # 0 Error; read each Warning
python3 scripts/export_testcases.py <target> --review-comments           # test cases only
```
