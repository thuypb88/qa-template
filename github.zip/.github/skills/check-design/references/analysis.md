# Review checklist: analysis (1-analysis.md)

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 10:03:39 (UTC+7)

Read lean: `slice.py toc 1-analysis.md`, then one section at a time; open each source at the cited line.

1. **Coverage.**
   - Every requirement, UC and client reference in `0-scope.md` (IT) / the test plan (ST) is analysed.
   - **R1** every acceptance criterion is in §2 and §10 (a missing AC = High).
   - Every field / parameter / column in the sources is in §5 (pack §5 tables); the source precedence is followed and
     each difference is a `Q-xxx`.
   - **R6.3** a localization TCOND per language per free-text input; **R10** valid + invalid per variant per flow step.
   - Every relevant `Q-ST-xxx` and every source gap is in §9.
   - ST: every item the modules list as Moved to ST is covered, or explicitly dropped with a reason and a question.
     A scoped ST analysis (Scope line `ST for modules …`) is judged against the modules it names: their items
     complete, the unnamed ones not a finding; a hand-off into an unanalysed module carries `partial` + `Q-ST-xxx`.
   - ST: the scope matches the current test plan; behaviour the plan does not cover yet is **Held** in §11 (not
     dropped, not asserted); a TCOND resting on an open question or an undeveloped custom development is **Blocked**.
2. **Accuracy.** Spot-check ≥ 10 cited rules against the source line — lengths, formats, mandatory flags, codes,
   status codes, transformation rules first. Missing / wrong citations and misquoted values are findings.
3. **Consistency.** Conflicts between sources (spec vs client documents vs contract vs mapping) missed or resolved
   silently (L-T11); hand-offs that contradict a neighbour's analysis (L-T02 → Fix upstream naming the other folder).
4. **Inventory (R5).** §3 lists every screen / endpoint / table / job / flow step with the surface's names. A missing
   item or an internal name = High (the mindmap is built from it).
5. **Testability (R2).** Each TCOND is atomic, has one outcome, and **Observable in** names a place at the pack
   surface; internal-only checks are in Out of black-box scope; validated items have negative + boundary TCONDs; state
   machines have allowed + refused transitions. Vague words ("fast", "appropriate") turned into TCONDs with an
   invented threshold instead of an `untestable` question = Med.
6. **Rules and questions** ([standards/methods/requirement-quality.md](../../../../standards/methods/requirement-quality.md)).
   BR rules atomic (one trigger, one outcome, exception or `missing`). Each §9 row has a Kind, the cited phrase,
   readings (ambiguous) or Evidence A / B (conflict), a proposed assumption, an Owner and Blocks. A question that can't
   be closed as written ("please clarify") = Low; a gap claimed without opening the other sources = Med (L-T01).
7. **Level scope (R9).** §11 matches the test plan per UC; out-of-IT items are in Moved to ST, not TCONDs; each external
   system TCOND names an IT fixture; baseline preconditions exist (IT).
8. **Diagrams** ([analysis-diagrams.md](../../../../standards/methods/analysis-diagrams.md)). List the
   source figures (`sources/parsed/<path>/<doc>.figures/INDEX.md`; screens: `extract_text.py <doc.docx> --figures`)
   and open the To-Be ones. Each §4 flow step
   with a source diagram or step table has a Mermaid diagram citing it; lanes, step IDs, decisions and loops match
   the figure; a node, lane or outcome with no source = Med (invention); a figure-vs-table difference not named in
   the **Diagram vs text** line or followed silently = Med; a missing diagram or §1 study diagram = Low. A block that
   does not render = Low.
9. **Structure.** 11 sections; exact title; the TCOND table starts `ID | Condition | Requirement | Type`; unique,
   sequential IDs; traceability complete.

Header coverage line: `Requirements a/b · ACs a/b · fields a/b`.
