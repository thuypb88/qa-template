---
name: check-design
description: Check steps 2, 4 and 6 (reviewer, IT or ST, every pack): review the analysis, scenarios or test cases. Review a folder's analysis (1-analysis.md), scenarios (2-mindmap.md), or test cases (3-test-cases/test-cases.json) against its upstream artifact, the sources, the client documents and the core / pack / project rules, following the review protocol (severity, verdict, evidence, fixes), and write the matching review file; then offer to apply the fixes. Use for "review / check the E4 analysis | mindmap | scenarios | test cases", "is the ST suite ready?", "review all modules". Not for: writing them → design-analysis (ST: design-system) / design-scenarios / design-cases; automated tests → check-automation; a requirement document → req-review; a skill → check-skill.
metadata:
  group: check
  order: "2·4·6"
---

# Check: analysis, scenarios or test cases

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** a target (module id, `st`, `all`) and the artifact (`analysis`, `scenarios` / `mindmap`, `test-cases`). If the user
names no artifact, review the latest step that exists without a current review (`pipeline_status.py`).
**Out:** the review file (overwrite); fixes to the artifact only if approved. **Rules:**
[standards/review-protocol.md](../../../standards/review-protocol.md) P1–P7; core, pack and project rules.
**Next:** the next writer (`design-scenarios` / `design-cases` / `auto-decide`), then `learn-retro` if findings
repeat a pattern.
**Output:** [assets/review.md](assets/review.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

| Artifact | Checklist | Script | Review file | Finding IDs |
|---|---|---|---|---|
| analysis | [references/analysis.md](references/analysis.md) | — | `1-analysis-review.md` | `RV-` (ST `SR-`) |
| scenarios | [references/scenarios.md](references/scenarios.md) | `check_scenarios.py <target>` | `2-mindmap-review.md` | `MR-` (ST `SMR-`) |
| test cases | [references/test-cases.md](references/test-cases.md) | `export_testcases.py <target> --check` + `slice.py tc <target> --patterns` | `3-test-cases/test-cases-review.md` | `TR-` (ST `STR-`) |

The review file itself is checked by `python3 scripts/check_review.py <target> <analysis|scenarios|test-cases>`
(title, header lines, sections, Findings columns and widths, Severity / Priority values, IDs, Questions form).

**Stop if** the artifact is missing (name its writer). Say in the header when it is older than its upstream.

## Steps

1. **Lessons first** (P1.5): `project/lessons.md` and the L-T rows naming `check-design` or this artifact's writer.
2. **Script** (when the table names one): copy its numbers into the header; Errors are findings; read each Warning's
   item before raising it (false positive → row with **No change**).
3. **Whole-artifact scan before spot-checks** (L-T06): the TOC (`slice.py toc`), or `slice.py tc --stats` and
   `--patterns` for test cases.
4. **Checklist** for the artifact — read only the reference file you need.
5. **Spot-check** the riskiest items first (P1.3), opening each source at the cited line.
6. **Write** the review file from [assets/review.md](assets/review.md), then `python3 scripts/check_review.py <target> <artifact>`:
   0 Error before anything else (a table row narrower than its header does not render; fix it, never skip it);
   read each Warning. **Test cases:** then put the comments on the TCs:
   `python3 scripts/export_testcases.py <target> --review-comments` writes each finding onto the TCs its
   **Item / section** cell names (`review_comment`, the workbook's Review Comment column) and re-exports; no
   `version` bump. A finding it reports as naming no TC stays in the review file only.
7. **Report and offer fixes** (P5). Applying: only the reviewed artifact; append IDs; re-run the script (and the
   export + `version` bump for test cases); append `## Revision log`, then re-run `--review-comments` (applied
   findings are marked "applied <date>"); name the downstream skill to re-run.
   **Test cases:** once the fixes are applied (or the verdict is Pass), ask the QA lead to approve this version; on
   approval run `python3 scripts/export_testcases.py <target> --deliver --approved-by "<name>"` — the only way the
   workbook reaches `deliverables/test-cases/`.
8. `project/status.md` board row + `project/log.md`; commit `<id> <artifact> review: <verdict>` (and the fixes, if applied,
   as their own commit).

## Output

Copy [assets/review.md](assets/review.md); title, header lines, sections, Findings columns, Severity / Priority,
finding IDs, fix forms, Fix order and Questions per [references/output-rules.md](references/output-rules.md) — read it
before writing the review.

## All modules (P6)

One target at a time; a summary table in chat (folder · verdict · items · coverage · High / Med); for test cases also
`test-design/it/test-cases-review-summary.md`.

## Pitfalls

L-T05 (clean script ≠ quality), L-T06 (spot-checking only), L-T11 (silent picks), L-T12 (one upstream cause = one
finding), L-T01 (trusting the artifact about its sources) in [standards/template-lessons.md](../../../standards/template-lessons.md).

## Done when

- [ ] Script numbers in the header; whole-artifact scan done; checklist complete.
- [ ] `check_review.py <target> <artifact>`: 0 Error.
- [ ] Spot-check count met (analysis ≥ 10 rules, scenarios ≥ 10 rows, test cases ≥ 15 TCs, all P1
  first).
- [ ] Every finding has evidence, severity, priority and a fix in one of the forms above; Fix order written.
- [ ] Test cases: `--review-comments` run; every TC a finding concerns is named in its Item / section cell
  (`TC-E4-012, 014…016`), so its comment reaches the workbook.
