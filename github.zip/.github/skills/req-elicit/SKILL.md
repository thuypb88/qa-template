---
name: req-elicit
description: Requirements: ask why before anything is written down (a vague request or CR, "test the new X" with no document, "we need …"). Run an ask-why loop from the QA side - classify the request (feature, complaint, workaround, KPI, solution bias, compliance…), show the five requirement layers (business, stakeholder, functional, non-functional, transition) as clear / partial / empty, list known vs unknown, ask 3-5 contextual questions per turn, paraphrase and classify each answer (symptom, root cause, rule, constraint), scan the failure modes nobody mentioned, stop when goals and risks are clear - then write plans/discovery/<date>-<slug>.md with open questions and assumptions. Also step 0a of a module (before plan-scope). Use for "we got a new request", "the client wants …, what should we ask", "clarify this CR", "discovery", "elicit requirements", "discovery for E4", "ask why", "phân tích yêu cầu", "khách hàng yêu cầu", "làm rõ yêu cầu". Reviewing a written document → req-review; writing stories → req-write.
metadata:
  group: req
  order: "0a"
---

# Requirements: elicit (ask why before testing what)

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the request as the user gives it (chat, email text, a meeting note, a ticket), any related sources and
`project/system-map.md`, `project/questions.md`. **Out:** a conversation of short turns, then
`plans/discovery/<YYYY-MM-DD>-<slug>.md` (header row `| Targets | <module ids> |`); open questions into
`project/questions.md` on the user's OK. **Rules:** core
R1 (no invention); [standards/methods/requirement-quality.md](../../../standards/methods/requirement-quality.md) §2 (gap
kinds), §6 (closable questions), §7 (layers). **Next:** the BA / client answers; then `req-write` (if QA must draft the
requirement), `plan-scope <module>` (step 0b) after a module discovery, or `req-review` / `plan-changes` when a document
arrives.
**Output:** [assets/discovery.md](assets/discovery.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

QA's reason to do this: a request accepted at face value gives tests for the wrong thing. The output is questions and
findings for the people who decide — never a requirement QA made up.

## Module discovery (pipeline step 0a)

Before `plan-scope`, every module folder (IT) needs one discovery that names it in its `Targets` row
(`scripts/pipeline_status.py` routes the folder here until one exists). The "request" is the module itself: start
from its sources (`0-scope.md` › Sources, `project.json` › modules), `project/questions.md` and the change-impact
records that touch it, run the loop below with the BA / client, and record what `plan-scope` needs: the scope
questions (in / out, which documents are a test basis), hand-offs to other modules and systems, and the open points
with an owner. One discovery may cover several modules (`| Targets | AP, BG, GL |`) or `all`. A document-inventory
discovery without a `Targets` row does not count.

## A new version of a discovery (new or changed sources, the same subject again)

A discovery file is a dated record: once its questions have gone out, it is not rewritten. When a `plan-changes`
record adds or changes documents the discovery covers (e.g. a requirement-baseline inventory), or the subject comes
back, write a **new** `plans/discovery/<YYYY-MM-DD>-<same slug>.md` (today's date; a file of today's date is the same
version: edit it):

- Header rows `| Supersedes | <earlier file> |` and `| Change record | <project/change-impact/…> |` (when there is one);
  keep the earlier `Targets` value, add a module only if this file does that module's discovery.
- Carry forward what is still true (cite the earlier file), add the new / changed documents and findings, mark each
  row **new**, **changed** or **withdrawn**, and re-list every open question with its current state.
- The earlier file stays as it is (other plans cite it); never archive or edit it for the new version.

## The loop (one or two stages per turn; never all at once)

1. **Classify the request.**

   | Kind | Signal | First move |
   |---|---|---|
   | Feature request | "add", "we need to build" | ask for the problem and who has it, before any feature detail |
   | Complaint / defect | "broken", "too slow", "users complain" | frequency, impact, where; symptom vs cause |
   | Operational pain / workaround | "we export to Excel", "ops does it by hand" | why the workaround exists; what breaks without it |
   | KPI / objective | "reduce", "increase … by" | which behaviour drives it; baseline and target |
   | **Solution bias** | a tool or technology named as the requirement | treat it as a hypothesis; find the problem first |
   | Process / reporting / compliance | approvals, reports, "regulation requires" | owner, rule source, evidence the auditor needs |

2. **Layer status** — show the table every turn (✅ clear · 🟡 partial · ⛔ empty): business, stakeholder,
   functional, non-functional, transition (§7 of the reference). A request that jumps to functions without a business
   reason is incomplete.
3. **Known / unknown** — objective and measure, stakeholders and roles, volume and frequency, current process, rules
   and eligibility, exceptions, constraints (regulation, budget, systems), risks, success measure, NFRs, migration /
   cutover.
4. **Ask 3–5 questions**, specific to this request and its gaps, in this priority: business impact → root cause →
   who → current process → risk → edge cases → how success is measured. Never a generic questionnaire.
5. **After each answer:** paraphrase it in one or two sentences, classify it (symptom · root cause · rule ·
   constraint · requirement · assumption), update the findings, then ask the next batch.
6. **Failure scan** (at least once): duplicates, timeouts, retries, rollback, partial failure, fraud / abuse,
   permissions, audit trail, data inconsistency, regulatory cases (personal data, KYC / AML where relevant).
7. **Stop** when the goal is measurable, causes (not only symptoms) are known, behaviour is concrete enough to test,
   the main risks are named, and new questions add little. Say so and ask the user for corrections before writing.

## Findings file (`plans/discovery/<date>-<slug>.md`)

Copy [assets/discovery.md](assets/discovery.md); header rows (incl. **Targets**), sections and version rules per
[references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- Max 3–5 questions per turn; no BRD / SRS / stories in the first answer.
- Every finding cites its speaker or source; inferences are labelled assumptions.
- The findings are input for the BA / client; nothing here becomes a test basis until confirmed in a source document.

## Done when

- [ ] Layer table, known / unknown and the failure scan done; stop condition stated.
- [ ] Findings file with assumptions and open questions (owners); questions copied to `project/questions.md` on OK.
- [ ] A later version is a new dated file with `Supersedes`; the earlier file is unchanged.
