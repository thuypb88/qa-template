# req-elicit: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 15:44:58 (UTC+7)

Read before writing the findings file. Copy [../assets/discovery.md](../assets/discovery.md), replace every
`<placeholder>`, delete the template comments. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1 · [requirement-quality.md](../../../../standards/methods/requirement-quality.md) §2, §6, §7 ·
[conventions.md](../../../../standards/conventions.md) (stamp, formats).

| Output | File | Write mode |
|---|---|---|
| turns | chat: layer table, known / unknown, 3–5 questions, paraphrase + class of each answer | per turn |
| findings | `plans/discovery/<YYYY-MM-DD>-<slug>.md` | new file per version; a file of today's date is edited; an earlier one is never edited or archived |
| questions | `project/questions.md` | on the user's OK |

## Rules

- **Template sections** of [discovery.md](../assets/discovery.md), in order: `## 1. Business problem and measurable goal` · `## 2. Stakeholders` · `## 3. Findings` · `## 4. Pain points and root causes` · `## 5. Candidate requirements` · `## 6. Business rules heard` · `## 7. Transition needs` · `## 8. Failure scan` · `## 9. Layer status` · `## 10. Assumptions` · `## 11. Open questions` · `## 12. Test impact`.
- **Header table** rows Request, Asked by, Date, Kind, Status (Draft), **Targets** (`| Targets | <module ids> |`,
  `st`, `all` or `—`; `pipeline_status.py` reads it); a new version adds `Supersedes` and, when there is one,
  `Change record`, and keeps the earlier Targets value.
- **Sections** in the template's order; a section with nothing to say says "None heard".
- Candidate requirements are marked **candidate** and cite who said them; inferences are labelled assumptions.
  Nothing here is a test basis until it is confirmed in a source document.
- A new version marks each carried row **new**, **changed** or **withdrawn** and re-lists every open question with
  its current state.
- **Open questions** `Topic | Question | Owner | Blocks`, each the smallest question that decides it.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
