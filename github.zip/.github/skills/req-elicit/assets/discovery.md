<!-- Template: req-elicit findings file. Copy to plans/discovery/<YYYY-MM-DD>-<slug>.md, replace every <placeholder>,
delete these comments. A new version is a new dated file with the Supersedes row. Rules: ../references/output-rules.md. -->
# Discovery: <subject>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

| Field | Value |
|---|---|
| Request | <the request as given> |
| Asked by | <who> |
| Date | <YYYY-MM-DD> |
| Kind | <Feature request \| Complaint / defect \| Operational pain \| KPI / objective \| Solution bias \| Process / reporting / compliance> |
| Status | Draft <— open questions sent to …> |
| Targets | <module ids \| st \| all \| —> |
| Supersedes | <earlier plans/discovery/… file — new version only> |
| Change record | <project/change-impact/… — when there is one> |

## 1. Business problem and measurable goal

<Problem, who has it; goal with baseline and target — cited to the speaker or source.>

## 2. Stakeholders

| Stakeholder | Role | Interest / pain | Source |
|---|---|---|---|

## 3. Findings

| # | Finding | Class (symptom · root cause · rule · constraint · requirement · assumption) | Said by / source | State (new · changed · withdrawn) |
|---|---|---|---|---|

## 4. Pain points and root causes

## 5. Candidate requirements

| ID | Candidate (functional / non-functional) | Said by | Status |
|---|---|---|---|
| CR-1 | <…> | <who> | **candidate** |

## 6. Business rules heard

## 7. Transition needs

## 8. Failure scan

<Duplicates, timeouts, retries, rollback, partial failure, fraud / abuse, permissions, audit trail, data
inconsistency, regulatory cases — each: found / not applicable / question.>

## 9. Layer status

| Layer | Status | What is missing |
|---|---|---|
| Business | <✅ \| 🟡 \| ⛔> | <…> |
| Stakeholder | <…> | <…> |
| Functional | <…> | <…> |
| Non-functional | <…> | <…> |
| Transition | <…> | <…> |

## 10. Assumptions

- <assumption — labelled, with what it rests on>

## 11. Open questions

| Topic | Question | Owner | Blocks |
|---|---|---|---|

## 12. Test impact

<What QA can and cannot plan yet; suggested next skill.>
