<!-- Template: check-skill report, given in chat (a project override: also one line in project/log.md). Replace every
<placeholder>; delete this comment. Rules: ../references/output-rules.md. -->
**Skill:** <name> · **Verdict:** <Pass | Pass with fixes | Rework>

| # | Severity | Where | Issue | Why it matters | Fix |
|---|---|---|---|---|---|
| <check 1–12> | <Blocking \| Suggestion> | <SKILL.md:line \| references/… \| assets/… \| missing file> | <issue> | <effect on an agent or user> | <edit, ready to apply> |

**Trigger test:** should-trigger <n>/5 · near-miss <n>/3 <, or the misses with the skill they went to>
**Evals:** <template-dev/tests/skill-evals/<name>.json: n cases | missing — proposed cases below>
**Not checked:** <runtime behaviour on a real module, unless a run was done>
**Next:** <apply on your OK, then sync_agents.py + selftest | learn-retro for a recurring failure>
