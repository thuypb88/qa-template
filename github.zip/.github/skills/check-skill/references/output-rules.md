# check-skill: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read when writing the report. Fill [../assets/skill-review.md](../assets/skill-review.md). Design rules for skills
are linked, never copied: [skill-architecture.md](../../../../standards/skill-architecture.md),
[SKILL_TEMPLATE.md](../../SKILL_TEMPLATE.md).

| Output | Where | Write mode |
|---|---|---|
| report | chat (a project override: plus one `project/log.md` line) | — |
| fixes (on the user's OK) | the skill's `SKILL.md`, `references/`, `assets/` (template repo, or the project's own `project-*` skill) | edit; Updated stamp |

## Rules

- One row per finding; **Severity** Blocking (the skill misfires, misroutes or writes a wrong output) or
  Suggestion. **Where** names the line or the missing file; no finding without evidence.
- **Trigger test** written out: five requests that should trigger it and three near misses that belong to a
  neighbour, each decidable from the descriptions alone.
- **Not checked** is always present: a static review says nothing about runtime behaviour.
- Template-owned skill in a project (not template-first): findings become a **Promote to template** row via
  `learn-retro`, never an edit.
- Applied fixes: Updated stamp set, `python3 scripts/workspace/sync_agents.py`, self-test green, CHANGELOG line
  (template).
