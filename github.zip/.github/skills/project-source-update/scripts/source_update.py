#!/usr/bin/env python3
"""Source update pipeline for the project-source-update skill: one-command intake, then a board of what is still behind.

    python3 .claude/skills/project-source-update/scripts/source_update.py intake <drop_dir>            # plan only
    python3 .claude/skills/project-source-update/scripts/source_update.py intake <drop_dir> --apply    # do it
    python3 .claude/skills/project-source-update/scripts/source_update.py [board] [--record <change-impact.md>] [--json]

intake: <drop_dir> is sources/**/<folder>_updated_<YYYYMMDD>/; the original is <folder> beside it. Without --apply it
prints the compare table and the merge plan. With --apply: verified backup zip + merge (compare_sources.py --merge
--apply), extract the added / overwritten files (extract_text.py), retire the drop folder (archive.py), show the
pending source changes. Next is always plan-changes (the record and the baseline need a person).

board (default): every item with its stage, state and the skill that does it; items depend on each other:
  0 intake → 1 record → 2a discovery → 2b strategy → 2c estimate → 2d test plan → 2e test plan review → 2f roadmap
                     ↘ 3 test-design rows (parallel with 2a–2e) ↗ (2f waits for 2e and every row done or held) → 4 close
A plan artifact is behind when its Updated / Generated stamp is older than the record or it does not name each new /
changed document; 2b–2f are also behind when older than a module added after the record (the estimate also needs
a size entry per module). A module added after the record gets its own rows: 2a (its discovery Targets row) and 3
(scope → analysis). A new / changed document that no module reads, no ADR names and the baseline discovery does not
mark as a reference / not a test basis gets a "3 decide" row: new module (source_pipeline.py add-module) or not. A test-design row is *held* while a Q- ID its decision names is open. "Ready now" lists every
item whose dependencies are done (run them in parallel); Next is the first. A record whose changes are all
editorial (identical copies, formatting) marks stages 2–3 done: nothing to propagate.
Writes nothing except in intake --apply (through the workspace scripts). Standard library only.
"""
import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]

STAMP = re.compile(r"\*\*Updated:\*\*\s*(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}(?::\d{2})?))?")
CREATED = re.compile(r"\*\*Created:\*\*\s*(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}(?::\d{2})?))?")
GENERATED = re.compile(r"Generated on (\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}(?::\d{2})?))?")
UPDATED_DIR = re.compile(r"_updated_\d{6,8}$", re.I)
STOP = {"tfm", "blueprint", "brd", "with", "appendix", "userrolematrix", "deliver", "confirmed", "final", "draft",
        "eng", "docx", "pdf", "xlsx", "xlsm", "pptx", "updated"}


def when(m) -> dt.datetime | None:
    if not m:
        return None
    t = m.group(2) or "00:00:00"
    t = t if t.count(":") == 2 else t + ":00"
    return dt.datetime.fromisoformat(f"{m.group(1)} {t}")


def stamp(path: Path, rx=STAMP) -> dt.datetime | None:
    try:
        return when(rx.search(path.read_text(encoding="utf-8", errors="replace")[:3000]))
    except OSError:
        return None


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def tokens(name: str) -> list[str]:
    stem = name.rsplit(".", 1)[0].lower()
    stem = re.sub(r"\(v\.?\s*deliver\)|v\d+r\d+|(?<!\d)20\d{6}(?!\d)|\d{6}", " ", stem)
    words = [w for w in re.split(r"[\s_\-.()]+", stem) if w and not w.isdigit()]
    out = [w for w in words if len(w) >= 3 and w not in STOP]
    # a module document (TFM_AA_BluePrint) has no distinctive word: fall back to "<key> <kind>" (aa, blueprint)
    return out or [w for w in words if len(w) >= 2 and w not in {"tfm", "eng", "confirmed", "final", "draft"}]


def cites(text_norm: str, name: str) -> bool:
    t = tokens(name)
    return bool(t) and all(norm(w) in text_norm for w in t)


def latest_record() -> Path | None:
    recs = sorted((ROOT / "project/change-impact").glob("*.md"))
    return recs[-1] if recs else None


def record_files(rec: Path) -> list[str]:
    """Document names the record lists before its Changes table (the Files block)."""
    text = rec.read_text(encoding="utf-8")
    head = text.split("## Changes", 1)[0]
    names = []
    for m in re.finditer(r"`([^`]+\.(?:docx|pdf|xlsx|xlsm|pptx|md|csv|json|ya?ml|txt))`", head, re.I):
        n = Path(m.group(1)).name
        if "…" in n or re.search(r"\.\w+\.md$", n) or "parsed/" in m.group(1):
            continue  # shortened names and parsed copies are not documents
        if n not in names:
            names.append(n)
    return names


def decision_rows(rec: Path) -> list[dict]:
    text = rec.read_text(encoding="utf-8")
    m = re.search(r"## Decision per folder\n(.*?)(?:\n## |\Z)", text, re.S)
    rows = []
    for line in (m.group(1).splitlines() if m else []):
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 5 or cells[0] in ("Folder",) or set(cells[0]) <= set("-: "):
            continue
        rows.append({"folder": cells[0].strip("`"), "decision": cells[1], "run": cells[-2], "fu": cells[-1]})
    return rows


def q_ids(text: str) -> list[str]:
    """Q- IDs, including shorthand lists: "Q-INIT-011, 041 / 042" → Q-INIT-011, Q-INIT-041, Q-INIT-042."""
    out = []
    for m in re.finditer(r"\b(Q-(?:[A-Z]+-)?)(\d{3})((?:\s*(?:,|/|and)\s*\d{3}\b)*)", text):
        out.append(m.group(1) + m.group(2))
        out += [m.group(1) + n for n in re.findall(r"\d{3}", m.group(3))]
    return sorted(set(out))


def open_ids(path: Path, prefix: str) -> set[str]:
    """IDs in the open part of a register (status.md §2 for FU, questions.md rows without Answered / Closed)."""
    if not path.is_file():
        return set()
    text = path.read_text(encoding="utf-8")
    if prefix == "FU":
        text = text.split("## 3.", 1)[0]
    out = set()
    for line in text.splitlines():
        m = re.match(rf"\|\s*({prefix}-[A-Z]*-?\d+)", line)
        if m and not re.search(r"\b(answered|closed|resolved)\b", line, re.I):
            out.add(m.group(1))
    return out


def stage_intake() -> list[dict]:
    items = []
    for d in sorted((ROOT / "sources").rglob("*")):
        if d.is_dir() and UPDATED_DIR.search(d.name) and "parsed" not in d.parts and "trace" not in d.parts:
            items.append({"id": "0", "stage": "0 intake", "item": str(d.relative_to(ROOT)), "state": "drop folder present",
                          "done": False, "run": f"source_update.py intake {d.relative_to(ROOT)} (--apply on OK)"})
    if not items:
        items.append({"id": "0", "stage": "0 intake", "item": "no *_updated_<date> drop folder", "state": "—", "done": True,
                      "run": "—"})
    return items


def stage_record(rec: Path | None) -> tuple[list[dict], list[str]]:
    import subprocess
    out = subprocess.run([sys.executable, "-B", str(ROOT / "scripts/trace_changes.py"), "--json"], cwd=ROOT,
                         capture_output=True, text=True)
    cmp = json.loads(out.stdout or "{}")
    pending = [c["path"] for c in cmp.get("changes", [])]
    base = json.loads((ROOT / "sources/trace/source-baseline.json").read_text(encoding="utf-8")) \
        if (ROOT / "sources/trace/source-baseline.json").is_file() else {}
    rec_at = stamp(rec, CREATED) if rec else None
    acc = base.get("accepted")
    acc_at = dt.datetime.fromisoformat(acc + (":00" if acc and acc.count(":") == 1 else "")) if acc else None
    items = []
    if pending and (not rec or (acc_at and rec_at and rec_at <= acc_at)):
        items.append({"id": "1", "stage": "1 record", "item": f"{len(pending)} source change(s) with no record", "done": False,
                      "state": "no change-impact record newer than the baseline", "run": "plan-changes"})
    elif pending:
        items.append({"id": "1", "stage": "1 record", "item": str(rec.relative_to(ROOT)), "done": False,
                      "state": f"record written, baseline not accepted ({len(pending)} pending)",
                      "run": "plan-changes step 8: trace_changes.py --accept --note <record> (user OK)"})
    else:
        items.append({"id": "1", "stage": "1 record", "item": str(rec.relative_to(ROOT)) if rec else "—", "done": True,
                      "state": f"baseline accepted {acc or '—'} ({base.get('note', '—')})", "run": "—"})
    names = [Path(c).name for c in pending if not any(UPDATED_DIR.search(x) for x in Path(c).parts)]
    seen = {tuple(tokens(n)) for n in names}
    for n in record_files(rec) if rec else []:
        if tuple(tokens(n)) not in seen:
            seen.add(tuple(tokens(n)))
            names.append(n)
    return items, names


PLANS = [
    ("2a", "plans/discovery/*requirement-baseline*.md", "discovery: requirement baseline (document inventory, open points)",
     "req-elicit (new dated baseline discovery that Supersedes the previous one: new documents, status, questions)", STAMP),
    ("2b", "plans/test-strategy.md", "test strategy (scope in / out, risk areas, integrations)", "plan-strategy", STAMP),
    ("2c", "plans/test-estimate.md", "estimate (plans/estimation.json → test-estimate.md)",
     "plan-testplan estimate (size entries from the new sources; test_estimate.py --write)", GENERATED),
    ("2d", "plans/test-plan.md", "test plan (references, scope, risks, schedule; version + .docx)",
     "plan-testplan plan (bump version; new .docx archives the old)", STAMP),
    ("2f", "plans/roadmap.md", "roadmap (milestones, risks, history)", "flow-roadmap update", STAMP),
]


def modules() -> list[dict]:
    """project.json modules with their folder and the time the folder was added (first commit of 0-scope.md)."""
    import subprocess
    try:
        mods = json.loads((ROOT / "project.json").read_text(encoding="utf-8")).get("modules", [])
    except (OSError, json.JSONDecodeError):
        return []
    out = []
    for m in mods:
        folder = ROOT / "test-design/it" / f"MOD-{m['id']}-{m.get('slug', '')}"
        scope = folder / "0-scope.md"
        log = subprocess.run(["git", "log", "--diff-filter=A", "--format=%ci", "--", str(scope.relative_to(ROOT))],
                             cwd=ROOT, capture_output=True, text=True).stdout.split("\n")
        first = [x for x in log if x.strip()]
        added = dt.datetime.fromisoformat(first[-1][:19]) if first else (dt.datetime.now() if scope.is_file() else None)
        reads = []
        sj = folder / "sources.json"
        if sj.is_file():
            try:
                reads = [Path(s["path"]).name for s in json.loads(sj.read_text(encoding="utf-8")).get("sources", [])]
            except (json.JSONDecodeError, KeyError):
                pass
        out.append({"id": m["id"], "folder": folder, "added": added, "reads": reads})
    return out


def targets_named(mod_id: str) -> bool:
    """A plans/discovery/*.md header row `| Targets | … |` names the module (or all)."""
    for f in (ROOT / "plans/discovery").glob("*.md"):
        m = re.search(r"^\|\s*Targets\s*\|([^|\n]*)\|", f.read_text(encoding="utf-8"), re.M | re.I)
        names = {x.strip().lower() for x in re.split(r"[,;/\s]+", m.group(1)) if x.strip()} if m else set()
        if mod_id.lower() in names or "all" in names:
            return True
    return False


def stage_modules(rec_at: dt.datetime | None, mods: list[dict]) -> list[dict]:
    """A module added after the record: its own design row (scope → analysis) and its discovery Targets."""
    items = []
    for m in mods:
        if not (rec_at and m["added"] and m["added"] > rec_at):
            continue
        rel_f = str(m["folder"].relative_to(ROOT))
        if not targets_named(m["id"]):
            items.append({"id": f"2a:{m['id']}", "stage": "2 plans", "item": rel_f, "done": False,
                          "state": f"new module {m['id']} not in any discovery Targets row",
                          "run": f"req-elicit {m['id']} (module discovery; today's discovery file is edited, else a new one)"})
        has = (m["folder"] / "1-analysis.md").is_file()
        items.append({"id": f"3:{rel_f}", "stage": "3 design", "item": rel_f, "done": has, "held": [],
                      "state": f"new module {m['id']} (added {m['added']:%Y-%m-%d %H:%M})"
                      + ("; analysis written" if has else "; scope and analysis to do"),
                      "run": f"plan-scope {m['id']} → design-analysis {m['id']} → check-design"})
    return items


DECIDED = re.compile(r"not a test basis|integration reference|outside the|out of scope|reporting template", re.I)


def stage_decide(names: list[str], mods: list[dict]) -> list[dict]:
    """A new / changed document that no module reads needs a decision: new module, integration reference, or not a
    test basis. Decided = a module reads it, an ADR names it, or the latest baseline discovery row naming it says so."""
    adrs = norm(" ".join(f.read_text(encoding="utf-8") for f in (ROOT / "project/decisions").glob("ADR-*.md")))
    discs = sorted((ROOT / "plans/discovery").glob("*requirement-baseline*.md"))
    rows = [ln for ln in discs[-1].read_text(encoding="utf-8").splitlines() if ln.startswith("|")] if discs else []
    read = {n for m in mods for n in m["reads"]}
    items = []
    for n in names:
        if n in read or cites(adrs, n) or any(cites(norm(r), n) and DECIDED.search(r) for r in rows):
            continue
        items.append({"id": f"3:decide:{n}", "stage": "3 design", "item": n, "done": False, "held": [],
                      "state": "read by no module and no decision recorded: new module, integration reference, "
                               "or not a test basis?",
                      "run": "QA lead decides → new module: source_pipeline.py add-module …; else record it in the "
                             "baseline discovery row or an ADR"})
    return items


def stage_plans(rec_at: dt.datetime | None, names: list[str], mods: list[dict] | None = None) -> list[dict]:
    """A plan is behind the record, or behind the newest module added after it (a new module changes the plans)."""
    newest = max((m["added"] for m in mods or [] if m["added"]), default=None)
    module_at = newest if newest and rec_at and newest > rec_at else None
    est_ids = set()
    try:
        est_ids = set(json.loads((ROOT / "plans/estimation.json").read_text(encoding="utf-8"))["size"]["modules"])
    except (OSError, json.JSONDecodeError, KeyError):
        pass
    missing_est = [m["id"] for m in mods or [] if m["id"] not in est_ids]
    items = []
    for sid, pattern, what, run, rx in PLANS:
        files = sorted(ROOT.glob(pattern)) if "*" in pattern else [ROOT / pattern]
        files = [f for f in files if f.is_file()]
        if not files:
            items.append({"id": sid, "stage": "2 plans", "item": pattern, "what": what, "state": "missing", "done": False,
                          "run": run})
            continue
        f = files[-1]
        at = stamp(f, rx)
        text = norm(f.read_text(encoding="utf-8", errors="replace"))
        missing = [n for n in names if not cites(text, n)]
        behind = bool(rec_at and (at is None or at < rec_at))
        # a module added after the record: every plan except the discovery (its Targets row is checked per module)
        new_mod = bool(sid != "2a" and module_at and (at is None or at < module_at))
        no_est = sid == "2c" and missing_est
        items.append({"id": sid, "stage": "2 plans", "item": str(f.relative_to(ROOT)), "what": what,
                      "updated": at.isoformat(sep=" ") if at else "no stamp", "behind": behind or new_mod,
                      "not_cited": missing, "done": not behind and not missing and not new_mod and not no_est,
                      "run": run,
                      "state": ("behind the record" if behind else "after the record")
                      + (f"; older than module(s) added {module_at:%Y-%m-%d %H:%M}" if new_mod else "")
                      + (f"; no size entry for {', '.join(missing_est)}" if no_est else "")
                      + (f"; does not name {len(missing)} of {len(names)} new / changed document(s)" if missing else "")})
        if f.name == "test-plan.md":
            v = re.search(r"\bVersion\s*\|?\s*v?(\d+\.\d+)", f.read_text(encoding="utf-8", errors="replace"))
            ver = v.group(1) if v else None
            revs = sorted((ROOT / "plans/test-plan-reviews").glob(f"*-v{ver}.md")) if ver else []
            items.append({"id": "2e", "stage": "2 plans", "item": f"plans/test-plan-reviews/*-v{ver or '?'}.md",
                          "what": "test plan review of the current version", "done": bool(revs) and not behind,
                          "state": f"review {revs[-1].name}" if revs else f"no review of v{ver or '?'}",
                          "run": "check-testplan"})
    return items


def stage_design(rec: Path | None) -> list[dict]:
    if not rec:
        return []
    fus = open_ids(ROOT / "project/status.md", "FU")
    q_open = open_ids(ROOT / "project/questions.md", "Q")
    items = []
    for r in decision_rows(rec):
        fu = re.findall(r"FU-\d+", r["fu"])
        none = r["decision"].lower().startswith("none") or r["decision"].startswith("input")
        open_fu = [x for x in fu if x in fus]
        done = (none and not open_fu) or (fu and not open_fu)
        qs = q_ids(r["decision"] + " " + r["run"])
        held = [] if done else [q for q in qs if q in q_open]
        items.append({"id": f"3:{r['folder']}", "stage": "3 design", "item": r["folder"], "state": r["decision"][:140],
                      "fu": ", ".join(fu) or "—", "fu_open": open_fu, "done": bool(done), "held": held,
                      "run": r["run"]})
    for i in items:  # "as AP": the row shares the named folder's hold
        m = re.search(r"\bas ([A-Z]{2,})\b", i["state"])
        if m and not i["done"] and not i["held"]:
            src = next((x for x in items if f"MOD-{m.group(1)}-" in x["item"]), None)
            if src:
                i["held"] = list(src["held"])
    return items


def stage_close(rec: Path | None) -> list[dict]:
    if not rec:
        return []
    text = rec.read_text(encoding="utf-8")
    qs = q_ids(text.split("## Questions", 1)[-1])
    q_open = open_ids(ROOT / "project/questions.md", "Q")
    still = [q for q in qs if q in q_open]
    return [{"id": "4", "stage": "4 close", "item": "questions raised by the record", "done": not still,
             "state": f"{len(still)} of {len(qs)} open: {', '.join(still)}" if still else f"{len(qs)} answered",
             "run": "chase the owners (project-assistant todo); answers re-open the design rows they block"}]


def editorial_only(rec: Path | None) -> bool:
    """Every row of the record's Changes table is editorial / none (identical copies, formatting)."""
    if not rec:
        return False
    m = re.search(r"## Changes\n(.*?)(?:\n## |\Z)", rec.read_text(encoding="utf-8"), re.S)
    kinds = []
    for line in (m.group(1).splitlines() if m else []):
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) >= 6 and cells[0] not in ("#",) and not set(cells[0]) <= set("-: "):
            kinds.append(cells[-2].lower())
    return bool(kinds) and all(k.startswith(("editorial", "none")) for k in kinds)


DEPS = {"1": ["0"], "2a": ["1"], "2b": ["2a"], "2c": ["2b"], "2d": ["2c"], "2e": ["2d"], "2f": ["2d", "2e", "3:*"],
        "4": ["*"]}


def schedule(items: list[dict]) -> list[dict]:
    """Ready now: not done, not held, every dependency done (a held design row counts as settled for 2f)."""
    by = {i["id"]: i for i in items}
    def ok(dep: str, me: str) -> bool:
        if dep == "*":
            return all(i["done"] for i in items if i["id"] != me)
        if dep == "3:*":
            return all(i["done"] or i.get("held") for i in items if i["id"].startswith("3:"))
        if dep == "2a" and not all(i["done"] for i in items if i["id"].startswith("2a:")):
            return False  # a new module's discovery row gates the strategy like 2a
        d = by.get(dep)
        return d is None or d["done"]
    ready = []
    for i in items:
        deps = DEPS.get(i["id"], ["1"] if i["id"].startswith(("3:", "2a:")) else [])
        i["ready"] = not i["done"] and not i.get("held") and all(ok(d, i["id"]) for d in deps)
        if i["ready"]:
            ready.append(i)
    return ready


def rel(p: Path) -> str:
    try:
        return str(p.relative_to(ROOT))
    except ValueError:
        return str(p)


def intake(drop: Path, apply: bool) -> int:
    import subprocess
    drop = (ROOT / drop).resolve() if not drop.is_absolute() else drop
    if not drop.is_dir() or not UPDATED_DIR.search(drop.name):
        print(f"not a drop folder (<folder>_updated_<YYYYMMDD>): {drop}", file=sys.stderr)
        return 2
    orig = drop.parent / UPDATED_DIR.sub("", drop.name)
    if not orig.is_dir():
        print(f"original folder missing: {orig} (ask which folder the analyses cite)", file=sys.stderr)
        return 2
    cs = ROOT / ".claude/skills/project-compare-sources/scripts/compare_sources.py"
    py = [sys.executable, "-B"]
    res = json.loads(subprocess.run(py + [str(cs), str(orig), str(drop), "--json"], cwd=ROOT, capture_output=True,
                                    text=True).stdout)
    to_extract = [r["new"] for r in res["files"] if r["status"] == "only-in-new"
                  or (r["status"] == "changed")]
    rc = subprocess.run(py + [str(cs), str(orig), str(drop), "--merge"] + (["--apply"] if apply else []), cwd=ROOT).returncode
    if not apply:
        print(f"\nWould then extract {len(to_extract)} file(s) and archive {rel(drop)}. "
              "Re-run with --apply on the user's OK.")
        return rc
    if rc != 0:
        print("merge not clean: stopped before extract / archive", file=sys.stderr)
        return rc
    if to_extract:
        subprocess.run(py + [str(ROOT / "scripts/extract_text.py")] + [str((orig / n).relative_to(ROOT)) for n in to_extract],
                       cwd=ROOT, check=False)
    subprocess.run(py + [str(ROOT / "scripts/workspace/archive.py"), str(drop.relative_to(ROOT)), "--reason",
                         f"client drop merged into {orig.relative_to(ROOT)} (ADR-002)",
                         "--slug", drop.name.lower().replace("_", "-")], cwd=ROOT, check=False)
    subprocess.run(py + [str(ROOT / "scripts/trace_changes.py")], cwd=ROOT, check=False)
    print("\nNext: /plan-changes (record, questions, decision per folder; accept the baseline on the user's OK)")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", nargs="?", default="board", choices=["board", "intake"])
    ap.add_argument("drop", nargs="?", type=Path)
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--record", type=Path)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if a.cmd == "intake":
        if not a.drop:
            print("intake needs <drop_dir>", file=sys.stderr)
            return 2
        return intake(a.drop, a.apply)
    rec = (ROOT / a.record if not a.record.is_absolute() else a.record) if a.record else latest_record()
    if rec and not rec.is_file():
        print(f"no such record: {rec}", file=sys.stderr)
        return 2
    rec_items, names = stage_record(rec)
    rec_at = stamp(rec, CREATED) if rec else None
    mods = modules()
    plans, design = stage_plans(rec_at, names, mods), stage_design(rec)
    fast = editorial_only(rec) and rec_items[0]["done"]
    if fast:
        for i in plans + design:
            i.update(done=True, held=[], state="no content change in the record: nothing to propagate")
    extra = stage_modules(rec_at, mods) + ([] if fast else stage_decide(names, mods))
    items = stage_intake() + rec_items + plans + [i for i in extra if i["id"].startswith("2a:")] + design \
        + [i for i in extra if not i["id"].startswith("2a:")] + stage_close(rec)
    ready = schedule(items)
    nxt = ready[0] if ready else None
    res = {"record": str(rec.relative_to(ROOT)) if rec else None,
           "record_created": rec_at.isoformat(sep=" ") if rec_at else None, "editorial_only": fast,
           "documents": names, "items": items, "ready": [i["id"] for i in ready], "next": nxt}
    if a.json:
        print(json.dumps(res, indent=1, ensure_ascii=False))
        return 0
    print(f"# Source update pipeline\n\nRecord: {res['record'] or '—'} (created {res['record_created'] or '—'})")
    print("New / changed documents: " + ("; ".join(names) or "—") + ("  · editorial only" if fast else "") + "\n")
    print("| # | Stage | Item | State | Done | Run |\n|---|---|---|---|---|---|")
    for i in items:
        state = i["state"] + (f" · FU {i['fu']}" if i.get("fu") else "") + (f" · Updated {i['updated']}" if i.get("updated") else "")
        mark = "✓" if i["done"] else ("held: " + ", ".join(i["held"]) if i.get("held") else ("ready" if i.get("ready") else "·"))
        sid = i["id"].split(":")[0]
        print(f"| {sid} | {i['stage']} | {i['item']} | {state} | {mark} | {i['run']} |")
    for n in names:
        miss = [Path(i["item"]).name for i in items if n in i.get("not_cited", []) and not i["done"]]
        if miss:
            print(f"\nNot named by {', '.join(miss)}: {n}")
    held = [i for i in items if i.get("held")]
    if held:
        print("\nHeld on open questions: " + "; ".join(f"{i['item']} ({', '.join(i['held'])})" for i in held))
    if ready:
        print("\nReady now (parallel): " + "; ".join(f"{i['id'].split(':')[0]} {Path(i['item']).name} → {i['run']}" for i in ready))
    print(f"\nNext: {nxt['run']} — {nxt['item']}" if nxt else
          "\nNext: " + ("answer the held questions" if held else "nothing behind; the source update is through."))
    return 0


if __name__ == "__main__":
    sys.exit(main())
