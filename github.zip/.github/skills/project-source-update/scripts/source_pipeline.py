#!/usr/bin/env python3
"""Source update pipeline in one command: from new or updated files under sources/ to the next skill to run.

    S=.claude/skills/project-source-update/scripts
    python3 $S/source_pipeline.py                     # detect + plan: what is new, what would run (writes nothing)
    python3 $S/source_pipeline.py run --apply         # do every mechanical step, stop at the first gate
    python3 $S/source_pipeline.py run --apply --accept   # also accept the baseline once a record covers the changes
    python3 $S/source_pipeline.py [...] --json
    python3 $S/source_pipeline.py add-module <ID> --name … --slug … --source "<glob>" [--refs …] [--depends A,B]
            [--upstream-of C] [--answers Q-…] --reason "<who decided, when>" [--apply]
                                                    # a new feature document becomes a QA module (plan / --apply)

Steps (the stages of the project-source-update skill; PR-7):
  0 detect   drop folders sources/**/<folder>_updated_<YYYYMMDD>/ and files that differ from the accepted baseline
  0 intake   each drop: compare, verified backup, merge into the original folder, archive the drop (ADR-002)
             → source_update.py intake <drop> [--apply]
  0 extract  new / changed documents → sources/parsed/ (extract_text.py; skips unchanged hashes)
  0 trace    sources/trace/source-changes.{md,json} (trace_changes.py): which level folders read each change
  1 record   GATE: a change-impact record newer than the baseline must name every changed file → /plan-changes.
             With a covering record, --accept runs trace_changes.py --accept --note <record> (only on the user's OK)
  2–4        checks (read-only): test_estimate.py --check, check_testplan.py, pipeline_status.py; then the board of
             source_update.py; every ready stage printed as the skill command to run, with its input

Without --apply nothing is written (intake and extract are shown as plans). The written steps go through the
workspace scripts (backup, archive, guard rules). The judgement stages (record, discovery, strategy, estimate inputs,
test plan, reviews, roadmap, test design) stay with their skills: this script hands them off, it never writes them.
Exit: 0 nothing pending · 1 a stage or gate is waiting · 2 error. Standard library only.
"""
import argparse
import datetime as dt
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True  # no __pycache__ in the skill folder (the agent mirrors copy it)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import source_update as su  # noqa: E402

ROOT = su.ROOT
PY = [sys.executable, "-B"]
SKILL = {  # stage → the command to hand off; {rec} = record, {disc} = latest baseline discovery, {today}
    "2a": "/req-elicit — new plans/discovery/{today}-requirement-baseline.md (Supersedes {disc}; Change record {rec})",
    "2b": "/plan-strategy — scope in / out, risks, integrations, entry / exit for the documents in {rec}",
    "2c": "/plan-testplan estimate — size entries for the new sources in plans/estimation.json, then --write ({rec})",
    "2d": "/plan-testplan plan — bump the version, references, scope, §6 from the estimate; new .docx archives the old",
    "2e": "/check-testplan — review the new test plan version",
    "2f": "/flow-roadmap update — milestones, risks, history, study rows for {rec}",
}


def sh(args: list[str], capture: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(PY + args, cwd=ROOT, capture_output=capture, text=True)


def drops() -> list[Path]:
    return [d for d in sorted((ROOT / "sources").rglob("*")) if d.is_dir() and su.UPDATED_DIR.search(d.name)
            and "parsed" not in d.relative_to(ROOT).parts and "trace" not in d.relative_to(ROOT).parts]


def pending() -> dict:
    out = sh(["scripts/trace_changes.py", "--json"])
    try:
        return json.loads(out.stdout or "{}")
    except json.JSONDecodeError:
        return {"error": (out.stderr or out.stdout)[-400:]}


def unextracted(paths: list[str]) -> list[str]:
    """Changed / added files whose parsed copy is missing or older than the file (extract_text.py would write)."""
    out = []
    for p in paths:
        f = ROOT / p
        if not f.is_file() or su.UPDATED_DIR.search(f.parent.name):
            continue
        parsed = ROOT / "sources/parsed" / f.relative_to(ROOT / "sources")
        parsed = parsed.with_name(parsed.name + ".md")
        if not parsed.is_file() or parsed.stat().st_mtime < f.stat().st_mtime:
            out.append(p)
    return out


def record_state(changes: list[dict], base: dict) -> dict:
    rec = su.latest_record()
    rec_at = su.stamp(rec, su.CREATED) if rec else None
    acc = base.get("baseline")
    acc_at = dt.datetime.fromisoformat(acc + (":00" if acc and acc.count(":") == 1 else "")) if acc else None
    newer = bool(rec and rec_at and (not acc_at or rec_at > acc_at))
    text = rec.read_text(encoding="utf-8") if rec else ""
    missing = [c["path"] for c in changes if Path(c["path"]).name not in text and c["path"] not in text]
    return {"record": su.rel(rec) if rec else None, "newer_than_baseline": newer,
            "covers": newer and not missing, "not_named": missing if newer else [c["path"] for c in changes]}


def checks() -> list[dict]:
    out = []
    for name, args in [("test_estimate --check", ["scripts/test_estimate.py", "--check"]),
                       ("check_testplan", ["scripts/check_testplan.py"])]:
        if not (ROOT / args[0]).is_file():
            continue
        r = sh(args)
        last = [ln for ln in (r.stdout + r.stderr).strip().splitlines() if ln.strip()]
        out.append({"check": name, "rc": r.returncode, "result": last[-1] if last else "—"})
    r = sh(["scripts/pipeline_status.py", "--json"])
    try:
        st = json.loads(r.stdout)
        folders = st.get("folders", st if isinstance(st, list) else [])
        nxt = [f"{f.get('key', '?')}: {f.get('next') if isinstance(f.get('next'), str) else (f.get('next') or ['—'])[0]}"
               for f in folders if isinstance(f, dict)]
        out.append({"check": "pipeline_status", "rc": r.returncode, "result": "; ".join(nxt) or "—"})
    except (json.JSONDecodeError, AttributeError):
        out.append({"check": "pipeline_status", "rc": r.returncode, "result": (r.stdout or r.stderr).strip()[-200:]})
    return out


def handoff(item: dict, rec: str | None) -> str:
    discs = sorted((ROOT / "plans/discovery").glob("*requirement-baseline*.md"))
    sid = item["id"].split(":")[0]
    tpl = SKILL.get(item["id"])
    if tpl:
        return tpl.format(rec=rec or "—", disc=su.rel(discs[-1]) if discs else "—", today=dt.date.today().isoformat())
    if sid == "3":
        return f"{item['run']} — {item['item']} (record {rec})"
    return item["run"]


def restamp(text: str, now: str) -> str:
    return su.re.sub(r"(\*\*Updated:\*\* )[^(]*(\(UTC\+7\))", rf"\g<1>{now} \2", text, count=1)


def add_module(a) -> int:
    """A new feature document becomes a QA module: project.json entry, folder (init_project.py), ADR, register lines."""
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    pj = ROOT / "project.json"
    src = pj.read_text(encoding="utf-8")
    p = json.loads(src)
    mid = a.module.upper()
    errs = []
    if any(m["id"] == mid for m in p["modules"]):
        errs.append(f"module {mid} already in project.json")
    files = sorted(ROOT.glob(a.source)) if a.source else []
    if not files:
        errs.append(f"--source matches no file: {a.source}")
    ids = {m["id"] for m in p["modules"]}
    deps = [x.strip().upper() for x in (a.depends or "").split(",") if x.strip()]
    ups = [x.strip().upper() for x in (a.upstream_of or "").split(",") if x.strip()]
    errs += [f"unknown module {x}" for x in deps + ups if x not in ids]
    for need in ("name", "slug", "reason"):
        if not getattr(a, need):
            errs.append(f"--{need} is required")
    if errs:
        print("add-module: " + "; ".join(errs), file=sys.stderr)
        return 2
    base = p["modules"][0]
    entry = {"id": mid, "slug": a.slug, "name": a.name, "pack": a.pack or base.get("pack", "ui"),
             "layout": a.layout or base.get("layout", "flow"), "security": a.security or base.get("security", "full"),
             "security_techniques": base.get("security_techniques", []) if (a.security or base.get("security")) == "full" else [],
             "refs": a.refs or [], "acceptance": [], "sources": [a.source], "variants": [], "depends_on": deps,
             "externals": []}
    decs = sorted((ROOT / "project/decisions").glob("ADR-[0-9][0-9][0-9]-*.md"))
    nxt = max([int(f.name[4:7]) for f in decs] + [0]) + 1
    adr = ROOT / f"project/decisions/ADR-{nxt:03d}-{a.slug}-is-a-qa-module.md"
    folder = f"test-design/it/MOD-{mid}-{a.slug}"
    print(f"add-module {mid} — {a.name}\n  source: " + ", ".join(su.rel(f) for f in files)
          + f"\n  folder: {folder}\n  depends on: {', '.join(deps) or '—'}; upstream of: {', '.join(ups) or '—'}"
          + f"\n  ADR: {su.rel(adr)}\n  questions answered: {', '.join(a.answers or []) or '—'}")
    if not a.apply:
        print("\nPlan only. Re-run with --apply on the QA lead's decision.")
        return 1
    ind = len(src.split("\n")[1]) - len(src.split("\n")[1].lstrip())
    for m in p["modules"]:
        if m["id"] in ups and mid not in m["depends_on"]:
            m["depends_on"].append(mid)
    p["modules"].append(entry)
    pj.write_text(json.dumps(p, ensure_ascii=False, indent=ind) + ("\n" if src.endswith("\n") else ""), encoding="utf-8")
    v = sh(["scripts/qa_config.py", "--validate"])
    if v.returncode != 0:
        pj.write_text(src, encoding="utf-8")
        print("project.json invalid, restored:\n" + v.stdout + v.stderr, file=sys.stderr)
        return 2
    sh(["scripts/init_project.py"], capture=False)
    adr.write_text(f"""# ADR-{nxt:03d}: {a.name} is a QA module, tested from its source document

> **Created:** {now} · **Updated:** {now} (UTC+7)

- **Status:** accepted (QA side)
- **Decided by:** {a.decided_by}, {now[:10]}
- **Context:** {'; '.join(su.rel(f) for f in files)} arrived as a new / changed source that no module read.
- **Decision:** module **{mid} — {a.name}** (pack `{entry['pack']}`, layout `{entry['layout']}`, security
  `{entry['security']}`), source `{a.source}`, refs {', '.join(entry['refs']) or '—'}; depends on {', '.join(deps) or '—'};
  {', '.join(ups) or 'no module'} now depend{'s' if len(ups) == 1 else ''} on {mid}. Folder `{folder}`.
- **Consequences:** {', '.join(a.answers or []) or 'no question'} answered; discovery Targets row for {mid}
  (`req-elicit`), then `plan-scope {mid}`, and the plans re-run (strategy, estimate, test plan + review, roadmap) as the
  `source_update.py` board shows; then `design-analysis {mid}`.
- **Evidence:** {a.reason}
""", encoding="utf-8")
    qf = ROOT / "project/questions.md"
    if a.answers and qf.is_file():
        q = qf.read_text(encoding="utf-8")
        for qid in a.answers:
            q = q.replace(f"| {qid} | ", f"| {qid} | **Answered {now[:10]} ({a.decided_by}, [ADR-{nxt:03d}](decisions/"
                                          f"{adr.name})): a test basis — module {mid}, folder {folder}.** ", 1)
        qf.write_text(restamp(q, now), encoding="utf-8")
    lf = ROOT / "project/log.md"
    if lf.is_file():
        lg = lf.read_text(encoding="utf-8").rstrip("\n")
        lg += (f"\n| {now[:10]} | project.json, {folder}, project/decisions | Module {mid} — {a.name} added "
               f"(source_pipeline.py add-module, ADR-{nxt:03d}): source {a.source}; depends on {', '.join(deps) or '—'}; "
               f"upstream of {', '.join(ups) or '—'}; answered {', '.join(a.answers or []) or '—'} | {su.rel(adr)}; next: "
               f"req-elicit {mid} (Targets), plan-scope {mid} |\n")
        lf.write_text(restamp(lg, now), encoding="utf-8")
    print(f"""
Done: project.json + {folder} + {su.rel(adr)}{' + questions' if a.answers else ''} + log.
Still by hand (the board shows each):
  1. Discovery Targets row names {mid} with a module section → /req-elicit {mid} (edit today's discovery, else a new one)
  2. A follow-up FU-NNN in project/status.md for the re-plan; project/index.md › Now if it lists the modules
  3. guard check, commit "Module {mid} ({a.name}) added: ADR-{nxt:03d} …"
  4. Re-run: python3 .claude/skills/project-source-update/scripts/source_pipeline.py""")
    return 0


def main() -> int:
    if len(sys.argv) > 1 and sys.argv[1] == "add-module":
        ap = argparse.ArgumentParser(prog="source_pipeline.py add-module", description=add_module.__doc__)
        ap.add_argument("cmd")
        ap.add_argument("module", help="module id, e.g. PU")
        ap.add_argument("--name", help='e.g. "Purchase Non-Sales (PU)"')
        ap.add_argument("--slug", help="e.g. purchase-non-sales")
        ap.add_argument("--source", help="glob under the workspace, e.g. 'sources/requirements/BRD/*Purchase_NonSales*.pdf'")
        ap.add_argument("--refs", action="append", help="requirement references (repeat)")
        ap.add_argument("--depends", help="modules this one depends on, comma-separated")
        ap.add_argument("--upstream-of", help="modules that now depend on this one, comma-separated")
        ap.add_argument("--pack"), ap.add_argument("--layout"), ap.add_argument("--security")
        ap.add_argument("--answers", action="append", help="question IDs the decision answers (repeat)")
        ap.add_argument("--decided-by", default="QA lead (the user)")
        ap.add_argument("--reason", help="the decision's evidence: who said what, when")
        ap.add_argument("--apply", action="store_true")
        return add_module(ap.parse_args())
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", nargs="?", default="plan", choices=["plan", "run"])
    ap.add_argument("--apply", action="store_true", help="run: write (intake, extract, trace)")
    ap.add_argument("--accept", action="store_true", help="run: accept the baseline when a record covers the changes")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    write = a.cmd == "run" and a.apply
    log, res = [], {"steps": [], "gate": None, "handoffs": [], "checks": []}

    def step(name: str, state: str, **kw):
        res["steps"].append({"step": name, "state": state, **kw})
        log.append(f"- **{name}** — {state}")

    # 0 detect + intake
    ds = drops()
    step("0 detect", f"{len(ds)} drop folder(s)" + (": " + ", ".join(su.rel(d) for d in ds) if ds else ""))
    for d in ds:
        if not a.json:
            print(f"\n## Intake {su.rel(d)}{'' if write else ' (plan)'}\n")
        rc = su.intake(d.relative_to(ROOT), write) if not a.json else \
            subprocess.run(PY + [str(Path(__file__).with_name("source_update.py")), "intake", str(d.relative_to(ROOT))]
                           + (["--apply"] if write else []), cwd=ROOT, capture_output=True, text=True).returncode
        step("0 intake", f"{su.rel(d)}: {'merged and archived' if write and rc == 0 else 'planned' if not write else f'stopped (rc {rc})'}")
        if write and rc != 0:
            res["gate"] = f"intake of {su.rel(d)} stopped: read the merge plan, fix, re-run"
    if res["gate"]:
        return finish(a, res, log)

    # 0 extract + trace
    p = pending()
    if "error" in p:
        step("0 trace", "trace_changes.py failed: " + p["error"])
        res["gate"] = "trace_changes.py failed"
        return finish(a, res, log)
    changes = [c for c in p.get("changes", []) if not any(su.UPDATED_DIR.search(x) for x in Path(c["path"]).parts)]
    todo = unextracted([c["path"] for c in changes if c["change"] != "removed"])
    if write and todo:
        sh(["scripts/extract_text.py"], capture=a.json)
    step("0 extract", (f"{len(todo)} file(s) " + ("extracted" if write else "would be extracted")
                       + ": " + ", ".join(todo)) if todo else "parsed copies current")
    if write:
        sh(["scripts/trace_changes.py"])
        p = pending()
        changes = [c for c in p.get("changes", []) if not any(su.UPDATED_DIR.search(x) for x in Path(c["path"]).parts)]
    step("0 trace", f"{len(changes)} change(s) since the baseline {p.get('baseline') or '—'}"
         + "".join(f"\n  - {c['change']}: {c['path']} → read by {', '.join(c.get('read_by') or ['—'])}" for c in changes))

    # 1 record gate
    if changes:
        r = record_state(changes, p)
        res["record"] = r
        if not r["newer_than_baseline"]:
            res["gate"] = ("/plan-changes — no change-impact record newer than the baseline: write "
                           f"project/change-impact/{dt.date.today().isoformat()}-<slug>.md for "
                           + ", ".join(Path(c['path']).name for c in changes))
        elif not r["covers"]:
            res["gate"] = f"/plan-changes — {r['record']} does not name: " + ", ".join(r["not_named"])
        elif write and a.accept:
            out = sh(["scripts/trace_changes.py", "--accept", "--note", r["record"]])
            step("1 accept", f"baseline accepted with note {r['record']}" if out.returncode == 0
                 else "accept failed: " + (out.stderr or out.stdout)[-300:])
            if out.returncode != 0:
                res["gate"] = "baseline accept failed"
        else:
            res["gate"] = (f"accept the baseline: {r['record']} names every change — on the user's OK, "
                           "re-run with `run --apply --accept`")
        step("1 record", res["gate"] or f"{r['record']} covers the changes; accepted")
        if res["gate"]:
            return finish(a, res, log)
    else:
        step("1 record", "no pending change: the latest record stands")

    # 2–4 checks + board
    res["checks"] = checks()
    for c in res["checks"]:
        step(f"check {c['check']}", c["result"])
    board = json.loads(subprocess.run(PY + [str(Path(__file__).with_name("source_update.py")), "--json"], cwd=ROOT,
                                      capture_output=True, text=True).stdout)
    res["board"] = {"record": board["record"], "ready": board["ready"],
                    "held": [{"item": i["item"], "held": i["held"]} for i in board["items"] if i.get("held")]}
    ready = [i for i in board["items"] if i.get("ready")]
    res["handoffs"] = [{"stage": i["id"].split(":")[0], "item": i["item"], "run": handoff(i, board["record"])}
                       for i in ready]
    behind = [i for i in board["items"] if not i["done"]]
    step("2–4 board", f"record {board['record']}: {len(behind)} item(s) not done, {len(ready)} ready, "
         f"{len(res['board']['held'])} held")
    return finish(a, res, log)


def finish(a, res: dict, log: list[str]) -> int:
    waiting = bool(res["gate"] or res["handoffs"] or res.get("board", {}).get("held"))
    if a.json:
        print(json.dumps(res, indent=1, ensure_ascii=False))
        return 1 if waiting else 0
    mode = "run" + (" --apply" if a.apply else " (dry: add --apply to write)") if a.cmd == "run" else "plan (writes nothing)"
    print(f"\n# Source update pipeline · {mode}\n")
    print("\n".join(log))
    if res["gate"]:
        print(f"\n**Gate:** {res['gate']}")
    if res["handoffs"]:
        print("\n**Ready now** (one skill each; run in parallel where the board allows):")
        for h in res["handoffs"]:
            print(f"  {h['stage']:>3}  {h['run']}")
    for h in res.get("board", {}).get("held", []):
        print(f"  held  {h['item']} — on {', '.join(h['held'])}")
    if not waiting:
        print("\nNothing pending: the source update is through.")
    print("\nAfter each skill and its review: commit the stage, then re-run this script.")
    return 1 if waiting else 0


if __name__ == "__main__":
    sys.exit(main())
