<!-- Template: project-source-update answer (chat). Rows from scripts/source_update.py; this skill writes no artifact of
its own. Replace every <placeholder>; delete this comment. Rules: ../references/output-rules.md. -->
**Source update <record slug>** · record [`project/change-impact/<file>`](<path>) · <editorial only: stages 2–3 skipped | content change>

| # | Stage | State | Run with | FU |
|---|---|---|---|---|
| <0> | <Intake> | <✓ \| · behind \| held: Q-…> | `<skill>` | <FU-…> |

**Ready now:** <items, plans and test design in parallel when the user asks>
**Held:** <item — question — what releases it>
**Next:** `/<skill> <target>` with the record path as its input
