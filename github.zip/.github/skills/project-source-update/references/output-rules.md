# project-source-update: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Fill [../assets/board-answer.md](../assets/board-answer.md). Linked, never copied:
[core-rules.md](../../../../standards/core-rules.md) R1 ·
[ADR-002](../../../../project/decisions/ADR-002-updated-source-drops-merge-into-original.md) ·
[conventions.md](../../../../standards/conventions.md) §11.

| Output | Where | Write mode |
|---|---|---|
| board | chat | per run of `source_update.py` |
| stage artifacts | each by its own skill (plan-changes, req-elicit, plan-strategy, plan-testplan, check-testplan, flow-roadmap, the test-design writers) | never by this skill |
| new module (add-module) | `project.json`, the module folder, an ADR | `source_pipeline.py add-module`, on the QA lead's decision |
| board rows | `project/status.md` › source update section | edit, from the script |
| log | `project/log.md` | `source update <slug> complete` at the end |

## Rules

- **Board rows** from the script; a stage is ✓ only when its artifact is current against the record.
- **Hold, don't skip:** a stage on an open scope question runs with the record's `Q-xxx: assumed …`, or is held with
  its FU and the question named.
- A "no change" stage is still recorded by its skill (one line, Updated stamp).
- One stage handed off at a time (several only when the user asks).
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
