---
name: project-source-update
description: Project (router, project-wide, both levels; the default route for every source change in TFM, PR-7): run the whole pipeline after the client updates a source folder - intake (compare, verified backup, merge, extract, archive the drop), trace the change (plan-changes), then bring every downstream artifact up to date (discovery, strategy, estimate, test plan and review, roadmap, the test-design folders the change record names), each by its own skill. scripts/source_pipeline.py runs the mechanical steps, stopping at each gate; scripts/source_update.py shows what is behind, ready or held. Use for "the client sent updated sources", "BRD_updated_<date> arrived, update everything", "re-run the plans after the source change", "what is still behind the new BRD", "cập nhật tài liệu mới", "chạy lại pipeline khi có tài liệu mới". Not for: only comparing / merging two folders → project-compare-sources; only the impact record → plan-changes; the next step without a source change → flow-next.
metadata:
  group: project
  order: "0"
---

# Project: source update pipeline

> **Created:** 2026-10-26 10:40:00 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** a source drop (`sources/**/<folder>_updated_<YYYYMMDD>/`) or any unaccepted change under `sources/`; the
latest `project/change-impact/` record; `plans/`, `test-design/`, `project/status.md`, `project/questions.md`.
**Out:** nothing of its own: each stage is written by its skill; this skill reports the board and hands off one stage
at a time. **Rules:** core R1 (no invention), [ADR-002](../../../project/decisions/ADR-002-updated-source-drops-merge-into-original.md)
(drops merge into the original folder after a backup), writer → reviewer at every step, archive never delete.
**Next:** the first item of *Ready now*.
**Stop if** no source changed and no drop folder exists → `flow-next`.
**Default route** ([PR-7](../../../project/rules.md)): every source change in TFM goes through this skill, not
straight to `plan-changes`; `project-assistant` status / todo name it first.
**Output:** [assets/board-answer.md](assets/board-answer.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

`S=.claude/skills/project-source-update/scripts/source_update.py`

- **Whole pipeline in one command** (start here): `python3 .claude/skills/project-source-update/scripts/source_pipeline.py`
  (plan, writes nothing) → on the user's OK `run --apply`: detect drops and changed files, intake each drop, extract,
  trace, then stop at the record gate (`/plan-changes`) or, once a record names every change, at the accept gate
  (`run --apply --accept` only on the user's OK); after that it runs the read-only checks and prints every ready
  stage as the skill command to run, with its input. Exit 1 while anything waits. Re-run after each stage.
- **Intake in one command:** `python3 $S intake <drop_dir>` (plan only) → on the user's OK `--apply`: verified backup
  zip, merge, extract the added / changed files, archive the drop folder, show the pending changes.
- **Board:** `python3 $S [--record <change-impact.md>] [--json]`: one row per item — `✓` done, `ready`, `held: Q-…`
  (a test-design row whose decision names an open question), `·` waiting on a dependency — then *Ready now* (run in
  parallel) and **Next**. Run it at the start and after every stage.
- **Fast path:** a record whose changes are all editorial (identical copies, formatting) marks stages 2–3 done.

## Stages and dependencies

`0 → 1 → 2a → 2b → 2c → 2d → 2e → 2f → 4`; the stage 3 rows start after 1 and run **in parallel** with 2a–2e;
2f (roadmap) waits for 2e and for every stage 3 row done or held.

| # | Stage | Skill | Done when (what the script checks) |
|---|---|---|---|
| 0 | **Intake:** compare, back up, merge, extract, retire the drop folder | `source_update.py intake <drop> [--apply]` (uses `project-compare-sources`, `extract_text.py` - text and flow charts, `sources/parsed/<file>.figures/` - `archive.py`) | no `*_updated_<date>` folder left under `sources/` |
| 1 | **Trace:** classify, trace to IDs, decide per folder, questions, FU; accept the baseline on OK | `plan-changes` | a record newer than the baseline; no pending change |
| 2a | **Discovery:** add the new / changed documents to the requirement baseline inventory (type, version, status, signed?), version conflicts, open points | `req-elicit` (a **new** `plans/discovery/<date>-requirement-baseline.md`, `Supersedes` the previous one, which stays unchanged) | the latest file is dated after the record and names every new document |
| 2b | **Strategy:** scope in / out, risk areas, integrations, entry / exit touched by the change | `plan-strategy` | as 2a |
| 2c | **Estimate:** size entries for the new sources / scope in `plans/estimation.json`, then `test_estimate.py --write` | `plan-testplan` mode estimate | `test-estimate.md` generated after the record; names every new document |
| 2d | **Test plan:** references, scope, risks, schedule; version bump; new `.docx` archives the old | `plan-testplan` mode plan | as 2a |
| 2e | **Test plan review** of the new version | `check-testplan` | a review file `*-v<current version>.md` |
| 2f | **Roadmap:** milestones, risks, history, gates | `flow-roadmap` mode update | as 2a |
| 3 | **Test design:** each row of the record's *Decision per folder*: `plan-scope` → `design-analysis` → `check-design` → `design-scenarios` → … from the step it names | the skill in the row's Run column | its FU closed (or decision *none*) |
| 3 | **Decide a document no module reads** (new feature?): new module, integration reference, or not a test basis | the QA lead; then § New feature document | a module reads it, an ADR names it, or the latest baseline discovery row naming it says "not a test basis" / "integration reference" / "outside …" |
| 3 | **New module** (added after the record): `plan-scope` → `design-analysis` → `check-design` | the board's row | its `1-analysis.md` exists (then the normal pipeline) |
| 2a | **New module's discovery:** its `Targets` row and module section | `req-elicit <id>` | a discovery `Targets` row names it |
| 4 | **Close:** the record's questions answered; follow-ups closed; `learn-retro` if a review repeated a finding | `project-assistant todo`, `learn-retro` | no record Q / FU open |

## Steps

1. Answer from [assets/board-answer.md](assets/board-answer.md) ([references/output-rules.md](references/output-rules.md)).
   Drop folder present → `intake` (plan, then `--apply` on OK), then `plan-changes` (record; accept on OK).
   Otherwise run the board and say what is ready and why (its rows).
2. **Hold, don't skip.** A stage that depends on an open scope question (e.g. "is document X in scope?") runs with
   the record's stated assumption, marked `Q-xxx: assumed …` in that artifact, or is held with its FU and the
   question named — say which, and ask the user when the assumption changes scope or effort.
3. Hand off: `/<skill> <target>` for one ready item (or, when the user asks, several ready items in parallel), with
   the record path as its input. A held row starts when its question is answered: re-run the board. After the skill and its
   reviewer finish, commit the stage (`<artifact> v<version>: source update <record slug>`), re-run the board.
4. Stages 2a–2f may be **no change** when the document is outside scope: the skill still records it (one line naming
   the document and why it changes nothing, Updated stamp), so the board shows the artifact as current.
5. At the end: the board shows no `·`; one `project/log.md` line `source update <slug> complete`.

## New feature document (a new or changed document no module reads)

The board shows it as `3 decide: <file>`. A new feature never gets a folder by assumption: the QA lead decides
(ask with the three options; until then the record's assumption stands, e.g. "integration reference", with its Q-).

1. **Integration reference / not a test basis** → say so in the baseline discovery row that names the file (today's
   file, else a new version) or in an ADR; the hand-offs are tested inside the modules that receive them.
2. **New module** → `S2=.claude/skills/project-source-update/scripts/source_pipeline.py`;
   `python3 $S2 add-module <ID> --name "<Name> (<ID>)" --slug <slug> --source "<glob of the document>" --refs "<§ / IDs>"
   --depends <modules it needs> --upstream-of <modules that receive its output> --answers <Q-…> --reason "<who said
   what, date>"` (plan) → `--apply` on the QA lead's OK. It writes the `project.json` entry (formatting kept; validated,
   restored on error), builds the folder (`init_project.py`), writes `ADR-NNN-<slug>-is-a-qa-module.md`, marks the
   `--answers` questions answered and appends the log line. A document without requirement IDs: refs are its To-Be
   sections and role-matrix functions; its own open-items appendix becomes one question (`Q-…`).
3. **By hand**, in this order (the board then shows each): the discovery `Targets` row and a module section
   (`req-elicit <ID>`; edit today's discovery, else a new version); a questions row still partly open is reworded
   so it stays open ("Partly decided … (still open)", never "answered"); an FU in `project/status.md` for the re-plan;
   `project/index.md` › Now; guard check; commit `Module <ID> (<name>) added: ADR-NNN …`.
4. **Re-plan:** every plan stamped before the new module is behind again (2b–2f; 2c also needs a size entry for it):
   `plan-scope <ID>` → `plan-strategy` → `plan-testplan` estimate / plan → `check-testplan` → `flow-roadmap update`,
   then `design-analysis <ID>`.

## Rules

- Router only: never write a plan, an estimate or a test design here; never merge, accept or archive without the
  user's OK (each is a separate question).
- Order matters: estimate before plan (the plan quotes it), plan before its review, roadmap last (it reads the gates);
  test-design rows follow the chain order of `flow-next`.
- A stage marked done by a newer stamp only is not proof it covers the change: read the artifact's change line.

## Done when

- [ ] Board run at start and after each stage; every stage done, or held with its FU and question named.
- [ ] Each artifact written / reviewed by its own skill and committed; new versions archived the old ones.
- [ ] Record questions and follow-ups closed or carried in `project/status.md`; log line written.
