# sql-debug: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing the record. Copy [../assets/debug-record.md](../assets/debug-record.md), replace every
`<placeholder>`, delete the template comment. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1, R9 · [packs/sql/rules.md](../../../../packs/sql/rules.md) · [packs/sql/dialects.md](../../../../packs/sql/dialects.md) ·
[defect-report.md](../../../../standards/methods/defect-report.md) §1 (a product defect, via `run-defects`).

| Output | File | Write mode |
|---|---|---|
| record | `<folder>/sql-debug/<YYYY-MM-DD>-<slug>.md` (chat only for a one-line fix) | new dated file |
| defect | via `run-defects` | minimal repro, expected (source-cited) vs actual, evidence |
| QA-owned fix | data / verification scripts | on the user's OK |
| log | `project/log.md` | one line |

## Rules

- **Sections** in order: header (symptom, environment, settings, classification) · `## Repro` · `## Hypotheses` ·
  `## Root cause` · `## Resolution`.
- **Repro** is the smallest failing statement plus the 2–5 rows that trigger it; not reproduced → what differs
  between runs.
- **Every hypothesis** has a check query, its result and a verdict; evidence before conclusion.
- **Root cause** separates trigger, cause and escape point; an unproven cause is a guess.
- Writes only on the test database, inside a rolled-back transaction, with synthetic data; never alter product
  objects, indexes or settings.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
