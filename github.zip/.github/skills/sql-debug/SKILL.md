---
name: sql-debug
description: SQL (IT or ST): debug a database problem from evidence - an error, a wrong or missing result, duplicates, a slow query or procedure, blocking / deadlock, a flaky SQL test, or a failed SQL test case. Reproduce it exactly (call, data, dialect and version, session settings), classify the symptom, shrink it to the smallest failing case, rank hypotheses and test each with a read-only discriminating query, read the plan for performance, and conclude with the root cause and evidence - then fix QA's own scripts, or hand a product defect to run-defects with the minimal repro; never change product objects. Writes <folder>/sql-debug/<date>-<slug>.md. Use for "this query returns wrong rows", "why is this proc slow", "deadlock", "ORA- / Msg / SQLSTATE error", "TC-S1-004 failed", "debug SQL", "sửa lỗi câu SQL", "query chạy chậm". Not for: explaining working code → sql-explain; running the suite → run-tests.
metadata:
  group: sql
  order: "E"
---

# SQL: debug

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the symptom (error text, the wrong output vs the expected one, timings, a failed TC with its `sql` block and
`runs/<key>/results.csv` detail); the SQL / object source or `sql-study` card; the dialect and engine version.
**Out:** `<folder>/sql-debug/<YYYY-MM-DD>-<slug>.md` (chat only for a one-line fix); a defect via `run-defects`;
fixes to QA-owned scripts (data, verification) on the user's OK. **Rules:** core R1, R9;
[packs/sql/rules.md](../../../packs/sql/rules.md); [packs/sql/dialects.md](../../../packs/sql/dialects.md) (error
functions, plan and lock views). **Next:** `run-defects` (product), `sql-data` / `sql-verify` (QA script), then
`run-tests` to confirm.
**Stop if** the problem is only on UAT / production → read-only evidence only, agreed with the owner; no writes.
**Output:** [assets/debug-record.md](assets/debug-record.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **Reproduce.** Exact statement and parameters, the data set (script or rows), user / role, dialect and version,
   session settings that change results (ANSI_NULLS, isolation level, time zone, NLS / collation, SQL mode). Not
   reproducible → collect what differs between the runs (data, time, concurrency) before guessing.
2. **Classify** and start from the matching row:

   | Symptom | First suspects |
   |---|---|
   | Error | the error number's documented cause; constraint / FK; conversion; no-data / too-many-rows; permissions; a trigger |
   | Wrong / missing rows | NULL semantics; join type or a WHERE on the outer side; join key grain (duplicates); filter on date with time; collation / trailing spaces; implicit conversion; stale data from a previous run |
   | Duplicates | a join to a non-unique key; missing condition; DISTINCT hiding it elsewhere |
   | Wrong number | integer division; rounding / FLOAT; currency scale; aggregate over NULLs; time zone |
   | Slow | plan: scans on large tables, estimate vs actual rows, non-sargable predicates (function on a column, conversion), parameter sniffing, missing index, row-by-row loops |
   | Blocking / deadlock | lock order between two code paths; long transactions; isolation level; missing index forcing wider locks |
   | Flaky | order without `ORDER BY`; shared data between tests; timing / `now()`; parallel runs on the same keys |

3. **Shrink:** remove clauses, joins and rows while the problem stays; the smallest failing statement + the 2–5 rows
   that trigger it is the repro.
4. **Hypotheses, ranked:** for each, a discriminating query (read-only; or DML on the test database inside a
   transaction that is rolled back) and what result would confirm or reject it. Run, record, move on.
5. **Root cause** with evidence (query + output, plan excerpt, lock graph). Separate the trigger, the cause and the
   escape point (why no test caught it).
6. **Resolve:**
   - QA-owned (data script, verification, TC expectation wrong vs the source) → fix on OK; re-run the TC.
   - Product → `run-defects` with the minimal repro, expected (source-cited) vs actual, and the evidence.
   - Spec unclear → `Q-xxx`.
   Suggest the regression TC that would have caught it (`sql-cases`).

## Record layout

Copy [assets/debug-record.md](assets/debug-record.md); sections and evidence rules per
[references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- Evidence before conclusion: every hypothesis is confirmed or rejected by a query result, not by reading alone.
- Never alter product objects, indexes or settings to "make it pass"; propose them in the defect.
- Writes only on the test database, in a transaction rolled back, with synthetic data.

## Done when

- [ ] Reproduced (or the differences between runs recorded); minimal repro written.
- [ ] Hypotheses with check queries and results; root cause with evidence.
- [ ] Resolution done or handed off (DEF / Q / fix); regression TC suggested; `project/log.md` line.
