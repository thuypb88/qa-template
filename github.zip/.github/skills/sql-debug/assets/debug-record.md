<!-- Template: sql-debug. Copy to <folder>/sql-debug/<YYYY-MM-DD>-<slug>.md (a one-line fix: chat only), replace every
<placeholder>, delete this comment. Rules: ../references/output-rules.md. -->
# SQL debug: <symptom in one line>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Symptom:** <error text | wrong output vs expected | timings | failed TC-…>
**Environment:** <DB, version, build> · **Settings:** <ANSI_NULLS, isolation level, time zone, NLS / collation, SQL mode>
**Classification:** <Error | Wrong / missing rows | Duplicates | Wrong number | Slow | Blocking / deadlock | Flaky>

## Repro

```sql
-- smallest failing statement, parameters written out
```

| <table> | <col> | <col> |
|---|---|---|
| <the 2–5 rows that trigger it> | | |

## Hypotheses

| # | Hypothesis | Check query | Result | Verdict |
|---|---|---|---|---|
| 1 | <…> | <read-only, or DML rolled back on the test database> | <output> | <confirmed \| rejected> |

## Root cause

**Trigger:** <…> · **Cause:** <…> · **Escape point:** <why no test caught it> · **Evidence:** <query + output, plan
excerpt, lock graph>

## Resolution

<QA-owned fix applied (on OK) and TC re-run | DEF-… via run-defects | Q-xxx> · **Regression TC:** <suggested, for sql-cases>
