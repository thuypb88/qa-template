---
name: plan-scope
description: Plan: one module's scope and readiness (IT step 0, writer). After the module's discovery (step 0a, req-elicit), refresh its generated 0-scope.md and sources.json with scripts/init_project.py (after editing its project.json entry), then rewrite the hand-maintained MANUAL block - scope boundary, cross-module dependencies, readiness per requirement, questions to raise first. Use for "update / refresh the E4 scope", "add a module", after the rules, sources or project.json change, before re-running design-analysis, or after design-cases to refresh readiness. System scope → design-system.
metadata:
  group: plan
  order: "0b"
---

# Plan: a module's scope

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the module's entry in `project.json`; its sources; its discovery (`plans/discovery/*.md` whose `Targets`
row names it); the neighbours' analyses; the test plan. **Out:** the
generated part of `0-scope.md` + `sources.json` (by the script), and the MANUAL block (by you). **Rules:** core R1,
R9. **Next:** `design-analysis`. **Stop if** no discovery names the module → `req-elicit <module>` (step 0a).
**Output:** [assets/0-scope-manual.md](assets/0-scope-manual.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **project.json first.** New module or changed refs / sources / variants / depends_on → edit the module's entry
   (`id`, `slug`, `name`, `pack`, `layout`, `security`, `refs`, `acceptance`, `sources`, `variants`,
   `depends_on`, `externals`). Run `python3 scripts/qa_config.py --validate`.
2. `python3 scripts/init_project.py` → refreshes `0-scope.md` (outside MANUAL), `sources.json`, INDEX, system map.
   Fix every "source missing" line (wrong glob, or the file still to come → a question).
3. **Rewrite the MANUAL block** from [assets/0-scope-manual.md](assets/0-scope-manual.md) (the guard only lets you edit inside it):
   - **Scope boundary:** in / out, citing the test plan's IT scope row; items the plan moves to ST.
   - **Cross-module dependencies:** `Depends on | What it needs | Hand-off as the tester sees it | Source`.
   - **Readiness per requirement:** Ready / Partly / Blocked, why, Q refs (after test cases exist: from their
     Blocked rows).
   - **Questions to raise first:** the few that block the most (from the discovery's open questions first).
4. A line in `project/log.md`; commit `<id> scope refresh`.

## Rules

- Never edit the generated part by hand; change `project.json` and re-run the script.
- A dependency names what the tester sees at the hand-off, not an internal call.

## Done when

- [ ] `qa_config.py --validate` clean; `init_project.py` run; no "source missing" line left unexplained.
- [ ] MANUAL block: scope boundary, dependencies, readiness per requirement, first questions; `project/log.md` line.
