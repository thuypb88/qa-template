# plan-scope: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before rewriting the MANUAL block. Use [../assets/0-scope-manual.md](../assets/0-scope-manual.md). Linked, never
copied: [core-rules.md](../../../../standards/core-rules.md) R1, R9 · [conventions.md](../../../../standards/conventions.md) §2.

| Output | File | Write mode |
|---|---|---|
| generated part | `<folder>/0-scope.md` outside MANUAL, `sources.json`, INDEX, system-map module table | `python3 scripts/init_project.py` only, never by hand |
| MANUAL block | `<folder>/0-scope.md` between `<!-- MANUAL:START -->` and `<!-- MANUAL:END -->` | rewrite |
| project entry | `project.json › modules[]` | edit, then `qa_config.py --validate` |
| log | `project/log.md` | one line |

## Rules

- **MANUAL sections**, in order: `## Scope boundary` · `## Cross-module dependencies`
  (`Depends on | What it needs | Hand-off as the tester sees it | Source`) · `## Readiness per requirement`
  (`Requirement | Readiness | Why | Q refs`; Ready / Partly / Blocked) · `## Questions to raise first`.
- Markers kept exactly; nothing written outside them.
- A dependency names what the tester sees at the hand-off, not an internal call.
- Every "source missing" line of the script is fixed or explained by a question.
