<!-- Template: design-cases checklist pass. Copy to <folder>/3-test-cases/checklist-pass.md, replace every
<placeholder>, delete this comment. Rules: ../references/output-rules.md. -->
# <module id> <GUI | API | ETL> checklist pass

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

Source: [packs/<pack>/checklist.md](<relative path>); inventory: [1-analysis.md §3](../1-analysis.md); suite:
`test-cases.json` v<version>.

Cells: `TC-<MOD>-nnn` = covered by a scenario TC (the check ID is in its notes) · `new TC-<MOD>-nnn` = checklist TC of
this pass · `Blocked` = S-oracle missing, waits on its `Q-` question · `N/A` = the item has no such element.

| Item | <check ID> | <check ID> |
|---|---|---|
| <inventory item> | <N/A \| TC-… \| new TC-… \| Blocked> | <…> |

## Counts

| N/A | Covered | New | Blocked | New questions |
|---|---|---|---|---|
| <n> | <n> | <n> | <n> | <n> |

## Notes on N/A

- <check ID on item: why the element does not exist>

## Questions raised by this pass (registered in project/questions.md)

- Q-<UI- | API- | ETL-xxx>: <question> — assumed <value>
