---
name: design-cases
description: Design step 5 (writer, IT or ST): the test cases. Expand a folder's 2-mindmap.md scenarios into detailed test cases in 3-test-cases/test-cases.json (common fields plus the pack block - api / etl), run the pack checklist pass (GUI / API / ETL checklist → 3-test-cases/checklist-pass.md), then check and export the Excel. Use for "write the E4 test cases", "produce the test case Excel", "add TCs for the new scenarios", "write the system / E2E test cases", "run the GUI checklist on E5". Reviewing them → check-design; modules with pack sql → sql-cases.
metadata:
  group: design
  order: "5"
---

# Design: test cases

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `2-mindmap.md`, `1-analysis.md` (field tables, §11 fixtures and baseline preconditions), client documents.
**Out:** `3-test-cases/test-cases.json` (source of truth), `3-test-cases/checklist-pass.md`, the generated
Excel (named by `project.json › excel.filename`, default `<suite>_Test_Cases_v<version>.xlsx`). Not the deliverable:
it is delivered only after review and approval (§3). **Rules:** core R1–R10, the pack's `rules.md` and `tc-fields.md`, project
rules; fields per [standards/conventions.md](../../../standards/conventions.md) §4. **Next:** `check-design`.
Note in the report if `2-mindmap-review.md` is missing.
**Output:** [assets/checklist-pass.md](assets/checklist-pass.md) · [assets/test-cases.json](assets/test-cases.json); rules [references/output-rules.md](references/output-rules.md) — read before writing.

**Existing suite:** new scenarios → append with the next free `tc_id`, never renumber. Rebuilt mindmap (a TS
mapping newer than the JSON) → rewrite from `…-001` in scenario order, bump `version`, say so.

Read lean, one level-1 item at a time: its mindmap section and rows, its analysis field table, the existing IDs
(`slice.py tc <target> --list`).

## 1. Each test case

How each field is written: [standards/methods/test-case-fields.md](../../../standards/methods/test-case-fields.md)
(preconditions, 1:1 steps ↔ decidable expected results, test data, refusals, notes, status). Files, field order, pack
block and versioning: [references/output-rules.md](references/output-rules.md) — read both before writing; a new suite
starts from [assets/test-cases.json](assets/test-cases.json).

## 2. Checklist pass (same run)

After the scenario TCs, apply the pack checklist (`packs/<pack>/checklist.md`) to every inventory item:
1. For each item × check: **N/A** (no such element), **covered** (an existing TC already checks it — add its ID to the
   TC's notes), or **new** (append a TC; S-oracle values from the analysis, else Blocked + `Q-xxx`; H-oracle written
   as `Q-UI-/Q-API-/Q-ETL-xxx: assumed …`, P3 or lower). `X` rows are ST: list them as Moved to ST at IT.
2. Write `3-test-cases/checklist-pass.md` from [assets/checklist-pass.md](assets/checklist-pass.md): the matrix `Item | <check IDs…>` with `N/A`, `TC-…` or `new TC-…`, then
   the counts and the new `Q-*` questions.
3. A folder whose pack has no inventory items of the checklist's kind → say so; no pass.

## 3. Check and export

```bash
python3 scripts/export_testcases.py <target> --check   # 0 Error; confirm or fix each Warning
python3 scripts/slice.py tc <target> --patterns         # no placeholders, filler or ported bodies (L-T04)
python3 scripts/export_testcases.py <target>            # writes the Excel (refuses on any Error)
```

Bump `version` with every change set.

**Deliverable: not here.** The test cases reach `deliverables/test-cases/` (`it/` · `st/` with `excel.deliver_by_level`) only after `check-design`, its fixes and
the QA lead's approval: `python3 scripts/export_testcases.py <target> --deliver --approved-by "<name>"` copies the
exported Excel under the same file name, archives the version it supersedes and indexes it in `deliverables/README.md`
(it refuses without a non-Rework review whose fixes are recorded). With `project.json › excel.test_cases_template`
the export already fills the organisation's workbook (conventions §5).

Update `project/status.md` (board row) and `project/log.md`; commit `<id> test cases v<version>: <what>`.

## Pitfalls

L-T04 (ported bodies), L-T07 (invented fixtures), L-T08 (real systems at IT), L-T09 (generic set-up), L-T10 (scratchpad
generators) in [standards/template-lessons.md](../../../standards/template-lessons.md), plus the project's own in `project/lessons.md`, and:
- **Near-duplicates.** Same trigger, action and observable outcome with other wording = one TC (or one data-driven TC
  with a row per value); split only when the trigger, how it is run or the expected outcome differs.
- **Technique lost between mindmap and TC.** The scenario's boundary / partition / transition must survive into
  `test_data` and `expected_result` (min-1 is really min-1 in the field's unit).

## Done when

- [ ] Every TS has ≥ 1 TC, in scenario order; each body uses its title's values.
- [ ] Every expected result decidable; negative TCs break one constraint; refusals read back where required.
- [ ] Baseline + special preconditions only; fixtures, no real systems at IT; pack blocks complete.
- [ ] R6.3 and R10 complete; the checklist pass ran (or N/A said); its TCs cite their check IDs.
- [ ] `--check` 0 Error; `--patterns` clean; `version` bumped; Excel exported (delivery waits for review and approval).
- [ ] Report TC counts per requirement / type / priority, uncovered requirements, checklist counts (new, covered,
  Blocked, new Q), the paths; suggest `check-design`.
