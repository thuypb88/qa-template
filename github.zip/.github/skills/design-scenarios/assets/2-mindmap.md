<!-- Template: design-scenarios. Copy to <folder>/2-mindmap.md, replace every <placeholder>, delete these comments.
Prefixes, areas and layout: packs/<pack>/scenarios.md. Rules: ../references/output-rules.md. -->
# <module name as in project.json | ST: project name>: test mindmap

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

<!-- ST scoped run only: -->
> **Scope:** ST for modules <ids> · not yet designed: <ids>

<IT | ST> (`<environment>`) · pack `<pack>` · layout `<layout>` · security `<value>`. In: [1-analysis.md](1-analysis.md)
(review [1-analysis-review.md](1-analysis-review.md) <date>: <verdict; findings applied> | unreviewed).

Coverage: TCONDs <a/b> · Requirements <a/b> · ACs <a/b> · <n> scenarios. Blocked: <rows waiting on Q-xxx, or none>.

## Overview

```mermaid
flowchart LR
  subgraph L1["<phase from the analysis>"]
    F1["<level-1 item><br/>TS-001–<nnn> · <count>"]
  end
  subgraph XC["Cross-cutting"]
    X1["<Security | Localization><br/>TS-<aaa>–<bbb> · <count>"]
  end
  F1 -->|<trigger stated in analysis §4 / §6>| X1
```

### <level-1 item>

```mermaid
flowchart LR
  P1(["<start>"]) --> P2["<step>"] --> P3(["<end>"])
  TS001["[P] TS-001 <8 words or fewer>"]
  TS002["[N] TS-002 <8 words or fewer>"]
  P2 -.- TS001 & TS002
  classDef pos fill:#e6f4ea,stroke:#2e7d32,color:#1b1b1b
  classDef neg fill:#fdecea,stroke:#c62828,color:#1b1b1b
  classDef bnd fill:#e8f0fe,stroke:#1565c0,color:#1b1b1b
  classDef sec fill:#f3e5f5,stroke:#6a1b9a,color:#1b1b1b
  classDef blk fill:#fff4e5,stroke:#ef6c00,stroke-dasharray:4,color:#1b1b1b
  class TS001 pos
  class TS002 neg
```

## Scenario table

| Scenario ID | <Level-1 header of the layout> | Area | Requirement | Refs | Scenario | Type | Priority | Technique |
|---|---|---|---|---|---|---|---|---|
| TS-001 | <level-1 item> | <area> | <REQ-ID> | <TCOND-…, AC-…> | <behaviour with its observable outcome> | <values.test_types> | <values.priorities> | <technique> |

## Out of black-box scope

| Check | Requirement | Covering layer |
|---|---|---|

## Moved to ST

<!-- IT only. -->
| Item | Why | Source |
|---|---|---|

## Coverage check

| Requirement / TCOND / AC | Scenarios | Note |
|---|---|---|

<Items × areas matrix · security techniques covered · blocking Q-xxx.>

## TS mapping

<!-- Rebuild with test-cases.json present only. -->
| Old TS | New TS | Change |
|---|---|---|
