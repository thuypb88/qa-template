# design-scenarios: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing `2-mindmap.md`. Copy [../assets/2-mindmap.md](../assets/2-mindmap.md), replace every
`<placeholder>`, delete the template comments. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1, R2, R5, R7, R10 · `packs/<pack>/scenarios.md` (layout, prefixes, easy-to-miss list) ·
[test-techniques.md](../../../../standards/methods/test-techniques.md) ·
[conventions.md](../../../../standards/conventions.md) (stamp, IDs).

| Output | File | Write mode | Checked by |
|---|---|---|---|
| mindmap | `<folder>/2-mindmap.md`, title exactly `# <name>: test mindmap` (ST: one file, `test-design/st/2-mindmap.md`) | overwrite on rebuild (with a TS mapping when TCs exist); append for a few new scenarios; scoped ST run edits only its branches | `check_scenarios.py`, `check-design` scenarios |

**Sections, in order:** title · stamp · header notes (reviewed / unreviewed; ST scoped run: the **Scope** line) ·
`## Overview` (one Mermaid block) · one `### <level-1 item>` block per item in inventory order (cross-cutting last) ·
`## Scenario table` · `## Out of black-box scope` · `## Moved to ST` (IT) · `## Coverage check` · `## TS mapping`
(rebuild with TCs present only).

## Mermaid (system-design style)

Draw the diagrams the way you would draw a system design: lanes, steps and hand-offs, with each scenario attached to
the step it tests. Every block is a `flowchart LR`.

**Overview** (one block, under `## Overview`, no leaves):
- One node per level-1 item: `F<n>["<item><br/>TS-aaa–bbb · <count>"]`.
- Group the nodes into subgraph lanes for the phases the analysis describes (for example Acquire · Change · Retire ·
  Period run · Controls). ST uses its group layout. Cross-cutting items go in a last lane, `Cross-cutting`.
- Draw an edge only for a hand-off the analysis states (§4 flow, §6 integrations), labelled with its trigger. Use a
  dotted edge `-.->|"Q-xxx blocked"|` for a gated or blocked hand-off.
- The shared record that every flow acts on may be a database node, `REC[("…")]`.

```mermaid
flowchart LR
  subgraph IN["Order intake"]
    F1["POST /v1/orders<br/>TS-001–004 · 4"]
  end
  subgraph OUT["Fulfilment"]
    F2["POST /v1/shipments<br/>TS-005–009 · 5"]
  end
  subgraph XC["Cross-cutting"]
    X1["Security<br/>TS-010–014 · 5"]
  end
  F1 -->|order paid| F2
```

**Item block** (one per level-1 item, under `### <item>`):
- **Spine:** the item's process path `P1 --> P2 --> …`, one node per step, in order:
  - UI flow: the steps in analysis §4.
  - UI form: the layout's areas (Display → Field validation → Buttons → Output).
  - API: request → auth → validation → processing → response.
  - ETL: source → extract → transform → load → target.
  - SQL: call → checks → work → result.
  - ST: the systems of the chain.

  Draw start and end as stadiums `([…])`. Use a decision `{…}` only where the source states the branch. A variant or
  alternate path that runs differently gets its own spine nodes.
- **Leaves:** one per scenario. The id is the TS ID without its hyphen (`TS004`) and the label is
  `[X] TS-nnn <text>`. Attach each leaf with `P<n> -.- TSnnn` to the step whose observable outcome it checks. The
  table still sets the TS order (item, then area), so the diagram never reorders IDs.
- **Type by colour:** paste the classDefs below and give each leaf the class that matches its prefix:
  - `pos`: `[P]`, `[UI]`, `[C]`, `[L]`, `[A]`, `[E2E]`
  - `neg`: `[N]`
  - `bnd`: `[B]`
  - `sec`: `[S]`
  - `blk`: any row that waits on a `Q-xxx`; it replaces the prefix's class.
- **Large items** (more than about 15 leaves, or no single path, such as Security): split the item into one subgraph
  per aspect (for example Access matrix · Segregation of duties · Session & URL · Input & upload). Put the leaves
  inside the subgraphs; no spine is needed.

```mermaid
flowchart LR
  P1(["POST /v1/orders"]) --> P2["Auth"] --> P3["Validate body"] --> P4["Create order"] --> P5(["201 + order"])
  TS001["[N] TS-001 Missing currency rejected"]
  TS002["[B] TS-002 Amount 0.01 accepted"]
  TS003["[P] TS-003 Order returned with its ID"]
  TS004["[S] TS-004 Other buyer's cart refused"]
  P3 -.- TS001 & TS002
  P5 -.- TS003
  P2 -.- TS004
  classDef pos fill:#e6f4ea,stroke:#2e7d32,color:#1b1b1b
  classDef neg fill:#fdecea,stroke:#c62828,color:#1b1b1b
  classDef bnd fill:#e8f0fe,stroke:#1565c0,color:#1b1b1b
  classDef sec fill:#f3e5f5,stroke:#6a1b9a,color:#1b1b1b
  classDef blk fill:#fff4e5,stroke:#ef6c00,stroke-dasharray:4,color:#1b1b1b
  class TS003 pos
  class TS001 neg
  class TS002 bnd
  class TS004 sec
```

**Syntax** (the checker counts a leaf only on an indented line that starts `id["[X]`):
- Declare every node on its own indented line, before the edges.
- Spine and overview labels never start with `[`, so they are not counted as leaves.
- Keep each leaf label to 8 words or fewer, rewritten rather than cut off; prefixes come from the pack's
  `scenarios.md`.
- Never put `"` inside a label; write ‘ ’ or `#quot;`. Write `<` and `>` as `#lt;` and `#gt;`; the only tag
  allowed is `<br/>`. No backticks.

A `2-mindmap.md` still in the older `mindmap` form stays valid; convert it at its next rebuild.

## Scenario table (fixed columns; the scripts read them)

| Scenario ID | <Level-1 header of the layout> | Area | Requirement | Refs | Scenario | Type | Priority | Technique |
|---|---|---|---|---|---|---|---|---|
| TS-001 | POST /v1/orders | Request validation | FR-003 | TCOND-021, AC-02 | Order without currency is rejected with 400 and error code CURRENCY_REQUIRED | Negative | P2 - High | equivalence partitioning |

- Rows follow the mindmap, item by item, area by area; `TS-001…` in that order; leaves ↔ rows 1:1.
- **Type**: `project.json › values.test_types` + the pack's extra types. **Priority**: `values.priorities`.
- **Adding later:** next free TS IDs, each row inside its item and area (the "split into runs" warning is expected;
  merges at the next rebuild).

## Other sections

- **Out of black-box scope** · **Moved to ST** (IT) · **Coverage check** (every requirement / TCOND / AC reaches a
  scenario, or the reason; an items × areas matrix; the security techniques covered; blocking `Q-xxx`).
- **TS mapping** (rebuild with TCs present): old TS → new TS; `design-cases` must then rewrite the TCs.

## Checks before done

`python3 scripts/check_scenarios.py <target>`: fix every Error; fix or justify each Warning.
