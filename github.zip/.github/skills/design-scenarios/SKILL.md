---
name: design-scenarios
description: Design step 3 (writer, IT or ST): the test scenarios. Build the test scenario mindmap of a module (or the system) from 1-analysis.md into 2-mindmap.md - Mermaid blocks plus the scenario table, laid out by the pack layout (UI form / flow, API resource / flow, ETL table / job; ST groups smoke, E2E, UC, integrations, RBAC, errors, NFR). Use for "design the E4 scenarios", "build the mindmap", "design the system / E2E scenarios", "ST scenarios for E4" (target st E4: only the ST branches that touch the named modules), or to rebuild a mindmap in the current layout. Reviewing it → check-design.
metadata:
  group: design
  order: "3"
---

# Design: test scenarios (mindmap)

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `1-analysis.md` (+ `1-analysis-review.md`: apply its open findings; header says "unreviewed" if absent); its
inventory gives level 1. ST: also the module mindmaps' E2E branches and `test-design/st/e2e-plan.md` (`design-e2e`); `st <module ids>` (e.g. `st E4`) scopes ST to those modules (§1a). **Out:** `2-mindmap.md` (overwrite; title
exactly `# <name>: test mindmap`). **Rules:** core R1, R2, R5, R7, R10; `packs/<pack>/scenarios.md` (layout, prefixes,
easy-to-miss list). **Next:** `check-design`.
With `3-test-cases/test-cases.json` present you are **rebuilding**: write a TS mapping. For a few new scenarios,
**append** instead.
**Output:** [assets/2-mindmap.md](assets/2-mindmap.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

Read lean: one inventory item at a time (`slice.py section 1-analysis.md "<item>"`, `slice.py rows … TCOND-…`); write
its block before reading the next.

## 1. Layout

- **IT:** the pack layout of the module (`project.json › modules[].layout`): level 1 = inventory items in inventory
  order, level 2 = the layout's areas in their order; cross-cutting branches last (pack `cross_cutting_areas`).
  Never by requirement ID.
- **ST:** level 1 = groups: Smoke → E2E flows (one per `E2E-NNN` chain of `e2e-plan.md`: spine = its hops, one leaf per path; no plan yet → `design-e2e` first) → UC walkthroughs → Integrations (one per INT row) →
  RBAC → Error handling → Non-functional. Area = the group's step (e.g. `Main flow`, `Exception`) — use the areas of
  the packs involved.

## 1a. ST for named modules (`st E4`)

Target `st <module ids>` writes only the ST branches that touch those modules, into the one ST mindmap
(`test-design/st/2-mindmap.md`), never a per-module copy. It lets the system level grow module by module while the
other modules are still at IT.

- **Ground (stop if missing).** The ST analysis and `e2e-plan.md` must cover the named modules: their chains, INT
  rows, roles and every row of their Moved to ST. A hop owned by a module with no analysis yet may be `partial` with a
  `Q-ST-xxx` (as `design-e2e` marks it). Not covered → `design-system st <ids>`, then `design-e2e st <ids>`, first.
- **In scope, per group:** Smoke rows of the modules; every `E2E-NNN` chain with a hop in a named module (the whole
  chain, every path, not only that module's hops); its UC walkthroughs; INT rows naming the module or its external
  systems; RBAC rows for its roles and objects; its Error handling and Non-functional rows. Group order and layout as
  in §1.
- **Moved to ST:** read the module's IT mindmap › Moved to ST and analysis §11. Each row lands in a scenario or in
  another plan (`design-nfr`), named in the Coverage check. None dropped.
- **No IT repeats** (R9): field checks, screen layout and single-module rules stay in the module's IT suite. An ST
  scenario checks what only the joined system shows: the key carried across a hop, the amount equal at the receiving
  surface, a refusal with no effect downstream.
- **Writing:** no ST mindmap yet → write it with these branches only. It exists → append or replace only these
  branches. Other modules' rows and their TS IDs stay as they are, and new rows take the next free TS IDs. A chain
  shared with an already-designed module is one item: add only its missing paths, never a second copy.
- **Scope line** under the title: `> **Scope:** ST for modules E4 · not yet designed: E5, E6, …`. Update it on every
  scoped run. The overview draws only the designed items, and a chain's hops into an undesigned module use a dotted
  edge `-.->|"Q-ST-xxx partial"|`.
- **Coverage check** per named module: chains and paths → TS, INT / RBAC rows → TS, Moved to ST rows → TS or plan,
  plus the `partial` hops and their questions.
- **Check:** `python3 scripts/check_scenarios.py st`; `check-design st scenarios` reviews the whole file.

## 2. Scenario rules

1. **One level-1 item × one behaviour** per scenario. Not "mandatory checks per form", not "all endpoints".
2. **Observable at the surface** (R2); invisible checks → **Out of black-box scope**.
3. **Every AC** maps to a scenario (R1); cite client-document layouts / wording.
4. **Security** per the module's `security` value and the pack's techniques.
5. **Level fit** (R9): IT moved-to-ST items go in that table; ST does not repeat IT field checks.
6. **R10** once per variant: valid + invalid each. **R6.3** one Localization scenario per language per input.
7. **Open questions** in the text (`Q-xxx`).
8. **Priority by risk:** P1 / P2 money, state, security, data loss, hand-offs; P3 / P4 cosmetic.
9. Walk the pack's **easy-to-miss** list per level-1 item by hand (L-T13).
10. **Apply the technique, don't just name it** ([standards/methods/test-techniques.md](../../../standards/methods/test-techniques.md)): pick it from
    the rule's shape (field → partitions + boundaries; condition combinations → decision table; status / lifecycle →
    state transition; many factors → pairwise; writes / dependencies → failure paths), do its steps, and put what it
    found (a gap, an overlap, an unreachable state) in §9 of the analysis via a `Q-xxx`.
11. **A refusal scenario names the absence of a side effect** where the source says nothing may change (no record,
    no state change, no partial load), not only the message.
12. **No duplicates:** two scenarios with the same trigger, action and observable outcome are one; split only when
    the trigger, the way it is run or the expected outcome differs.

## 3. Output

Mermaid style (overview, item blocks, classDefs, syntax the checker counts), the fixed scenario table, the other
sections and the check: copy [assets/2-mindmap.md](assets/2-mindmap.md) and follow
[references/output-rules.md](references/output-rules.md) — read it before writing. Then
`python3 scripts/check_scenarios.py <target>`: fix every Error; fix or justify each Warning.

## Pitfalls

L-T03, L-T10, L-T13 ([standards/template-lessons.md](../../../standards/template-lessons.md)), plus:
- **A per-module ST mindmap** (`st-E4/2-mindmap.md`) or a scoped run that drops another module's rows. ST is one
  file; a scoped run edits only its own branches.
- **By-requirement tree** in a form / resource / table module = Rework.
- **Renumbering with TCs present.** Append, except a full rebuild with a TS mapping.
- **Citing an ID the analysis lacks.** Write "TCOND pending"; raise it upstream.
- **Integer boundaries on everything.** Amounts, decimals, byte-limited text and date-times have their own step
  (techniques §3).
- **Only the happy transition.** Each state needs its refused events too (techniques §5).
- **Cut-off leaf labels** ("GR posts Dr Fixed Asset / Cr"). Rewrite the label to 8 words or fewer; never truncate.
- **A quote inside a label** breaks the block, and the script cannot see that. Use ‘ ’ or `#quot;`.
- **Invented edges.** An overview edge or a spine step the analysis does not state is invention; cite it, or leave
  it out.

## Done when

- [ ] Layout per pack; cross-cutting last; leaves ↔ rows 1:1; TS in order.
- [ ] Every block is a `flowchart LR` per §3: overview lanes and hand-offs from the analysis; each leaf id = its TS ID,
      attached to a spine step and classed by type; no `"` inside a label.
- [ ] Easy-to-miss list walked per item; R10 and R6.3 complete; every Technique value applied per its section.
- [ ] Out of scope, Moved to ST, Coverage check (+ TS mapping) present; script 0 Error.
- [ ] Scoped ST (`st E4`): Scope line current; every chain touching the module, its INT / RBAC rows and every Moved
      to ST row placed; other modules' rows and TS IDs untouched; no IT field check repeated.
- [ ] Report counts per item / type / priority, uncovered items; suggest `check-design`.
