---
name: design-system
description: Design ST step 1 (writer, system level, every pack): the system analysis. Analyze the whole system, or only the slice that touches named modules (st E4), from the module analyses' neighbours, integrations and Moved-to-ST items, the test plan's system level, the strategy, the system map and the cross-module parts of the sources, and write test-design/st/1-analysis.md - modules and external systems in a context diagram, a cross-module process map, cross-module requirements and ACs, the ST inventory (smoke, candidate chains, UC walkthroughs, INT rows, RBAC, errors, NFR), swimlane flows across modules, the data thread, INT rows with the real systems, an RBAC / SoD matrix, ST TCONDs, Q-ST questions, a Moved-to-ST ledger (none dropped), environment and data per wave - plus test-design/st/0-scope.md. Use for "analyze the system", "ST analysis", "system test analysis", "analysis st", "ST analysis for E4", "phân tích kiểm thử hệ thống". One module → design-analysis; chains → design-e2e.
metadata:
  group: design
  order: "ST"
---

# Design: system analysis (ST)

> **Created:** 2026-10-26 16:19:01 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** target `st` (whole system) or `st <module ids>` (the slice that touches them). The test plan's system level
and `plans/test-strategy.md` (risk order, environments, entry / exit); every module analysis, read by rows: §1
neighbours, §6 integrations, §9 open questions on hand-offs, §11 Moved to ST; each module's mindmap › Moved to ST;
`project/system-map.md`; `project.json` (`levels.ST`, `modules[].depends_on`, `external_systems`, `variant_sets`,
`languages`); the cross-module and integration sections of the sources (figures included). **Out:**
`test-design/st/1-analysis.md` (overwrite or scoped update; title exactly `# <project name>: system analysis`) and
the hand-written `test-design/st/0-scope.md`. **Rules:** core R1, R2, R6.3, R9, R10; the `rules.md` and
`analysis.md` of every pack in use; [requirement-quality.md](../../../standards/methods/requirement-quality.md);
[analysis-diagrams.md](../../../standards/methods/analysis-diagrams.md); project rules. **Next:** `check-design st
analysis` (`SR-` findings), then `design-e2e`.
**Stop if** `project.json` has no ST level → `plan-setup`; (`st <ids>`) a named module has no reviewed IT analysis →
that module's `design-analysis` and `check-design` first (its §11 seeds the slice).
**Output:** [assets/0-scope.md](assets/0-scope.md) · [assets/1-analysis.md](assets/1-analysis.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

Read lean: never a whole module analysis. `slice.py rows <analysis> <neighbour ids> Moved INT Q-INIT` and
`slice.py section <analysis> "11"`; open a source only at the hand-off lines. Read `project/lessons.md` and the L-T
rows for `design-analysis`.

## Steps

1. **Scope.** The test plan's system level (what ST covers, environments, entry / exit), the strategy's risk order,
   `levels.ST` (environment name, real externals). Module status table: module · IT analysis (reviewed / draft /
   none) · Moved to ST rows · in this run (yes / no). It gives the Scope line. Compare `project.json › modules` with
   the plan's scope: a module or flow the plan does not cover yet (added after it, a scope gate still open) gets its
   hand-offs analysed and its own behaviour **held** — kept in §11 › Held, not dropped, not turned into scenarios —
   with the plan follow-up that releases it, named in the Scope line.
2. **Hand-off harvest.** One row per hand-off a source states: `from → to | trigger | business object + key | what
   the receiving side shows | source (both sides)`. A module with no analysis: read its source at the hand-off line,
   mark the row `partial` with a `Q-ST-xxx`. The two sides differ → one `Q-ST-xxx` citing both (L-T02).
3. **Moved-to-ST ledger.** Every row of every module in scope, with its module ID, lands in a group (Smoke, chain,
   UC walkthrough, INT, RBAC, Error handling, NFR) or is dropped with a reason and a `Q-ST-xxx`. None silently.
4. **Cross-module requirements.** The rules that only the joined system can show: one document feeding another,
   sub-ledger = ledger, period close across modules, shared master data, approvals that cross modules, migrated
   data. Atomic `BR-ST-n` with their source; ACs that span modules.
5. **External systems.** Per `external_systems` entry: direction, trigger, data, the ST counterpart (real, sandbox or
   still mocked = a gap), owner, availability (`Q-INIT-xxx`), what our surface shows when it succeeds and fails.
6. **Roles.** Roles from the sources and module analyses × business objects / actions across modules; segregation of
   duties where a source states it. Unknown access = a question, never a guessed cell.
7. **Write** the sections ([assets/1-analysis.md](assets/1-analysis.md)), then `0-scope.md` (scope boundary, module status table, Scope line, entry
   criteria, first questions). Update `project/questions.md` with the new `Q-ST` and a line in `project/log.md`.

## Required sections

The eleven sections of the analysis at system level, plus `0-scope.md`: copy
[assets/1-analysis.md](assets/1-analysis.md) and [assets/0-scope.md](assets/0-scope.md) and follow
[references/output-rules.md](references/output-rules.md) — read it before writing.

## ST for named modules (`st E4`)

- **Writes** only the parts that touch the named modules: their neighbours in §1, cross-module requirements, flows,
  INT rows, roles, TCONDs, questions and every row of their Moved to ST.
- **Others untouched:** content and IDs from earlier runs stay; new `BR-ST` / TCOND / `Q-ST` / `INT` IDs take the
  next free number; a flow shared with an already-analysed module is extended, never copied.
- **Scope line** under the title and in `0-scope.md`, updated every run: `> **Scope:** ST for modules E4 · not yet
  analysed: E5, E6, …`. Completeness is judged against it.

## Rules

- **No invention.** Every hand-off, value and role cell cites a source; unstated → §9. A hand-off nobody states is
  not drawn.
- **System level only (R9).** Field rules, screen layout and single-module logic stay in the module analyses.
- **Real systems at ST (R9).** A mock kept at ST is a gap with a `Q-ST-xxx`.
- **Blocked, not asserted.** A TCOND whose expected result hangs on an open conflict (L-T11) or on a custom
  development the source says is not built is marked **Blocked (Q-…)**, with no expected result. If a surface that
  exists today shows part of it, add a TCOND for that surface.
- **IDs on rewrite.** Keep live IDs; mark removed ones *retired*; never reuse.
- **Downstream.** If `e2e-plan.md`, the ST mindmap or TCs exist, say in the header they need re-checking.

## Pitfalls

L-T01, L-T02, L-T07, L-T16 in [standards/template-lessons.md](../../../standards/template-lessons.md), plus:
- **Module analyses pasted together.** ST analyses the joins; a single-module rule is cited, not copied.
- **A Moved-to-ST row dropped** because no chain fits: it goes to another group or gets a question.
- **One side of a hand-off.** AP says it sends, GL says it receives something else: that is the question.
- **Chains by module order** in §3 instead of by business outcome.
- **Scope ahead of the plan.** A module added by a decision the test plan has not caught up with: its own behaviour
  analysed as in scope (a High review finding). Analyse the hand-offs; hold the rest until the plan is updated.
- **A question asked, then answered in the TCOND.** §9 says the result is unknown, §8 asserts "is blocked": mark
  the TCOND Blocked.
- **Citations at the wrong line.** Parsed tables put separators and blank lines next to the row; check each cited
  line (and each range's first line) shows the row it claims before writing the link references.

## Done when

- [ ] Eleven sections; exact title; context diagram + process map; a swimlane per cross-module flow.
- [ ] Every hand-off cited on both sides or `partial` + `Q-ST`; every Moved-to-ST row placed or questioned.
- [ ] INT rows per external system with their ST counterpart; RBAC matrix cited; data thread cited.
- [ ] Held items and Blocked TCONDs listed in §11 with their question or plan follow-up; none asserted in §8.
- [ ] `0-scope.md` with the module status table and the Scope line; `project/questions.md` + `log.md` updated.
- [ ] Report counts (hand-offs, partial, BR-ST rules, ACs, ST items per group, INT rows, TCONDs by type, moved rows
  placed, questions); suggest `check-design st analysis`, then `design-e2e`.
