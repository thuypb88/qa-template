<!-- Template: design-system ST scope. Copy to test-design/st/0-scope.md, replace every <placeholder>, delete this
comment. Rules: ../references/output-rules.md. -->
# <project name>: ST scope

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

> **Scope:** ST for modules <ids> · not yet analysed: <ids | none> <· held items and what releases them>

Hand-written by `design-system` (no generated part). Detail: [1-analysis.md](1-analysis.md).

| Field | Value |
|---|---|
| Level | ST — environment `<as in project.json>`, external systems <real \| …> |
| Pack / layout | <pack / layout per module> |
| Modules | <ids> |
| External systems | <systems> |
| Basis | <sources, test plan §, strategy §> |

## Scope boundary

<In / out, cited.>

## Module status

| Module | IT analysis | Moved to ST rows | In this run |
|---|---|---|---|
| <id> | <reviewed \| draft \| none> | <n> | <yes \| no> |

## Entry criteria

- <per module: IT reviewed / run, from the strategy>

## Questions to raise first

- Q-ST-<xxx>: <question> — blocks <…>
