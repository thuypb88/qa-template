<!-- Template: design-system. Copy to test-design/st/1-analysis.md, replace every <placeholder>, delete these comments.
Rules: ../references/output-rules.md. -->
# <project name>: system analysis

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

> **Scope:** ST for modules <ids> · not yet analysed: <ids | none>

## 0. Citation keys

| Key | File |
|---|---|
| <KEY> | [<document>](<relative path>) |

**Precedence:** <project.json › sources.precedence>.

## 1. Overview

**Purpose of ST:** <…> · **Actors:** <…> · **Modules in / out:** <…> · **External systems in / out:** <…> ·
**Assumptions:** <Q-ST-xxx: assumed …>

### System study diagram

```mermaid
flowchart LR
    %% context: actors, every module in scope, external systems, each stated hand-off labelled with its trigger
```

```mermaid
flowchart LR
    %% process map along the business objects' lives across modules
```

## 2. Requirement breakdown

### 2.1 Hand-off harvest

| From → to | Trigger | Business object + key | What the receiving side shows | Source (both sides) | Status |
|---|---|---|---|---|---|
| <module → module> | <…> | <document + key> | <…> | [KEY:line] · [KEY:line] | <full \| partial (Q-ST-xxx)> |

### 2.2 Cross-module business rules

| Rule | Rule text | Modules | Source |
|---|---|---|---|
| BR-ST-1 | <one trigger, one outcome> | <ids> | [KEY:line] |

### 2.3 Acceptance criteria that span modules

| AC ID | Criterion | Source | Requirements |
|---|---|---|---|

## 3. Inventory: ST items

| Group | Item | Modules / systems | Source |
|---|---|---|---|
| <Smoke \| Chain \| UC walkthrough \| INT \| RBAC \| Error handling \| Non-functional> | <item> | <ids> | [KEY:line] |

## 4. Functional flow

### F1. <flow name> (<chain ref>)

| Step | Module / system | What happens | Surface where it shows | Source |
|---|---|---|---|---|

```mermaid
flowchart LR
    %% swimlane: one lane per module or external system, redrawn from <figure> [KEY:line]
```

**Diagram vs text:** <same | the difference, named>

## 5. Data

### 5.1 Data thread

| Value | Born at | Must equal at | Source |
|---|---|---|---|

### 5.2 Shared master data and owner

| Master data | Owner module | Used by | Source |
|---|---|---|---|

### 5.3 Cross-module states

| Object | State in module A | Effect in module B | Source |
|---|---|---|---|

### 5.4 Migrated data

| Data | What is verified | Source |
|---|---|---|

## 6. Integrations

| INT | System | Direction | Trigger | Data | ST counterpart | Observable in | Q |
|---|---|---|---|---|---|---|---|
| INT-1 | <system> | <in \| out> | <…> | <…> | <real \| sandbox \| still mocked (gap)> | <surface> | <Q or —> |

## 7. Non-functional

<Volumes, response times, security, accessibility, compatibility as the sources state them (cited); handed to
design-nfr. A vague target is an `untestable` question.>

## 8. Testable conditions

| ID | Condition | Requirement | Type | <ST item> | Observable in |
|---|---|---|---|---|---|
| TCOND-001 | <condition> | <BR-ST / AC / Moved-to-ST row> | <e2e \| integration \| reconciliation \| security \| performance \| localization> | <item> | <module surface> |

### Out of black-box scope

| Check | Requirement | Covering layer |
|---|---|---|

## 9. Gaps, conflicts & open questions

| ID | Kind | Topic | Evidence A | Evidence B | Proposed assumption | Owner | Blocks |
|---|---|---|---|---|---|---|---|
| Q-ST-001 | <kind> | <topic> | [KEY:line] | <…> | <value> | <owner> | <IDs> |

## 10. Traceability

| Requirement / AC / Moved-to-ST row | BR rules | TCONDs | Q refs |
|---|---|---|---|

## 11. Level scope

<Candidate chains · INT rows · RBAC / SoD matrix · smoke set · NFR hand-off · Moved-to-ST ledger (every row, its
group or its drop reason) · environment (as in project.json) and data per wave · order between waves · entry
criteria per module · **Held** items and what releases them · **Blocked** TCONDs with their question.>
