# design-system: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing the system analysis and the ST scope. Copy [../assets/1-analysis.md](../assets/1-analysis.md) and
[../assets/0-scope.md](../assets/0-scope.md), replace every `<placeholder>`, delete the template comments. Linked,
never copied: [core-rules.md](../../../../standards/core-rules.md) R1, R2, R9, R10 ·
[analysis-diagrams.md](../../../../standards/methods/analysis-diagrams.md) ·
[requirement-quality.md](../../../../standards/methods/requirement-quality.md) ·
[conventions.md](../../../../standards/conventions.md) (stamp, IDs, formats).

| Output | File | Write mode | Checked by |
|---|---|---|---|
| system analysis | `test-design/st/1-analysis.md`, title exactly `# <project name>: system analysis` | overwrite; a scoped run (`st <ids>`) edits only the parts touching those modules, IDs kept | `check-design st analysis` |
| ST scope | `test-design/st/0-scope.md`, title `# <project name>: ST scope` | overwrite | — |
| questions | `project/questions.md` (new `Q-ST`) · `project/log.md` (one line) | append | — |

## Required sections of `1-analysis.md` (the eleven of the analysis, at system level)

1. **Overview.** Purpose of ST, actors, modules and external systems in / out, assumptions, then `### System study
   diagram`: a context diagram (actors, every module in scope, external systems, each stated hand-off labelled with
   its trigger) and a process map along the business objects' lives across modules (analysis-diagrams §2).
2. **Requirement breakdown.** Cross-module requirements with their `BR-ST-n` rules, then **Acceptance criteria**
   that span modules. A single-module rule stays in its module analysis (cite it, don't copy it).
3. **Inventory: ST items** `Group | Item | Modules / systems | Source`, in the ST group order: Smoke → candidate
   chains (business outcome, refined into `E2E-NNN` by `design-e2e`) → UC walkthroughs → INT rows → RBAC → Error
   handling → Non-functional. These names become the ST mindmap level 1.
4. **Functional flow.** Each cross-module flow, step by step with the surface where each step shows; a swimlane
   diagram per flow with one lane per module or external system, redrawn from the source figure, with its **Diagram
   vs text** line.
5. **Data.** The data thread (`Value | Born at | Must equal at | Source`): amounts, quantities, tax, cost centre,
   document keys; shared master data and who owns it; cross-module states; migrated data and what is verified.
6. **Integrations.** INT rows `INT-n | System | Direction | Trigger | Data | ST counterpart | Observable in | Q`.
7. **Non-functional.** Volumes, response times, security, accessibility, compatibility as the sources state them
   (cited), handed to `design-nfr`; a vague target is an `untestable` question.
8. **Testable conditions** `| ID | Condition | Requirement | Type | <ST item> | Observable in |` (first four columns
   fixed). Types: e2e / integration / reconciliation / security / performance / localization. **Observable in**
   names the module surface where it shows. No repeated IT field checks (R9); internal-only → **Out of black-box
   scope**.
9. **Gaps, conflicts & open questions** (`Q-ST-001…`, columns as in `design-analysis`), ordered by what they block;
   module questions that block a hand-off are cited with their IDs.
10. **Traceability** `Requirement / AC / Moved-to-ST row | BR rules | TCONDs | Q refs`.
11. **Level scope.** Candidate chains, INT rows, the RBAC matrix, the smoke set, NFR hand-off, the Moved-to-ST ledger,
    environment (named as in `project.json`) and data per wave, the order between waves, entry criteria per module
    (IT reviewed / run); **Held** items (scope ahead of the plan) with what releases them, and **Blocked** TCONDs
    with their question and what still runs meanwhile.

Before §1: `## 0. Citation keys` (`Key | File`) and the source-precedence note; after §11: `## Revision log`.

## Required sections of `0-scope.md`

Title · stamp · the **Scope** line (`> **Scope:** ST for modules <ids> · not yet analysed: <ids>`) ·
`## Scope boundary` · `## Module status` (`Module | IT analysis | Moved to ST rows | In this run`) ·
`## Entry criteria` (from the strategy, per module) · `## Questions to raise first`.

## Rules

- **IDs** `BR-ST-n`, `TCOND-NNN` (ST folder numbering), `Q-ST-001…`, `INT-n`: next free number on every run;
  never renumbered or reused; removed ones marked *retired*.
- **Cite, don't copy** a single-module rule: link the module analysis row.
- **Scope line** under the title of both files, updated every run; completeness is judged against it.
- **Moved-to-ST ledger:** every row of every module in scope lands in a group or is dropped with a reason and a
  `Q-ST-xxx`; none silently.
- Environments named exactly as `project.json`.
