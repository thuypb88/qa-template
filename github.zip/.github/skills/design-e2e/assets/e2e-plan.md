<!-- Template: design-e2e. Copy to test-design/st/e2e-plan.md, replace every <placeholder>, delete these comments.
Rules: ../references/output-rules.md. -->
# <project name>: end-to-end plan

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

<!-- Scoped run (st <ids>) only: -->
> **Scope:** E2E chains touching <ids> · not yet designed: <ids>

**Sources:** <ST analysis (Updated <stamp>), module analyses, system map, test plan v<x>> · **Open questions:** <n>

## 0. Citation keys

| Key | File |
|---|---|
| <KEY> | [<document>](<relative path>) |

## 1. Hand-off graph

```mermaid
flowchart LR
    %% one node per module / external system; every edge a stated hand-off, labelled with its trigger and cited
```

## 2. Chain catalogue

| E2E | Chain | Business outcome | Modules / systems | Priority | Smoke | Moved items covered | Q |
|---|---|---|---|---|---|---|---|
| E2E-001 | <chain name> | <outcome the business sees> | <ids, systems> | <P1–P4> | <Yes \| No> | <Moved-to-ST rows> | <Q-ST-… or —> |

## E2E-001 · <chain name>

<Business object, its life, the risk this chain covers.>

### Hops

| Hop | From → To | Trigger (actor, action) | Object + key | Checkpoint (surface) | Source | Q |
|---|---|---|---|---|---|---|
| H1 | <module → module> | <role, action> | <document + key> | <screen / report / response where it shows> | [KEY:line] | <Q or —> |

### Data thread

| Value | Born at | Must equal at | Source |
|---|---|---|---|
| <amount, quantity, tax, key> | <hop> | <hops> | [KEY:line] |

### Paths

| Path | Area | What happens | Must not happen | Technique | Q |
|---|---|---|---|---|---|
| <happy \| rejection \| re-submission \| reversal \| cut-off \| variant \| hand-over> | <ST area> | <…> | <side effect that must be absent> | <technique> | <Q or —> |

## 3. Environment and data

| Chain | Environment (as in project.json) | Data / accounts | Wave | Source |
|---|---|---|---|---|

## 4. Moved items → chain / group

| Moved-to-ST row | From | Chain / ST group | Note |
|---|---|---|---|

## 5. Out of black-box scope

| Check | Why | Covering layer |
|---|---|---|

## 6. Open questions

- Q-ST-<xxx> (<chains / hops>): <question> — assumed <value>
