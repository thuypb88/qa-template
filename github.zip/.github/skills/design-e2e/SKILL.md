---
name: design-e2e
description: Design ST (writer, system level, every pack): the end-to-end chains. Find the business chains that cross modules and external systems from the module analyses' hand-offs and Moved-to-ST items, the system analysis, the system map and the test plan, and write test-design/st/e2e-plan.md - one E2E-NNN chain per business outcome along the business object's life, its hops (trigger, document key, checkpoint at the receiving surface), the data thread that must stay equal end to end, the paths worth testing (happy, each rejection with no downstream effect, re-submission, reversal, period / cut-off timing, variants pairwise, role hand-overs), environment and data per chain, risk order and a smoke subset - then hand the E2E group to design-scenarios st. Use for "design the E2E scenarios", "end-to-end flows across modules", "which business chains do we test in ST", "E2E chains for E4 only" (st E4), "kịch bản E2E", "kiểm thử end-to-end". One module's flows → design-scenarios; non-functional → design-nfr.
metadata:
  group: design
  order: "ST"
---

# Design: end-to-end chains (ST)

> **Created:** 2026-10-26 15:37:44 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `test-design/st/1-analysis.md` (E2E chains, INT rows, RBAC matrix, moved items); every module analysis
(`slice.py rows` on its §1 neighbours, §6 integrations, §11 Moved to ST); `project/system-map.md`; the test plan's
system level and `plans/test-strategy.md` (risk order); `project.json` (`modules[].depends_on`, `external_systems`,
`variants`, `levels`). Target `st` (every chain) or `st <module ids>` (only the chains that touch them, see "ST for
named modules"). **Out:** `test-design/st/e2e-plan.md` (`E2E-NNN` chains); then the E2E group of
`test-design/st/2-mindmap.md` (`design-scenarios st`) and its TCs (`design-cases st`). **Rules:** core R1, R2, R9,
R10; [test-techniques.md](../../../standards/methods/test-techniques.md) §5 (long flows), §6 (pairwise); project rules.
**Next:** `design-scenarios st` (E2E group), then `check-design st scenarios`.
**Stop if** `test-design/st/1-analysis.md` is missing or older than a module analysis it draws on →
`design-system st` first; with `st <ids>`, also when its Scope line does not list the named modules →
`design-system st <ids>` first. A module in a chain with no analysis yet: draw the chain from its source, mark the hop
`partial` with a `Q-ST-xxx`, never from memory.
**Output:** [assets/e2e-plan.md](assets/e2e-plan.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

Read lean: `slice.py rows` on the hand-off and Moved-to-ST lines; never a whole analysis.

## Steps

1. **Hand-off graph.** One edge per hand-off a source states: `from → to | trigger | business object + key | what
   the receiving side shows | source`. Read both sides of every edge; the two sides describe it differently → one
   `Q-ST-xxx` citing both (L-T02).
2. **Chains.** Follow the business object's life, not the module order: one chain = one business outcome the client
   cares about, from its trigger to its last observable result (a report figure, a balance, a closed period, a
   document in the external system). Seed them from the cross-module acceptance criteria, the test plan's E2E list
   and every module's Moved to ST. Each moved item lands in a chain or in another ST group (INT, RBAC, NFR) — none
   dropped; list where.
3. **Hops** per chain (table below): the actor and action that triggers it, the document key the next document
   quotes, and a **checkpoint at the receiving surface** (record exists, key carried, amount, status, posting). A
   hop with nothing visible is checked by its effect at the next surface; internal-only → Out of black-box scope.
4. **Data thread:** the values that must stay equal along the chain (amount, quantity, tax, cost centre, the keys)
   and the final reconciliation the sources state (sub-ledger = ledger, sent = received). This is the oracle; each
   value cited, unknown → `Q-ST-xxx: assumed …`.
5. **Paths** (techniques §5.6, one per path the business cares about):
   - happy path;
   - each rejection at a hop (refused approval, failed check, validation), with what must **not** happen downstream
     (no document, no posting, no message);
   - re-submission after a rejection;
   - reversal or cancellation mid-chain and its compensating effect on the documents already made;
   - timing: period end, lock / cut-off date, a hop that crosses a period;
   - variants (R10): the chain's factors pairwise (techniques §6), each value at least once;
   - role hand-overs: a different person per step where the RBAC matrix / SoD says so.
6. **Environment and data** per chain: the ST environment named as in `project.json`, real or sandbox external
   systems (R9), the data the chain needs and creates, the order between chains (one's output is another's input),
   reset. A step another team performs is written as a request; its effect is checked at our surface.
7. **Risk order and smoke:** priority from the strategy (money, tax / legal, cross-system, data loss); one short
   happy path per critical chain is the smoke subset.
8. **Write** `e2e-plan.md`, then run `design-scenarios st` for the E2E group: level 1 = one chain, areas Main ·
   Rejection · Re-submission · Reversal · Timing · Variant · Roles, spine = the hops, one leaf per path.

## ST for named modules (`st E4`)

- **Chains:** every chain with a hop in a named module, whole, every hop and path, including hops in modules not yet
  analysed (marked `partial` with the `Q-ST-xxx` of the ST analysis). Seed from the named modules' Moved to ST; each
  row lands in a chain or another ST group.
- **Others untouched:** earlier chains and their `E2E-NNN` stay; new chains take the next free number; a chain that
  already exists gets only its missing hops and paths.
- **Scope line** under the title, as in the ST analysis: `> **Scope:** chains for modules E4 · not yet designed: E5,
  E6, …`. The chain catalogue's *Moved items covered* lists the named modules' rows.
- **Next:** `design-scenarios st <ids>`.

## Output

Copy [assets/e2e-plan.md](assets/e2e-plan.md); sections, fixed columns and ID rules per
[references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- **No invention:** every hop, checkpoint and thread value cites a source; a hand-off no source states is not drawn.
- **Observable at each hop (R2)**, not only at the end: a failure must show at the hop where it happened.
- **No repeated IT checks (R9):** field rules stay in the module suites; cite their TCs where a chain relies on them.
- **IDs stable:** `E2E-NNN`, never renumbered or reused; a dropped chain is marked *retired* with the reason.
- **ST uses the real systems (R9);** a mock in a chain is a gap with a `Q-ST-xxx`, never silently kept.

## Pitfalls

L-T02 (neighbour conflicts), L-T07 (invented fixtures), L-T16 (literal test-plan wording) in
[standards/template-lessons.md](../../../standards/template-lessons.md), plus:
- **Chains by module order** ("AP then GL") instead of by business object and outcome.
- **Happy path only:** rejections, reversals and period boundaries are where cross-module defects live.
- **One checkpoint at the end:** the defect cannot be located, and a compensating error hides the first one.
- **Key not traced:** each document must show the number of the one before it; without it a hop is not proven.

## Done when

- [ ] Scoped (`st E4`): Scope line current; every chain touching the named modules complete; earlier chains and
  IDs untouched.
- [ ] Hand-off graph cited both sides; every module's Moved to ST item placed (chain or group) or questioned.
- [ ] Every chain has hops with surface checkpoints, a data thread and the paths of step 5 that its sources allow.
- [ ] Environment, data and order per chain; risk order and smoke subset; open `Q-ST-xxx` in `project/questions.md`.
- [ ] `project/status.md` + `log.md`; report chains, hops, paths by area, moved items placed, questions; suggest
  `design-scenarios st`.
