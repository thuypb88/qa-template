# design-e2e: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing the E2E plan. Copy [../assets/e2e-plan.md](../assets/e2e-plan.md), replace every
`<placeholder>`, delete the template comments. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1, R2, R9, R10 · [test-techniques.md](../../../../standards/methods/test-techniques.md) ·
[conventions.md](../../../../standards/conventions.md) (stamp, IDs).

| Output | File | Write mode |
|---|---|---|
| E2E plan | `test-design/st/e2e-plan.md`, title `# <project>: end-to-end plan` | overwrite; a scoped run (`st <ids>`) edits only the chains touching those modules |
| ST scenarios | `test-design/st/2-mindmap.md` E2E group | by `design-scenarios st`, not here |

## Rules

- **Sections**, in order: header (sources, versions, open-question count; scoped: the **Scope** line) ·
  `## 0. Citation keys` · `## 1. Hand-off graph` (Mermaid `flowchart LR`, every edge cited) ·
  `## 2. Chain catalogue` · one `## E2E-NNN · <chain>` per chain with `### Hops`, `### Data thread`,
  `### Paths` · `## 3. Environment and data` · `## 4. Moved items → chain / group` ·
  `## 5. Out of black-box scope` · `## 6. Open questions`; `## Revision log` on later versions.
- **Columns** fixed as in the template: catalogue `E2E | Chain | Business outcome | Modules / systems | Priority |
  Smoke | Moved items covered | Q`; hops `Hop | From → To | Trigger (actor, action) | Object + key | Checkpoint
  (surface) | Source | Q`; data thread `Value | Born at | Must equal at | Source`; paths `Path | Area | What
  happens | Must not happen | Technique | Q`.
- **IDs** `E2E-NNN`, never renumbered or reused; a dropped chain is marked *retired* with the reason. A chain shared
  with an already-designed module is one item: add only its missing paths.
- **No invention:** every hop, checkpoint and thread value cites a source; a hand-off no source states is not drawn.
  A hop into a module with no analysis yet is `partial` with a `Q-ST-xxx`.
- **Observable at each hop (R2);** no repeated IT checks (R9: cite the module TCs a chain relies on).
- **ST uses the real systems (R9):** a mock in a chain is a gap with a `Q-ST-xxx`.
- Every Moved-to-ST row of the modules in scope lands in a chain or a named ST group (§4); none dropped.
