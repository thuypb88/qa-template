# sql-verify: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing verifications. Bodies come from the dialect template in
[packs/sql/dialects.md](../../../../packs/sql/dialects.md) § Verification (SQL Server, Oracle, PostgreSQL, MySQL /
MariaDB, script form); deploy / drop from [../assets/deploy.sql](../assets/deploy.sql) and
[../assets/drop.sql](../assets/drop.sql). Linked, never copied: [packs/sql/rules.md](../../../../packs/sql/rules.md)
R-SQL4, R-SQL5 · [packs/sql/tc-fields.md](../../../../packs/sql/tc-fields.md) › Verification contract ·
[automation/README.md](../../../../automation/README.md).

| Output | File | Write mode |
|---|---|---|
| verification | `automation/sql/verify/<name>.<dialect>.sql` (proc `qa.verify_<object>`, or script form) | one per object / flow group |
| deploy / drop | `automation/sql/verify/deploy-<MOD>.<dialect>.sql`, `drop-<MOD>.<dialect>.sql` | overwrite |
| runner | `automation/sql/test_<id>_sql.py` = a copy of `test_example_sql.py` with `MODULE` set | once per module |
| TC links | `sql.verify` (`proc` / `script`) and `verify_ref` in `test-cases.json` | edit; bump `version` |
| log | `project/log.md` | one line (run result, or "unexecuted") |

## Rules

- **Contract:** each verification returns rows `(tc_id, result, detail)`, `result` PASS / FAIL, **exactly one row per
  TC**, also when the call raises an unexpected error (FAIL with the error text); a missing row is NO RESULT.
- **Each TC block:** comment `-- TC-… · <title>`; act = the TC's `call` exactly; assert the TC's `expect` as
  literals (never a value the object or a copy of its logic computed); errors: the CATCH / EXCEPTION path is PASS
  when number and message match; writes and refusals read back; undo its changes; `detail` shows actual vs expected.
- **Independent:** blocks don't depend on each other's order and can run alone.
- **Scope:** nothing outside schema `qa` is created or altered; deploy only to the test database of the level;
  credentials only from the environment.
