-- Template: sql-verify deploy script. Copy to automation/sql/verify/deploy-<MOD>.<dialect>.sql; replace every
-- <placeholder> and delete these two template lines. Rules: ../references/output-rules.md.
-- Deploy verifications of <MOD> · Dialect: <dialect> · Test database of the level only. Creates nothing outside schema qa.
-- 1. Schema qa, if missing (dialect form: packs/sql/dialects.md › Quick reference).
<create schema qa if it does not exist>;
-- 2. Helper types (Oracle only): the row type and table type of the contract (tc_id, result, detail).
-- 3. One verification per object, body from the dialect template in packs/sql/dialects.md › Verification:
--    per TC block: -- TC-… · <title> · act (the TC's call exactly) · assert the TC's expect literals · undo · one row.
<create or replace qa.verify_<object> …>;
