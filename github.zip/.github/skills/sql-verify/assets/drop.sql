-- Template: sql-verify drop script. Copy to automation/sql/verify/drop-<MOD>.<dialect>.sql; replace every <placeholder>
-- and delete these two template lines. Rules: ../references/output-rules.md.
-- Drop verifications of <MOD> · Dialect: <dialect> · Removes everything deploy-<MOD> created, nothing else.
<drop qa.verify_<object>>;
-- <drop helper types (Oracle)>;
