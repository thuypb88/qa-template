<!-- Template: run-select. Copy to plans/regression/<YYYY-MM-DD>-<slug>.md, replace every <placeholder>, delete this
comment. Rules: ../references/output-rules.md. -->
# Regression set: <slug>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Build:** <version / commit under test> · **Baseline:** <build compared with> · **Date:** <YYYY-MM-DD> · **Trigger:**
<release notes / fix list / change-impact record / defect fixes>

## Changes

| # | Change | Kind (feature · fix · configuration · data · interface) | Source | Modules | IDs |
|---|---|---|---|---|---|

## Selection

| Folder | TC | Layer | Reason | Auto / Manual | P |
|---|---|---|---|---|---|
| <test-design/…> | <TC-…> | <Smoke \| Direct \| Defect retest \| Neighbours \| Risk> | <smoke \| direct:<ID> \| retest:DEF-… \| neighbour:<module> \| risk> | <Auto \| Manual> | <P1–P4> |

## Exclusions and residual risk

| Excluded | Why | Residual risk |
|---|---|---|

## Commands

```bash
python3 scripts/run_tests.py <folder> --grep "<TC_E4_003 or TC_E4_017 (pytest) | TC-E4-003|TC-E4-017 (Playwright)>"
```

## Manual list

| Folder | TC | P | Tester |
|---|---|---|---|

## Counts

| Folder | Selected / suite | Auto | Manual |
|---|---|---|---|
