# run-select: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing the record. Copy [../assets/regression.md](../assets/regression.md), replace every
`<placeholder>`, delete the template comment. Linked, never copied: [conventions.md](../../../../standards/conventions.md)
(stamp, §3 IDs).

| Output | File | Write mode |
|---|---|---|
| regression record | `plans/regression/<YYYY-MM-DD>-<slug>.md` | new dated file per set |
| log | `project/log.md` | one line |

## Rules

- **Sections**, in order: header (build, baseline, date, trigger) · `## Changes` · `## Selection` ·
  `## Exclusions and residual risk` · `## Commands` · `## Manual list` · `## Counts`.
- **Every selected TC** has a reason code: `smoke` · `direct:<ID>` · `retest:DEF-…` · `neighbour:<module>` ·
  `risk`; never selected by name alone. A change with no traceable link is **unknown** and widened to the item's
  P1 / P2 TCs, with the reason.
- **Order:** Auto first (smoke → direct → retests → neighbours → risk), manual after; P1 before P3.
- **Commands** runnable as written: pytest packs `--grep` with a `-k` expression with underscores
  (`"TC_E4_003 or TC_E4_017"`), Playwright a regex (`"TC-E4-003|TC-E4-017"`); a whole folder needs no `--grep`.
- The set is a plan; results come only from `run-tests`.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
