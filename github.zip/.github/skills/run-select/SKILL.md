---
name: run-select
description: Run E0: select the regression set (a new build, a fix, a change record, a release candidate; IT or ST). Choose the smallest regression set that still protects what the change can break - TCs whose rules, data or expected results the change touches, the neighbours' hand-off TCs (project.json depends_on), retests of fixed defects and their surroundings, the smoke set, and P1 journeys for a release - each with its reason, plus the deliberate exclusions and the residual risk; write plans/regression/<date>-<slug>.md with the exact run_tests.py commands and the manual list. Use for "what should we rerun", "regression for build 1.4.2", "select regression tests", "smoke + regression for the hotfix", "minimal regression". Not for: tracing what changed in the sources → plan-changes; running the set → run-tests. This skill is the only owner of regression sets.
metadata:
  group: run
  order: "E0"
---

# Run: select the regression set

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** what changed — release notes / fix list from the user, `project/change-impact/` records (their *Affected TCs*
section), `project/defects.md` (fixed → retest); the suites (`slice.py tc <target> --list`, `--priority P1`), the
automation plans, `project.json › modules[].depends_on`. **Out:** `plans/regression/<YYYY-MM-DD>-<slug>.md`; a line in
`project/log.md`. **Next:** `run-tests` with the commands from the record.
**Output:** [assets/regression.md](assets/regression.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **Pin the build:** version / commit under test and the baseline it is compared with. Results from another build
   don't count.
2. **List the changes** (feature, fix, configuration, data, interface) with their source; map each to modules and
   requirement / rule IDs (`slice.py rows <analysis> <IDs>`, `grep -rn` in the suites).
3. **Select, in layers** — each TC with its reason:

   | Layer | Take | Reason code |
   |---|---|---|
   | Smoke | the smoke set (ST smoke group; IT: one P1 TC per level-1 item) | `smoke` |
   | Direct | TCs citing a changed rule / field / endpoint / table, or whose data or expected result the change touches | `direct:<ID>` |
   | Defect retest | the TC that found each fixed defect, plus its twins (same item and area) | `retest:DEF-…` |
   | Neighbours | hand-off / E2E TCs of `depends_on` modules on both sides of a changed interface | `neighbour:<module>` |
   | Risk | P1 journeys for a release; areas with recent defects | `risk` |

   A change with no traceable link → **unknown**, not "no impact": widen to the item's P1 / P2 TCs and say why.
4. **Exclude on purpose:** list what is left out and why (untouched module, cosmetic, covered elsewhere); this is the
   residual risk the report will carry.
5. **Cost and order:** Auto first (smoke → direct → retests → neighbours → risk), manual after, P1 before P3; flag
   long or environment-heavy TCs.
6. **Write the commands** per folder: pytest packs take a `-k` expression with underscores
   (`run_tests.py E4 --grep "TC_E4_003 or TC_E4_017"`), Playwright a regex (`--grep "TC-E4-003|TC-E4-017"`); a whole
   folder needs no `--grep`. The manual part as a TC list for the testers.

## Output

Copy [assets/regression.md](assets/regression.md); sections, reason codes and command forms per
[references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- Never select by name alone; every TC has a reason code that traces to a change, a defect, smoke or risk.
- A removed or weakened TC: check its obligation is still covered by another selected TC.
- The set is a plan; results come only from `run-tests`.

## Done when

- [ ] Build pinned; every change mapped (or marked unknown and widened); every selected TC has a reason.
- [ ] Exclusions written; commands runnable as written; report counts and suggest `run-tests`.
