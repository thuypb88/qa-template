# Skills catalog

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-11-06 09:28:00 (UTC+7)

Thirty-nine skills in **eight groups by objective** plus the **domain group `sql-`**. Each name is `<group>-<objective>`, so the groups stay together in
every skill picker (Claude Code `/`, Codex, Copilot, Gemini CLI), which all sort by name and only find `skills/<name>/SKILL.md`, one
level deep. The level comes from the target (a module id → IT, `st` → ST); the pack from `project.json`. This README is
the catalog, not a skill. Each skill folder: `SKILL.md`, `references/` (incl. `output-rules.md`) and `assets/` (the
templates of what it writes), checked by `python3 scripts/check_skills.py` (the guard runs it on every changed
skill). Design rules: [standards/skill-architecture.md](../../standards/skill-architecture.md); the v1.4 → v1.5 rename map:
`template-manifest.json › renamed_skills`. After changing a skill, run
`python3 scripts/workspace/sync_agents.py` (Codex copy in `.agents/skills/`, Copilot copy in `.github/skills/`, Gemini copy in `.gemini/skills/`).

**Not sure which skill?** `/flow-next` names one, with its reason.

```mermaid
flowchart LR
    FN{{flow-next}} -.routes.-> plan & req & design & check & auto & run & learn
    FC[[flow-cadence: day · sprint · release]] -.gates.-> run
    FR[[flow-roadmap: start · update · health]] -.phases.-> plan & design & auto & run & learn
    subgraph plan[plan- · what to test]
        PS[setup] --> PT[strategy] --> PP[testplan] --> PC[changes] --> PSc[scope]
    end
    subgraph req[req- · is it testable]
        RE[elicit] --> RR[review]
        RW[write]
    end
    subgraph design[design- · what exactly]
        DA[analysis] --> DS[scenarios] --> DC[cases] --> DD[data]
        DY[system] --> DE[e2e] --> DS
        DN[nfr]
    end
    subgraph check[check- · is our work right]
        CD[design]
        CA[automation]
        CS[skill]
        CT[testplan]
    end
    subgraph auto[auto- · automate]
        AD[decide] --> AG[design] --> AW[write]
    end
    subgraph run[run- · does the build work]
        RS[select] --> RT[tests] --> RD[defects] --> RP[report]
        RX[explore]
    end
    subgraph learn[learn- · learn and share]
        LR[retro]
        LE[explain]
        LG[glossary]
    end
    plan --> req --> design --> auto --> run --> learn
    DA & DY & DS & DC -. reviewed by .-> CD
    DD -. data plan .-> AG
    AG & AW -. reviewed by .-> CA
    CD -. gates .-> AW
```

## flow- · Where are we, and what next?

Orchestrators: they name the next skill and keep the gates; they never do the work. A project may add its own skills as `.claude/skills/project-<name>/` (never synced to the template), e.g. a
monitor or a source-update router; they are listed in the project's README, not here.

| Skill | Objective | Writes |
|---|---|---|
| `flow-next` | the one next skill for a folder or a plain request (router) | chat |
| `flow-cadence` | pace a **day** (start gate, queue, EOD), a **sprint** (six stages, DoD) or a **release** (freeze, RC, go / no-go, after go-live) | chat · `plans/sprints/` · `plans/releases/` |
| `flow-roadmap` | the QA lead's roadmap for the whole engagement: **start** (join, phases P0–P8, maturity L1–L4), **update** (gates, trend, milestone history from git), **health** (risks, gaps) | `plans/roadmap.md` |

## plan- · What do we test, how, and is our basis current?

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| -1 | `plan-setup` | set up a project from the template, once | `project.json`, `project/` (rules, memory), folders | `qa_config.py --validate`, `init_project.py` |
| -1 | `plan-strategy` | write or review the test strategy (project, sprint or release section) | `plans/test-strategy.md` | — |
| -1 | `plan-testplan` | the formal test plan with its estimation (three-point, per activity and module) and schedule (phases, milestones, burn-up) | `plans/test-plan.md`, `plans/estimation.json` → `plans/test-estimate.md` (+ .xlsx) | `test_estimate.py --check` |
| 0 | `plan-changes` | what changed in `sources/`, what it touches (affected TCs) | `project/change-impact/…`, baseline | `trace_changes.py` |
| 0b | `plan-scope` | one module's scope boundary and readiness, after its discovery (0a `req-elicit`) | `0-scope.md` MANUAL block | `init_project.py` |

## req- · Is the requirement good enough to test?

QA's side of the requirements. Proposals stay **Proposed** until the BA / client confirms them and the user puts the
confirmed text in `sources/` (then `plan-changes` → `design-analysis`).

| Skill | Objective | Writes |
|---|---|---|
| `req-elicit` | ask why before anything is written: layers, known / unknown, 3–5 questions per turn; **step 0a** of a module (discovery, before `plan-scope`); a later version (new or changed sources) is a new dated file that `Supersedes` the earlier one | `plans/discovery/…` (`Targets` row) |
| `req-review` | findings and questions on a written document (SRS, stories, use cases, API spec, mapping) | `plans/requirement-reviews/…`, `project/questions.md` |
| `req-write` | draft or fix requirement text — form **story** (INVEST, Given-When-Then) or **use-case** (13 fields, 20-point check, test seeds) | `plans/stories/…`, `plans/use-cases/…` (Proposed) |

## design- · What exactly do we test, with which data?

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| 1 | `design-analysis` | analysis of a module (IT) | `1-analysis.md` | — |
| ST | `design-system` | system analysis: hand-offs, cross-module rules, INT, RBAC, Moved-to-ST ledger, Held / Blocked items (whole or `st <ids>`) | `test-design/st/1-analysis.md`, `0-scope.md` | — |
| 3 | `design-scenarios` | test scenarios (mindmap + table) | `2-mindmap.md` | `check_scenarios.py` |
| 5 | `design-cases` | test cases, pack checklist pass, Excel | `test-cases.json`, `checklist-pass.md`, Excel | `export_testcases.py --check` |
| 5+ | `design-data` | data plan, sets and fixtures | `3-test-cases/test-data.md`, `automation/<pack>/fixtures/` | — |
| ST | `design-e2e` | end-to-end chains across modules: hops, checkpoints, data thread, paths (input of the ST E2E group) | `test-design/st/e2e-plan.md` | `check_scenarios.py st` |
| ST | `design-nfr` | performance, security, accessibility, compatibility plan | `test-design/st/nfr-plan.md` | `check_scenarios.py st` |

## check- · Is our own work right?

Independent reviewers: findings with evidence and fixes; the writer applies them (writer ≠ reviewer).

| Order | Skill | Reviews | Writes | Check |
|---|---|---|---|---|
| 2 · 4 · 6 | `check-design` | analysis, scenarios, test cases | `*-review.md` | the step's script, `check_review.py` |
| A4 | `check-automation` | design mode: the codebase design before tests are written · tests mode: would each test fail on a wrong build? | `automation/docs/reviews/<date>-<pack>-design.md` · `3-test-cases/automation-review.md` | `run_tests.py --plan` |
| -1 | `check-testplan` | a test plan (ours or anyone's) before it is issued: shape, sources, criteria, estimate and schedule | `plans/test-plan-reviews/<date>-<slug>-v<version>.md` | `check_testplan.py`, `test_estimate.py --check` |
| — | `check-skill` | a skill as a contract; its behaviour evals; new skills | the skill (on OK), sync | `check_skills.py`, `template-dev/tests/selftest.py` |

## auto- · What do we automate, and build it

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| A1 | `auto-decide` | what and how to automate, per TC | `automation` fields, `automation-plan.md` | `export_testcases.py --check` |
| A2 | `auto-design` | design the automation codebase (layout, layers, shared components, locators, data builders, hook clients, CI) before detailed code | `automation/docs/<pack>-design.md` | `check-automation` design mode |
| A3 | `auto-write` | write the tests for a spec or wave, as the design says; only once the test case review is current and the design reviewed | `automation/<pack>/…` | `run_tests.py --plan` |

## run- · Does the build work, and what do we tell people?

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| E0 | `run-select` | the regression set for a build / fix / release (sole owner) | `plans/regression/…` | — |
| E | `run-tests` | run, triage, record cycles and manual results | `runs/`, cycle results | `run_tests.py`, `record_manual.py` |
| E | `run-explore` | exploratory charters, sessions, debriefs | `<folder>/exploratory/ET-NNN-…` | — |
| E | `run-defects` | report, register, retest, close defects | `project/defects.md` | — |
| E+ | `run-report` | test summary / exit report | `test-reports/…` | — |

## learn- · What did we learn, and can others follow it?

| Skill | Objective | Writes |
|---|---|---|
| `learn-retro` | lessons, decisions, lasting fixes | `project/` |
| `learn-explain` | explain an artifact or a point to a named audience (client, PM, BA, dev, new tester, ELI5) | chat |
| `learn-glossary` | the project glossary from the sources: terms, role codes, ID schemes, conflicts, undefined terms, domain notes (external — verify); modes build · refresh · check | `project/system-map.md` › Glossary |

## sql- · Database code: understand it, test it, verify it (domain group)

For stored procedures, functions, views, triggers, jobs and queries — engine-neutral, with SQL Server / Oracle /
PostgreSQL / MySQL notes in [packs/sql/dialects.md](../../packs/sql/dialects.md). A module with `"pack": "sql"` runs the
normal chain with `sql-cases` at step 5 and `sql-verify` at A2; study, explain and debug work on any SQL, in any
project. Why a domain group: [skill-architecture.md §3a](../../standards/skill-architecture.md).

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| 1- | `sql-study` | study database code: one card per object (interface, data touched, rules with `file:line`, errors, transactions, risks) | `<folder>/sql-study/` | — |
| — | `sql-explain` | explain a query, procedure, plan or DB error to a named audience | chat | — |
| E | `sql-debug` | reproduce, shrink, test hypotheses, root cause; defect or script fix | `<folder>/sql-debug/` | — |
| 5+ | `sql-data` | idempotent data + cleanup scripts per data set | `3-test-cases/sql/data/` | run twice + cleanup |
| 5 | `sql-cases` | test cases with the `sql` block, SQL checklist pass | `test-cases.json`, `checklist-pass.md`, Excel | `export_testcases.py --check` |
| A3 | `sql-verify` | verification procedures / scripts returning `tc_id, result, detail` | `automation/sql/verify/`, `test_<id>_sql.py` | `run_tests.py <id> --pack sql` |

```mermaid
flowchart LR
    SS[sql-study] --> DA[design-analysis] --> DS[design-scenarios] --> SC[sql-cases] --> SD[sql-data]
    SC --> AD[auto-decide] --> SV[sql-verify] --> RT[run-tests]
    RT -. failure .-> DB[sql-debug]
    SX[sql-explain]
```

## Order across levels

`flow-roadmap start` (joining a project) → `plan-setup` (+ `plan-strategy` when the client has no usable plan; `req-elicit` for a vague request) →
(`design-system` → `check-design st analysis`, when the test plan has a system level) → each module in
`project.json` order through steps 0a–6 (discovery `req-elicit` → `plan-scope`, then 1–6; `req-review` first for a raw document) → `design-system` again (picks up
every "Moved to ST"; or module by module, `design-system st <id>` → `design-e2e st <id>` → `design-scenarios st <id>`
as each module's IT design is reviewed) → `design-e2e` → the rest of the ST chain (+ `design-nfr`) → `auto-decide` → (`design-data` when the data plan is missing or stale) →
`auto-design` (→ `check-automation` design mode) → `auto-write` (→ `check-automation` tests mode)
→ `run-select` → `run-tests` / `run-explore` / `run-defects` → `run-report` → `learn-retro`.

## Shared methods (read on demand, never copied into a skill)

| File | What | Read by |
|---|---|---|
| [requirement-quality.md](../../standards/methods/requirement-quality.md) | atomic rules, gap kinds, ambiguity, conflicts, testability, closable questions, layers, stories, use cases | `req-*`, `design-analysis`, `plan-strategy` |
| [test-techniques.md](../../standards/methods/test-techniques.md) | EP, BVA, decision table, state transition, pairwise, failure paths, edge dimensions, use-case flows | `design-scenarios`, `design-e2e`, `design-data`, `plan-strategy` |
| [analysis-diagrams.md](../../standards/methods/analysis-diagrams.md) | system study diagram, flow diagrams redrawn from source workflow figures, `extract_text.py --figures`, Mermaid hygiene | `design-analysis`, `check-design` |
| [design-diagrams.md](../../standards/methods/design-diagrams.md) | layer diagram, run-phase flow, builder chains, spec map (automation design); set dependency and run order, pairwise factors (data plan); agreement with the tables | `auto-design`, `design-data`, `check-automation` |
| [defect-report.md](../../standards/methods/defect-report.md) | defect report, flaky tests, run summary conclusion | `run-tests`, `run-defects`, `run-report` |

A skill's own `references/` hold only its own output rules (`output-rules.md`, in every skill) and its own modes and
checklists (e.g. `check-design/references/`, `flow-cadence/references/`, `req-write/references/`,
`check-automation/references/`).

## Rules for skills

- **Add a skill** only when its input, primary output and triggers are bounded apart from every other skill;
  otherwise add a mode (a `references/<mode>.md`), a pack file (`packs/<pack>/…`) or a shared method.
- **Write one:** copy [SKILL_TEMPLATE.md](SKILL_TEMPLATE.md), pick the group, then `check-skill` it and add
  `template-dev/tests/skill-evals/<name>.json`.
- **List it in the same change set:** its row in the group table above, the count at the top, the diagram and the
  order line when it joins the chain (a `project-<name>` skill goes in the project's `README.md` instead);
  `check_skills.py` warns on a skill listed in neither ([CLAUDE.md](../../CLAUDE.md) › Adding a skill).
- `python3 template-dev/tests/selftest.py` checks: name = folder = `<group>-<objective>` (groups incl. `sql`); `metadata.group` = the prefix and an
  `order`; description ≤ 1024 chars; a `## Done when` list; every relative link (skills and `standards/methods/`);
  no link into another skill's `references/`; no retired v1.4 name anywhere; the eval files' shape.
- `python3 scripts/check_skills.py [<skill>]` checks the output contract: the `**Output:**` line, `assets/` templates and
  `references/output-rules.md` in step (0 Error to commit).

**Sources studied:** awesome-qa-skills (PolyForm Noncommercial; v1.2–1.3, and the grouping by objective in v1.5),
BA Zone's user-story / use-case / product-discovery skills by Phúc NT and the ELI5 skill (MIT; v1.4). Ideas were
rewritten for this pipeline; no text was copied.
