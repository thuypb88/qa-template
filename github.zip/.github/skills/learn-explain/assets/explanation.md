<!-- Template: learn-explain (chat; a file only when the user asks, e.g. plans/onboarding-<topic>.md). Replace every
<placeholder>; delete this comment. Rules: ../references/output-rules.md. -->
**For:** <audience> · **About:** <the thing explained> · **From:** <project files read>

**What:** <one sentence with the essence.>

**Like:** <one analogy from the audience's world — skip for developers.>

**Details:**
- <only the layers this audience needs; numbers, IDs, dates from the files>

**So what:** <impact for them · the decision needed and its deadline · the next step and who takes it>
