# learn-explain: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Fill [../assets/explanation.md](../assets/explanation.md). Linked, never copied:
[conventions.md](../../../../standards/conventions.md) §1–2 (where a file goes), §8 (language).

| Output | Where | Write mode |
|---|---|---|
| explanation | chat | per request |
| file (only when asked) | `plans/onboarding-<topic>.md` (the only extra file allowed at the top of `plans/`) | new or edit; stamp |

## Rules

- **Shape** always what → analogy → details → so what; the audience is named at the top.
- **Facts** only from project files read in this turn; uncertain or unverified facts stay marked (a defect "not
  reproduced yet", a run "not executed").
- Never hide a failure or a risk to make the message nicer; never talk down.
- **Language** `project.json › project.document_language` unless the user asks for another.
