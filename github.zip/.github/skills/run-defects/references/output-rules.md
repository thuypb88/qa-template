# run-defects: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing a report or a register row. Linked, never copied:
[defect-report.md](../../../../standards/methods/defect-report.md) §1 (the report form — the source of
[../assets/defect-report.md](../assets/defect-report.md)), §2 · [core-rules.md](../../../../standards/core-rules.md) R2, R9 ·
[conventions.md](../../../../standards/conventions.md) §3 (IDs), §10 (dates).

| Output | Template | File | Write mode |
|---|---|---|---|
| defect report | [defect-report.md](../assets/defect-report.md) | chat, and `runs/<key>/defects.md` for a run | one per root symptom, listing every TC it fails |
| register | [register-row.md](../assets/register-row.md) | `project/defects.md` | insert newest first; update status in place with the date; closed rows stay |
| TC link | — | `defect_id` on the TCs (`record_manual.py`, or a JSON edit with a `version` bump + export) | only once the tracker ID is known |
| log | — | `project/log.md` | one line |

## Rules

- **Title** says the symptom at the surface, never the cause; a suspected cause goes to Notes, marked as a guess.
- **Expected** quotes the TC's expected result with its source; **Actual** the exact text / status / values.
- **Severity** Critical / Major / Minor / Trivial by impact (user, data, money, legal); priority P1–P4 by how soon.
  Both proposed; the tracker owner decides.
- **IDs** `DEF-NNN`, next free number, never reused; the tracker ID goes in **Tracker** when the user gives one.
- **Status** changes are dated and come from the tracker or the user; never "Closed" without a retest on a named
  build (`Passed n of n`).
- Never edit an expected result to make a defect disappear; a wrong TC goes to the writer.
