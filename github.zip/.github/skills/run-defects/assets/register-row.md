<!-- Template: run-defects register row. Insert at the top of the table in project/defects.md (newest first; closed rows
stay). Replace every <placeholder>, delete this comment. Rules: ../references/output-rules.md. -->
| DEF-<NNN> | <tracker ID or —> | <symptom title> | <Critical \| Major \| Minor \| Trivial> | <P1–P4> | <New \| Open \| Fixed \| Retest \| Closed \| Reopened \| Rejected \| Duplicate \| Deferred> | <test-design/…> | <TC-…> | <build, YYYY-MM-DD> | <build or —> | <build, YYYY-MM-DD, Passed n of n \| Failed> | <notes; who decided a Rejected / Deferred> |
