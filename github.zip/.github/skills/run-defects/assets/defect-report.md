<!-- Template: run-defects, one product defect. Same form as standards/methods/defect-report.md §1 (keep them identical;
the method is the source). Goes into runs/<key>/defects.md and the chat. Replace every <placeholder>, delete this
comment. Rules: ../references/output-rules.md. -->
### <TC ID> — <what is wrong, at the surface, in one line>

| Field | Value |
|---|---|
| Environment · build | <env name exactly as project.json> · <build / version / commit, or "unknown"> |
| Found by | <TC ID> (<automated run <date> / manual>) · cycle <name or —> |
| Preconditions | <the TC's baseline + specials, with the fixture names> |
| Steps | 1. … (the TC's steps, with the data actually used) |
| Expected | <the TC's expected result, with its source citation / requirement ID> |
| Actual | <what happened, exact text / status / values> |
| Reproducible | <n of m runs> (rerun with `run_tests.py <target> --grep <TC ID>`) |
| Impact | <who / what is affected; blocks which TCs or flows> |
| Severity · priority (proposed) | <Critical / Major / Minor / Trivial> · <P1–P4>, with one line why |
| Evidence | <paths under runs/: screenshot, trace, response body, query output> |
| Notes | <open questions, suspected area — marked as a guess, never as the cause> |
