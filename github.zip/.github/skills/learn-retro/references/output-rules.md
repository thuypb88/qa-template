# learn-retro: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing to `project/`. Row shapes: [../assets/retro-rows.md](../assets/retro-rows.md). Linked, never
copied: [conventions.md](../../../../standards/conventions.md) §3 (IDs) ·
[template-lessons.md](../../../../standards/template-lessons.md) (L-T rows) · `project/decisions/ADR-000-template.md`.

| Output | File | Write mode |
|---|---|---|
| lessons | `project/lessons.md` | new `L-NNN` row, or Seen + 1 with the new evidence; never deleted (superseded instead) |
| decisions | `project/decisions/ADR-NNN-<slug>.md` from `ADR-000-template.md` | new file per decision |
| project rule | `project/rules.md` › `## PR-n. <title>` | append, next free n |
| questions | `project/questions.md` | append |
| follow-ups, board | `project/status.md` (§2 → §3 when done) | edit |
| now | `project/index.md` › Now (3–6 lines; file under 5 KB) | rewrite that block |
| log | `project/log.md` | one line |
| lasting fix | the skill's Pitfalls, a script check, a `PR-n`, or a **Promote to template** row | only on the user's OK |

## Rules

- **Lesson row** `L-NNN | Where | Lesson | Evidence | Seen | Action`: the lesson is the mistake and the way to avoid
  it, one sentence each; evidence cites a finding ID, a run, or the user's words with the date.
- Lessons are about how the work goes wrong; system facts go to `project/system-map.md`, open points to
  `project/questions.md`.
- **Cause, not symptom:** each High finding / Rework / escaped defect gets trigger, root cause, contributing factors
  and escape point; an unproven cause is marked as a guess.
- **Action** values: `→ skill <name>` · `→ rule PR-n` · `→ script` · `promote` · `superseded by L-NNN`.
- Personal agent memory keeps a pointer only, never the lesson.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
