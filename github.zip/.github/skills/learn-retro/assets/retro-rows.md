<!-- Template: learn-retro. Rows to add to project/ memory files, then the chat report. Replace every <placeholder>; delete
these comments. Each file's own table header wins. Rules: ../references/output-rules.md. -->

<!-- project/lessons.md: a new lesson (a known one: Seen + 1 and the new evidence appended) -->
| L-<NNN> | <skill / artifact> | **<the mistake, one sentence.>** <the way to avoid it, one sentence.> | <folder, artifact, finding ID, YYYY-MM-DD> | 1 | <→ skill <name> \| → rule PR-n \| → script \| promote \| superseded by L-NNN> |

<!-- project/decisions/ADR-NNN-<slug>.md: copy project/decisions/ADR-000-template.md -->

<!-- project/log.md -->
| <YYYY-MM-DD> | project | Retro: <n> lessons (<new> new, <seen> seen again), <m> ADRs, <k> lasting fixes proposed | <commit or file> |

<!-- Chat report -->
**Retro <YYYY-MM-DD>** · since <last retro date>

| Finding / event | Trigger | Root cause | Escape point | Lesson | Lasting fix (proposed) |
|---|---|---|---|---|---|
| <ID, run, correction> | <what showed it> | <the step that produced it> | <earliest skill / check / script that should have caught it> | <L-NNN> | <fix, or —> |

**Apply the lasting fixes?** <list, awaiting your OK>
