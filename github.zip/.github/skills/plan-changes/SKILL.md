---
name: plan-changes
description: Plan: change control - what changed in the sources and what it touches (step 0, both levels). Find what changed in sources/ since the accepted baseline with scripts/trace_changes.py, re-extract the changed documents, compare old and new content, trace each change to requirements, modules, citations and test cases (the affected TCs), decide per level folder (none / refresh scope / patch / re-run from a step), and write project/change-impact/<date>-<slug>.md. Use for "trace the requirement changes", "what changed in sources", "the client sent a new SRS / API spec / mapping / test plan", "impact analysis", or after a file under sources/ is added or replaced. One module's scope → plan-scope.
metadata:
  group: plan
  order: "0"
---

# Plan: trace source changes

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** `sources/` vs `sources/trace/source-baseline.json`; the level folders. **Out:**
`project/change-impact/<YYYY-MM-DD>-<slug>.md`; a `project/log.md` line; follow-ups in `project/status.md`; then the
accepted baseline. **Rules:** core R1. **Next:** the skills the decision table names, in chain order.
**Output:** [assets/change-impact.md](assets/change-impact.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. `python3 scripts/trace_changes.py` → the changed / added / removed files and who reads them.
2. **Old vs new content.** `python3 scripts/extract_text.py <changed files>` (and the pack parsers for API specs /
   mappings). Get the old text from git: `git show HEAD:sources/parsed/<file>.md > <scratchpad>/old.md`, then
   `diff -u` old vs new. For a workbook, compare per sheet. Read the diff, not the whole document. The
   re-extraction also rewrites the document's flow charts (`sources/parsed/<file>.figures/`, embedded as
   `![Fig <n> …]` links in the text, so a moved figure shows in the text diff too): diff its `INDEX.md`
   the same way (a figure added, removed or moved to another heading) and open a changed image (`git status` lists
   it) next to its old one (`git show HEAD:<path> > <scratchpad>/old.png`) - a flow chart can change with no text
   change.
3. **Classify each change:** new / changed / removed requirement, rule, field, value, message, endpoint, status
   code, mapping rule, environment, schedule; or editorial only (no test impact).
4. **Trace each one** (`slice.py rows <analysis> <IDs>`; `grep -rn "<old value>" test-design`):
   requirement / AC IDs → TCONDs → scenarios → TCs; and the citations that point at moved lines. Follow
   `project.json › modules[].depends_on` both ways: a changed hand-off reaches the neighbour's TCs too. A link you
   can't trace is **unknown**, not "no impact" — list it under Questions.
   - **Removed or weakened** requirement / rule: its TCs are retired, but check that whatever *else* they protected
     (a shared field rule, a hand-off) is still covered by another TC; if not, say which.
5. **Decide per folder:**

   | Decision | When | Run |
   |---|---|---|
   | none | editorial, or nothing cites it | — |
   | refresh scope | sources list / refs changed | `plan-scope` |
   | patch | a few values / TCs, structure unchanged | the writer of the earliest affected step, in patch mode |
   | re-run from step N | new / removed behaviour, a new form / endpoint / table | `design-analysis` / `design-scenarios` / `design-cases` from N |

6. **Write the record** from [assets/change-impact.md](assets/change-impact.md) per
   [references/output-rules.md](references/output-rules.md).
   **Affected TCs:** the TCs whose expected results or data the change touches and the neighbours' hand-off TCs,
   each with its reason. This is the input of `run-select`, which owns the regression set (smoke, retests,
   exclusions, commands); do not build the set here.
7. **Follow-ups** in `project/status.md` §2 (`FU-NNN`, Run with = the skill), a line in `project/log.md`.
8. **Ask the user** before accepting: `python3 scripts/trace_changes.py --accept --note "<record path>"`. Commit
   `change impact <slug>`.

## Rules

- Impact only: the regression set is `run-select`'s output, built from this record once the writers have patched
  the TCs.

- Never edit `sources/` or downstream artifacts here; the decision table drives the writers.
- A changed value used by a TC is never "none", even if the requirement ID is the same.
- Accept the baseline only after the record exists (otherwise the change is lost from view).


## Done when

- [ ] Every changed file classified; every change traced to IDs (or marked unknown with a question).
- [ ] Decision per folder with the skill to run; affected TCs listed for `run-select`; follow-ups `FU-NNN` recorded.
- [ ] Baseline accepted only after the record exists and the user agreed.

## Pitfalls

- **Moved lines.** An inserted paragraph shifts every later line number: citations to `[KEY:line]` break silently.
  List the folders whose citations need a refresh (patch).
- **A pre-filled or edited template** looks like a document change; check what actually changed (ALPHA Q-CI-001).
