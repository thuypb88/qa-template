<!-- Template: plan-changes. Copy to project/change-impact/<YYYY-MM-DD>-<slug>.md, replace every <placeholder>, delete
this comment. Rules: ../references/output-rules.md. -->
# Change impact: <slug>

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

**Files:** <path (added / changed / removed)> · **Baseline:** <date of the accepted baseline> → <on acceptance of this record>

## Changes

| # | File · location | Old | New | Kind | IDs affected |
|---|---|---|---|---|---|
| 1 | <file · §, line or figure> | <old text / value> | <new text / value> | <new / changed / removed requirement, rule, field, value, message, endpoint, status code, mapping rule, environment, schedule \| editorial> | <REQ / AC / TCOND IDs \| unknown> |

## Decision per folder

| Folder | Decision | Items affected (TCOND / TS / TC) | Run | FU |
|---|---|---|---|---|
| <test-design/…> | <none \| refresh scope \| patch \| re-run from step N> | <IDs> | <skill> | <FU-NNN> |

## Affected TCs

| Folder | TCs | Why (changed rule / value / neighbour hand-off) |
|---|---|---|

## Questions

- Q-<xxx> (<folder>): <question>
