# plan-changes: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing the record. Copy [../assets/change-impact.md](../assets/change-impact.md), replace every
`<placeholder>`, delete the template comment. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md)
R1 · [conventions.md](../../../../standards/conventions.md) (stamp, §3 IDs, §10 formats).

| Output | File | Write mode |
|---|---|---|
| impact record | `project/change-impact/<YYYY-MM-DD>-<slug>.md`, title `# Change impact: <slug>` | new file per change set |
| follow-ups | `project/status.md` §2 (`FU-NNN`, Run with = the skill) | append |
| log | `project/log.md` | append one line |
| baseline | `sources/trace/source-baseline.json` via `trace_changes.py --accept --note "<record path>"` | only after the record exists and the user agreed |

## Rules

- **Sections**, in order: header (Files, Baseline) · `## Changes` · `## Decision per folder` · `## Affected TCs` ·
  `## Questions`.
- **Changes:** one row per change, classified; every row traced to IDs or marked **unknown** with a question. A
  changed value used by a TC is never "none".
- **Decision** one of: none · refresh scope (`plan-scope`) · patch (the writer of the earliest affected step) ·
  re-run from step N; each with its skill and a `FU-NNN`.
- **Affected TCs** with their reason, including the neighbours' hand-off TCs; the regression set itself is
  `run-select`'s output, never built here.
- Moved lines: list the folders whose `[KEY:line]` citations need a refresh (patch).
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
