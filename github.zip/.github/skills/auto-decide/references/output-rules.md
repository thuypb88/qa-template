# auto-decide: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 15:36:15 (UTC+7)

Read before writing. Copy the templates in [../assets/](../assets/), replace every `<placeholder>`, delete the
template comments. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md) R2, R9 ·
[conventions.md](../../../../standards/conventions.md) §1 (`automation/` is project-owned), §4 (fields).

| Output | Template | File | Write mode |
|---|---|---|---|
| TC fields | — | `<folder>/3-test-cases/test-cases.json`: `automation`, `automation_note`, `automation_readiness` only | edit; bump `version` (minor); re-export the Excel |
| plan | [automation-plan.md](../assets/automation-plan.md) | `<folder>/3-test-cases/automation-plan.md` | overwrite |
| feasibility | [automation-feasibility.md](../assets/automation-feasibility.md) | `automation/docs/automation-feasibility.md` (created on the first run) | replace this folder's rows in the three Folders tables, the Totals and the Summary; hooks numbered once per project |

## Rules

- **TC fields:** `automation` only `Auto` / `Manual` / `Auto + Manual`; `automation_note` strings identical
  across TCs that share a reason (the plan groups on them). Never change TC content here: wrong content → *Raise to
  the writer*.
- **Plan sections**, in order: header (TC version, review state, level, pack, runner, data and feasibility links) ·
  `## Counts` · `## Specs` · `## Waves` · `## Blockers` · `## Changes to the tags` ·
  `## Raise to the writer (\`design-cases\`)` · `## Manual residue`.
- **Spec table** columns fixed: `Spec | Pack | TCs | Data-driven | Fixtures / hooks | Readiness | Wave`. Spec paths
  per pack: UI `automation/ui/tests/<id>/<item>.spec.ts`; API `automation/api/test_<id>_<item>.py`; ETL
  `automation/etl/test_<id>_<table>.py`; SQL `automation/sql/verify/verify_<object>.<dialect>.sql`.
- **Readiness** values: Ready · Blocked by hook · Blocked (data) · Rewrite (R2) · Deferred (open question).
- **Counts** recounted from `test-cases.json`, never copied from an older plan (L-T15).
- **Hooks** `H<n>`, numbered once for the project; a hook only sets up state; the surface stays the oracle.
- **Feasibility doc sections**, in order: `## Summary` (4 bullets: totals, biggest blocker, run so far, next per
  folder) · `## How to read this file` (the term table) · `## Folders` with `### Decision per folder`,
  `### Readiness of the automated part`, `### First spec and progress` (each with a **Total** row where it counts) ·
  `## Hooks` (`Hook | What it does | Name in the analyses | TCs that need it | Status | Owner`; status proposed ·
  agreed · available · not needed; unused numbers on one "Reserved" line) · `## Frameworks per pack` (State with
  evidence) · `## Updating this file`.
- **Feasibility counts** recounted from each folder's `test-cases.json`; readiness columns use the exact
  `automation_readiness` values; a folder whose TCs predate the field says its readiness comes from its plan.
  "TCs that need it" = the TCs whose `automation_note` names the hook, with how many wait on it alone.

## Checks before done

```bash
python3 scripts/export_testcases.py <target> --check && python3 scripts/export_testcases.py <target>
python3 scripts/tracks.py <target>
```
