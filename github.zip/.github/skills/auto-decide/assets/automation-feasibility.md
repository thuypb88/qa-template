<!-- Template: auto-decide, project-wide feasibility. Copy to automation/docs/automation-feasibility.md on the first run,
replace every <placeholder>, delete these comments. Later runs replace one folder's rows, the Totals and the Summary.
Rules: ../references/output-rules.md. -->
# Automation feasibility (<project code>)

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

What can be automated in each test-design folder, what it waits for, and with which tools. Written by `auto-decide`
(one folder at a time); read by `auto-design`, `auto-write`, `flow-roadmap` and the QA lead. Every count is recounted
from the folder's `test-cases.json`, never copied from an older version of this file.

## Summary

- **<n> of <n> TCs** have an automated part (<n> Auto, <n> Auto + Manual); **<n> are Ready** to write (<folder n · …>).
- **Biggest blocker:** <the hook or question that holds the most TCs, with the count>.
- **Run so far:** <written n of n, run n — or why nothing has run, with its follow-up>.
- **Next per folder:** <folder → skill or follow-up · …>

## How to read this file

| Term | Meaning |
|---|---|
| **Auto** | the whole TC is automated |
| **Auto + Manual** | part automated, part checked by a person (e.g. a printed QR Code, a visual sign-off) |
| **Manual** | run by a person only |
| **Ready** | the automated part can be written now |
| **Blocked: H\<n\>** | waits for hook H\<n\> from the DEV team (table below) |
| **Blocked: data** | the test data is not concrete or resettable yet; the test case writer fixes it |
| **Rewrite** | a step or check is off the tested surface (R2); the test case is rewritten first |
| **Deferred** | the expected value rests on an open question (`Q-…`); not scripted until it is answered |

The readiness values are the exact strings of `automation_readiness` in `test-cases.json` (one per Auto / Auto +
Manual TC). A hook only sets up state; the screen stays the oracle (R2).

## Folders

### Decision per folder

| Folder | Level | TC version | TCs | Auto | Auto + Manual | Manual | Plan |
|---|---|---|---|---|---|---|---|
| <short name — module name> | <IT (env) \| ST (env)> | <v> | <n> | <n> | <n> | <n> | [automation-plan.md](<path>) |
| **Total** | | | **<n>** | **<n>** | **<n>** | **<n>** | |

<Modules with no test cases yet: no row until auto-decide runs on them.>

### Readiness of the automated part

| Folder | Automated part | Ready | Blocked: H\<n\> | Blocked: data | Rewrite | Deferred |
|---|---|---|---|---|---|---|
| <short name> | <Auto + Auto + Manual count> | <n> | <n> (<H1> <n> · <H2> <n> …) | <n> | <n> | <n> |
| **Total** | **<n>** | **<n>** | **<n>** | **<n>** | **<n>** | **<n>** |

<Only when a folder's TCs have no `automation_readiness` (written before template 1.36.0): "<folder>'s readiness
comes from its plan's waves until `auto-decide <folder>` runs again; the other folders' is recounted from the field.">

### First spec and progress

| Folder | Wave 1 | Written | Run | Next |
|---|---|---|---|---|
| <short name> | <spec path + TC IDs> | <n of n> | <n, or why 0> | <skill or follow-up> |

## Hooks

What the DEV team must provide so a test can set up its state. Numbers are fixed for the project and never reused.
Status: **proposed** (asked, no answer) · **agreed** (DEV will build it) · **available** (usable now) · **not needed**.

| Hook | What it does | Name in the analyses | TCs that need it | Status | Owner |
|---|---|---|---|---|---|
| H1 | Seed the base fixtures and reset the IT environment between runs | <base fixtures of each analysis §11> | <every IT Auto TC (suite-wide)> | <proposed (source)> | <DEV team> |
| H2 | Run a scheduled job now | <`HOOK-…`> | <folder n (n wait only on it)> | <status> | <owner> |
| H3 | Fault switches / mock error scenarios | <name> | <…> | <status> | <owner> |
| H4 | Short timeouts (session expiry) | <name> | <…> | <status> | <owner> |
| H5 | Set the system date (clock control) | <name> | <…> | <status> | <owner> |
| H6 | Control endpoint for data / config changes | <name> | <…> | <status> | <owner> |
| H7 | Test accounts / mock login: one user or token per role, per level | <`USER-*`> | <every Auto TC (suite-wide)> | <status> | <owner> |

<H1–H7 are the standard numbers (`auto-decide` gate G4); a project need beyond them takes H8, H9 … and keeps it.
Move every hook no TC names to one line:>
Reserved, not needed yet: **<Hn>** <what> · **<Hn>** <what>

## Frameworks per pack

| Pack | Framework | Folder | State |
|---|---|---|---|
| ui | Playwright (TypeScript) | `automation/ui` | <not created (the first spec creates it) \| created (what exists); run state with evidence \| not used: why> |
| api | pytest + `api_client.py` | `automation/api` | <state> |
| etl | pytest + `reconcile.py` | `automation/etl` | <state> |
| sql | pytest + `sql_verify.py` (verification procedures / scripts) | `automation/sql` | <state> |

<Packs the project does not use: one row "<packs> · not used: <why>", or drop them.>

## Updating this file

- `auto-decide <folder>` replaces that folder's rows in the three Folders tables and the Totals, recounted from its
  `test-cases.json`; it adds a hook here before any TC names it.
- A hook's status changes when the DEV team answers; its "TCs that need it" is recounted from the `automation_note`
  values that name it.
- The Summary is rewritten on every update; nothing else in the file is hand-edited.
