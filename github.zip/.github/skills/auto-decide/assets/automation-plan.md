<!-- Template: auto-decide. Copy to <folder>/3-test-cases/automation-plan.md, replace every <placeholder>, delete these
comments. Rules: ../references/output-rules.md. -->
# <module name | ST: project name>: automation plan

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

`test-cases.json` v<version> (<n> TCs) · review [test-cases-review.md](test-cases-review.md): <verdict, fixes applied> ·
level <IT | ST> (`<environment>`) · pack `<pack>` · runner <runner> (`project.json › runners.<pack>`). Data:
[test-data.md](test-data.md). Hooks and frameworks: [automation-feasibility.md](<relative path>).

<Suite-wide prerequisites (hooks every spec needs) and what "Ready" means here.>

## Counts

| | TCs |
|---|---|
| Auto | <n> |
| Auto + Manual | <n> (<TC IDs: why>) |
| Manual | <n> |
| **Ready** | **<n>** (P1 <n> · P2 <n> · P3 <n>) |
| Blocked by hook | <n> (<H-n: count>) |
| Blocked (data) | <n> |
| Rewrite (R2) | <n> |
| Deferred (open question) | <n> |

## Specs

| Spec | Pack | TCs | Data-driven | Fixtures / hooks | Readiness | Wave |
|---|---|---|---|---|---|---|
| <automation/<pack>/… per pack naming> | <pack> | <TC-… ranges> | <yes: rows by … \| no> | <FX-…, H-n> | <Ready \| Blocked by hook \| Rewrite \| Deferred> | <1> |

## Waves

| Wave | Content | Specs | TCs | Gate |
|---|---|---|---|---|
| 1 | <smoke + auth / RBAC> | <…> | <n> | <what must hold first> |

## Blockers

| Hook / question | TCs | Owner |
|---|---|---|
| <H-n name \| Q-xxx> | <TC IDs> | <owner> |

## Changes to the tags

| TC | Old → new | Gate |
|---|---|---|
| <TC-…> | <Manual → Auto> | <gate that decided it> |

## Raise to the writer (`design-cases`)

- <TC-…: what in the TC content blocks automation, and the fix>

## Manual residue

| TC | Why manual | Gate |
|---|---|---|
