<!-- Template: sql-explain (chat; on request a note in <folder>/sql-study/explain-<slug>.md). Replace every <placeholder>;
delete this comment. Rules: ../references/output-rules.md. -->
**<Mode: query | procedure | plan | error>** · dialect <dialect (given | inferred from <syntax>)> · for <audience>

**In one sentence:** <what it returns or changes, in business words.>

**Walk-through:**
1. <step in the mode's shape; for queries the grain after each join: "one row per …">

**Worked example (illustrative rows, not project data):**

| <table> | <col> | <col> |
|---|---|---|

→ after <step>: <intermediate rows> → result: <final rows>

**Traps here:** <only the ones that apply>

**For you:** <testers: cases worth a test (checklist IDs) · PM / BA: what it means for the business · ELI5: one analogy>
