# sql-explain: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Fill [../assets/explanation.md](../assets/explanation.md). Linked, never copied:
[packs/sql/dialects.md](../../../../packs/sql/dialects.md) · [packs/sql/checklist.md](../../../../packs/sql/checklist.md).

| Output | Where | Write mode |
|---|---|---|
| explanation | chat | per request |
| note (on request) | `<folder>/sql-study/explain-<slug>.md`, with the header stamp | new or edit |

## Rules

- **Opening sentence first**, then the walk-through in the mode's shape (query · procedure · plan · error).
- **Dialect** stated, as given or as inferred (and from what).
- **Worked example** rows are made up and labelled illustrative, never presented as project data.
- **Traps** only where they apply; contradictions with the spec cite both and stay a `Q-xxx` or go to `sql-debug`.
- Unknown columns are "not documented"; length fits the audience.
