<!-- Template: run-tests. Append as the last section of runs/run-summary.md (the rest is written by
scripts/run_tests.py), and give the triage table in chat. Replace every <placeholder>, delete this comment.
Rules: ../references/output-rules.md. -->
## Conclusion

**Tested:** <targets and packs that ran, build, environment> · **Not tested:** <what did not run and why: manual
residue, Blocked, No result, runner missing>

**Failed / No result P1–P2 (before any rate):**

| TC | P | Result | Class | Defect / owner |
|---|---|---|---|---|
| <TC-…> | <P1> | <Failed \| No result \| Flaky (passed 1 of 2)> | <Product \| Automation \| TC \| Environment \| Flaky> | <defect report / auto-write / writer / env owner> |

**Counts (executed):** Passed <n> · Failed <n> · Skipped <n> · No result <n> of <n> Auto TCs; manual residue <n>.
<"not executed / not enough evidence" when nothing ran>

| Exit criterion | Status | Evidence |
|---|---|---|
| <criterion from the test plan> | <Met \| Not met \| Blocked \| Unknown> | <file, count> |

**Release position (recommendation):** <ready | ready with conditions | not ready> — <reasons by TC ID>. The decision
belongs to <who the test plan names>.
