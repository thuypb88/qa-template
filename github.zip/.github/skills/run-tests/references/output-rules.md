# run-tests: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing the conclusion or a defect report. Linked, never copied:
[defect-report.md](../../../../standards/methods/defect-report.md) §1 (defect report), §2 (flaky, environment), §3
(conclusion) · [core-rules.md](../../../../standards/core-rules.md) R2, R9.

| Output | Template | File | Write mode |
|---|---|---|---|
| run summary | generated | `runs/run-summary.{md,json}`, `runs/<key>/results.csv`, JUnit, `manual-checklist.csv` | `run_tests.py` only |
| conclusion | [run-conclusion.md](../assets/run-conclusion.md) | `runs/run-summary.md`, last section `## Conclusion` | append after each run |
| defect reports | defect-report.md §1 | `runs/<key>/defects.md` and chat; register via `run-defects` | one per root symptom |
| cycle | — | result fields in `test-cases.json` + Excel | `run_tests.py --record <cycle>` / `record_manual.py` only, when the user names a cycle |
| status, log | — | `project/status.md`, `project/log.md` | one row / line |

## Rules

- **Executed counts only:** planned or Auto-tagged is not executed; an Auto TC no test reported is **No result**,
  never Passed. Nothing ran → "not executed / not enough evidence".
- **Failures before percentages:** every failed or No-result P1 / P2 TC by ID before any pass rate.
- **Triage class** for every non-skipped failure: Product · Automation · TC · Environment · Flaky (passed n of m).
- **Gate view** per exit criterion: Met · Not met · Blocked · Unknown; missing evidence is never Met.
- A recommendation, never a decision; the decision belongs to the people the test plan names.
- `runs/` is not in git: a run is kept only when recorded as a cycle.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
