# flow-next: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 15:44:58 (UTC+7)

Fill [../assets/answer.md](../assets/answer.md). Chat only; this skill writes no file.

| Output | Template | Where | Write mode |
|---|---|---|---|
| next step | [answer.md](../assets/answer.md) | chat | per request; no file |

## Rules

- **One answer:** one primary skill (`**Next:**`), at most one helper (`**Then:**`); never a menu.
- **Evidence:** the reason names the file or script line it rests on; otherwise "unknown".
- **Also open:** warnings that matter (unaccepted source changes, stale reviews, deliverables missing / stale /
  unindexed / sent-stale), one line each, or "none".
- **All folders:** the status table `Folder | Next | Why` first, then the order: change control → ST analysis (when
  the test plan has ST) → modules in `project.json` order → the rest of the ST chain.
- The named skill runs only on the user's go-ahead.
