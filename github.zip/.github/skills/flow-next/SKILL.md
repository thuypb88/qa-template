---
name: flow-next
description: Flow: which skill runs next, and why (router; before any other skill). Say which skill runs next and why, from scripts/pipeline_status.py (deliverables, review verdicts, stale reviews, automation plan, unaccepted source changes) or by matching a plain request to one skill. Use for "what's next", "where are we", "status of E4 / all modules", "which skill do I use for …", "the client sent a new file, what now?", or a request that names no skill and mixes phases. Never does the work itself.
metadata:
  group: flow
  order: "-"
---

# Flow: which skill runs next

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** a target (module id, folder, `st`) or none, and/or a plain request. **Out:** a chat answer; no files.
**Tool:** `python3 scripts/pipeline_status.py [target] [--json]` (read-only). **Next:** the named skill, only on the
user's go-ahead.
**Output:** [assets/answer.md](assets/answer.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **Project set up?** `project.json` missing, or `project.code` is `CHANGE-ME`, or no modules → `plan-setup`
   (a QA lead just joining, or asking for the whole plan → `flow-roadmap start`).
2. **Status:** `python3 scripts/pipeline_status.py <target>`. Read `project/index.md` › Now and `project/status.md` for
   what the script can't know (waiting on DEV, decisions pending).
3. **Sources first.** Files differ from the accepted baseline → `plan-changes` before everything, unless the latest
   `project/change-impact/` record covers exactly those files and only its follow-ups remain.
4. **Match a work request** — first the group (the question the user is asking), then the skill:

   | Group — question | Request | Skill |
   |---|---|---|
   | **flow** — what next, in what rhythm | plan my day, EOD · sprint testing, sprint exit · release, go / no-go, hotfix | `flow-cadence` (mode day · sprint · release) |
   | | joining a project, QA roadmap, onboarding plan, whole-project status, project health, milestone history | `flow-roadmap` (mode start · update · health) |
   | **plan** — what to test, is the basis current | new project, documents arrived, project.json skeleton | `plan-setup` |
   | | test strategy, test approach, entry / exit criteria, review the client's test plan | `plan-strategy` |
   | | write the test plan document, test schedule, estimation, man-days, when can testing finish | `plan-testplan` (mode plan · estimate · schedule) |
   | | review / check a test plan, schedule or estimate before it is sent or signed | `check-testplan` |
   | | new / changed source file, impact | `plan-changes` |
   | | a module's scope, readiness per requirement, new module (after its discovery) | `plan-scope` |
   | **req** — is the requirement testable | a vague request / CR, "the client wants …", what should we ask; a module's discovery (step 0a, before `plan-scope`) | `req-elicit` |
   | | check a written requirement document / story / use case, questions for the BA | `req-review` |
   | | write / refine stories and criteria, write / split use cases (as proposals) | `req-write` |
   | **design** — what exactly, with which data | analysis of a module | `design-analysis` |
   | | analysis of the system / ST (whole, or the slice for named modules) | `design-system` |
   | | scenarios / mindmap | `design-scenarios` |
   | | test cases, Excel, checklist pass (pack sql → `sql-cases`) | `design-cases` |
   | | test data, fixtures, pairwise data sets | `design-data` |
   | | end-to-end / E2E scenarios across modules, which business chains to test in ST | `design-e2e` |
   | | performance, security, accessibility, compatibility testing | `design-nfr` |
   | **check** — is our own work right | review an analysis, mindmap or test cases | `check-design` |
   | | review the automation design or the automated tests, "is this test any good" | `check-automation` |
   | | review / write a skill, "why didn't the skill trigger" | `check-skill` |
   | **auto** — what to automate, build it | what to automate, re-tag, feasibility | `auto-decide` |
   | | design the automation codebase / framework, page objects, data builders | `auto-design` |
   | | write the automated tests | `auto-write` |
   | **run** — does the build work, what do we report | what to rerun for a build / fix / release | `run-select` |
   | | run tests, record a cycle, flaky test, manual results | `run-tests` |
   | | exploratory session, charters | `run-explore` |
   | | log / retest / close a defect, defect status | `run-defects` |
   | | test summary / exit / status report | `run-report` |
   | **sql** — database code (modules with pack sql, or any SQL question) | study / map a procedure, package or schema | `sql-study` |
   | | explain a query, procedure, plan or DB error | `sql-explain` |
   | | wrong rows, DB error, slow query, deadlock, failed SQL TC | `sql-debug` |
   | | test data / seed / insert scripts | `sql-data` |
   | | test cases for a procedure / function / view (pack sql) | `sql-cases` |
   | | stored procedures / scripts that verify the SQL test cases | `sql-verify` |
   | **learn** — what did we learn, can others follow | lessons, "why does this keep happening", after a review | `learn-retro` |
   | | explain something to the client / PM / BA / a new tester, ELI5 | `learn-explain` |
   | | glossary, "what does <term> mean here", role codes, refresh / check the glossary | `learn-glossary` |

   If the target's upstream step is missing or stale, that step is primary.
5. **Confirm the decisive gap** in the file the script names: a review "stale" whose fixes were applied after it
   (Revision log) is not stale; **Rework** → the writer again with the findings.
   **Deliverables** (the script's last block): an issued document that is *missing*, *stale* or *unindexed* goes to
   the skill it names (`plan-testplan` plan mode, `design-cases`, `run-report`) for its deliverable step only, after
   the folder's own next step; *sent-stale* → a new version, never an overwrite. List them under **Also open**.
6. **Answer and stop** with [assets/answer.md](assets/answer.md) ([references/output-rules.md](references/output-rules.md)).

   For all folders: the status table (folder · next · why), then the order: change control → ST analysis (when the
   test plan has ST) → modules in `project.json` order → the rest of the ST chain.

## Rules

- **One answer.** One primary skill, at most one helper.
- **Evidence only.** Every claim from the script or a file you opened, else "unknown".
- **Chain order wins.** Unreviewed steps come before automation.

## Done when

- [ ] One **Next** skill with its target and the evidence behind it; at most one helper.
- [ ] Nothing was written or run besides the read-only status script.
