---
name: plan-setup
description: Plan: set up a project from this template (step -1, once per project). Bootstrap a QA workspace made from this template - inventory the documents in sources/, extract them, draft project.json (levels, environments, external systems, modules with pack ui / api / etl / sql and layout, variant sets, languages, IDs, runners), project/ (rules.md, system map, decisions), list the Q-INIT questions, then on the user's confirmation build the module folders with scripts/init_project.py. Use for "set up a new project", "initialise the workspace", "we got the documents for <project>", or when project.json is still the template skeleton. Adding one module later → plan-scope; a changed document → plan-changes.
metadata:
  group: plan
  order: "-1"
---

# Plan: set up a project

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-10-28 14:43:17 (UTC+7)

**In:** the documents in `sources/` (client originals, requirements, API specs, mappings, test plan); the user's
answers. **Out:** `project.json`, `project/rules.md`, `project/system-map.md`, `project/decisions/ADR-001…`,
`project/questions.md` (Q-INIT rows), `project/index.md` › Now; then the generated folders. **Rules:** core R1, R9, R10;
[standards/conventions.md](../../../standards/conventions.md). **Next:** `design-analysis` (ST first if the test plan has a
system level, else the first module).
**Stop if** `sources/` holds no requirement document: say what is needed (at least one of SRS / user stories / API
spec / mapping, and the test plan if one exists).
**Output:** [assets/setup-summary.md](assets/setup-summary.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **Inventory.** List every file under `sources/` (`find sources -type f -not -path '*/parsed/*'`): kind (client
   original, requirement, API spec, mapping, DDL, test plan, template), language, version / date. Files the user
   still needs to move into the right folder → say so ([sources/README.md](../../../sources/README.md)).
2. **Extract.** `python3 scripts/extract_text.py` for documents; API specs →
   `python3 scripts/parsers/openapi_inventory.py <spec>`; mapping workbooks →
   `python3 scripts/parsers/sttm_inventory.py <file>`. Look at the images and diagrams with Read (architecture,
   flows, screen mock-ups often hold what the text lacks); the flow charts of a `.docx` / `.pdf` are listed in
   `sources/parsed/<path>/<doc>.figures/INDEX.md`.
3. **Read for the profile, not for the tests.** Use `slice.py toc` / `section`. Extract only what `project.json`
   needs:
   - **Project:** code (short, A–Z0–9), name, client, timezone, document language.
   - **Levels** (test plan): which levels exist, the environment of each, whether external systems are mocked.
     Default IT (per module, mocks) + ST (whole system, real systems). Write the env names exactly (R9.3).
   - **External systems:** name, what they exchange, IT stand-in (`mock`, `stub`, `fixture`, `sandbox`), ST (`real`,
     `sandbox`).
   - **Modules:** one per epic / service / pipeline the plan or spec names. Per module: `id` (short, e.g. `E4`,
     `API1`, `D2`), kebab-case `slug`, `name` as the documents say it, `pack` (`ui` — tested through screens / forms /
     printouts; `api` — through HTTP contracts; `etl` — through data; `sql` — through database objects: procedures,
     functions, views, triggers, then also `sql.dialect` / `version`), `layout` from the pack (ui: `form` | `flow`;
     api: `resource` | `flow`; etl: `table` | `job`; sql: `object` | `flow`) with the reason, `security` (`full` | `limited` | `none`),
     `refs` (requirement IDs), `acceptance` (client AC IDs), `sources` (globs), `variants`, `depends_on`,
     `externals`. One system tested two ways (screens + its API) = two modules.
   - **Variant sets** (R10): sets of things that behave differently and must each be covered (forms, customer
     types, source systems, channels).
   - **Languages** (R6.3), **ID formats** (keep the defaults unless the client template dictates others),
     **values** (test types / priorities / statuses from the client's test case template if there is one).
   - **Runners** per pack in use (see `automation/README.md`; leave out packs not used).
   - **Precedence** (`sources.precedence`): which document wins for what, when the documents say so.
4. **Project rules.** Anything the documents or the user impose beyond core + pack rules → `PR-n` in
   `project/rules.md`, each citing its source; a decision by a person → also `project/decisions/ADR-NNN-<slug>.md`.
5. **Project memory.** `project/system-map.md`: interfaces table (INT rows from the test plan / architecture), roles,
   glossary. `project/index.md` › Now: 3–6 lines.
6. **Questions.** Everything you had to assume → `Q-INIT-NNN: assumed <value>` in `project/questions.md`
   (Folder = `project`), with the evidence.
7. **Show and stop.** In chat, from [assets/setup-summary.md](assets/setup-summary.md): the module table (id · name · pack / layout · security · refs count · sources), the
   levels, the external systems, the project rules, the Q-INIT list. Ask the user to confirm or correct.
   **Do not run step 8 before they confirm.**
8. **Build.** `python3 scripts/qa_config.py --validate` (fix every error), then `python3 scripts/init_project.py`.
   It writes the module folders, `0-scope.md`, `sources.json`, `test-design/it/INDEX.md`, the system-map module table,
   AGENTS.md, hooks and the first source baseline. Then `python3 scripts/pipeline_status.py`.
9. **Commit** `project set-up: <n> modules (template v<version>)`.

## Rules

- Never invent a module, system, role or rule: every value cites a document line or a user answer; else Q-INIT.
- `sources/` is read-only (the guard blocks it).
- Keep `project.json › guard.template_dev` false in a project (it is true only in the template repo).
- Personal agent memory may point here, but project facts go in `project.json` and `project/`, never only in memory.

## Pitfalls

- **Modules by document chapter** instead of by what a tester runs: a chapter "Non-functional" is not a module.
- **One pack per system** when it is tested at two surfaces: the UI module tests screens; the API module the
  contract. Each keeps R2 at its own surface (L-T05, R-UI1.5).
- **Guessing environments** from habit ("SIT = system integration"). Copy the test plan's names; where the plan and a
  lead's instruction differ, record an ADR (ALPHA: "IT runs in the SIT environment", 2026-10-13).

## Done when

- [ ] `qa_config.py --validate` OK; `init_project.py` ran; `pipeline_status.py` lists every folder.
- [ ] Every module has pack, layout (+ reason), refs, sources; every external system has IT and ST stand-ins.
- [ ] project-rules, ADRs, system map, Q-INIT written; the user confirmed step 7.
- [ ] Report: modules by pack, levels, Q-INIT count; suggest the first `design-analysis`.
