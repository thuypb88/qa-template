<!-- Template: plan-setup, step 7 "Show and stop" (chat). Replace every <placeholder>; delete this comment. Ask the user to
confirm or correct; never run step 8 before they confirm. Rules: ../references/output-rules.md. -->
**Project:** <code> · <name> · client <client> · timezone <tz> · document language <lang>

| Module | Name | Pack / layout (why) | Security | Refs | Sources |
|---|---|---|---|---|---|
| <id> | <name as the documents say it> | <ui / flow (screens and workflows)> | <full \| limited \| none> | <n> | <globs> |

| Level | Environment | External systems |
|---|---|---|
| IT | <exact name> | <system: mock \| stub \| fixture \| sandbox> |
| ST | <exact name> | <system: real \| sandbox> |

**Variant sets:** <set: values> · **Languages:** <…> · **Runners:** <pack: runner>
**Project rules:** PR-1 <title> (<source>) · …
**Questions (Q-INIT):** <n> — Q-INIT-001 <assumed …> · …

Confirm or correct the above; I build the folders (`qa_config.py --validate`, `init_project.py`) only after your OK.
