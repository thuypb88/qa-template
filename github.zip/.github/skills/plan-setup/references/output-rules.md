# plan-setup: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-10-28 14:25:08 (UTC+7)

Read before writing. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md) R1, R9, R10 ·
[conventions.md](../../../../standards/conventions.md) §1–3 (ownership, layout, IDs) · `project.json` keys:
`python3 scripts/qa_config.py --validate` is the schema.

| Output | Template | File | Write mode |
|---|---|---|---|
| summary (step 7) | [setup-summary.md](../assets/setup-summary.md) | chat | before any build; stop for the user's OK |
| project profile | the seeded `project.json` | `project.json` | edit; `qa_config.py --validate` clean |
| project rules | the file's own form (`## PR-n. <title>`, rule, source) | `project/rules.md` | append `PR-n`, next free number |
| decisions | `project/decisions/ADR-000-template.md` | `project/decisions/ADR-NNN-<slug>.md` | new file per decision |
| system map | the file's own sections (interfaces, roles, glossary) | `project/system-map.md` | edit |
| questions | the file's own table | `project/questions.md` (`Q-INIT-NNN: assumed <value>`, Folder = `project`) | append |
| now | — | `project/index.md` › Now (3–6 lines) | rewrite that block |
| folders | generated | module folders, `0-scope.md`, `sources.json`, `INDEX.md`, AGENTS.md, hooks, source baseline | `python3 scripts/init_project.py` only, after the user confirms |

## Rules

- Every value cites a document line or a user answer; else a `Q-INIT`.
- Environment names copied exactly from the test plan (R9.3); module `name` exactly as the documents say it.
- `guard.template_dev` stays false in a project.
- Rows appended to `project/` memory files (`questions.md`, `log.md`, `status.md`, `lessons.md`, `defects.md`) use the columns of that file's own table header; never add or reorder columns.
