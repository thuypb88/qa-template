---
name: auto-design
description: Automation A2: design the automation codebase before detailed test code. Use the automation plan, cases, data plan and pack inventory to define layout, layers, shared components, locators and test-id agreements, roles, data builders, isolation, cleanup, waits, binding, reporting, exact dependency versions and CI. Map each test-design folder’s specs to new or reused components. Use for “design the automation framework”, “plan the Playwright codebase”, “page object design”, or before wave 1 / when auto-write needs a missing component. Runs after auto-decide, before auto-write (IT or ST, every pack); runs design-data first when the data plan is missing or stale. Decisions → auto-decide; test data → design-data; tests → auto-write (SQL: sql-verify); design review → check-automation.
metadata:
  group: auto
  order: "A2"
---

# Automation: design the codebase

> **Created:** 2026-10-23 14:20:00 · **Updated:** 2026-11-05 00:00:00 (UTC+7)

**In:** the folder's `3-test-cases/automation-plan.md` (specs, waves, hooks), its TCs (`slice.py tc <target> --stats`,
`--form "<item>"`), `3-test-cases/test-data.md` (named sets, isolation, run order), analysis §3 inventory (screens,
fields, buttons, messages) and §11 fixtures / hooks, `automation/docs/automation-feasibility.md` (hooks H1…,
frameworks), `automation/README.md` and the pack's README, `project.json › runners`, and the existing
`automation/<pack>/` code. **Out:** `automation/docs/<pack>-design.md`, created on the first run for the pack and
extended with one section per folder after that. No test code. **Rules:** core R2 (the assertion stays at the
surface), R9 (IT mocks / ST real systems), conventions §1 (`automation/` is project-owned), the pack rules; diagrams per [design-diagrams.md](../../../standards/methods/design-diagrams.md) §2.
**Next:** `check-automation` design mode, then `auto-write` (SQL: `sql-verify`).
**Stop if** there is no automation plan → `auto-decide`; the folder's test case review is missing, stale, Rework,
or its fixes are not applied → `check-design` (or the writer first). A design built on TCs that will still change
gets built twice. A missing or stale `3-test-cases/test-data.md` is not a stop: step 1 runs `design-data` first.
**Output:** [assets/pack-design.md](assets/pack-design.md); rules [references/output-rules.md](references/output-rules.md) — read before writing.

## Steps

1. **Data plan first.** Run `python3 scripts/pipeline_status.py <target>`. If it names `design-data`
   (`3-test-cases/test-data.md` missing or older than the TCs), run `/design-data <target>` now (for the system
   target `/design-data st`): that skill's own steps, output contract and Done when, its file written and reported.
   Then continue with step 2 in the same run, on that plan. A data blocker it raises (a `Q-xxx`, a fixture to
   propose) carries into step 11 as a gap; it does not stop the design.
2. **Read the existing code first.** If `automation/<pack>/` already holds tests or components, the design describes
   them and extends them. It never replaces working code without a finding to justify it.
3. **Layers.** Fix one direction of dependency: specs → flows (multi-screen business steps) → page objects /
   components → data builders → hook clients → config / environment. A spec never reaches past the layer below it,
   and nothing below a spec asserts an expected result. Assertions stay in the spec, against the TC's expected
    result. Draw the layer diagram under the §2 table (design-diagrams §2.1).
   For UI automation, keep business flows under `automation/ui/flows/it/<module>/` or
   `automation/ui/flows/st/` according to `project.json › levels`; cross-level helpers belong in
   `automation/ui/flows/shared/`. IT and ST flows never import from each other.
4. **Shared components from the inventory.** Read analysis §3 across the folders that are in scope, not one module.
   Name the components that repeat (list view, form with status bar, a dialog, a report screen, a journal entry, a
   wizard) and give each one owner file. A module page object composes them, it doesn't copy them.
5. **Locator strategy.** Use the order the pack README gives: role and label text as the TC names it, then a test id
   agreed with DEV. List the test ids to ask DEV for, and the places where labels repeat (the scoping container for
   each). No devtools CSS and no index-based locators.
6. **Login and roles.** One authenticated state per role (`USER-*` / H7), created once per run. Name the role
   switch a flow needs ("sign in as USER-MGR" within a TC).
7. **Data.** One builder per named data set of `test-data.md` (base fixture → derived set), with the per-run
   prefix, the fresh-copy rule, the cleanup order and the run order (for example a shared setting reset last). A
   value an open question decides lives in one constants file, named by its `Q-xxx`. Under the builder table, a
   builder-chain diagram for each builder of ≥ 3 steps or ≥ 2 roles; under the run-order table, the run-phase flow
   (design-diagrams §2.2, §2.3).
8. **Hooks and mocks.** One client per hook used (`Hn` from the feasibility doc). Each hook only sets up state; the
   design says which screen the spec reads afterwards. IT mocks answer in the contract's shape (R9).
9. **Waits, binding, reporting.** Wait on the observable state the next step needs, never fixed sleeps. Test titles
   start with the TC ID (`automation/tc_binding.py`), with one ID per data-driven row. Reporters as the pack README
   says (JUnit for `run_tests.py`). Traces and screenshots on failure.
10. **Dependencies and CI.** Use exact versions (no ranges) and the scripts in `package.json` / `pytest.ini`. State
   which waves run in CI and when, and the environment variables, named and never set in the repo.
11. **Per folder.** Map each spec row of the plan to the flows, components, builders and hook clients it uses,
    marked **new** or **reused**. List the gaps that block a spec (a missing hook, test id or fixture) with their owner.
    A spec map only when the table hides shared use (design-diagrams §2.4).
12. Record the change: `project/status.md` board row, `project/log.md`, commit
    `automation design: <pack> (<folder> section)` (with step 1: `<folder> test data plan + automation design: <pack>`).

## Output

Copy [assets/pack-design.md](assets/pack-design.md) on the first run for a pack; sections and fixed tables per
[references/output-rules.md](references/output-rules.md) — read it before writing.

## Rules

- A design, not code: signatures and responsibilities, no test bodies. `auto-write` writes the code from it.
- A component `auto-write` needs and the design lacks means this skill extends the design first. No ad hoc helper
  appears in a spec.
- Shared before specific: a second module reuses a component, it doesn't copy it.

## Done when

- [ ] `3-test-cases/test-data.md` current before the design (written by `design-data` in step 1 when it was not).
- [ ] Every spec row of the plan maps to its components, builders and hooks, each marked new or reused.
- [ ] Every named data set the specs need has a builder, a cleanup and a place in the run order.
- [ ] Locator strategy, test ids to request, roles, waits, binding, reporting, dependencies and CI are stated.
- [ ] Layer diagram, run-phase flow and the builder chains drawn; each agrees with its table (design-diagrams §4).
- [ ] Gaps listed with owners; report the design and suggest `check-automation` design mode, then `auto-write`.
