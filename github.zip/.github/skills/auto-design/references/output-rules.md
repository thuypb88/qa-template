# auto-design: output rules

> **Created:** 2026-10-28 14:25:08 · **Updated:** 2026-11-05 00:00:00 (UTC+7)

Read before writing the design. Copy [../assets/pack-design.md](../assets/pack-design.md) on the first run for a pack;
afterwards extend the existing file. Linked, never copied: [core-rules.md](../../../../standards/core-rules.md) R2, R9 ·
[conventions.md](../../../../standards/conventions.md) §1 · `automation/README.md` and the pack's README.

| Output | File | Write mode | Reviewed by |
|---|---|---|---|
| codebase design | `automation/docs/<pack>-design.md`, title `# <PACK> automation design (pack \`<pack>\`)` | created on the first run for the pack; then one `### <folder>` section under §10 per folder, other sections extended | `check-automation` design mode |

## Rules

- **Template sections** of [pack-design.md](../assets/pack-design.md), in order: `## 1. Layout` · `## 2. Layers and rules` · `## 3. Shared components` · `## 4. Locators` · `## 5. Roles and login` · `## 6. Data builders, isolation and run order` · `## 7. Hook clients and mocks` · `## 8. Waits, binding, reporting` · `## 9. Dependencies, scripts, CI, environment` · `## 10. Per folder` · `## Open points`.
- **Sections**, in order: header table `Item | Value` (pack · runner, system under test, level, folders covered,
  inputs, existing code) · `## 1. Layout` (tree) ·
  `## 2. Layers and rules` · `## 3. Shared components` (`Component | File | Used by | Inventory source`) ·
  `## 4. Locators` (strategy, test ids to request, scoped duplicates) · `## 5. Roles and login` ·
  `## 6. Data builders, isolation and run order` (`Builder | Set | Base | Cleanup | Specs`) ·
  `## 7. Hook clients and mocks` · `## 8. Waits, binding, reporting` · `## 9. Dependencies, scripts, CI,
  environment` · `## 10. Per folder` (`Spec | Flows | Components | Builders | Hooks | New / reused | Gaps`) ·
  `## Open points`; `## Revision log` on later versions.
- **No test code** in this file beyond short signatures; tests are `auto-write`'s.
- **Every spec row** of the folder's `automation-plan.md` maps to a §10 row; every named set of `test-data.md` has a
  builder, cleanup and a place in the run order.
- **UI flow ownership:** the design places IT module flows in `flows/it/<module>/`, ST flows in `flows/st/`, and
  cross-level helpers in `flows/shared/`; it names which level owns every flow in the §10 spec map. IT and ST flows
  never import each other.
- **Dependencies** at exact versions, never ranges; no secrets or URLs (environment variable names only).
- **Gaps** `G-<n>`, numbered once per design file, each with an owner.
- A hook client sets up state only; the screen or response read after it is named (R2).
- **Diagrams** per [design-diagrams.md](../../../../standards/methods/design-diagrams.md) §2 (Mermaid): the layer diagram
  under the §2 table, the run-phase flow under the §6 run-order table, one builder chain per builder of ≥ 3 steps or
  ≥ 2 roles under the §6 builder table; a §10 spec map only when §2.4 says so. Each is a view of its table (§4 there):
  same names, same order, changed in the same edit.
