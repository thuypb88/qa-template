<!-- Template: auto-design. Copy to automation/docs/<pack>-design.md on the first run for the pack; later runs add one
§10 section per folder. Replace every <placeholder>, delete these comments. Rules: ../references/output-rules.md. -->
# <PACK> automation design (pack `<pack>`)

> **Created:** <YYYY-MM-DD HH:mm:ss> · **Updated:** <YYYY-MM-DD HH:mm:ss> (<timezone>)

Project-owned (conventions §1). Written by `auto-design`, reviewed by `check-automation` (design mode), implemented by
`auto-write`. Signatures and responsibilities only, no test bodies.

| Item | Value |
|---|---|
| Pack · runner | `<pack>` · <runner> (`project.json › runners.<pack>`) |
| System under test | <system, version> |
| Level | <IT on `<env>`: mocks / fixtures · ST on `<env>`: real systems> (R9) |
| Folders covered | <test-design folders, with their automation-plan.md versions> |
| Inputs | <analysis §3, §6, §11; automation-feasibility.md hooks; test-data.md> |
| Existing code | <none \| what is built, commit> |

## 1. Layout

```text
automation/<pack>/
├── <file or folder>      # <what lives here, § that rules it>
```

## 2. Layers and rules

| Layer | May | Never |
|---|---|---|
| <spec / flow / page object / component / builder / hook client> | <…> | <assert below the surface, call a hook from a spec …> |

```mermaid
flowchart TB
  spec["Specs (assert)"] --> flow["Fixtures / flows"] --> page["Pages / components"] --> data["Data"] --> hook["Hook clients"] --> config["Config"]
```

## 3. Shared components

| Component | File | Used by | Inventory source |
|---|---|---|---|

## 4. Locators

<Strategy (role / label as the TC names it, or an agreed test id); test ids to request from DEV; scoped duplicates.>

## 5. Roles and login

| Role code | Authenticated state | Env vars | Source |
|---|---|---|---|

## 6. Data builders, isolation and run order

| Builder | Set | Base | Cleanup | Specs |
|---|---|---|---|---|

<Per-run prefix, fresh-copy rule, run order between sets.>

<!-- One builder chain per builder of >= 3 steps or >= 2 roles (design-diagrams §2.3). -->
```mermaid
flowchart LR
  b1["<ROLE>: <action> (<TC> s<n>)"] -- "<record>" --> b2["<ROLE>: <action> (<TC> s<n>)"] --> out(["returns <value>"])
```

<Run-order table: Phase | Invocation | Content | Workers.>

```mermaid
flowchart LR
  setup["setup · workers 1"] --> p2["<phase> · workers <n>"] --> cleanup["cleanup · workers 1"]
  ext0["<owner>: <step outside the runner>"]:::ext --> setup
  classDef ext stroke-dasharray:4
```

## 7. Hook clients and mocks

| Hook | Client | Sets up | Never used as |
|---|---|---|---|

## 8. Waits, binding, reporting

<Wait on observable state, no sleeps; test titles / names start with the TC ID (tc_binding); JUnit for run_tests.py;
trace on failure.>

## 9. Dependencies, scripts, CI, environment

| Dependency | Exact version | Why |
|---|---|---|

<Scripts, CI schedule per wave, environment variables (names only, no values).>

## 10. Per folder

### <test-design folder>

| Spec | Flows | Components | Builders | Hooks | New / reused | Gaps |
|---|---|---|---|---|---|---|

### Gaps

| Gap | Blocks | Owner | Status |
|---|---|---|---|
| G-1 | <specs / TCs> | <owner> | <open \| agreed \| done> |

## Open points

- <decision still open, with its owner>
