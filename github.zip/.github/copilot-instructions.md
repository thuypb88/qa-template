<!-- Generated from CLAUDE.md by scripts/workspace/sync_agents.py — do not edit; edit CLAUDE.md and re-run. -->

> **GitHub Copilot — read this first.** These are the same rules and skills the other agents on this project use.
> - **Skills** are in `.github/skills/<name>/SKILL.md` (the table under "The pipeline" names them). Load the one whose
>   description matches the task; the user may also ask for one by name ("use the design-analysis skill for E4").
> - **No Claude Code hooks run for you** (`.claude/settings.json`). So: never edit a file the guard lists as generated
>   (`sources/`, every `.xlsx` under the level folders, `test-design/it/INDEX.md`, `*/sources.json`, `0-scope.md` outside its
>   MANUAL block, `AGENTS.md`, `.agents/`, `.github/skills/`, `.github/copilot-instructions.md`, `GEMINI.md`,
>   `.gemini/skills/`) or template-owned
>   (`template-manifest.json`); and **before you finish any change run `python3 scripts/workspace/guard.py check`** and fix what
>   it reports. The git pre-commit hook runs the same checks.
> - Wherever the text below says "Claude", read "the agent". Project facts are in `project.json` and `project/`.

# CLAUDE.md

> **Created:** 2026-10-22 09:23:38 · **Updated:** 2026-11-06 09:40:00 (UTC+7)

A QA workspace built from **QA-template**. It turns a client's documents (requirements, API contracts, data mappings,
test plan) into analysis → test scenarios → test cases (JSON + Excel) → automated tests → execution results, per
module (IT) and for the whole system (ST), for UI, API, ETL and SQL (database code) testing.

**Start every session here:** read [project.json](../project.json) (what this project is) and
[project/index.md](../project/index.md) (where it stands). Not sure what to do next → `/flow-next`. A fresh copy (no modules
in `project.json`) → `/plan-setup`. A QA lead joining the project, or the whole-project view → `/flow-roadmap`
(`plans/roadmap.md`).

## Where things are

| Need | File |
|---|---|
| Project facts: modules, packs, levels, environments, systems, variants, languages, IDs, runners | [project.json](../project.json) |
| Rules for every artifact (R1–R10) | [standards/core-rules.md](../standards/core-rules.md) |
| Rules per test type (R-UI, R-API, R-ETL, R-SQL), checklists, analysis / scenario / TC shapes | `packs/<ui\|api\|etl\|sql>/` |
| Rules for this project only (PR-n) | [project/rules.md](../project/rules.md) |
| Review severity, verdict, evidence, fixes (P1–P7) | [standards/review-protocol.md](../standards/review-protocol.md) |
| Folders, file names, IDs, fields, stamps, value formats (dates, numbers, amounts: §10), commits — the design system | [standards/conventions.md](../standards/conventions.md) |
| Project vocabulary: terms, role codes, ID schemes, conflicts (every row cited; `learn-glossary`, `python3 scripts/glossary.py --check`) | [project/system-map.md](../project/system-map.md) › Glossary |
| Automation codebase design per pack and its dated reviews; the tests themselves | `automation/docs/<pack>-design.md`, `automation/docs/reviews/` · `automation/<pack>/` ([automation/README.md](../automation/README.md)) |
| Shared memory: status, questions, decisions, lessons, log | [project/](../project/index.md) · cross-project lessons [standards/template-lessons.md](../standards/template-lessons.md) |
| Skills catalog: eight groups by objective (flow · plan · req · design · check · auto · run · learn) + domain group sql, and order. Each skill folder: `SKILL.md` (contract, steps) · `references/output-rules.md` (rules of what it writes) · `assets/` (templates of what it writes) | [.github/skills/README.md](skills/README.md) · check: `python3 scripts/check_skills.py [<skill>]` |
| Our plans (QA roadmap, strategy, requirement reviews, regression sets, sprint / release records) · test summary reports · defects | [plans/](../plans/README.md) · [test-reports/](../test-reports/README.md) · [project/defects.md](../project/defects.md) |
| Issued testing documents (test plan .docx, test case / dashboard workbooks, reports), filled from `plans/templates/` | [deliverables/](../deliverables/README.md) |
| Other agents' copies (generated): Codex `AGENTS.md` + `.agents/skills/`; GitHub Copilot `.github/copilot-instructions.md` + `.github/skills/`, plus path rules in `.github/instructions/`; Gemini CLI `GEMINI.md` + `.gemini/skills/` | `python3 scripts/workspace/sync_agents.py` |

Precedence: core rules → pack rules → project rules (a project rule may tighten, never loosen).

## The pipeline

| Step | Skill | Output (in the level folder) | Check |
|---|---|---|---|
| lead | `flow-roadmap` (start · update · health) | `plans/roadmap.md`: phases P0–P8, maturity, study plan, history | `python3 scripts/roadmap_status.py` |
| set-up | `plan-setup` | `project.json`, `project/` (rules, memory), folders | `python3 scripts/qa_config.py --validate` |
| plan | `plan-strategy` → `plan-testplan` (plan · estimate · schedule) → `check-testplan` | `plans/test-strategy.md`, `plans/test-plan.md`, `plans/estimation.json` → `plans/test-estimate.md` | `python3 scripts/test_estimate.py --check` · `python3 scripts/check_testplan.py` |
| 0 | `plan-changes` | `project/change-impact/…` | `python3 scripts/trace_changes.py` |
| 0a → 0b | `req-elicit` (discovery) → `plan-scope` | `plans/discovery/<date>-<slug>.md` (header row `\| Targets \| <module ids> \|`) · `0-scope.md` MANUAL block | `python3 scripts/pipeline_status.py <target>` |
| 1 → 2 | `design-analysis` → `check-design` | `1-analysis.md`, `1-analysis-review.md` | `python3 scripts/check_review.py <target> analysis` |
| 3 → 4 | `design-scenarios` → `check-design` | `2-mindmap.md`, `2-mindmap-review.md` | `python3 scripts/check_scenarios.py <target>` · `check_review.py <target> scenarios` |
| 5 → 6 | `design-cases` → `check-design` | `3-test-cases/test-cases.json` + Excel, `checklist-pass.md`, `test-cases-review.md` | `python3 scripts/export_testcases.py <target> --check` · `check_review.py <target> test-cases` |
| A1 | `auto-decide` (splits into an Auto and a Manual track) | `automation` / `automation_readiness` fields, `automation-plan.md` | `python3 scripts/export_testcases.py <target> --check` · `python3 scripts/tracks.py <target>` |
| A2 → A4 | `auto-design` → `check-automation` (design) | `automation/docs/<pack>-design.md` with its diagrams ([design-diagrams.md](../standards/methods/design-diagrams.md)), `automation/docs/reviews/<date>-<pack>-design[-r2…].md` | — |
| A3 → A4 | `auto-write` → `check-automation` (tests) | `automation/<pack>/`, `automation-review.md` | `python3 scripts/run_tests.py <target> --plan` |
| E | `run-tests` | `runs/` (raw output, not in git), recorded cycles | `python3 scripts/run_tests.py <target>` |
| B | `learn-retro` | `project/` lessons, decisions, status | — |

Skill names are `<group>-<objective>`; the group is the question it answers: `flow-` (what next, in what rhythm) ·
`plan-` (what to test, is the basis current) · `req-` (is the requirement testable; proposals enter the test basis
only through `sources/`) · `design-` (what exactly, with which data) · `check-` (is our own work right) · `auto-` ·
`run-` (does the build work, what do we report) · `learn-`; plus the domain group `sql-` (study, explain, debug,
data scripts, test cases and verification procedures for database code; pack `sql`). Catalog: [.github/skills/README.md](skills/README.md);
design rules: [standards/skill-architecture.md](../standards/skill-architecture.md). Manual results go back into the JSON
with `python3 scripts/record_manual.py`.

Targets: a module id from `project.json` (`E4`), its folder, `st`, `it` or `all`. Writer → reviewer at every step;
apply the review's fixes before the next step. Automation code is written only on reviewed ground: the test case
review is current (a TC change after it means `check-design` again) and the codebase design is reviewed
(`auto-design` → `check-automation` design mode) before `auto-write`.

## Rules that never change

- **Observable at the pack surface (R2).** UI: what the tester sees. API: the HTTP response. ETL: query results. SQL: what a caller of the DB object gets back. A check
  below the surface is "Out of black-box scope", never a test case that peeks.
- **No invention.** Every statement cites a source line, a requirement ID or a client document; every unknown is a
  `Q-xxx: assumed <value>`. Never pick a side of a conflict silently.
- **Structure follows how the test is run** (the pack layout), never the requirement list. TC titles start with
  `[<Level-1 item>]`.
- **Steps ↔ expected results 1:1**, one behaviour per TC, one baseline precondition plus only this TC's specials.
- **Each variant (R10) and each language (R6.3)** gets its own scenario and TC.
- **IDs are never renumbered or reused;** append with the next free number.
- **Archive, never delete.** Retire a file with `python3 scripts/workspace/archive.py <path> --reason "<why>"`
  (→ `archive/<date>-<slug>/`, indexed in `archive/README.md`); only generated files may be deleted
  ([conventions §11](../standards/conventions.md#11-archive-dont-delete)). The guard refuses a commit that deletes one.
  A new version of a deliverable archives the version it supersedes in the same change set, without being asked.
- **The Excel is generated from the JSON** (`export_testcases.py`); bump `version` on every change.
- **Automated means it ran.** A test that was written but never executed (runner missing, gate held) is reported as
  written / not run, never as automated or runnable; its first run comes before any status, plan or report says so.
- **IT uses mocks / fixtures; ST uses the real systems** (R9). Name environments exactly as `project.json` does.

## Reading large artifacts (token budget)

Never read a file over ~40 KB whole: map it, then read the part the step needs. Tool: `scripts/slice.py`.

| To get | Run |
|---|---|
| A Markdown outline with line ranges and sizes | `python3 scripts/slice.py toc <file.md>` |
| One section | `python3 scripts/slice.py section <file.md> "5.2"` |
| Every line citing some IDs | `python3 scripts/slice.py rows <file.md> TCOND-031 FR-004 Q-010` |
| A suite's shape / one line per TC | `python3 scripts/slice.py tc <target> --stats` / `--list` |
| Some TCs in full | `python3 scripts/slice.py tc <target> --ids … / --scenario TS-012 / --form "<item>" / --priority P1` |
| Templated bodies across a suite | `python3 scripts/slice.py tc <target> --patterns` |
| One sheet of a workbook | `python3 scripts/extract_text.py <file.xlsx> --sheet "<name>"` |

Trust the check scripts for what they check (counts, IDs, formats); spend the reading on what they can't judge.

## Guardrails

[scripts/workspace/guard.py](../scripts/workspace/guard.py) enforces the rules in code: before every Edit / Write, and
before a shell command that visibly writes, moves or removes a path (redirection, `tee`, `sed -i`, `cp`, `mv`, `rm`, …;
best effort), it blocks generated files
(`sources/`, `INDEX.md`, `sources.json`, `0-scope.md` outside MANUAL, every `.xlsx`, `AGENTS.md`, `.agents/`,
`.github/copilot-instructions.md`, `.github/skills/`, `GEMINI.md`, `.gemini/skills/`), `archive/`, the
template-owned files (not in a template-first project) and `project.json › protected_paths`; after an edit of
`test-cases.json` / `2-mindmap.md` it feeds new checker Errors back to the agent, and after an edit of a skill the
`check_skills.py` findings on its output format; when a turn ends (once, as a block)
and at every commit it checks version bumps, exported Excel, Updated stamps, the agents sync, a changed skill's output
contract (`check_skills.py`, 0 Error), the git remote, the git
hooks being on, and the path rules for every committer (`archive/` edits, `protected_paths`, `init_project.py`
output, template-owned files vs the template repo). Agents without these hooks (Codex, GitHub Copilot, Gemini CLI) run
`python3 scripts/workspace/guard.py check` before they finish; the git pre-commit hook catches the rest. Not caught: a
hand edit of a client document, of `sources/parsed/` or of an exported `.xlsx` (`trace_changes.py` reports source
changes). The guard fails open on an internal error or timeout. Errors that already exist are ratcheted in
`.harness/check-baseline.json` (`python3 scripts/workspace/guard.py baseline`, asks first). Bypass a commit check only
knowingly (`git commit --no-verify`, reason in the message).

## Conventions

- **Before adding a folder or file,** read [standards/conventions.md](../standards/conventions.md) §1–2 and put it where
  files of its kind live; generated output stays in its generated place.
- **Reviews of plans are kept, never overwritten:** one dated file per reviewed version, in a reviews folder beside
  the document: `plans/test-plan-reviews/<YYYY-MM-DD>-<slug>-v<version>.md` for a test plan (ours or anyone's),
  `plans/<folder>/reviews/<YYYY-MM-DD>-<slug>.md` for any other planning document. The top of `plans/` holds only the
  files the scripts read there and `onboarding-<topic>.*`. Level-folder reviews keep their fixed names
  (`1-analysis-review.md`, …), because the pipeline checks them.
- **Template-owned files** (rules, packs, scripts, skills; see `template-manifest.json`) are changed in the template
  repo and pulled with `python3 scripts/workspace/template_sync.py --from <template>`. In a **template-first project**
  (`project.json › guard.template_first`) they are changed in the project first, kept project-neutral, with a
  `TEMPLATE_VERSION` bump and its `CHANGELOG.md` entry, then pushed:
  `python3 scripts/workspace/template_sync.py --push --to <template> --apply --merge` (refused when the project is
  behind the template — pull first; commits on a template branch, runs the self-test, merges, tags `v<version>`).
  Promote a change to the template only once a second project needs it, or with a self-test step for it (rule of
  two); until then it is a project rule or lesson. A project's own skills are `.github/skills/project-<name>/` (never
  synced). All projects at a glance: `python3 scripts/workspace/template_status.py`. Project-specific needs go into
  `project.json`, `project/rules.md` or `project/`.
- **Docs header:** `> **Created:** … · **Updated:** YYYY-MM-DD HH:mm:ss (<timezone>)` (24-hour, with seconds); set Updated on every content change.
- **Python** uses the standard library (openpyxl for Excel, PyYAML optional for YAML specs; test frameworks only under
  `automation/`). A missing package or tool (`No module named openpyxl / pytest`, `pdftotext not found`, Playwright):
  run `python3 scripts/workspace/setup_workspace.py --check` and tell the user what it reports; don't pip-install ad hoc.
- **Language:** docs and TCs in `project.document_language`; UI labels exactly as shown.
- **Formats:** dates `YYYY-MM-DD`, date-times `YYYY-MM-DD HH:mm:ss` (24-hour, `project.timezone`), A.D. calendar, amounts `THB 1,250.00`
  ([conventions §10](../standards/conventions.md#10-formats-dates-times-numbers-amounts)); expected results quote the
  surface as shown, in the format a project rule `PR-n` records.
- **Glossary:** a term enters `project/system-map.md` › Glossary only with a source line; domain notes are marked
  *external — verify* and are never a test basis.
- **Memory:** project facts belong in `project.json` and `project/` (shared by every agent and person), not only in an
  agent's personal memory. After a review with repeated findings, run `learn-retro`.
- **Changing a skill:** keep `SKILL.md`, its `assets/` templates and `references/output-rules.md` in step (the
  `**Output:**` line links them); `python3 scripts/check_skills.py <skill>` must show 0 Error (the guard blocks a commit
  otherwise) and should show 0 Warning; design rules in [standards/skill-architecture.md](../standards/skill-architecture.md) §5a.
- **Adding a skill:** list it in the same change set. A template skill gets its row in
  [.github/skills/README.md](skills/README.md) (its group table, the skill count, the diagram and the order
  line when it joins the chain); a project skill (`project-<name>`) gets its line in the project's `README.md`, never
  in the catalog (template-owned, project-neutral). `check_skills.py` warns on a skill listed in neither.
- **Other agents:** after changing this file or a skill, run `python3 scripts/workspace/sync_agents.py` (mirrors in
  `project.json › agents.mirrors`: `codex`, `copilot`, `gemini`).

## Version history and backup

Local git repository (branch `main`). When `project.json › git.local_only` is true: no remote, no push, no hosted repo
until the user says so. Commit after each change set, naming the folder, artifact and version
(`E4 test cases v0.3: review fixes TR-001…007`). The post-commit hook runs `scripts/workspace/backup.py`: suite version tags
(`tc/<folder>/v<version>`), a local mirror and a daily bundle in `../<CODE>-backups/`. After a fresh clone:
`git config core.hooksPath scripts/workspace/git-hooks`. Restore: `git clone ../<CODE>-backups/<CODE>.git <dir>`, or
`git show tc/<folder>/v<version>:<path>`.
