# Changelog

> **Created:** 2026-11-05 15:36:09 (UTC+7) · **Updated:** 2026-11-05 16:51:46 (UTC+7)

## Unreleased

### Added

- `--page` is optional on `scan` and `stability`: the name comes from the URL when it is left out.

### Fixed

- A page with only buttons outside a form, such as a documentation site, was reported as `NO_FIELDS`. Those buttons are now
  scanned when a page has nothing else, and `--all-buttons` includes them on any page.
- A page name with a hyphen produced a Page Object file that Python could not import.

## 1.0.0 (2026-11-05)

First release. Works on any website; nothing in it depends on a particular site.

### Added

- `scan`, `review`, `generate`, `validate`, `apply-fixes`: the locator registry workflow, with verified locators and
  fix proposals you approve.
- `stability`: compares several scans, optionally as a second user, and flags locators that change.
- `settings` and `--types`: choose which locator types are used, and their priority.
- `login`: sign in by hand on any site and save the session. The tool never sees a password.
- Smart locators: anchored to nearby text, partial match and attribute, used only when a field has nothing better.
- Field settling: waits for the number of fields to hold, so a page still loading is not scanned half loaded.
- HTML reports grouped by page region, with a CSS & XPath panel, a locator type settings form and copyable code.
- `--version`, `python -m locatorscan`, and a release build that tests the built package in a clean environment.

### Changed from the 0.1.0 demo

- Renamed from `locscan` to `locatorscan`: the command, the Python package and the project folder.
- Project layout: one root with `src/`, `tests/`, `docs/`, `examples/`, `skills/` and `scripts/`.
- `report.py` became the `locatorscan.report` package, with its CSS and JavaScript as separate files.

### Known limitations

See [SYSTEM-DESIGN § Known limitations](docs/SYSTEM-DESIGN.md#12-known-limitations).
