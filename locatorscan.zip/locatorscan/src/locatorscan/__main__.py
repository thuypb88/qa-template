"""`python -m locatorscan` is the same as the `locatorscan` command."""

import sys

from locatorscan.cli import main

sys.exit(main())
