"""The registry: one YAML file per page under `locators/`, kept in git. The single source of truth."""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import yaml
from pydantic import ValidationError

from locatorscan.config import Workspace
from locatorscan.errors import ConfigError
from locatorscan.models import (
    FieldRecord,
    FixProposal,
    PageStability,
    PageValidation,
    RegistryField,
    RegistryPage,
    ScanResult,
)


def _page_file(ws: Workspace, page: str) -> Path:
    return ws.registry_dir / f"{page}.yaml"


def load(ws: Workspace, page: str) -> RegistryPage | None:
    path = _page_file(ws, page)
    if not path.exists():
        return None
    try:
        return RegistryPage.model_validate(yaml.safe_load(path.read_text(encoding="utf-8")))
    except (yaml.YAMLError, ValidationError) as exc:
        raise ConfigError(f"Registry file {path} is invalid: {exc}") from exc


def save(ws: Workspace, registry_page: RegistryPage) -> Path:
    path = _page_file(ws, registry_page.page)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = registry_page.model_dump(mode="json", exclude_none=True)
    header = (
        f"# Locator registry for page '{registry_page.page}'.\n"
        "# Edit through `locatorscan review` / `locatorscan apply-fixes`.\n"
    )
    path.write_text(header + yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=200), encoding="utf-8")
    return path


def pages(ws: Workspace) -> list[str]:
    if not ws.registry_dir.exists():
        return []
    return sorted(p.stem for p in ws.registry_dir.glob("*.yaml"))


def to_registry_field(record: FieldRecord, verified_on: str) -> RegistryField:
    if record.primary is None:
        raise ValueError(f"Field {record.key} has no verified locator and cannot enter the registry")
    return RegistryField(
        label=record.label,
        group=record.group,
        kind=record.kind,
        primary=record.primary,
        fallbacks=record.fallbacks,
        xpath=record.xpath,
        frame_path=record.frame_path,
        in_shadow_dom=record.in_shadow_dom,
        fingerprint=record.fingerprint,
        last_verified=verified_on,
    )


def merge_scan(existing: RegistryPage | None, scan: ScanResult, accepted: dict[str, FieldRecord]) -> RegistryPage:
    """Add or replace the accepted fields. Fields already in the registry but not accepted stay as they are."""
    verified_on = scan.scanned_at[:10]
    fields = dict(existing.fields) if existing else {}
    for key, record in accepted.items():
        fields[key] = to_registry_field(record, verified_on)
    return RegistryPage(page=scan.page, url=scan.url, app_version=scan.app_version, fields=fields)


def apply_fix(field: RegistryField, fix: FixProposal) -> RegistryField:
    return field.model_copy(
        update={
            "primary": fix.new_primary,
            "fallbacks": fix.new_fallbacks,
            "xpath": fix.new_xpath,
            "frame_path": fix.new_frame_path,
            "fingerprint": fix.new_fingerprint,
            "last_verified": date.today().isoformat(),
        }
    )


# ---------------------------------------------------------------- scan / validation files in out/


def scan_file(ws: Workspace, page: str) -> Path:
    return ws.out_dir / "scans" / f"{page}.json"


def validation_file(ws: Workspace, page: str) -> Path:
    return ws.out_dir / "validation" / f"{page}.json"


def stability_file(ws: Workspace, page: str) -> Path:
    return ws.out_dir / "stability" / f"{page}.json"


def write_json(path: Path, model: ScanResult | PageValidation | PageStability) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(model.model_dump(mode="json"), indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def read_scan(ws: Workspace, page: str) -> ScanResult:
    path = scan_file(ws, page)
    if not path.exists():
        raise ConfigError(f"No scan found for page '{page}'. Run `locatorscan scan --page {page} --url ...` first.")
    return ScanResult.model_validate_json(path.read_text(encoding="utf-8"))


def read_validation(ws: Workspace, page: str) -> PageValidation:
    path = validation_file(ws, page)
    if not path.exists():
        raise ConfigError(f"No validation found for page '{page}'. Run `locatorscan validate --page {page}` first.")
    return PageValidation.model_validate_json(path.read_text(encoding="utf-8"))
