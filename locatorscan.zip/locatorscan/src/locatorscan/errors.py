"""Error hierarchy. Each error carries the code and exit code from the design spec's error table."""

from __future__ import annotations


class LocatorScanError(Exception):
    """Base error. `code` is the stable error name; `exit_code` is what the CLI returns."""

    code: str = "ERROR"
    exit_code: int = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class NavError(LocatorScanError):
    code = "NAV_ERROR"
    exit_code = 2


class PageTimeoutError(LocatorScanError):
    code = "TIMEOUT"
    exit_code = 3


class AuthRequiredError(LocatorScanError):
    code = "AUTH_REQUIRED"
    exit_code = 4


class BlockedError(LocatorScanError):
    code = "BLOCKED"
    exit_code = 5


class NoFieldsError(LocatorScanError):
    code = "NO_FIELDS"
    exit_code = 6


class LocatorsBrokenError(LocatorScanError):
    """Raised by `validate` when at least one registry locator is broken or no longer unique."""

    code = "LOCATORS_BROKEN"
    exit_code = 7


class ConfigError(LocatorScanError):
    code = "CONFIG_ERROR"
    exit_code = 8


class DynamicLocatorsError(LocatorScanError):
    """Raised by `stability` when a primary locator changed between runs or relies on data-driven text."""

    code = "DYNAMIC_LOCATORS"
    exit_code = 9
