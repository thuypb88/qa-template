"""locatorscan: Form & Input Locator Scanner."""

__version__ = "1.0.0"
