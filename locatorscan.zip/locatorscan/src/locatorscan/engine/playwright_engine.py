"""Default engine: Playwright drives the browser; discover.js finds fields inside each frame;
Python verifies every candidate matches exactly one element, and the right one."""

from __future__ import annotations

import logging
import re
import time
from collections.abc import Callable, Generator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from playwright.sync_api import Error as PlaywrightError
from playwright.sync_api import Frame, Page, sync_playwright
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from locatorscan import ranking
from locatorscan.config import Workspace
from locatorscan.errors import AuthRequiredError, BlockedError, NavError, NoFieldsError, PageTimeoutError
from locatorscan.locators import build, in_frames
from locatorscan.models import (
    Candidate,
    FieldRecord,
    FieldState,
    FieldStatus,
    FieldValidation,
    Fingerprint,
    FixProposal,
    PageValidation,
    RegistryField,
    RegistryPage,
    ScanResult,
)
from locatorscan.stability import VOLATILE_TEXT_WARNING, is_volatile_text

log = logging.getLogger(__name__)

_FIELD_SELECTOR = (
    'input,select,textarea,button,[contenteditable=""],[contenteditable="true"],'
    "[role=textbox],[role=searchbox],[role=spinbutton],[role=combobox],[role=listbox],"
    "[role=checkbox],[role=radio],[role=switch],[role=button]"
)
_COUNT_FIELDS_JS = """(selector) => {
  let count = 0;
  const walk = (root) => {
    count += root.querySelectorAll(selector).length;
    root.querySelectorAll("*").forEach((el) => { if (el.shadowRoot) walk(el.shadowRoot); });
  };
  walk(document);
  return count;
}"""
_SETTLE_POLL_MS = 100
_SETTLE_LIMIT_S = 15.0  # a page that never stops changing must not use up the scan budget
_EMPTY_GRACE_FACTOR = 5  # an empty page may still be loading, so it gets longer before it counts as settled
_DISCOVER_JS = (Path(__file__).parent / "discover.js").read_text(encoding="utf-8")
_TARGET_INDEX_JS = "(els, idx) => els.indexOf(window.__locatorscan.fields[idx])"
_IDENTITY_JS = "(el, i) => !!window.__locatorscan && window.__locatorscan.fields[i] === el"
_INDEX_JS = "el => (window.__locatorscan ? window.__locatorscan.fields.indexOf(el) : -1)"
_FRAME_SELECTOR_JS = """el => {
  if (el.id && !/\\d{4,}/.test(el.id)) return 'iframe#' + CSS.escape(el.id);
  const n = el.getAttribute('name'); if (n) return `iframe[name="${n}"]`;
  const t = el.getAttribute('title'); if (t) return `iframe[title="${t}"]`;
  return 'iframe >> nth=' + [...el.ownerDocument.querySelectorAll('iframe')].indexOf(el);
}"""
_BLOCKED_JS = """() => {
  const src = [...document.querySelectorAll('iframe')].map(f => f.src || '').join(' ');
  if (/recaptcha|hcaptcha|challenges\\.cloudflare\\.com|turnstile/i.test(src)) return true;
  const text = document.body ? document.body.innerText : '';
  return /verify you are (a )?human|are you a robot|unusual traffic/i.test(text);
}"""
_WEAK_LABEL_SOURCES = {"placeholder", "title", "name", "none"}
_LOAD_STATES = {"load", "domcontentloaded", "networkidle"}

RawField = dict[str, Any]


@dataclass
class FrameScan:
    frame: Frame
    path: list[str]
    fields: list[RawField]


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class PlaywrightEngine:
    def __init__(self, workspace: Workspace) -> None:
        self.ws = workspace
        self.cfg = workspace.config
        self._deny = [re.compile(p) for p in self.cfg.deny_list]

    # ------------------------------------------------------------ browser

    @contextmanager
    def session(self) -> Generator[Page, None, None]:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=self.cfg.headless, channel=self.cfg.browser_channel)
            state = self.ws.storage_state
            context = browser.new_context(
                viewport={"width": self.cfg.viewport.width, "height": self.cfg.viewport.height},
                storage_state=str(state) if state and state.exists() else None,
            )
            page = context.new_page()
            page.set_default_timeout(self.cfg.timeout_ms)
            try:
                yield page
            finally:
                context.close()
                browser.close()

    def save_session(self, url: str, path: Path, wait: Callable[[], object]) -> None:
        """Open a browser for a person to sign in, then store the session. No site's form is assumed."""
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=self.cfg.headless, channel=self.cfg.browser_channel)
            context = browser.new_context()
            page = context.new_page()
            page.set_default_timeout(self.cfg.timeout_ms)
            try:
                page.goto(url, wait_until="domcontentloaded")
            except PlaywrightError as exc:
                browser.close()
                raise NavError(f"Could not open {url}: {exc.message.splitlines()[0]}") from exc
            wait()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.parent.chmod(0o700)
            context.storage_state(path=str(path))
            path.chmod(0o600)
            browser.close()

    def load(self, page: Page, url: str) -> None:
        """Open the page and wait until it is ready. Raises the spec's error codes on failure."""
        try:
            response = page.goto(url, wait_until="domcontentloaded", timeout=self.cfg.timeout_ms)
        except PlaywrightTimeoutError as exc:
            raise PageTimeoutError(f"Timed out opening {url}") from exc
        except PlaywrightError as exc:
            raise NavError(f"Could not open {url}: {exc.message.splitlines()[0]}") from exc
        if response is not None and response.status >= 400:
            raise NavError(f"{url} returned HTTP {response.status}")
        try:
            if self.cfg.wait_for in _LOAD_STATES:
                page.wait_for_load_state(self.cfg.wait_for)  # type: ignore[arg-type]
            else:
                page.wait_for_selector(self.cfg.wait_for, state="attached")
        except PlaywrightTimeoutError as exc:
            raise PageTimeoutError(f"Page never reached ready state '{self.cfg.wait_for}'") from exc
        requested = url.lower()
        current = page.url.lower()
        for pattern in self.cfg.login_url_patterns:
            if pattern in current and pattern not in requested:
                raise AuthRequiredError(f"Redirected to a login page ({page.url}). Refresh the stored session.")
        if page.evaluate(_BLOCKED_JS):
            raise BlockedError("CAPTCHA or bot protection detected. The scan stops here; it never bypasses it.")
        self._wait_until_settled(page)

    def _count_fields(self, page: Page) -> int:
        total = 0
        for frame in page.frames:
            try:
                total += int(frame.evaluate(_COUNT_FIELDS_JS, _FIELD_SELECTOR))
            except PlaywrightError:  # a frame navigating or going away: the next poll counts it
                continue
        return total

    def _wait_until_settled(self, page: Page) -> None:
        """Wait until the field count holds, so a page still filling in is not scanned half loaded."""
        settle = self.cfg.settle_ms / 1000
        if settle == 0:
            return
        limit = time.monotonic() + min(_SETTLE_LIMIT_S, self.cfg.timeout_ms / 2000)
        last = self._count_fields(page)
        since = time.monotonic()
        while time.monotonic() < limit:
            page.wait_for_timeout(_SETTLE_POLL_MS)
            count = self._count_fields(page)
            if count != last:
                last, since = count, time.monotonic()
            elif time.monotonic() - since >= (settle if count else settle * _EMPTY_GRACE_FACTOR):
                return
        log.warning("Fields were still changing when the wait ended (%d so far); the scan may be incomplete", last)

    # ------------------------------------------------------------ discovery

    def _frame_path(self, frame: Frame) -> list[str]:
        path: list[str] = []
        current = frame
        while current.parent_frame is not None:
            path.insert(0, current.frame_element().evaluate(_FRAME_SELECTOR_JS))
            current = current.parent_frame
        return path

    def discover(self, page: Page) -> tuple[list[FrameScan], int, list[str]]:
        opts = {
            "scope": self.cfg.scope,
            "testAttributes": self.cfg.test_attributes,
            "denyList": self.cfg.deny_list,
            "volatileText": self.cfg.volatile_text,
            "standaloneButtons": self.cfg.standalone_buttons,
        }
        scans: list[FrameScan] = []
        skipped = 0
        errors: list[str] = []
        for frame in page.frames:
            try:
                path = self._frame_path(frame)
                result: dict[str, Any] = frame.evaluate(_DISCOVER_JS, opts)
            except PlaywrightError as exc:
                errors.append(f"FRAME_BLOCKED {frame.url}: {exc.message.splitlines()[0]}")
                continue
            skipped += int(result["skippedHidden"])
            scans.append(FrameScan(frame=frame, path=path, fields=list(result["fields"])))
        return scans, skipped, errors

    def _verify(self, frame: Frame, raw: RawField) -> list[Candidate]:
        checked: list[Candidate] = []
        for c in raw["candidates"]:
            cand = Candidate.model_validate(c)
            loc = build(frame, cand)
            try:
                cand.match_count = loc.count()
                cand.is_target = cand.match_count == 1 and bool(loc.evaluate(_IDENTITY_JS, raw["idx"]))
                if cand.is_target:
                    cand.target_index = 0
                elif cand.match_count > 1:
                    position = int(loc.evaluate_all(_TARGET_INDEX_JS, raw["idx"]))
                    cand.target_index = position if position >= 0 else None
            except PlaywrightError:
                cand.match_count = 0  # selector the engine could not evaluate: rejected
            checked.append(cand)
        return checked

    def _fingerprint(self, raw: RawField) -> Fingerprint:
        attrs = raw["attrs"]
        raw_id = attrs.get("id")
        stable_id = raw_id if raw_id and not any(d.search(raw_id) for d in self._deny) else None
        return Fingerprint(
            tag=raw["tag"],
            input_type=raw["inputType"],
            role=raw["role"],
            label=raw["label"],
            name=attrs.get("name"),
            id=stable_id,
            group=raw["group"],
            placeholder=attrs.get("placeholder"),
        )

    def _warnings(
        self, raw: RawField, cands: list[Candidate], has_primary: bool, primary_strategy: str | None
    ) -> list[str]:
        w: list[str] = []
        if raw["labelSource"] in _WEAK_LABEL_SOURCES:
            w.append("UNLABELLED")
        if raw["labelSource"] == "text-before":
            w.append("LABEL_FROM_LAYOUT")
        if not raw["native"]:
            w.append("CUSTOM_WIDGET")
        if raw["inShadow"]:
            w.append("SHADOW_DOM")
        if not raw["state"]["visible"]:
            w.append("HIDDEN")
        if not has_primary:
            eligible = (c for c in cands if ranking.eligible(c, self.cfg.locator_types))
            w.append("NON_UNIQUE" if any(c.match_count > 1 for c in eligible) else "NO_LOCATOR")
        if primary_strategy == "positional":
            w.append("POSITIONAL_ONLY")
        if (
            primary_strategy
            and ranking.uses_visible_text(primary_strategy)
            and is_volatile_text(raw["label"], self.cfg.volatile_text)
        ):
            w.append(VOLATILE_TEXT_WARNING)
        return w

    # ------------------------------------------------------------ scan

    def scan(self, url: str, page_name: str) -> ScanResult:
        deadline = time.monotonic() + self.cfg.timeout_ms / 1000
        with self.session() as page:
            self.load(page, url)
            scans, skipped, errors = self.discover(page)
            pending: list[tuple[FrameScan, RawField]] = [(s, f) for s in scans for f in s.fields]
            if not pending:
                raise NoFieldsError(f"No form fields found inside '{self.cfg.scope}' on {url}")
            status: str = "OK"
            built: list[tuple[FrameScan, RawField, list[Candidate]]] = []
            for fscan, raw in pending:
                if time.monotonic() > deadline:
                    status = "PARTIAL"
                    log.warning(
                        "Scan budget used up after %d of %d fields; keeping partial results", len(built), len(pending)
                    )
                    break
                built.append((fscan, raw, self._verify(fscan.frame, raw)))
        keys = ranking.make_keys(
            (raw["label"], raw["group"], raw["attrs"].get("name") or raw["attrs"].get("id") or raw["tag"])
            for _, raw, _ in built
        )
        records: list[FieldRecord] = []
        for key, (fscan, raw, cands) in zip(keys, built, strict=True):
            primary, fallbacks, xpath = ranking.choose(cands, self.cfg.locator_types)
            records.append(
                FieldRecord(
                    key=key,
                    label=raw["label"],
                    label_source=raw["labelSource"],
                    group=raw["group"],
                    kind=raw["kind"],
                    tag=raw["tag"],
                    input_type=raw["inputType"],
                    role=raw["role"],
                    state=FieldState.model_validate(raw["state"]),
                    frame_path=fscan.path,
                    in_shadow_dom=bool(raw["inShadow"]),
                    primary=primary,
                    fallbacks=fallbacks,
                    xpath=xpath,
                    candidates=cands,
                    fingerprint=self._fingerprint(raw),
                    warnings=self._warnings(raw, cands, primary is not None, primary.strategy if primary else None),
                )
            )
        return ScanResult(
            page=page_name,
            url=url,
            app_version=self.cfg.app_version,
            scanned_at=_now(),
            status="PARTIAL" if status == "PARTIAL" else "OK",
            fields=records,
            locator_types=self.cfg.locator_types,
            skipped_hidden_inputs=skipped,
            frame_errors=errors,
        )

    # ------------------------------------------------------------ validate

    def _proposal(self, fscan: FrameScan, raw: RawField, reason: str, sim: float) -> FixProposal | None:
        primary, fallbacks, xpath = ranking.choose(self._verify(fscan.frame, raw), self.cfg.locator_types)
        if primary is None:
            return None
        return FixProposal(
            reason=reason,
            matched_label=raw["label"],
            similarity=sim,
            new_primary=primary,
            new_fallbacks=fallbacks,
            new_xpath=xpath,
            new_frame_path=fscan.path,
            new_fingerprint=self._fingerprint(raw),
        )

    def _check_field(self, page: Page, field: RegistryField) -> tuple[FieldStatus, str | None, int, str]:
        """Try primary then fallbacks. Returns (status, used, discovered index or -1, detail)."""
        if field.frame_path and page.locator(field.frame_path[0]).count() == 0:
            return "MISSING_FRAME", None, -1, f"frame {field.frame_path[0]} not found"
        scope = in_frames(page, field.frame_path)
        attempts = [("primary", field.primary)] + [(f"fallback[{i + 1}]", s) for i, s in enumerate(field.fallbacks)]
        counts: list[str] = []
        for used, spec in attempts:
            loc = build(scope, spec)
            try:
                n = loc.count()
            except PlaywrightError:
                n = 0
            counts.append(f"{used}={n}")
            if n == 1:
                idx = int(loc.evaluate(_INDEX_JS))
                return ("OK" if used == "primary" else "FALLBACK_USED"), used, idx, ", ".join(counts)
        status: FieldStatus = "NON_UNIQUE" if any(not c.endswith("=0") for c in counts) else "BROKEN"
        return status, None, -1, "matches: " + ", ".join(counts)

    def validate(self, registry_page: RegistryPage, url: str) -> PageValidation:
        with self.session() as page:
            self.load(page, url)
            scans, _, _ = self.discover(page)
            by_path = {tuple(s.path): s for s in scans}
            claimed: set[tuple[tuple[str, ...], int]] = set()
            results: list[FieldValidation] = []
            needs_heal: list[tuple[FieldValidation, RegistryField]] = []
            for key, field in registry_page.fields.items():
                status, used, idx, detail = self._check_field(page, field)
                result = FieldValidation(key=key, label=field.label, status=status, used=used, detail=detail)
                path = tuple(field.frame_path)
                if idx >= 0:
                    claimed.add((path, idx))
                    fscan = by_path.get(path)
                    if status == "FALLBACK_USED" and fscan is not None and idx < len(fscan.fields):
                        result.proposal = self._proposal(
                            fscan,
                            fscan.fields[idx],
                            "primary failed; field found by fallback, new primary suggested",
                            1.0,
                        )
                else:
                    needs_heal.append((result, field))
                results.append(result)
            for result, field in needs_heal:
                best: tuple[float, FrameScan, RawField] | None = None
                for fscan in scans:
                    for raw in fscan.fields:
                        if (tuple(fscan.path), raw["idx"]) in claimed:
                            continue
                        sim = ranking.similarity(field.fingerprint, self._fingerprint(raw))
                        if sim >= ranking.HEAL_THRESHOLD and (best is None or sim > best[0]):
                            best = (sim, fscan, raw)
                if best is not None:
                    sim, fscan, raw = best
                    claimed.add((tuple(fscan.path), raw["idx"]))
                    result.proposal = self._proposal(fscan, raw, "closest fingerprint match", sim)
            new_fields = [
                str(raw["label"] or raw["attrs"].get("name") or raw["tag"])
                for fscan in scans
                for raw in fscan.fields
                if (tuple(fscan.path), raw["idx"]) not in claimed
            ]
        return PageValidation(
            page=registry_page.page,
            url=url,
            registry_version=registry_page.app_version,
            checked_version=self.cfg.app_version,
            checked_at=_now(),
            results=results,
            new_fields=new_fields,
        )
