"""The engine interface. Our Playwright scanner is the default; an MCP-backed engine
(SelectorsHub or LocatorLabs) can be added later without touching the registry or CLI."""

from __future__ import annotations

from typing import Protocol

from locatorscan.models import PageValidation, RegistryPage, ScanResult


class LocatorEngine(Protocol):
    def scan(self, url: str, page_name: str) -> ScanResult:
        """Find every form field on the page and return verified, ranked locators."""
        ...

    def validate(self, registry_page: RegistryPage, url: str) -> PageValidation:
        """Re-check stored locators on the live page and propose fixes for broken ones."""
        ...
