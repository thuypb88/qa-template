"""Locator engines. The registry and CLI only depend on the LocatorEngine interface."""

from locatorscan.engine.base import LocatorEngine
from locatorscan.engine.playwright_engine import PlaywrightEngine

__all__ = ["LocatorEngine", "PlaywrightEngine"]
