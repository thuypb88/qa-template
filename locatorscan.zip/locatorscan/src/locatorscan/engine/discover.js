// In-page field discovery. Runs inside one frame via frame.evaluate(source, opts).
// Read-only: it never types, clicks or changes the DOM. Found elements are kept in
// window.__locatorscan.fields so Python can check that a candidate locator hits the same element.
(opts) => {
  const deny = opts.denyList.map((p) => new RegExp(p));
  const isDenied = (v) => !v || deny.some((r) => r.test(v));
  const norm = (s) => (s || "").replace(/\s+/g, " ").trim(); // \s covers &nbsp;
  const clean = (s) => norm(s).replace(/[\s:*]+$/, "").trim();
  const xq = (s) => {
    if (!s.includes("'")) return `'${s}'`;
    if (!s.includes('"')) return `"${s}"`;
    return "concat('" + s.split("'").join(`', "'", '`) + "')";
  };
  const cssStr = (s) => '"' + s.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';

  const NATIVE = new Set(["input", "select", "textarea", "button"]);
  const FIELD_SEL = [
    "input", "select", "textarea", "button",
    '[contenteditable=""]', '[contenteditable="true"]',
    "[role=textbox]", "[role=searchbox]", "[role=spinbutton]", "[role=combobox]", "[role=listbox]",
    "[role=checkbox]", "[role=radio]", "[role=switch]", "[role=button]",
  ].join(",");
  const GROUP_SEL = "fieldset, form, [role=form], [role=group], [role=dialog], [role=region], section";
  const STRONG_LABELS = new Set(["label[for]", "label-wrap", "aria-labelledby", "aria-label", "text"]);

  const scopeEl = document.querySelector(opts.scope) || document.body;
  if (!scopeEl) return { fields: [], skippedHidden: 0 };

  // ---- collect, walking into open shadow roots
  const found = [];
  const standalone = []; // buttons outside any form or group: page chrome, unless the page has nothing else
  let skippedHidden = 0;
  const collect = (root, inShadow) => {
    for (const el of root.querySelectorAll(FIELD_SEL)) {
      const tag = el.tagName.toLowerCase();
      if (tag === "input" && (el.type || "").toLowerCase() === "hidden") { skippedHidden++; continue; }
      // A custom widget that wraps a native control: keep the native control only.
      if (!NATIVE.has(tag) && el.querySelector("input, select, textarea")) continue;
      if (tag === "button" || el.getAttribute("role") === "button") {
        const inGroup = el.closest(GROUP_SEL) || (el.getRootNode().host || null);
        if (!inGroup && (el.type || "").toLowerCase() !== "submit" && opts.standaloneButtons !== "always") {
          standalone.push({ el, inShadow });
          continue;
        }
      }
      found.push({ el, inShadow });
    }
    for (const host of root.querySelectorAll("*")) {
      if (host.shadowRoot) collect(host.shadowRoot, true);
    }
  };
  collect(scopeEl, false);
  if (scopeEl.shadowRoot) collect(scopeEl.shadowRoot, true);
  if (!found.length) found.push(...standalone);

  // ---- helpers
  const implicitRole = (el) => {
    const explicit = el.getAttribute("role");
    if (explicit) return explicit;
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "text").toLowerCase();
    if (tag === "textarea") return "textbox";
    if (tag === "select") return el.multiple || el.size > 1 ? "listbox" : "combobox";
    if (tag === "button") return "button";
    if (el.isContentEditable) return "textbox";
    if (tag !== "input") return null;
    if (["text", "email", "tel", "url"].includes(type)) return "textbox";
    if (type === "search") return "searchbox";
    if (type === "number") return "spinbutton";
    if (type === "checkbox") return "checkbox";
    if (type === "radio") return "radio";
    if (["submit", "button", "reset"].includes(type)) return "button";
    return null; // password, date, file...: no reliable role locator
  };

  const textWithoutControls = (node) => {
    const copy = node.cloneNode(true);
    copy.querySelectorAll("input, select, textarea, button, option").forEach((c) => c.remove());
    return norm(copy.textContent);
  };

  const resolveLabel = (el) => {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (tag === "button" || (tag === "input" && ["submit", "button", "reset"].includes(type)) || el.getAttribute("role") === "button") {
      const t = tag === "input" ? norm(el.value) : norm(el.textContent);
      const al = el.getAttribute("aria-label");
      if (al) return { label: clean(al), raw: norm(al), source: "aria-label", labelEl: null };
      if (t) return { label: t, raw: t, source: "text", labelEl: null };
    }
    if (el.labels && el.labels.length) {
      const lab = el.labels[0];
      const raw = textWithoutControls(lab);
      if (raw) return { label: clean(raw), raw, source: lab.contains(el) ? "label-wrap" : "label[for]", labelEl: lab };
    }
    const lb = el.getAttribute("aria-labelledby");
    if (lb) {
      const rootNode = el.getRootNode();
      const raw = norm(lb.split(/\s+/).map((id) => {
        const n = rootNode.getElementById ? rootNode.getElementById(id) : document.getElementById(id);
        return n ? n.textContent : "";
      }).join(" "));
      if (raw) return { label: clean(raw), raw, source: "aria-labelledby", labelEl: null };
    }
    const al = el.getAttribute("aria-label");
    if (al) return { label: clean(al), raw: norm(al), source: "aria-label", labelEl: null };
    // Visible text just before the field (grid-style screens): walk up to 3 levels.
    let node = el;
    for (let depth = 0; depth < 3 && node && node !== scopeEl; depth++) {
      let sib = node.previousElementSibling;
      for (let hops = 0; sib && hops < 2; hops++, sib = sib.previousElementSibling) {
        if (sib.matches(FIELD_SEL) || sib.querySelector(FIELD_SEL)) break;
        const t = norm(sib.textContent);
        if (t && t.length <= 60) return { label: clean(t), raw: t, source: "text-before", labelEl: sib };
      }
      node = node.parentElement;
    }
    for (const attr of ["placeholder", "title", "name"]) {
      const v = el.getAttribute(attr);
      if (v) return { label: clean(v), raw: norm(v), source: attr, labelEl: null };
    }
    return { label: null, raw: null, source: "none", labelEl: null };
  };

  const headingOf = (g) => {
    for (const c of g.children) {
      if (/^H[1-6]$/.test(c.tagName)) return { text: norm(c.textContent), tag: c.tagName.toLowerCase() };
    }
    return null;
  };

  const resolveGroup = (el) => {
    let start = el;
    let g = start.closest(GROUP_SEL);
    while (!g && start.getRootNode().host) {
      start = start.getRootNode().host;
      g = start.closest(GROUP_SEL);
    }
    while (g) {
      const tag = g.tagName.toLowerCase();
      if (tag === "fieldset") {
        const legend = g.querySelector(":scope > legend");
        if (legend && norm(legend.textContent)) {
          const n = norm(legend.textContent);
          return { name: clean(n), xpath: `//fieldset[legend[normalize-space()=${xq(n)}]]` };
        }
      }
      const al = g.getAttribute("aria-label");
      if (al) return { name: clean(al), xpath: `//${tag}[@aria-label=${xq(al)}]` };
      const h = headingOf(g);
      if (h && h.text) {
        return { name: clean(h.text), xpath: `//${tag}[${h.tag}[normalize-space()=${xq(h.text)}]]` };
      }
      if (tag === "form") {
        const fid = g.getAttribute("id");
        if (fid && !isDenied(fid)) return { name: fid, xpath: `//form[@id=${xq(fid)}]` };
        const fname = g.getAttribute("name");
        if (fname) return { name: fname, xpath: `//form[@name=${xq(fname)}]` };
      }
      g = g.parentElement ? g.parentElement.closest(GROUP_SEL) : null;
    }
    return { name: null, xpath: null };
  };

  const absoluteXPath = (el) => {
    const parts = [];
    let n = el;
    while (n && n.nodeType === 1) {
      const tag = n.tagName.toLowerCase();
      let i = 1;
      for (let s = n.previousElementSibling; s; s = s.previousElementSibling) if (s.tagName === n.tagName) i++;
      parts.unshift(`${tag}[${i}]`);
      n = n.parentElement;
    }
    return "/" + parts.join("/");
  };

  // ---- reference locators: shown in the report for people to copy, never chosen as primary (ranking.py)
  const LANDMARK = new Set(["header", "nav", "main", "aside", "footer", "form", "fieldset", "section", "article", "dialog"]);
  const CLASS_DENY = [/\d{4,}/, /[0-9a-f]{8}-/, /^(css|sc|jsx|emotion)-/, /^(active|show|focus|hover|open|selected|disabled)$/];
  const MAX_PATH_DEPTH = 5;
  const stableClasses = (el) => [...el.classList].filter((c) => !CLASS_DENY.some((r) => r.test(c)));
  const sameTagIndex = (el) => {
    let i = 1;
    for (let s = el.previousElementSibling; s; s = s.previousElementSibling) if (s.tagName === el.tagName) i++;
    return i;
  };
  const hasSameTagSibling = (el) =>
    sameTagIndex(el) > 1 || [...(el.parentElement ? el.parentElement.children : [])].some(
      (s) => s !== el && s.tagName === el.tagName);
  const tagOf = (el) => el.tagName.toLowerCase();
  const isRoot = (el) => ["html", "body"].includes(tagOf(el));
  const step = (el) => (hasSameTagSibling(el) ? `${tagOf(el)}[${sameTagIndex(el)}]` : tagOf(el));
  // The element and its ancestors, innermost first, up to the nearest landmark or MAX_PATH_DEPTH.
  const nearChain = (el) => {
    const chain = [el];
    for (let n = el.parentElement; n && !isRoot(n) && chain.length < MAX_PATH_DEPTH; n = n.parentElement) {
      chain.push(n);
      if (LANDMARK.has(tagOf(n))) break;
    }
    return chain;
  };
  const fullChain = (el) => {
    const chain = [];
    for (let n = el; n; n = n.parentElement) chain.push(n);
    return chain;
  };
  const addReferenceLocators = (el, role, add, xp) => {
    const classes = stableClasses(el);
    if (classes.length) {
      add("css", classes.map((c) => `.${CSS.escape(c)}`).join(""), "class-names", "OK", 0.1,
        `Classes: ${classes.join(", ")}`);
    }
    const cssPath = nearChain(el).reverse().map((n) => {
      const c = stableClasses(n)[0];
      return c ? `${tagOf(n)}.${CSS.escape(c)}` : tagOf(n);
    }).join(" > ");
    add("css", cssPath, "css-path", "OK", 0.1, "CSS selector");
    xp("//" + nearChain(el).reverse().map(step).join("/"), "xpath-path", "OK", 0.1, "Structural XPath");
    const full = fullChain(el).reverse();
    xp("/" + full.map(step).join("/"), "xpath-absolute", "OK", 0.1, "Full path from root - breaks easily");
    const belowBody = full.filter((n) => !isRoot(n));
    xp("//" + belowBody.map((n) => `${tagOf(n)}[position()=${sameTagIndex(n)}]`).join("/"), "xpath-position", "OK", 0.1,
      "Index-based using position()");
    if (role) add("role", role, "role-only", "OK", 0.1, "Role only (no name) - may match multiple elements");
  };

  // ---- smart locators: survive changing positions and generated ids
  const volatilePatterns = (opts.volatileText || []).flatMap((p) => {
    try { return [new RegExp(p)]; } catch { return []; }
  });
  const MAX_ANCHOR_DEPTH = 12;
  const MAX_ANCHOR_LENGTH = 60;
  // Text that names one thing, not a number or a value that changes with data or user.
  const isAnchorText = (t) => t.length >= 2 && t.length <= MAX_ANCHOR_LENGTH && /\p{L}/u.test(t) &&
    !/(^|\s)[\d.,]+(\s|$)/u.test(t) && // "59 To Review" is a count that moves; "ACC-01-MAIN" is a name
    !volatilePatterns.some((r) => r.test(t));
  const leafTexts = (() => {
    const cache = new Map();
    return (container) => {
      if (cache.has(container)) return cache.get(container);
      const out = [];
      for (const n of container.querySelectorAll("*")) {
        if (n.children.length === 0 && !NATIVE.has(tagOf(n)) && n.closest("button") === null) {
          const text = norm(n.textContent);
          if (text) out.push({ el: n, text });
        }
      }
      cache.set(container, out);
      return out;
    };
  })();
  const repeatedSiblings = (n) => [...(n.parentElement ? n.parentElement.children : [])].filter(
    (s) => s !== n && s.tagName === n.tagName);
  // Repeated ancestors holding visible text that none of their siblings has: a card and its title, a row and its key.
  const SEMANTIC_REPEAT = new Set(["article", "li", "tr", "section"]);
  const findAnchors = (el) => {
    const found = [];
    let n = el.parentElement;
    for (let depth = 0; n && !isRoot(n) && depth < MAX_ANCHOR_DEPTH; depth++, n = n.parentElement) {
      const siblings = repeatedSiblings(n);
      if (!siblings.length) continue;
      const others = new Set(siblings.flatMap((s) => leafTexts(s).map((x) => x.text)));
      const unique = leafTexts(n).filter((x) => isAnchorText(x.text) && !others.has(x.text) && isVisible(x.el));
      const isTitle = (x) => /^h[1-6]$/.test(tagOf(x.el)) || /title|name|heading/i.test(
        `${x.el.className || ""} ${(x.el.parentElement && x.el.parentElement.className) || ""}`);
      const best = unique.find(isTitle) || unique[0];
      if (best) found.push({ container: n, text: best.text });
    }
    // A real card or row beats any wrapper; a plain div needs a class, or every div around it would match too.
    const semantic = found.filter((a) => SEMANTIC_REPEAT.has(tagOf(a.container)));
    return (semantic.length ? semantic : found.filter((a) => stableClasses(a.container).length)).slice(0, 2);
  };
  const scopeXPath = ({ container, text }) => {
    const tag = tagOf(container);
    const cls = SEMANTIC_REPEAT.has(tag) ? "" :
      `[contains(concat(' ', normalize-space(@class), ' '), ${xq(` ${stableClasses(container)[0]} `)})]`;
    return `//${tag}${cls}[.//*[normalize-space()=${xq(text)}]]`;
  };
  const isStableName = (v) => v && !isDenied(v) && !/^\d+$/.test(v);
  const smartTargets = (el, info, xtag) => {
    const out = [];
    const name = el.getAttribute("name");
    if (isStableName(name)) out.push(`${xtag}[@name=${xq(name)}]`);
    const al = el.getAttribute("aria-label");
    if (al) out.push(`${xtag}[@aria-label=${xq(al)}]`);
    const title = el.getAttribute("title");
    if (title) out.push(`${xtag}[@title=${xq(title)}]`);
    if (info.raw && info.source === "text") out.push(`${xtag}[normalize-space()=${xq(info.raw)}]`);
    const type = el.getAttribute("type");
    if (type) out.push(`${xtag}[@type=${xq(type)}]`);
    return out.slice(0, 2);
  };
  const addSmartLocators = (el, info, xtag, xp) => {
    for (const anchor of findAnchors(el)) {
      const scope = scopeXPath(anchor);
      const why = `Finds it through nearby text '${anchor.text}'`;
      smartTargets(el, info, xtag).forEach((target, i) => {
        xp(`${scope}//${target}`, "smart-anchor", "OK", 0.55 - i / 100, why);
      });
      if (NATIVE.has(tagOf(el))) {
        const same = [...anchor.container.querySelectorAll(tagOf(el))];
        xp(`(${scope}//${tagOf(el)})[${same.indexOf(el) + 1}]`, "smart-anchor", "OK", 0.5,
          `${why}, then position ${same.indexOf(el) + 1} among its ${tagOf(el)} elements`);
      }
    }
    const title = el.getAttribute("title");
    if (title) xp(`//${xtag}[@title=${xq(title)}]`, "smart-attribute", "OK", 0.54, `title '${title}'`);
    for (const attr of ["id", "name"]) {
      const m = /^([A-Za-z_:.-]*[A-Za-z][A-Za-z_:.-]*[-_:.])\d+$/.exec(el.getAttribute(attr) || "");
      if (m) {
        xp(`//${xtag}[starts-with(@${attr}, ${xq(m[1])})]`, "smart-partial", "OK", 0.53,
          `${attr} starting with '${m[1]}', ignoring the generated number`);
      }
    }
    if (info.raw && info.source === "text") {
      const m = /^(.*\p{L}.*\s)[\d.,]+$/u.exec(info.raw);
      if (m) {
        xp(`//${xtag}[starts-with(normalize-space(), ${xq(m[1])})]`, "smart-partial", "OK", 0.52,
          `text starting with '${m[1].trim()}', ignoring the number`);
      }
    }
  };

  const isVisible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    if (el.checkVisibility) return el.checkVisibility({ visibilityProperty: true, opacityProperty: false });
    const cs = getComputedStyle(el);
    return cs.display !== "none" && cs.visibility !== "hidden";
  };

  // ---- candidates
  const buildCandidates = (el, info, group, inShadow) => {
    const tag = el.tagName.toLowerCase();
    const roleAttr = el.getAttribute("role");
    const xtag = NATIVE.has(tag) || !roleAttr ? tag : `*[@role=${xq(roleAttr)}]`;
    const out = [];
    const add = (kind, value, strategy, tier, score, explanation, name) =>
      out.push({ kind, value, name: name || null, strategy, tier, score, explanation });
    const xp = (value, strategy, tier, score, explanation) => {
      if (!inShadow) add("xpath", value, strategy, tier, score, explanation);
    };
    const role = implicitRole(el);
    const strong = STRONG_LABELS.has(info.source);

    for (const a of opts.testAttributes) {
      const v = el.getAttribute(a);
      if (v && !isDenied(v)) {
        add("css", `[${a}=${cssStr(v)}]`, "test-attr", "BEST", 0.98, `${a}="${v}"`);
        xp(`//${xtag}[@${a}=${xq(v)}]`, "test-attr", "BEST", 0.97, `${a}="${v}"`);
      }
    }
    // Label text may carry decorations ("Trade Date *"). Offer both forms; verification keeps what matches.
    const labelForms = info.label ? [...new Set([info.label, info.raw])] : [];
    if (role && strong) {
      for (const n of labelForms) add("role", role, "role", "BEST", 0.95, `role ${role} named '${n}'`, n);
    }
    if (strong && info.source !== "text") {
      for (const n of labelForms) add("label", n, "label", "BEST", 0.93, `label '${n}'`);
    }
    const lbIds = (el.getAttribute("aria-labelledby") || "").trim();
    if (lbIds && !lbIds.includes(" ") && info.raw && info.source === "aria-labelledby") {
      xp(`//${xtag}[@aria-labelledby=//*[normalize-space()=${xq(info.raw)}]/@id]`, "labelledby", "GOOD", 0.8,
        `element labelled by '${info.label}'`);
    }
    const id = el.getAttribute("id");
    if (id && !isDenied(id)) {
      add("css", `#${CSS.escape(id)}`, "id", "GOOD", 0.86, `id '${id}'`);
      xp(`//${xtag}[@id=${xq(id)}]`, "id", "GOOD", 0.85, `id '${id}'`);
    }
    const name = el.getAttribute("name");
    if (name && !isDenied(name)) {
      const type = (el.getAttribute("type") || "").toLowerCase();
      const val = el.getAttribute("value");
      const byValue = (type === "radio" || type === "checkbox") && val;
      const xVal = byValue ? `[@value=${xq(val)}]` : "";
      const cVal = byValue ? `[value=${cssStr(val)}]` : "";
      xp(`//${xtag}[@name=${xq(name)}]${xVal}`, "name", "GOOD", 0.8, `name '${name}'`);
      add("css", `${tag}[name=${cssStr(name)}]${cVal}`, "name", "GOOD", 0.79, `name '${name}'`);
      if (group.xpath) {
        xp(`${group.xpath}//${xtag}[@name=${xq(name)}]${xVal}`, "scoped-name", "GOOD", 0.78,
          `${group.name} section → name '${name}'`);
      }
    }
    const al = el.getAttribute("aria-label");
    if (al) xp(`//${xtag}[@aria-label=${xq(al)}]`, "aria-label", "GOOD", 0.78, `aria-label '${al}'`);

    if (info.raw && info.source === "label[for]") {
      xp(`//${xtag}[@id=//label[normalize-space()=${xq(info.raw)}]/@for]`, "label-for", "GOOD", 0.82,
        `label '${info.label}' → its 'for' id`);
      xp(`//label[normalize-space()=${xq(info.raw)}]/following::${xtag}[1]`, "label-anchor", "GOOD", 0.74,
        `label '${info.label}' → next ${tag}`);
      if (group.xpath) {
        xp(`${group.xpath}//label[normalize-space()=${xq(info.raw)}]/following::${xtag}[1]`, "scoped-label",
          "GOOD", 0.77, `${group.name} section → label '${info.label}' → next ${tag}`);
      }
    }
    if (info.raw && info.source === "label-wrap") {
      xp(`//label[starts-with(normalize-space(), ${xq(info.raw)})]//${xtag}`, "label-anchor", "GOOD", 0.8,
        `inside label '${info.label}'`);
      if (group.xpath) {
        xp(`${group.xpath}//label[starts-with(normalize-space(), ${xq(info.raw)})]//${xtag}`, "scoped-label",
          "GOOD", 0.77, `${group.name} section → inside label '${info.label}'`);
      }
    }
    if (info.raw && info.source === "text") {
      xp(`//${xtag}[normalize-space()=${xq(info.raw)}]`, "text", "GOOD", 0.8, `text '${info.label}'`);
      if (group.xpath) {
        xp(`${group.xpath}//${xtag}[normalize-space()=${xq(info.raw)}]`, "scoped-text", "GOOD", 0.77,
          `${group.name} section → text '${info.label}'`);
      }
    }
    if (info.raw && info.source === "text-before") {
      xp(`//*[normalize-space(text())=${xq(info.raw)}]/following::${xtag}[1]`, "text-anchor", "OK", 0.66,
        `text '${info.label}' → next ${tag}`);
      if (group.xpath) {
        xp(`${group.xpath}//*[normalize-space(text())=${xq(info.raw)}]/following::${xtag}[1]`, "scoped-text",
          "OK", 0.64, `${group.name} section → text '${info.label}' → next ${tag}`);
      }
    }
    const ph = el.getAttribute("placeholder");
    if (ph) {
      add("placeholder", ph, "placeholder", "OK", 0.6, `placeholder '${ph}'`);
      xp(`//${xtag}[@placeholder=${xq(ph)}]`, "placeholder", "OK", 0.58, `placeholder '${ph}'`);
    }
    xp(absoluteXPath(el), "positional", "OK", 0.3, "absolute position in the page (fragile)");
    addReferenceLocators(el, role, add, xp);
    addSmartLocators(el, info, xtag, xp);
    return out;
  };

  const kindOf = (el, role) => {
    const tag = el.tagName.toLowerCase();
    if (tag === "select" || role === "combobox" || role === "listbox") return "choice";
    if (["checkbox", "radio", "switch"].includes(role)) return "toggle";
    if (role === "button") return "action";
    return "text";
  };

  const fields = [];
  window.__locatorscan = { fields: [] };
  for (const { el, inShadow } of found) {
    const idx = window.__locatorscan.fields.length;
    window.__locatorscan.fields.push(el);
    const tag = el.tagName.toLowerCase();
    const role = implicitRole(el);
    const info = resolveLabel(el);
    const group = resolveGroup(el);
    fields.push({
      idx,
      tag,
      inputType: tag === "input" ? (el.getAttribute("type") || "text").toLowerCase() : null,
      role,
      kind: kindOf(el, role),
      native: NATIVE.has(tag),
      label: info.label,
      labelSource: info.source,
      group: group.name,
      inShadow,
      state: {
        visible: isVisible(el),
        disabled: !!el.disabled || el.getAttribute("aria-disabled") === "true",
        readonly: !!el.readOnly || el.getAttribute("aria-readonly") === "true",
        required: !!el.required || el.getAttribute("aria-required") === "true",
      },
      attrs: {
        id: el.getAttribute("id"),
        name: el.getAttribute("name"),
        placeholder: el.getAttribute("placeholder"),
      },
      candidates: buildCandidates(el, info, group, inShadow),
    });
  }
  return { fields, skippedHidden };
}
