"""Pure ranking logic: choosing locators, naming fields, and fingerprint similarity.

No browser here, so everything in this module is unit-tested directly.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Sequence
from pathlib import PurePosixPath
from urllib.parse import unquote, urlsplit

from locatorscan.models import Candidate, Fingerprint, LocatorSpec, LocatorType

MAX_FALLBACKS = 2
# A proposed fix must look at least this similar to the stored fingerprint.
# 0.55 means the label, or name plus type, must line up; lower values matched unrelated fields in fixtures.
HEAL_THRESHOLD = 0.55

_FINGERPRINT_WEIGHTS: dict[str, float] = {
    "label": 0.35,
    "name": 0.2,
    "id": 0.15,
    "input_type": 0.1,
    "group": 0.1,
    "placeholder": 0.05,
    "role": 0.05,
}


_LABEL_TEXT_STRATEGIES = {"role", "label", "label-for", "label-anchor", "labelledby", "text", "text-anchor"}


# Shown in reports for people to copy. Never eligible as a primary, fallback or best XPath, so adding one cannot
# change what the registry stores.
REFERENCE_STRATEGIES = frozenset(
    {"class-names", "css-path", "xpath-path", "xpath-absolute", "xpath-position", "role-only"}
)


def _family(strategy: str) -> str:
    """Strategies in one family break for the same reason (e.g. all depend on the visible label text)."""
    if strategy.startswith("smart-"):
        return "smart"
    family = strategy.removeprefix("scoped-")
    return "label-text" if family in _LABEL_TEXT_STRATEGIES else family


_NOT_A_PAGE_NAME = frozenset({"index", "default", "home"})
LOCATOR_TYPE_TITLES: dict[LocatorType, str] = {
    "role": "Role-based (get_by_role)",
    "semantic": "Semantic (label, placeholder, test id)",
    "id": "ID",
    "name": "Name",
    "smart": "Smart (dynamic: anchored, partial match)",
    "css": "CSS selectors",
    "xpath": "XPath",
}
_TYPE_BY_STRATEGY: dict[str, LocatorType] = {
    "role": "role",
    "role-only": "role",
    "test-attr": "semantic",
    "label": "semantic",
    "placeholder": "semantic",
    "id": "id",
    "name": "name",
    "scoped-name": "name",
}


def locator_type(candidate: LocatorSpec) -> LocatorType:
    """The settings group a locator belongs to; what it relies on counts before how it is written."""
    if candidate.strategy.startswith("smart-"):
        return "smart"
    return _TYPE_BY_STRATEGY.get(candidate.strategy, "css" if candidate.kind == "css" else "xpath")


def allowed(candidate: LocatorSpec, locator_types: Sequence[LocatorType] | None) -> bool:
    return locator_types is None or locator_type(candidate) in locator_types


def eligible(candidate: LocatorSpec, locator_types: Sequence[LocatorType] | None) -> bool:
    """Can this be chosen? Reference locators stay out, except CSS when asked for: nothing else is plain CSS."""
    if not allowed(candidate, locator_types):
        return False
    return candidate.strategy not in REFERENCE_STRATEGIES or (bool(locator_types) and candidate.kind == "css")


def uses_visible_text(strategy: str) -> bool:
    return _family(strategy) == "label-text"


def to_spec(candidate: Candidate) -> LocatorSpec:
    return LocatorSpec.model_validate(candidate.model_dump(exclude={"match_count", "is_target", "target_index"}))


def choose(
    candidates: Sequence[Candidate], locator_types: Sequence[LocatorType] | None = None
) -> tuple[LocatorSpec | None, list[LocatorSpec], str | None]:
    """Pick the primary locator, up to two fallbacks of different strategies, and the best XPath.

    Only candidates that matched exactly one element, and the right one, are eligible. With `locator_types`, only
    those types count and earlier types win; an absolute path stays the last resort whatever the order.
    """

    def rank(c: Candidate) -> tuple[bool, int, float]:
        priority = locator_types.index(locator_type(c)) if locator_types else 0
        return (bool(locator_types) and c.strategy == "positional", priority, -c.score)

    verified = sorted(
        (c for c in candidates if eligible(c, locator_types) and c.is_target and c.match_count == 1), key=rank
    )
    if not verified:
        return None, [], None
    primary = verified[0]
    fallbacks: list[Candidate] = []
    # A fallback is only useful if it fails for different reasons than the primary,
    # so each fallback must come from a different strategy family ('scoped-name' is the 'name' family).
    seen = {_family(primary.strategy)}
    for cand in verified[1:]:
        if len(fallbacks) == MAX_FALLBACKS:
            break
        if _family(cand.strategy) in seen or cand.strategy == "positional" or _family(cand.strategy) == "smart":
            continue  # a smart locator only ever stands in for a field that has nothing better
        seen.add(_family(cand.strategy))
        fallbacks.append(cand)
    # Second pass: if no other family exists (e.g. a button known only by its text),
    # still keep one fallback of a different locator kind rather than none.
    for cand in verified[1:]:
        if len(fallbacks) == MAX_FALLBACKS or fallbacks:
            break
        if cand.kind != primary.kind and cand.strategy != "positional" and _family(cand.strategy) != "smart":
            fallbacks.append(cand)
    best_xpath = next((c.value for c in verified if c.kind == "xpath"), None)
    return to_spec(primary), [to_spec(f) for f in fallbacks], best_xpath


def page_name_from_url(url: str) -> str:
    """The last meaningful path part of a URL, else its host: `/docs/best-practices` -> `best_practices`."""
    parts = urlsplit(url)
    segments = [unquote(s) for s in parts.path.split("/") if s]
    if segments:
        segments[-1] = PurePosixPath(segments[-1]).stem
    meaningful = [s for s in segments if s.lower() not in _NOT_A_PAGE_NAME and not s.isdigit()]
    source = meaningful[-1] if meaningful else (parts.hostname or "").removeprefix("www.")
    return _ascii_name(source) or "page"


def _ascii_name(text: str) -> str:
    name = re.sub(r"[^0-9a-zA-Z]+", "_", text).strip("_").lower()
    return f"page_{name}" if name[:1].isdigit() else name


def snake(text: str) -> str:
    """'Trade Date (T)' -> 'trade_date_t'. Always returns a valid Python identifier."""
    s = re.sub(r"[^0-9a-zA-Z]+", "_", text).strip("_").lower()
    s = re.sub(r"_+", "_", s)
    if not s:
        return "field"
    if s[0].isdigit():
        s = f"f_{s}"
    return s[:48].rstrip("_")


def make_keys(raw: Iterable[tuple[str | None, str | None, str]]) -> list[str]:
    """Build unique field keys from (label, group, fallback_name) triples.

    Duplicate labels are prefixed with their group ('settlement_amount'); anything still duplicated gets '_2', '_3'.
    """
    items = list(raw)
    base = [snake(label) if label else snake(fallback) for label, _group, fallback in items]
    counts: dict[str, int] = {}
    for b in base:
        counts[b] = counts.get(b, 0) + 1
    keys: list[str] = []
    used: set[str] = set()
    for (_label, group, _fb), b in zip(items, base, strict=True):
        key = f"{snake(group)}_{b}" if counts[b] > 1 and group else b
        candidate, n = key, 2
        while candidate in used:
            candidate = f"{key}_{n}"
            n += 1
        used.add(candidate)
        keys.append(candidate)
    return keys


def _text_similarity(a: str, b: str) -> float:
    a_n, b_n = a.strip().lower(), b.strip().lower()
    if a_n == b_n:
        return 1.0
    ta, tb = set(re.findall(r"[a-z0-9]+", a_n)), set(re.findall(r"[a-z0-9]+", b_n))
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def similarity(stored: Fingerprint, found: Fingerprint) -> float:
    """0..1 similarity of a discovered field to a stored fingerprint. Only attributes the stored one has count."""
    total = 0.0
    score = 0.0
    for attr, weight in _FINGERPRINT_WEIGHTS.items():
        want = getattr(stored, attr)
        if want is None:
            continue
        total += weight
        got = getattr(found, attr)
        if got is not None:
            score += weight * _text_similarity(str(want), str(got))
    if total == 0:
        return 0.0
    result = score / total
    if stored.tag != found.tag:
        result *= 0.5
    return round(result, 3)
