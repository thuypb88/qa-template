"""Find locators that change between scans of the same page. Pure logic: the scans come in as data."""

from __future__ import annotations

import re
from collections.abc import Iterable, Sequence
from datetime import UTC, datetime

from locatorscan import ranking
from locatorscan.locators import describe
from locatorscan.models import (
    Candidate,
    FieldRecord,
    FieldStability,
    LocatorChange,
    LocatorSpec,
    LocatorType,
    PageStability,
    ScanResult,
    StabilityStatus,
)

VOLATILE_TEXT_WARNING = "VOLATILE_TEXT"
_NUMERIC = re.compile(r"[\d\s.,:/%+-]*\d[\d\s.,:/%+-]*")

_FieldId = tuple[object, ...]


def is_volatile_text(label: str | None, patterns: Iterable[str]) -> bool:
    """True for text that is only a number, date or time, or that matches a project's `volatile_text` pattern."""
    if not label:
        return False
    return bool(_NUMERIC.fullmatch(label)) or any(re.search(p, label) for p in patterns)


def _position(f: FieldRecord) -> str | None:
    return next((c.value for c in f.candidates if c.strategy == "positional"), None)


def _position_id(f: FieldRecord) -> _FieldId | None:
    path = _position(f)
    return (tuple(f.frame_path), path) if path else None


def _identity_id(f: FieldRecord) -> _FieldId:
    fp = f.fingerprint
    return (tuple(f.frame_path), fp.tag, fp.role, fp.input_type, fp.label or fp.name or fp.id)


def _primary_id(f: FieldRecord) -> _FieldId | None:
    p = f.primary
    if p is None or p.strategy == "positional":
        return None
    return (tuple(f.frame_path), p.kind, p.value, p.name)


def _align(runs: Sequence[ScanResult]) -> list[list[FieldRecord | None]]:
    """One row per field and one column per run: same primary, else same position, else same identity if it moved."""
    rows: list[list[FieldRecord | None]] = []
    by_primary: dict[_FieldId, list[FieldRecord | None]] = {}
    by_position: dict[_FieldId, list[FieldRecord | None]] = {}

    def remember(row: list[FieldRecord | None], f: FieldRecord) -> None:
        for index, key in ((by_primary, _primary_id(f)), (by_position, _position_id(f))):
            if key:
                index.setdefault(key, row)

    for column, run in enumerate(runs):
        rest: list[FieldRecord] = []
        for f in run.fields:  # a primary that is still there says the most, so it goes before any position
            key = _primary_id(f)
            row = by_primary.get(key) if key else None
            if row is not None and row[column] is None:
                row[column] = f
                remember(row, f)
            else:
                rest.append(f)
        unplaced: list[FieldRecord] = []
        for f in rest:
            pos = _position_id(f)
            row = by_position.get(pos) if pos else None
            if row is not None and row[column] is None:
                row[column] = f
                remember(row, f)
            else:
                unplaced.append(f)
        for f in unplaced:
            identity = _identity_id(f)
            row: list[FieldRecord | None] | None = next(
                (r for r in rows if r[column] is None and any(x and _identity_id(x) == identity for x in r)),
                None,
            )
            if row is None:
                row = [None for _ in runs]
                rows.append(row)
            row[column] = f
            remember(row, f)
    return rows


def _spec_id(spec: LocatorSpec | None) -> tuple[str, str, str | None] | None:
    return (spec.kind, spec.value, spec.name) if spec else None


def _candidate_text(c: Candidate) -> str:
    return f"{describe(c)} .nth({c.target_index})" if c.match_count > 1 and c.target_index is not None else describe(c)


def _changes(fields: Sequence[FieldRecord], types: Sequence[LocatorType] | None) -> list[LocatorChange]:
    """Candidates whose locator differs between runs. `.nth(k)` counts: a changed position breaks copied code."""
    per_run: list[dict[tuple[str, str], list[str]]] = []
    for f in fields:
        seen: dict[tuple[str, str], list[str]] = {}
        for c in (c for c in f.candidates if ranking.allowed(c, types)):
            seen.setdefault((c.strategy, c.kind), []).append(_candidate_text(c))
        per_run.append(seen)
    keys = list(dict.fromkeys(k for seen in per_run for k in seen))
    changes: list[LocatorChange] = []
    for key in keys:
        values = [sorted(seen.get(key, [])) for seen in per_run]
        if any(v != values[0] for v in values):
            changes.append(
                LocatorChange(strategy=key[0], kind=key[1], values=[" ; ".join(v) or "(none)" for v in values])
            )
    return changes


def _judge(
    row: Sequence[FieldRecord | None], labels: Sequence[str], types: Sequence[LocatorType] | None
) -> FieldStability:
    present = [f for f in row if f is not None]
    first = present[0]

    def verdict(
        status: StabilityStatus, detail: str = "", changes: list[LocatorChange] | None = None
    ) -> FieldStability:
        return FieldStability(key=first.key, label=first.label, status=status, detail=detail, changes=changes or [])

    if len(present) < len(row):
        missing = [label for label, f in zip(labels, row, strict=True) if f is None]
        return verdict("NOT_IN_ALL_RUNS", f"Not found in: {', '.join(missing)}")
    changes = _changes(present, types)
    primaries = [f.primary for f in present]
    if len({_spec_id(p) for p in primaries}) > 1:
        values = [describe(p) if p else "(none)" for p in primaries]
        primary_change = LocatorChange(strategy="primary", kind="any", values=values)
        return verdict("DYNAMIC", "The primary locator changed", [primary_change, *changes])
    if any(VOLATILE_TEXT_WARNING in f.warnings for f in present):
        detail = "The primary locator relies on text that looks data-driven, even though it did not change this time"
        return verdict("VOLATILE_TEXT", detail, changes)
    if changes:
        return verdict("PARTLY_DYNAMIC", "The primary held; other locators changed", changes)
    if primaries[0] is not None and primaries[0].strategy == "positional":
        detail = "Unchanged in these runs, but it relies on page position: added or reordered content will move it"
        return verdict("POSITION_ONLY", detail)
    if primaries[0] is None:
        return verdict("NO_LOCATOR", "No unique locator in any run, so nothing to compare")
    return verdict("STABLE")


def compare(runs: Sequence[ScanResult], labels: Sequence[str]) -> PageStability:
    """Judge every field across the runs. A partial scan cannot prove a field is missing, so those are not judged."""
    if len(runs) < 2 or len(runs) != len(labels):
        raise ValueError("compare needs at least two runs and one label per run")
    partial = any(r.status == "PARTIAL" for r in runs)
    results: list[FieldStability] = []
    not_compared = 0
    for row in _align(runs):
        if partial and any(f is None for f in row):
            not_compared += 1
        else:
            results.append(_judge(row, labels, runs[0].locator_types))
    return PageStability(
        page=runs[0].page,
        url=runs[0].url,
        app_version=runs[0].app_version,
        checked_at=datetime.now(UTC).isoformat(timespec="seconds"),
        runs=list(labels),
        partial=partial,
        not_compared=not_compared,
        results=results,
    )
