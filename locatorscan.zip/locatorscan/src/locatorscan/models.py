"""Data contracts: config, scan output, registry and validation results.

These Pydantic models are the single source of truth for every file the tool reads or writes.
JSON Schemas are generated from them (`locatorscan schema`), so code and contract cannot drift.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

Tier = Literal["BEST", "GOOD", "OK"]
LocatorKind = Literal["role", "label", "placeholder", "css", "xpath"]
LocatorType = Literal["role", "semantic", "id", "name", "smart", "css", "xpath"]
FieldKind = Literal["text", "choice", "toggle", "action"]
FieldStatus = Literal["OK", "FALLBACK_USED", "BROKEN", "NON_UNIQUE", "MISSING_FRAME"]
StabilityStatus = Literal[
    "NOT_IN_ALL_RUNS", "DYNAMIC", "VOLATILE_TEXT", "PARTLY_DYNAMIC", "POSITION_ONLY", "NO_LOCATOR", "STABLE"
]


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


# ---------------------------------------------------------------- config


class Viewport(_Strict):
    width: int = 1440
    height: int = 900


class ScannerConfig(_Strict):
    """Contents of `scanner.config.yaml`. Paths are relative to the config file."""

    app_version: str = "unversioned"
    base_url: str | None = None
    browser_channel: str | None = Field(default=None, description="e.g. 'chrome' to use installed Google Chrome")
    headless: bool = True
    storage_state: str | None = Field(default=None, description="Session file from a one-time manual login")
    test_attributes: list[str] = Field(default_factory=lambda: ["data-testid", "data-qa", "data-cy", "data-test"])
    deny_list: list[str] = Field(
        default_factory=lambda: [
            r"^ember\d+",
            r"^mat-[a-z-]+-\d+",
            r"^react-select-\d+",
            r"^:r[0-9a-z]+:$",
            r"[0-9a-f]{8}-[0-9a-f]{4}",
            r"_[a-zA-Z0-9]{5,}$",
            r"\d{4,}",
        ]
    )
    scope: str = "body"
    wait_for: str = Field(default="load", description="load | domcontentloaded | networkidle | a CSS selector")
    settle_ms: int = Field(
        default=1000,
        ge=0,
        description="Wait until the number of fields holds this long before scanning; 0 turns it off",
    )
    timeout_ms: int = 30_000
    viewport: Viewport = Field(default_factory=Viewport)
    login_url_patterns: list[str] = Field(default_factory=lambda: ["/login", "/signin", "/sso/"])
    locator_types: list[LocatorType] | None = Field(
        default=None,
        description="Types to use, highest priority first; a type left out is excluded. Unset: rank by score alone",
    )
    standalone_buttons: Literal["auto", "always"] = Field(
        default="auto", description="Buttons outside a form or group. auto: only when the page has no other fields"
    )
    volatile_text: list[str] = Field(
        default_factory=list, description="Regexes for visible text that changes with user or data, e.g. a user name"
    )
    registry_dir: str = "locators"
    out_dir: str = "out"
    generated_dir: str = "generated"

    @field_validator("locator_types")
    @classmethod
    def _one_of_each(cls, value: list[LocatorType] | None) -> list[LocatorType] | None:
        if value is not None and (not value or len(set(value)) != len(value)):
            raise ValueError("locator_types needs at least one type, each listed once")
        return value


# ---------------------------------------------------------------- locators


class LocatorSpec(_Strict):
    """A locator stored as data, so it can be rebuilt for Playwright or exported as XPath."""

    kind: LocatorKind
    value: str
    name: str | None = Field(default=None, description="Accessible name, for kind=role")
    strategy: str
    tier: Tier
    score: float
    explanation: str = ""


class Candidate(LocatorSpec):
    match_count: int = 0
    is_target: bool = False
    target_index: int | None = Field(default=None, description="Position of the field among the matches, when found")


class FieldState(_Strict):
    visible: bool
    disabled: bool
    readonly: bool
    required: bool


class Fingerprint(_Strict):
    """What healing compares when every stored locator fails."""

    tag: str
    input_type: str | None = None
    role: str | None = None
    label: str | None = None
    name: str | None = None
    id: str | None = None
    group: str | None = None
    placeholder: str | None = None


# ---------------------------------------------------------------- scan output


class FieldRecord(_Strict):
    key: str
    label: str | None
    label_source: str
    group: str | None
    kind: FieldKind
    tag: str
    input_type: str | None
    role: str | None
    state: FieldState
    frame_path: list[str]
    in_shadow_dom: bool
    primary: LocatorSpec | None
    fallbacks: list[LocatorSpec]
    xpath: str | None
    candidates: list[Candidate]
    fingerprint: Fingerprint
    warnings: list[str]


class ScanResult(_Strict):
    page: str
    url: str
    app_version: str
    scanned_at: str
    status: Literal["OK", "PARTIAL"]
    fields: list[FieldRecord]
    locator_types: list[LocatorType] | None = None
    skipped_hidden_inputs: int = 0
    frame_errors: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------- registry


class RegistryField(_Strict):
    label: str | None = None
    group: str | None = None
    kind: FieldKind
    primary: LocatorSpec
    fallbacks: list[LocatorSpec] = Field(default_factory=list[LocatorSpec])
    xpath: str | None = None
    frame_path: list[str] = Field(default_factory=list)
    in_shadow_dom: bool = False
    fingerprint: Fingerprint
    last_verified: str


class RegistryPage(_Strict):
    page: str
    url: str
    app_version: str
    fields: dict[str, RegistryField]


# ---------------------------------------------------------------- validation


class FixProposal(_Strict):
    reason: str
    matched_label: str | None
    similarity: float
    new_primary: LocatorSpec
    new_fallbacks: list[LocatorSpec] = Field(default_factory=list[LocatorSpec])
    new_xpath: str | None
    new_frame_path: list[str] = Field(default_factory=list)
    new_fingerprint: Fingerprint


class FieldValidation(_Strict):
    key: str
    label: str | None
    status: FieldStatus
    used: str | None = Field(default=None, description="'primary' or 'fallback[n]' when a locator resolved")
    detail: str = ""
    proposal: FixProposal | None = None


class PageValidation(_Strict):
    page: str
    url: str
    registry_version: str
    checked_version: str
    checked_at: str
    results: list[FieldValidation]
    new_fields: list[str] = Field(default_factory=list, description="Labels of fields on the page but not in registry")

    def count(self, status: FieldStatus) -> int:
        return sum(1 for r in self.results if r.status == status)


# ---------------------------------------------------------------- stability


class LocatorChange(_Strict):
    strategy: str
    kind: str
    values: list[str] = Field(description="The locator in each run, in run order")


class FieldStability(_Strict):
    key: str
    label: str | None
    status: StabilityStatus
    detail: str = ""
    changes: list[LocatorChange] = Field(default_factory=list[LocatorChange])


class PageStability(_Strict):
    page: str
    url: str
    app_version: str
    checked_at: str
    runs: list[str]
    partial: bool = Field(default=False, description="A run ran out of scan budget, so missing fields were not judged")
    not_compared: int = 0
    results: list[FieldStability]

    def count(self, status: StabilityStatus) -> int:
        return sum(1 for r in self.results if r.status == status)
