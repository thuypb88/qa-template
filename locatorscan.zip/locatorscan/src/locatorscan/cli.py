"""Command line: scan → review → generate, then validate → apply-fixes after each app release."""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from collections.abc import Sequence
from dataclasses import replace
from pathlib import Path

from pydantic import ValidationError

from locatorscan import __version__, codegen, console, registry, report, stability
from locatorscan.config import Workspace, config_file, load_workspace
from locatorscan.engine import PlaywrightEngine
from locatorscan.errors import ConfigError, DynamicLocatorsError, LocatorsBrokenError, LocatorScanError
from locatorscan.locators import describe
from locatorscan.models import (
    FieldRecord,
    LocatorType,
    PageStability,
    PageValidation,
    RegistryPage,
    ScannerConfig,
    ScanResult,
)
from locatorscan.ranking import LOCATOR_TYPE_TITLES, page_name_from_url

_TIER_RANK = {"BEST": 0, "GOOD": 1, "OK": 2}


# ---------------------------------------------------------------- commands


def _apply_page_options(ws: Workspace, args: argparse.Namespace) -> None:
    if args.scope:
        ws.config.scope = args.scope
    if args.wait_for:
        ws.config.wait_for = args.wait_for
    if args.all_buttons:
        ws.config.standalone_buttons = "always"


def _resolve_page(args: argparse.Namespace) -> None:
    if not args.page:
        args.page = page_name_from_url(args.url)
        console.say(f"Page name: {args.page} (from the URL; use --page to choose another)")


def cmd_scan(ws: Workspace, args: argparse.Namespace) -> int:
    _apply_page_options(ws, args)
    _resolve_page(args)
    url = ws.resolve_url(args.url)
    result = PlaywrightEngine(ws).scan(url, args.page)
    if "://" not in args.url:
        # Keep the URL as given (relative path or base_url path) so the registry stays portable.
        result = result.model_copy(update={"url": args.url})
    out = registry.write_json(registry.scan_file(ws, args.page), result)
    html = report.write(ws, f"{args.page}-scan", report.scan_html(result))
    console.table(
        ["key", "label", "tier", "primary locator", "warnings"],
        [
            [
                f.key,
                f.label or "",
                f.primary.tier if f.primary else "NONE",
                describe(f.primary) if f.primary else "-",
                ",".join(f.warnings),
            ]
            for f in result.fields
        ],
    )
    console.say(
        f"\n{result.status}: {len(result.fields)} fields ({result.skipped_hidden_inputs} hidden inputs skipped)"
    )
    for e in result.frame_errors:
        console.say(f"  {e}")
    console.say(f"Scan:   {out}\nReport: {html}\nNext:   locatorscan review --page {args.page}")
    return 0


def _review_one(f: FieldRecord) -> tuple[bool, str]:
    assert f.primary is not None
    console.say(f"\n{f.key}  ({f.label}, {f.group or 'no group'})  {f.primary.tier}: {describe(f.primary)}")
    if f.warnings:
        console.say(f"  warnings: {', '.join(f.warnings)}")
    choice = console.ask("  accept / rename / skip?", "ars", "a")
    if choice == "s":
        return False, f.key
    if choice == "r":
        return True, console.ask_text("  new key", f.key)
    return True, f.key


def cmd_review(ws: Workspace, args: argparse.Namespace) -> int:
    scan = registry.read_scan(ws, args.page)
    auto = args.yes or not console.interactive()
    if auto and not args.yes:
        console.say("No terminal attached: accepting by tier (use --yes to make this explicit).")
    max_rank = _TIER_RANK[args.min_tier]
    accepted: dict[str, FieldRecord] = {}
    skipped: list[str] = []
    manual: list[str] = []
    for f in scan.fields:
        if f.primary is None:
            manual.append(f"{f.key} ({', '.join(f.warnings)})")
            continue
        if auto:
            if _TIER_RANK[f.primary.tier] <= max_rank:
                accepted[f.key] = f
            else:
                skipped.append(f"{f.key} ({f.primary.tier})")
            continue
        keep, key = _review_one(f)
        if keep:
            accepted[key] = f.model_copy(update={"key": key})
        else:
            skipped.append(f.key)
    merged = registry.merge_scan(registry.load(ws, args.page), scan, accepted)
    path = registry.save(ws, merged)
    console.say(f"Accepted {len(accepted)} fields into {path}")
    if skipped:
        console.say(f"Skipped (below {args.min_tier} or by choice): {', '.join(skipped)}")
    if manual:
        console.say(f"Need a manual locator: {', '.join(manual)}")
    console.say("Next:   locatorscan generate")
    return 0


def _registry_pages(ws: Workspace, page: str | None) -> list[RegistryPage]:
    names = [page] if page else registry.pages(ws)
    loaded = [registry.load(ws, n) for n in names]
    found = [rp for rp in loaded if rp is not None]
    if not found:
        raise ConfigError("No registry pages found. Run `locatorscan scan` and `locatorscan review` first.")
    return found


def cmd_generate(ws: Workspace, args: argparse.Namespace) -> int:
    for rp in _registry_pages(ws, args.page):
        po, csv_path = codegen.generate(ws, rp)
        console.say(f"{rp.page}: {len(rp.fields)} locators → {po} and {csv_path}")
    return 0


def cmd_validate(ws: Workspace, args: argparse.Namespace) -> int:
    engine = PlaywrightEngine(ws)
    failed = 0
    fallback = 0
    for rp in _registry_pages(ws, args.page):
        url = ws.resolve_url(args.url or rp.url)
        result: PageValidation = engine.validate(rp, url)
        registry.write_json(registry.validation_file(ws, rp.page), result)
        html = report.write(ws, f"{rp.page}-validation", report.validation_html(result, rp))
        console.table(
            ["key", "status", "resolved by", "fix proposal"],
            [
                [
                    r.key,
                    r.status,
                    r.used or "-",
                    f"{describe(r.proposal.new_primary)} (sim {r.proposal.similarity:.2f})" if r.proposal else "-",
                ]
                for r in result.results
            ],
        )
        broken = result.count("BROKEN") + result.count("NON_UNIQUE") + result.count("MISSING_FRAME")
        failed += broken
        fallback += result.count("FALLBACK_USED")
        console.say(
            f"\n{rp.page}: {result.count('OK')} OK, {result.count('FALLBACK_USED')} fallback, {broken} broken"
            f"  ({rp.app_version} → {result.checked_version})\nReport: {html}"
        )
        if result.new_fields:
            console.say(f"New fields not in the registry: {', '.join(result.new_fields)} (re-scan to add them)")
        if any(r.proposal for r in result.results):
            console.say(f"Next:   locatorscan apply-fixes --page {rp.page}")
    if failed or (args.strict and fallback):
        raise LocatorsBrokenError(f"{failed} broken and {fallback} fallback-only locators")
    return 0


def cmd_apply_fixes(ws: Workspace, args: argparse.Namespace) -> int:
    validation = registry.read_validation(ws, args.page)
    rp = registry.load(ws, args.page)
    if rp is None:
        raise ConfigError(f"No registry page '{args.page}'")
    proposals = [r for r in validation.results if r.proposal is not None and r.key in rp.fields]
    if not args.yes and not console.interactive():
        # Fixes change the registry, so they are never applied silently.
        for r in proposals:
            assert r.proposal is not None
            console.say(f"{r.key} ({r.status}) → {describe(r.proposal.new_primary)}  sim {r.proposal.similarity:.2f}")
        console.say(f"{len(proposals)} proposals listed, none applied. Re-run with --yes once they are approved.")
        return 0
    applied: list[str] = []
    for r in proposals:
        p = r.proposal
        assert p is not None
        if not args.yes:
            console.say(
                f"\n{r.key} is {r.status}. Proposed: {describe(p.new_primary)}  ({p.reason}, "
                f"similarity {p.similarity:.2f}, matched label {p.matched_label!r})"
            )
            if console.ask("  apply?", "yn", "n") != "y":
                continue
        rp.fields[r.key] = registry.apply_fix(rp.fields[r.key], p)
        applied.append(r.key)
    unresolved = [r.key for r in validation.results if r.status in ("BROKEN", "NON_UNIQUE") and r.proposal is None]
    if applied:
        rp.app_version = validation.checked_version
        registry.save(ws, rp)
    console.say(f"Applied {len(applied)} fixes: {', '.join(applied) or '-'}")
    if unresolved:
        console.say(f"Still broken, needs a re-scan or manual fix: {', '.join(unresolved)}")
    if applied:
        console.say("Next:   locatorscan generate")
    return 0


def _stability_runs(ws: Workspace, args: argparse.Namespace) -> list[tuple[str, Workspace]]:
    if args.runs < 2:
        raise ConfigError("--runs must be at least 2: a comparison needs two scans")
    state: Path | None = args.compare_state
    if state is None:
        return [(f"session {i}", ws) for i in range(1, args.runs + 1)]
    if not state.is_file():
        raise ConfigError(f"--compare-state file not found: {state}")
    other = replace(ws, config=ws.config.model_copy(update={"storage_state": str(state.resolve())}))
    return [(f"session {i}", ws) for i in range(1, args.runs)] + [(f"state {state.stem}", other)]


def cmd_stability(ws: Workspace, args: argparse.Namespace) -> int:
    _apply_page_options(ws, args)
    _resolve_page(args)
    url = ws.resolve_url(args.url)
    planned = _stability_runs(ws, args)  # checked first, so a bad option fails before any browser starts
    scans: list[ScanResult] = []
    for label, run_ws in planned:
        console.say(f"Scanning: {label}")
        scans.append(PlaywrightEngine(run_ws).scan(url, args.page))
    result = stability.compare(scans, [label for label, _ in planned])
    if "://" not in args.url:
        result = result.model_copy(update={"url": args.url})
    out = registry.write_json(registry.stability_file(ws, args.page), result)
    html = report.write(ws, f"{args.page}-stability", report.stability_html(result))
    flagged = [r for r in result.results if r.status != "STABLE"]
    console.table(
        ["key", "status", "detail"],
        [[r.key, r.status, r.detail] for r in flagged],
    )
    failing = result.count("DYNAMIC") + result.count("VOLATILE_TEXT") + result.count("NOT_IN_ALL_RUNS")
    partly = result.count("PARTLY_DYNAMIC")
    position = result.count("POSITION_ONLY")
    console.say(
        f"\n{result.count('STABLE')} stable, {failing} dynamic or unreliable, {partly} partly dynamic, "
        f"{position} position only, "
        f"{result.count('NO_LOCATOR')} no locator\nResult: {out}\nReport: {html}"
    )
    if result.partial:
        console.say(f"A run hit the scan budget: {result.not_compared} fields not compared. Raise timeout_ms.")
    if failing or (args.strict and (partly or position)):
        raise DynamicLocatorsError(
            f"{failing} dynamic or unreliable, {partly} partly dynamic and {position} position-only fields"
        )
    return 0


_TYPES_LINE = re.compile(r"^locator_types:.*(?:\n[ \t]+-.*)*\n?", re.MULTILINE)


def _parse_types(text: str) -> list[LocatorType]:
    """`role,id,xpath` as a checked list; the same rules as the config file."""
    values = [v.strip() for v in text.split(",") if v.strip()]
    try:
        types = ScannerConfig.model_validate({"locator_types": values}).locator_types
    except ValidationError as exc:
        raise ConfigError(
            f"Bad locator types '{text}'. Choose from: {', '.join(LOCATOR_TYPE_TITLES)}, each once."
        ) from exc
    assert types is not None
    return types


def _save_types(path: Path, types: list[LocatorType] | None) -> None:
    """Change only the locator_types line, so the comments and other settings in the file survive."""
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    line = f"locator_types: [{', '.join(types)}]\n" if types else ""
    if _TYPES_LINE.search(text):
        text = _TYPES_LINE.sub(line, text, count=1)
    else:
        text = f"{text}{'' if not text or text.endswith(chr(10)) else chr(10)}{line}"
    path.write_text(text, encoding="utf-8")


def cmd_settings(ws: Workspace, args: argparse.Namespace) -> int:
    path = config_file(args.config)
    types = ws.config.locator_types
    if args.reset or args.set is not None:
        types = None if args.reset else _parse_types(args.set)
        _save_types(path, types)
        console.say(f"Saved to {path}. It applies to the next scan; re-scan and review to update the registry.")
    shown = types or list(LOCATOR_TYPE_TITLES)
    rows = [[str(i) if types else "-", t, LOCATOR_TYPE_TITLES[t]] for i, t in enumerate(shown, 1)]
    console.table(["priority", "type", "includes"], rows)
    if types is None:
        console.say(
            "All types are on and ranked by score (default). Save your own order: locatorscan settings --set ..."
        )
        return 0
    excluded = [t for t in LOCATOR_TYPE_TITLES if t not in types]
    console.say(f"Excluded: {', '.join(excluded) or 'none'}")
    return 0


def cmd_login(ws: Workspace, args: argparse.Namespace) -> int:
    if not console.interactive():
        raise ConfigError("login needs a terminal and a display: a person signs in, in the browser it opens.")
    if ws.storage_state is None:
        raise ConfigError("Set storage_state in the config: it says where to keep the session.")
    visible = replace(ws, config=ws.config.model_copy(update={"headless": False}))
    PlaywrightEngine(visible).save_session(
        ws.resolve_url(args.url),
        ws.storage_state,
        lambda: console.ask_text("Sign in in the browser, then press Enter here", ""),
    )
    console.say(f"Session saved to {ws.storage_state}. Keep it private and out of git.")
    return 0


def cmd_schema(ws: Workspace, args: argparse.Namespace) -> int:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    for name, model in {
        "scan-result": ScanResult,
        "registry-page": RegistryPage,
        "page-validation": PageValidation,
        "page-stability": PageStability,
    }.items():
        path = out / f"{name}.schema.json"
        path.write_text(json.dumps(model.model_json_schema(), indent=2), encoding="utf-8")
        console.say(str(path))
    return 0


# ---------------------------------------------------------------- parser


_ALL_BUTTONS_HELP = "also include buttons outside a form or group, such as page chrome"


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="locatorscan", description="Form & Input Locator Scanner")
    p.add_argument("--version", action="version", version=f"locatorscan {__version__}")
    p.add_argument("--config", type=Path, help="scanner.config.yaml (default: ./scanner.config.yaml)")
    p.add_argument("--app-version", help="override app_version from config (label for this release)")
    p.add_argument("--types", metavar="TYPES", help="locator types for this run only, e.g. role,id (not saved)")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("scan", help="discover form fields and generate verified locators")
    s.add_argument("--url", required=True, help="absolute URL, path relative to base_url, or local HTML file")
    s.add_argument("--page", help="name for the registry and Page Object, e.g. trade_entry (default: from the URL)")
    s.add_argument("--scope", help="CSS selector to limit the scan (overrides config)")
    s.add_argument("--wait-for", help="load, domcontentloaded, networkidle or a CSS selector (overrides config)")
    s.add_argument("--all-buttons", action="store_true", help=_ALL_BUTTONS_HELP)
    s.set_defaults(func=cmd_scan)

    r = sub.add_parser("review", help="accept scanned fields into the registry")
    r.add_argument("--page", required=True)
    r.add_argument("--yes", action="store_true", help="accept every field at or above --min-tier without prompting")
    r.add_argument("--min-tier", choices=["BEST", "GOOD", "OK"], default="GOOD")
    r.set_defaults(func=cmd_review)

    g = sub.add_parser("generate", help="build Page Objects and CSV from the registry")
    g.add_argument("--page")
    g.set_defaults(func=cmd_generate)

    v = sub.add_parser("validate", help="re-check registry locators on the live page")
    v.add_argument("--page")
    v.add_argument("--url", help="check against this URL instead of the one stored in the registry")
    v.add_argument("--strict", action="store_true", help="also fail when a field only resolves via a fallback")
    v.set_defaults(func=cmd_validate)

    t = sub.add_parser("stability", help="scan a page several times and flag locators that change")
    t.add_argument("--url", required=True, help="absolute URL, path relative to base_url, or local HTML file")
    t.add_argument("--page", help="name for the output files (default: from the URL)")
    t.add_argument("--scope", help="CSS selector to limit the scan (overrides config)")
    t.add_argument("--wait-for", help="load, domcontentloaded, networkidle or a CSS selector (overrides config)")
    t.add_argument("--all-buttons", action="store_true", help=_ALL_BUTTONS_HELP)
    t.add_argument("--runs", type=int, default=2, help="number of scans, at least 2 (default: 2)")
    t.add_argument("--compare-state", type=Path, help="session file of another user, used for the last run")
    t.add_argument("--strict", action="store_true", help="also fail on partly dynamic and position-only fields")
    t.set_defaults(func=cmd_stability)

    st = sub.add_parser("settings", help="show or save which locator types to use, and their priority")
    group = st.add_mutually_exclusive_group()
    group.add_argument("--set", metavar="TYPES", help="types to keep, highest priority first, e.g. role,semantic,id")
    group.add_argument("--reset", action="store_true", help="back to the default: all types, ranked by score")
    st.set_defaults(func=cmd_settings)

    lg = sub.add_parser("login", help="sign in by hand in a browser and save the session for later scans")
    lg.add_argument("--url", required=True, help="any page of the site that leads to its sign-in")
    lg.set_defaults(func=cmd_login)

    a = sub.add_parser("apply-fixes", help="apply fix proposals from the last validation")
    a.add_argument("--page", required=True)
    a.add_argument("--yes", action="store_true", help="apply every proposal without prompting")
    a.set_defaults(func=cmd_apply_fixes)

    sc = sub.add_parser("schema", help="write JSON Schemas for the data contracts")
    sc.add_argument("--out", default="schemas")
    sc.set_defaults(func=cmd_schema)
    return p


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING, format="%(levelname)s %(message)s")
    try:
        ws = load_workspace(args.config)
        if args.app_version:
            ws.config.app_version = args.app_version
        if args.types:
            ws.config.locator_types = _parse_types(args.types)
        return int(args.func(ws, args))
    except LocatorScanError as exc:
        console.err(f"{exc.code}: {exc.message}")
        return exc.exit_code
    except KeyboardInterrupt:
        console.err("Interrupted")
        return 130


if __name__ == "__main__":
    sys.exit(main())
