"""All terminal output goes through here (the only module allowed to print)."""

from __future__ import annotations

import sys
from collections.abc import Sequence


def say(text: str = "") -> None:
    print(text)


def err(text: str) -> None:
    print(text, file=sys.stderr)


def table(headers: Sequence[str], rows: Sequence[Sequence[str]], max_width: int = 46) -> None:
    def cut(s: str) -> str:
        return s if len(s) <= max_width else s[: max_width - 1] + "…"

    cells = [[cut(str(c)) for c in row] for row in rows]
    widths = [max(len(h), *(len(r[i]) for r in cells)) if cells else len(h) for i, h in enumerate(headers)]
    print("  ".join(h.ljust(w) for h, w in zip(headers, widths, strict=True)))
    print("  ".join("-" * w for w in widths))
    for r in cells:
        print("  ".join(c.ljust(w) for c, w in zip(r, widths, strict=True)))


def ask(question: str, choices: str, default: str) -> str:
    """Ask a one-letter question, e.g. ask('Accept?', 'ars', 'a')."""
    while True:
        answer = input(f"{question} [{'/'.join(choices)}] (default {default}): ").strip().lower() or default
        if answer in choices:
            return answer
        print(f"Please answer one of: {', '.join(choices)}")


def ask_text(question: str, default: str) -> str:
    return input(f"{question} (default {default}): ").strip() or default


def interactive() -> bool:
    return sys.stdin.isatty()
