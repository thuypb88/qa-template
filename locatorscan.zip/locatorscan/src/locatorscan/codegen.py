"""Generate typed Playwright-Python Page Objects and CSV exports from the registry."""

from __future__ import annotations

import csv
import io
import keyword
import re
from pathlib import Path

from locatorscan.config import Workspace
from locatorscan.locators import describe, to_python
from locatorscan.models import RegistryPage
from locatorscan.ranking import snake


def class_name(page: str) -> str:
    return "".join(part.capitalize() for part in re.split(r"[^0-9a-zA-Z]+", page) if part) + "Page"


def _attr(key: str) -> str:
    return f"{key}_" if keyword.iskeyword(key) or key in {"page", "url", "goto"} else key


def page_object_source(rp: RegistryPage, url: str | None = None) -> str:
    """`url` is the resolved address written into the class; defaults to the registry value."""
    cls = class_name(rp.page)
    lines = [
        f'"""Generated from locators/{rp.page}.yaml by locatorscan (app version {rp.app_version}). Do not edit.',
        "",
        "Change locators through the registry (`locatorscan review`, `locatorscan apply-fixes`),",
        "then run `locatorscan generate`.",
        '"""',
        "",
        "from __future__ import annotations",
        "",
        "from playwright.sync_api import Locator, Page",
        "",
        "",
        f"class {cls}:",
        f"    URL = {(url or rp.url)!r}",
        "",
        "    def __init__(self, page: Page) -> None:",
        "        self.page = page",
        "",
        "    def goto(self) -> None:",
        "        self.page.goto(self.URL)",
    ]
    for key, f in rp.fields.items():
        doc_bits = [f.label or key]
        if f.group:
            doc_bits.append(f"({f.group})")
        doc = " ".join(doc_bits) + f" - {f.primary.tier}, {f.primary.strategy}."
        fallback = "; ".join(describe(s) for s in f.fallbacks)
        lines += [
            "",
            "    @property",
            f"    def {_attr(key)}(self) -> Locator:",
            f'        """{doc.replace(chr(34), chr(39))}',
        ]
        if fallback:
            lines.append(f"        Fallbacks: {fallback.replace(chr(34), chr(39))}")
        if f.xpath:
            lines.append(f"        XPath: {f.xpath.replace(chr(34), chr(39))}")
        lines += [
            '        """',
            f"        return {to_python(f.primary, f.frame_path)}",
        ]
    return "\n".join(lines) + "\n"


def csv_source(rp: RegistryPage) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(
        [
            "key",
            "label",
            "group",
            "kind",
            "tier",
            "strategy",
            "playwright",
            "xpath",
            "frame_path",
            "shadow_dom",
            "fallbacks",
            "last_verified",
        ]
    )
    for key, f in rp.fields.items():
        writer.writerow(
            [
                key,
                f.label or "",
                f.group or "",
                f.kind,
                f.primary.tier,
                f.primary.strategy,
                to_python(f.primary, f.frame_path, root="page"),
                f.xpath or "",
                " > ".join(f.frame_path),
                "yes" if f.in_shadow_dom else "no",
                " | ".join(describe(s) for s in f.fallbacks),
                f.last_verified,
            ]
        )
    return buf.getvalue()


def generate(ws: Workspace, rp: RegistryPage) -> tuple[Path, Path]:
    pages_dir = ws.generated_dir / "pages"
    pages_dir.mkdir(parents=True, exist_ok=True)
    init = pages_dir / "__init__.py"
    if not init.exists():
        init.write_text('"""Generated Page Objects. Do not edit."""\n', encoding="utf-8")
    po = pages_dir / f"{snake(rp.page)}_page.py"  # importable, whatever the page name
    po.write_text(page_object_source(rp, ws.resolve_url(rp.url)), encoding="utf-8")
    csv_path = ws.generated_dir / f"{rp.page}.csv"
    csv_path.write_text(csv_source(rp), encoding="utf-8")
    return po, csv_path
