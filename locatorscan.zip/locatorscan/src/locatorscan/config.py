"""Load `scanner.config.yaml` and resolve its relative paths."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml
from pydantic import ValidationError

from locatorscan.errors import ConfigError
from locatorscan.models import ScannerConfig

DEFAULT_CONFIG_NAME = "scanner.config.yaml"


@dataclass(frozen=True)
class Workspace:
    """A loaded config plus the folder its relative paths resolve against."""

    config: ScannerConfig
    root: Path

    @property
    def registry_dir(self) -> Path:
        return self.root / self.config.registry_dir

    @property
    def out_dir(self) -> Path:
        return self.root / self.config.out_dir

    @property
    def generated_dir(self) -> Path:
        return self.root / self.config.generated_dir

    @property
    def storage_state(self) -> Path | None:
        if self.config.storage_state is None:
            return None
        return self.root / self.config.storage_state

    def resolve_url(self, url: str) -> str:
        """Accept absolute URLs, base_url-relative paths, and local HTML files."""
        if "://" in url:
            return url
        local = (self.root / url).resolve()
        if local.exists():
            return local.as_uri()
        if self.config.base_url:
            return self.config.base_url.rstrip("/") + "/" + url.lstrip("/")
        raise ConfigError(f"Cannot resolve URL '{url}': not absolute, not a local file, and no base_url in config.")


def config_file(config_path: Path | None) -> Path:
    return config_path if config_path is not None else Path.cwd() / DEFAULT_CONFIG_NAME


def load_workspace(config_path: Path | None) -> Workspace:
    """Load the config file, or fall back to defaults in the current folder."""
    if config_path is None:
        candidate = Path.cwd() / DEFAULT_CONFIG_NAME
        if not candidate.exists():
            return Workspace(config=ScannerConfig(), root=Path.cwd())
        config_path = candidate
    if not config_path.exists():
        raise ConfigError(f"Config file not found: {config_path}")
    try:
        raw: object = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        config = ScannerConfig.model_validate(raw)
    except (yaml.YAMLError, ValidationError) as exc:
        raise ConfigError(f"Invalid config {config_path}: {exc}") from exc
    return Workspace(config=config, root=config_path.parent.resolve())
