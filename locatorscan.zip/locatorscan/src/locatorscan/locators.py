"""Turn stored LocatorSpecs into Playwright locators (at run time) or Python source (for Page Objects)."""

from __future__ import annotations

import json
from typing import Any

from playwright.sync_api import Frame, FrameLocator, Locator, Page

from locatorscan.models import LocatorSpec

Scope = Page | Frame | FrameLocator


def build(scope: Scope, spec: LocatorSpec) -> Locator:
    """Rebuild a Playwright locator from a stored spec."""
    if spec.kind == "role":
        role: Any = spec.value  # Playwright types the role as a Literal; the registry stores plain strings.
        return scope.get_by_role(role, name=spec.name, exact=True)
    if spec.kind == "label":
        return scope.get_by_label(spec.value, exact=True)
    if spec.kind == "placeholder":
        return scope.get_by_placeholder(spec.value, exact=True)
    if spec.kind == "css":
        return scope.locator(f"css={spec.value}")
    return scope.locator(f"xpath={spec.value}")


def in_frames(page: Page, frame_path: list[str]) -> Page | FrameLocator:
    scope: Page | FrameLocator = page
    for selector in frame_path:
        scope = scope.frame_locator(selector)
    return scope


def _lit(text: str) -> str:
    return json.dumps(text, ensure_ascii=False)


def to_python(spec: LocatorSpec, frame_path: list[str], root: str = "self.page") -> str:
    """Python source for the locator, e.g. `self.page.get_by_label("Trade Date", exact=True)`."""
    expr = root + "".join(f".frame_locator({_lit(sel)})" for sel in frame_path)
    if spec.kind == "role":
        return f"{expr}.get_by_role({_lit(spec.value)}, name={_lit(spec.name or '')}, exact=True)"
    if spec.kind == "label":
        return f"{expr}.get_by_label({_lit(spec.value)}, exact=True)"
    if spec.kind == "placeholder":
        return f"{expr}.get_by_placeholder({_lit(spec.value)}, exact=True)"
    prefix = "css=" if spec.kind == "css" else "xpath="
    return f"{expr}.locator({_lit(prefix + spec.value)})"


def playwright_code(spec: LocatorSpec, frame_path: list[str], index: int | None = None, root: str = "page") -> str:
    """Python to paste into a test, e.g. `page.locator('main > button').nth(2)`. `index` picks one of the matches."""
    expr = root + "".join(f".frame_locator({sel!r})" for sel in frame_path)
    if spec.kind == "role":
        name = f", name={spec.name!r}, exact=True" if spec.name else ""
        expr += f".get_by_role({spec.value!r}{name})"
    elif spec.kind == "label":
        expr += f".get_by_label({spec.value!r}, exact=True)"
    elif spec.kind == "placeholder":
        expr += f".get_by_placeholder({spec.value!r}, exact=True)"
    elif spec.kind == "xpath" and not spec.value.startswith("//"):
        expr += f".locator({'xpath=' + spec.value!r})"  # Playwright only auto-detects XPath from a leading //
    else:
        expr += f".locator({spec.value!r})"
    return expr if index is None else f"{expr}.nth({index})"


def describe(spec: LocatorSpec) -> str:
    """Short human form for reports: `label 'Trade Date'`, `xpath //input[@name='x']`."""
    if spec.kind == "role":
        return f"role {spec.value} '{spec.name}'"
    if spec.kind in ("label", "placeholder"):
        return f"{spec.kind} '{spec.value}'"
    return f"{spec.kind} {spec.value}"
