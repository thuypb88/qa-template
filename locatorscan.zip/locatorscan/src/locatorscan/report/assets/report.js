var byScore = !!document.querySelector('.settings[data-by-score]');
function apply() {
  var all = document.querySelectorAll('.set-order li');
  var rows = Array.prototype.filter.call(all, function (li) { return !li.hidden; });
  var types = rows.map(function (li) { return li.dataset.type; });
  rows.forEach(function (li, i) { li.querySelector('.set-num').textContent = i + 1; });
  document.querySelectorAll('details.locators').forEach(function (panel) {
    var cards = Array.prototype.slice.call(panel.querySelectorAll('.loc'));
    var rank = function (c) { return byScore ? 0 : types.indexOf(c.dataset.type); };
    cards.sort(function (a, b) { return rank(a) - rank(b) || a.dataset.i - b.dataset.i; });
    var end = panel.querySelector('.loc-end');
    cards.forEach(function (c) { c.hidden = types.indexOf(c.dataset.type) < 0; panel.insertBefore(c, end); });
    panel.querySelector('.loc-count').textContent = cards.filter(function (c) { return !c.hidden; }).length;
  });
  var command = document.querySelector('.set-command');
  if (command) {
    command.textContent = !types.length ? 'Tick at least one type'
      : byScore ? 'locatorscan settings --reset' : 'locatorscan settings --set ' + types.join(',');
    command.nextElementSibling.disabled = !types.length;
  }
}
function changed() { byScore = false; apply(); }
document.addEventListener('change', function (e) {
  if (!e.target.matches('.set-check input')) return;
  document.querySelector('.set-order li[data-type="' + e.target.dataset.type + '"]').hidden = !e.target.checked;
  changed();
});
var dragged = null;
document.addEventListener('dragstart', function (e) {
  if (e.target.matches && e.target.matches('.set-order li')) { dragged = e.target; dragged.classList.add('dragging'); }
});
document.addEventListener('dragover', function (e) {
  var over = dragged && e.target.closest && e.target.closest('.set-order li');
  if (!over) return;
  e.preventDefault();
  if (over === dragged) return;
  var box = over.getBoundingClientRect(), after = e.clientY > box.top + box.height / 2;
  over.parentNode.insertBefore(dragged, after ? over.nextSibling : over);
});
document.addEventListener('dragend', function () {
  if (dragged) { dragged.classList.remove('dragging'); dragged = null; changed(); }
});
document.addEventListener('click', function (e) {
  var t = e.target;
  if (t.matches('.copy') && !t.disabled) {
    var text = t.previousElementSibling.textContent;
    var done = function () { t.textContent = 'Copied'; setTimeout(function () { t.textContent = 'Copy'; }, 1200); };
    var legacy = function () {
      var a = document.createElement('textarea');
      a.value = text; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove(); done();
    };
    if (navigator.clipboard) { navigator.clipboard.writeText(text).then(done, legacy); } else { legacy(); }
  } else if (t.matches('.set-up, .set-down')) {
    var row = t.closest('li'), up = t.matches('.set-up'), other = row;
    do { other = up ? other.previousElementSibling : other.nextElementSibling; } while (other && other.hidden);
    if (other) { row.parentNode.insertBefore(up ? row : other, up ? other : row); changed(); }
  } else if (t.matches('.set-reset')) {
    var list = document.querySelector('.set-order');
    Array.prototype.slice.call(list.children)
      .sort(function (a, b) { return a.dataset.d - b.dataset.d; })
      .forEach(function (li) { li.hidden = false; list.appendChild(li); });
    document.querySelectorAll('.set-check input').forEach(function (c) { c.checked = true; });
    byScore = true; apply();
  } else if (t.matches('.toggle-all')) {
    var open = t.dataset.open !== 'true';
    document.querySelectorAll('details.locators').forEach(function (d) { d.open = open; });
    t.dataset.open = String(open);
    t.textContent = (open ? 'Collapse' : 'Expand') + ' all locators';
  }
});
