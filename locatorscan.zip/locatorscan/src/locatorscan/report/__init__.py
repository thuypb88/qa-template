"""Self-contained HTML reports for scans, validations and stability checks (no external assets, readable offline)."""

from locatorscan.report.layout import write
from locatorscan.report.scan import scan_html
from locatorscan.report.stability import stability_html
from locatorscan.report.validation import validation_html

__all__ = ["scan_html", "stability_html", "validation_html", "write"]
