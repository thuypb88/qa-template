"""The stability report: fields grouped by how far their locators can be trusted."""

from __future__ import annotations

from html import escape

from locatorscan.models import (
    FieldStability,
    PageStability,
    StabilityStatus,
)
from locatorscan.report.layout import category_card, element_line, plural, render_page, status_badge

_STABILITY_SECTIONS: dict[StabilityStatus, tuple[str, str, str, str]] = {
    # status: category title, badge class, noun for the count, what the reader should do
    "NOT_IN_ALL_RUNS": ("Not found in every run", "fail", "failed", "Check whether the field depends on user or data."),
    "DYNAMIC": ("Dynamic", "fail", "failed", "Do not use this locator; ask for a stable attribute such as a test id."),
    "VOLATILE_TEXT": ("Volatile text", "warn", "failed", "Do not rely on this text; it can change with data or user."),
    "PARTLY_DYNAMIC": ("Partly dynamic", "warn", "warning", "The primary is safe; avoid copying the changed locators."),
    "POSITION_ONLY": (
        "Position only",
        "warn",
        "warning",
        "Unchanged so far, but ask for a stable attribute such as a test id.",
    ),
    "NO_LOCATOR": ("No locator", "info", "not compared", "No unique locator exists; ask for a test id."),
    "STABLE": ("Stable", "pass", "passed", ""),
}


def _stability_row(r: FieldStability, runs: list[str], cls: str) -> str:
    lines: list[str] = []
    for change in r.changes:
        title = "primary" if change.strategy == "primary" else f"{change.strategy} ({change.kind})"
        lines.append(f'<div class="sub">{escape(title)}</div>')
        lines.extend(element_line(run, value) for run, value in zip(runs, change.values, strict=True))
    detail = f'<div class="sub">{escape(r.detail)}</div>' if r.detail else ""
    return (
        f'<div class="issue">{status_badge(r.status, cls)}{escape(r.label or "(no label)")} '
        f'<code class="key">{escape(r.key)}</code>{detail}{"".join(lines)}</div>'
    )


def stability_html(s: PageStability) -> str:
    sections: list[str] = []
    for status, (title, cls, noun, advice) in _STABILITY_SECTIONS.items():
        rows = [_stability_row(r, s.runs, cls) for r in s.results if r.status == status]
        if rows:
            count = plural(len(rows), noun) if noun == "warning" else f"{len(rows)} {noun}"
            note = f'<div class="issue sub">{escape(advice)}</div>' if advice else ""
            sections.append(category_card(title, count, [note, *rows]))
    if s.partial:
        note = (
            f'<div class="issue">{status_badge("PARTIAL", "fail")}A run hit the scan budget, so raise timeout_ms.</div>'
        )
        sections.insert(0, category_card("Fields not compared", plural(s.not_compared, "field"), [note]))
    cards = [
        ("Total", len(s.results), ""),
        ("Stable", s.count("STABLE"), "pass"),
        ("Dynamic", s.count("DYNAMIC") + s.count("NOT_IN_ALL_RUNS"), "fail"),
        ("Volatile text", s.count("VOLATILE_TEXT"), "warn"),
        ("Partly dynamic", s.count("PARTLY_DYNAMIC"), "warn"),
        ("Position only", s.count("POSITION_ONLY"), "warn"),
        ("No locator", s.count("NO_LOCATOR"), ""),
    ]
    return render_page(
        f"Stability · {s.page}",
        [("URL", s.url), ("Checked", s.checked_at)],
        [f"App {s.app_version}", f"Compared: {', '.join(s.runs)}"],
        cards,
        "".join(sections),
    )
