"""The scan report: fields grouped by where they sit on the page, each with its locator panel and the settings form."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from html import escape

from locatorscan.locators import describe, playwright_code
from locatorscan.models import (
    Candidate,
    FieldRecord,
    LocatorType,
    ScanResult,
)
from locatorscan.ranking import LOCATOR_TYPE_TITLES, allowed, locator_type
from locatorscan.report.layout import (
    TIER_CLASS,
    category_card,
    element_line,
    plural,
    render_page,
    status_badge,
    xpath_line,
)

# Cards in the order people reach for them; any other candidate follows, best score first.
_CARD_TITLES = {
    "smart-anchor": "Smart Locator (anchored)",
    "smart-partial": "Smart Locator (partial match)",
    "smart-attribute": "Smart Locator (attribute)",
    "class-names": "Class Names",
    "css-path": "CSS",
    "xpath-path": "XPath",
    "xpath-absolute": "Absolute XPath",
    "xpath-position": "Position XPath",
    "role": "get_by_role",
    "role-only": "get_by_role",
    "label": "get_by_label",
}
_UNIQUE_PILL = '<span class="pill pass">✓ 1</span>'
_FRAGILE = frozenset({"xpath-absolute", "xpath-position", "positional"})

_LANDMARKS = frozenset({"header", "nav", "main", "aside", "footer", "form", "fieldset", "section", "article", "dialog"})
_NO_LANDMARK = "Outside page landmarks"


@dataclass
class _Category:
    title: str
    path: str | None = None
    fields: list[FieldRecord] = field(default_factory=lambda: list[FieldRecord]())


def _region(path: str | None) -> tuple[str, str | None]:
    """Title and path prefix of the innermost landmark on an absolute XPath such as /html[1]/body[1]/main[1]/div[2]."""
    if not path or not path.startswith("/html"):
        return _NO_LANDMARK, None
    segments = path.strip("/").split("/")
    hits = [i for i, s in enumerate(segments) if s.split("[")[0].lower() in _LANDMARKS]
    if not hits:
        return _NO_LANDMARK, None
    names = [segments[i].removesuffix("[1]") for i in hits[:-1]] + [segments[hits[-1]]]
    return " › ".join(names), "/" + "/".join(segments[: hits[-1] + 1])


def _positional(f: FieldRecord) -> str | None:
    return next((c.value for c in f.candidates if c.strategy == "positional"), None)


def _group_scan(fields: Iterable[FieldRecord]) -> list[_Category]:
    """Categories in page order: frame first, then the field's named group, else its landmark."""
    categories: dict[str, _Category] = {}
    for f in fields:
        title, path = (f.group, None) if f.group else _region(_positional(f))
        if f.frame_path:
            title = f"Frame {' > '.join(f.frame_path)} › {title}"
        categories.setdefault(title, _Category(title, path)).fields.append(f)
    return list(categories.values())


def _reaches_field(c: Candidate) -> bool:
    return c.is_target or c.target_index is not None


def _card_order(c: Candidate, types: list[LocatorType] | None) -> tuple[int, int, float]:
    priority = (types.index(locator_type(c)) if locator_type(c) in types else len(types)) if types else 0
    order = list(_CARD_TITLES)
    return (priority, order.index(c.strategy), 0.0) if c.strategy in _CARD_TITLES else (priority, len(order), -c.score)


def _card_title(c: Candidate) -> str:
    if c.strategy in _CARD_TITLES:
        return _CARD_TITLES[c.strategy]
    return f"{c.strategy.replace('-', ' ').capitalize()} ({c.kind})"


def _locator_card(c: Candidate, frame_path: list[str], types: list[LocatorType] | None, index: int) -> str:
    many = c.match_count > 1
    fragile = c.strategy in _FRAGILE
    place = f" · element {c.target_index + 1} of {c.match_count} matches" if many and c.target_index is not None else ""
    code = playwright_code(c, frame_path, c.target_index if many else None)
    tier = "FRAGILE" if fragile else c.tier
    tier_cls = "fail" if fragile else TIER_CLASS[c.tier]
    matches = f'<span class="pill warn">{c.match_count} matches</span>' if many else _UNIQUE_PILL
    return (
        f'<div class="loc{" fragile" if fragile else ""}" data-type="{locator_type(c)}" data-i="{index}"'
        f'{"" if allowed(c, types) else " hidden"}><div class="loc-head">'
        f'<span class="loc-title">{escape(_card_title(c))}</span>{matches}'
        f'<span class="pill {tier_cls}">{tier}</span></div>'
        f'<div class="sub">{escape(c.explanation)}{escape(place)}</div>'
        f'<div class="loc-code"><code>{escape(code)}</code><button class="copy" type="button">Copy</button></div></div>'
    )


def _locator_panel(f: FieldRecord, types: list[LocatorType] | None) -> str:
    usable = [c for c in f.candidates if _reaches_field(c)]
    rejected = len(f.candidates) - len(usable)
    if any(c.strategy == "xpath-absolute" for c in usable):
        usable = [c for c in usable if c.strategy != "positional"]  # the same path, written with every index
    defaults = {id(c): i for i, c in enumerate(sorted(usable, key=lambda c: _card_order(c, None)))}
    cards: dict[str, tuple[Candidate, str]] = {}
    for c in sorted(usable, key=lambda c: _card_order(c, types)):
        cards.setdefault(playwright_code(c, f.frame_path), (c, _locator_card(c, f.frame_path, types, defaults[id(c)])))
    if not cards:
        return ""
    shown = sum(1 for c, _ in cards.values() if allowed(c, types))
    note = f"{plural(rejected, 'other candidate')} did not reach this element." if rejected else ""
    return (
        f'<details class="locators"><summary>CSS &amp; XPath (<span class="loc-count">{shown}</span>)</summary>'
        f'{"".join(html for _, html in cards.values())}<div class="sub loc-end">{note}</div></details>'
    )


def _settings_panel(types: list[LocatorType] | None) -> str:
    """The saved setting as a form. A static page cannot write the config, so it builds the command that does."""
    defaults: list[LocatorType] = list(LOCATOR_TYPE_TITLES)
    current: list[LocatorType] = types or defaults
    ordered: list[LocatorType] = [*current, *(d for d in defaults if d not in current)]
    checks = "".join(
        f'<label class="set-check"><input type="checkbox" data-type="{t}"{" checked" if t in current else ""}>'
        f"{escape(LOCATOR_TYPE_TITLES[t])}</label>"
        for t in defaults
    )
    rows = "".join(
        f'<li draggable="true" data-type="{t}" data-d="{defaults.index(t)}"{"" if t in current else " hidden"}>'
        '<span class="set-handle" aria-hidden="true">≡</span>'
        f'<span class="set-num">{current.index(t) + 1 if t in current else ""}</span>'
        f'<span class="set-name">{escape(LOCATOR_TYPE_TITLES[t])}</span>'
        f'<button class="set-move set-up" type="button" aria-label="Move {t} up">↑</button>'
        f'<button class="set-move set-down" type="button" aria-label="Move {t} down">↓</button></li>'
        for t in ordered
    )
    now = " > ".join(types) if types else "all types, ranked by score"
    command = f"locatorscan settings --set {','.join(types)}" if types else "locatorscan settings --reset"
    return (
        f'<details class="settings" open{"" if types else " data-by-score"}><summary>Locator type settings</summary>'
        f'<div class="settings-body"><div class="sub">This scan used: {escape(now)}. Changes here update the '
        "CSS &amp; XPath cards below straight away. To change primary locators, run the command, then re-scan "
        "and review.</div>"
        '<div class="set-cols"><div><h3>Include locator types</h3><div class="sub">Untick to exclude a type</div>'
        f"{checks}</div>"
        '<div><h3>Priority order</h3><div class="sub">Drag or use the arrows (top = highest)</div>'
        f'<ol class="set-order">{rows}</ol></div></div>'
        '<div class="set-foot"><h3>Save for future scans</h3><div class="loc-code">'
        f'<code class="set-command">{escape(command)}</code><button class="copy" type="button">Copy</button></div>'
        '<button class="set-reset" type="button">Reset to default</button></div></div></details>'
    )


def _scan_row(f: FieldRecord, types: list[LocatorType] | None) -> str:
    badge = status_badge(f.primary.tier, TIER_CLASS[f.primary.tier]) if f.primary else status_badge("NONE", "fail")
    chips = [f.kind] + (["shadow DOM"] if f.in_shadow_dom else []) + f.warnings
    lines: list[str] = []
    if f.primary:
        lines.append(element_line("primary", describe(f.primary)))
        if "→" in f.primary.explanation:
            lines.append(f'<div class="sub">{escape(f.primary.explanation)}</div>')
    lines.extend(xpath_line(f.xpath, [f.primary, *f.fallbacks]))
    lines.extend(element_line(f"fallback {i}", describe(x)) for i, x in enumerate(f.fallbacks, 1))
    lines.append(_locator_panel(f, types))
    return (
        f'<div class="issue">{badge}{escape(f.label or "(no label)")} <code class="key">{escape(f.key)}</code>'
        f'<span class="sub"> · {escape(f.label_source)}</span>'
        f"{''.join(f'<span class=chip>{escape(c)}</span>' for c in chips)}{''.join(lines)}</div>"
    )


def _tier_counts(fields: Iterable[FieldRecord]) -> dict[str, int]:
    counts = {"BEST": 0, "GOOD": 0, "OK": 0, "NONE": 0}
    for f in fields:
        counts[f.primary.tier if f.primary else "NONE"] += 1
    return counts


def scan_html(scan: ScanResult) -> str:
    totals = _tier_counts(scan.fields)
    sections = [
        category_card(
            c.title,
            ", ".join(f"{n} {tier}" for tier, n in _tier_counts(c.fields).items() if n),
            (_scan_row(f, scan.locator_types) for f in c.fields),
            c.path,
        )
        for c in _group_scan(scan.fields)
    ]
    if scan.frame_errors:
        rows = [f'<div class="issue">{status_badge("FAIL", "fail")}{escape(e)}</div>' for e in scan.frame_errors]
        sections.insert(0, category_card("Frames not scanned", plural(len(rows), "error"), rows))
    cards = [
        ("Total", len(scan.fields), ""),
        ("Best", totals["BEST"], "pass"),
        ("Good", totals["GOOD"], "good"),
        ("OK", totals["OK"], "warn"),
        ("No locator", totals["NONE"], "fail"),
    ]
    return render_page(
        f"Scan · {scan.page}",
        [("URL", scan.url), ("Scanned", scan.scanned_at)],
        [
            f"App {scan.app_version}",
            f"Status {scan.status}",
            f"{plural(scan.skipped_hidden_inputs, 'hidden input')} skipped",
            f"Locator types: {' > '.join(scan.locator_types) if scan.locator_types else 'all, by score'}",
        ],
        cards,
        "".join(sections),
        _settings_panel(scan.locator_types),
    )
