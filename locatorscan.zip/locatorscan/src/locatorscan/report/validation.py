"""The validation report: registry locators grouped by outcome, problems first."""

from __future__ import annotations

from html import escape

from locatorscan.locators import describe
from locatorscan.models import (
    FieldStatus,
    FieldValidation,
    PageValidation,
    RegistryPage,
)
from locatorscan.report.layout import category_card, element_line, plural, render_page, status_badge, xpath_line

_STATUS_CLASS: dict[FieldStatus, str] = {
    "BROKEN": "fail",
    "MISSING_FRAME": "fail",
    "NON_UNIQUE": "fail",
    "FALLBACK_USED": "warn",
    "OK": "pass",
}
_STATUS_ORDER: dict[FieldStatus, str] = {  # problems first; the titles are the category headers
    "BROKEN": "Broken",
    "MISSING_FRAME": "Frame missing",
    "NON_UNIQUE": "Not unique",
    "FALLBACK_USED": "Fallback used",
    "OK": "OK",
}


def _validation_row(r: FieldValidation, registry: RegistryPage) -> str:
    lines: list[str] = []
    stored = registry.fields.get(r.key)
    if stored:
        lines.append(element_line("primary", describe(stored.primary)))
        lines.extend(xpath_line(stored.xpath, [stored.primary, *stored.fallbacks]))
        lines.extend(element_line(f"fallback {i}", describe(x)) for i, x in enumerate(stored.fallbacks, 1))
    if r.proposal:
        p = r.proposal
        matched = f" · matched {p.matched_label!r}" if p.matched_label else ""
        lines.append(element_line(f"proposed fix ({p.new_primary.tier}, needs approval)", describe(p.new_primary)))
        lines.append(f'<div class="sub">{escape(p.reason)} · similarity {p.similarity:.2f}{escape(matched)}</div>')
    used = f'<span class="chip">resolved by {escape(r.used)}</span>' if r.used else ""
    detail = f'<div class="sub">{escape(r.detail)}</div>' if r.detail else ""
    return (
        f'<div class="issue">{status_badge(r.status, _STATUS_CLASS[r.status])}{escape(r.label or "(no label)")} '
        f'<code class="key">{escape(r.key)}</code>{used}{detail}{"".join(lines)}</div>'
    )


def validation_html(v: PageValidation, registry: RegistryPage) -> str:
    sections: list[str] = []
    for status, title in _STATUS_ORDER.items():
        rows = [_validation_row(r, registry) for r in v.results if r.status == status]
        if rows:
            counts = {
                "fail": f"{len(rows)} failed",
                "warn": plural(len(rows), "warning"),
                "pass": f"{len(rows)} passed",
            }
            sections.append(category_card(title, counts[_STATUS_CLASS[status]], rows))
    if v.new_fields:
        rows = [f'<div class="issue">{status_badge("NEW", "info")}{escape(n)}</div>' for n in v.new_fields]
        sections.append(category_card("New fields not in the registry", f"{len(rows)} new", rows))
    failed = v.count("BROKEN") + v.count("MISSING_FRAME") + v.count("NON_UNIQUE")
    cards = [
        ("Total", len(v.results), ""),
        ("Passed", v.count("OK"), "pass"),
        ("Failed", failed, "fail"),
        ("Warnings", v.count("FALLBACK_USED"), "warn"),
    ]
    return render_page(
        f"Validation · {v.page}",
        [("URL", v.url), ("Checked", v.checked_at)],
        [
            f"Registry {v.registry_version} → checked on {v.checked_version}",
            plural(sum(1 for r in v.results if r.proposal), "fix proposal"),
            plural(len(v.new_fields), "new field"),
        ],
        cards,
        "".join(sections),
    )
