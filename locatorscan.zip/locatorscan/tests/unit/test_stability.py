"""Comparison logic with hand-built scans. No browser."""

from __future__ import annotations

from typing import Any

import pytest

from locatorscan.models import FieldRecord, LocatorSpec, ScanResult
from locatorscan.report import stability_html
from locatorscan.stability import VOLATILE_TEXT_WARNING, compare, is_volatile_text


def _candidate(strategy: str, kind: str, value: str, **kw: Any) -> dict[str, Any]:
    base = {"strategy": strategy, "kind": kind, "value": value, "tier": "OK", "score": 0.1}
    return base | {"match_count": 1, "is_target": True} | kw


def _field(key: str, primary: str | None, path: str = "/html[1]/body[1]/main[1]/input[1]", **kw: Any) -> FieldRecord:
    spec = {"kind": "css", "value": primary, "strategy": "id", "tier": "GOOD", "score": 0.86} if primary else None
    data: dict[str, Any] = {
        "key": key,
        "label": key,
        "label_source": "text",
        "group": None,
        "kind": "text",
        "tag": "input",
        "input_type": "text",
        "role": "textbox",
        "state": {"visible": True, "disabled": False, "readonly": False, "required": False},
        "frame_path": [],
        "in_shadow_dom": False,
        "primary": spec,
        "fallbacks": [],
        "xpath": None,
        "candidates": [_candidate("positional", "xpath", path)],
        "fingerprint": {"tag": "input", "role": "textbox", "input_type": "text", "label": key},
        "warnings": [],
    }
    return FieldRecord.model_validate(data | kw)


def _run(*fields: FieldRecord, status: str = "OK") -> ScanResult:
    return ScanResult.model_validate(
        {"page": "p", "url": "u", "app_version": "1", "scanned_at": "t", "status": status, "fields": list(fields)}
    )


def _statuses(*runs: ScanResult) -> dict[str, str]:
    labels = [f"run {i}" for i in range(len(runs))]
    return {r.key: r.status for r in compare(runs, labels).results}


def test_same_scans_are_stable() -> None:
    assert _statuses(_run(_field("a", "#a")), _run(_field("a", "#a"))) == {"a": "STABLE"}


def test_changed_primary_is_dynamic_and_keeps_each_value() -> None:
    result = compare([_run(_field("a", "#x1")), _run(_field("a", "#x2"))], ["one", "two"])
    assert result.results[0].status == "DYNAMIC"
    assert result.results[0].changes[0].values == ["css #x1", "css #x2"]


def test_a_changed_label_is_still_the_same_field_when_the_position_holds() -> None:
    assert _statuses(_run(_field("run_abc", "#a")), _run(_field("run_xyz", "#b"))) == {"run_abc": "DYNAMIC"}


def test_changed_secondary_locator_is_partly_dynamic() -> None:
    path = _candidate("positional", "xpath", "/html[1]/body[1]/main[1]/input[1]")
    one = _field("a", "#a", candidates=[path, _candidate("name", "css", "[name=x1]")])
    two = _field("a", "#a", candidates=[path, _candidate("name", "css", "[name=x2]")])
    assert _statuses(_run(one), _run(two)) == {"a": "PARTLY_DYNAMIC"}


def test_a_changed_position_among_matches_counts_as_a_change() -> None:
    path = _candidate("positional", "xpath", "/html[1]/body[1]/main[1]/input[1]")
    many = {"match_count": 5, "is_target": False}
    one = _field("a", "#a", candidates=[path, _candidate("css-path", "css", "a", target_index=1, **many)])
    two = _field("a", "#a", candidates=[path, _candidate("css-path", "css", "a", target_index=3, **many)])
    assert _statuses(_run(one), _run(two)) == {"a": "PARTLY_DYNAMIC"}


def test_a_moved_field_is_matched_by_identity() -> None:
    moved = _field("a", "#a", path="/html[1]/body[1]/main[1]/input[9]")
    assert _statuses(_run(_field("a", "#a")), _run(moved)) == {"a": "PARTLY_DYNAMIC"}


def test_field_in_one_run_only() -> None:
    result = compare([_run(_field("a", "#a")), _run()], ["one", "two"])
    assert result.results[0].status == "NOT_IN_ALL_RUNS"
    assert "two" in result.results[0].detail


def test_a_partial_scan_cannot_prove_a_field_is_missing() -> None:
    result = compare([_run(_field("a", "#a")), _run(status="PARTIAL")], ["one", "two"])
    assert (result.partial, result.not_compared, result.results) == (True, 1, [])


def test_unchanged_volatile_text_is_flagged_and_outranked_by_a_real_change() -> None:
    warned = {"warnings": [VOLATILE_TEXT_WARNING]}
    assert _statuses(_run(_field("a", "#a", **warned)), _run(_field("a", "#a", **warned))) == {"a": "VOLATILE_TEXT"}
    assert _statuses(_run(_field("a", "#x", **warned)), _run(_field("a", "#y", **warned))) == {"a": "DYNAMIC"}


def test_an_unchanged_positional_primary_is_not_called_stable() -> None:
    spec = {"kind": "xpath", "value": "/html[1]/body[1]/input[1]", "strategy": "positional", "tier": "OK", "score": 0.3}
    field = _field("a", None).model_copy(update={"primary": LocatorSpec.model_validate(spec)})
    assert _statuses(_run(field), _run(field)) == {"a": "POSITION_ONLY"}


def test_no_locator_in_any_run() -> None:
    assert _statuses(_run(_field("a", None)), _run(_field("a", None))) == {"a": "NO_LOCATOR"}


@pytest.mark.parametrize("text", ["278", "1,250.00", "2026-11-05", "12:30", "50 %"])
def test_numbers_and_dates_are_volatile(text: str) -> None:
    assert is_volatile_text(text, [])


@pytest.mark.parametrize("text", ["Save", "Step 2", "", None])
def test_ordinary_text_is_not_volatile(text: str | None) -> None:
    assert not is_volatile_text(text, [])


def test_project_patterns_make_text_volatile() -> None:
    assert is_volatile_text("Jane Doe (acme_db)", ["^Jane Doe"])


def test_compare_needs_two_runs() -> None:
    with pytest.raises(ValueError):
        compare([_run()], ["one"])


def test_report_groups_by_status_and_escapes_values() -> None:
    result = compare([_run(_field("a", "#<x>")), _run(_field("a", "#y"))], ["one", "two"])
    html = stability_html(result)
    assert "Dynamic (1 failed)" in html
    assert "#&lt;x&gt;" in html
    assert "#<x>" not in html


def test_a_field_that_moved_keeps_its_primary_and_is_not_confused_with_the_new_occupant() -> None:
    a1 = _field("a", "#a", path="/html[1]/main[1]/article[1]/button[1]")
    b1 = _field("b", "#b", path="/html[1]/main[1]/article[2]/button[1]")
    a2 = _field("a", "#a", path="/html[1]/main[1]/article[2]/button[1]")
    b2 = _field("b", "#b", path="/html[1]/main[1]/article[1]/button[1]")
    assert _statuses(_run(a1, b1), _run(b2, a2)) == {"a": "PARTLY_DYNAMIC", "b": "PARTLY_DYNAMIC"}
