from __future__ import annotations

import pytest

from locatorscan import ranking
from locatorscan.models import Candidate, Fingerprint


def cand(strategy: str, kind: str, score: float, ok: bool = True, count: int = 1) -> Candidate:
    return Candidate(
        kind=kind,
        value=f"{strategy}-v",
        strategy=strategy,
        tier="GOOD",
        score=score,
        match_count=count,
        is_target=ok,
    )


def test_choose_picks_highest_verified_candidate() -> None:
    primary, _, _ = ranking.choose([cand("id", "css", 0.86), cand("role", "role", 0.95, ok=False, count=2)])
    assert primary is not None and primary.strategy == "id"


def test_choose_returns_none_when_nothing_unique() -> None:
    assert ranking.choose([cand("label", "label", 0.93, ok=False, count=2)]) == (None, [], None)


def test_choose_fallbacks_come_from_different_strategy_families() -> None:
    _, fallbacks, _ = ranking.choose(
        [
            cand("role", "role", 0.95),
            cand("label", "label", 0.93),  # same family as role (label text)
            cand("label-for", "xpath", 0.82),  # same family again
            cand("id", "css", 0.86),
            cand("name", "xpath", 0.80),
            cand("scoped-name", "xpath", 0.78),  # 'name' family, already used
        ]
    )
    assert [f.strategy for f in fallbacks] == ["id", "name"]


def test_choose_never_uses_positional_as_fallback() -> None:
    _, fallbacks, _ = ranking.choose([cand("role", "role", 0.95), cand("positional", "xpath", 0.3)])
    assert fallbacks == []


def test_choose_keeps_one_other_kind_when_only_one_family_exists() -> None:
    _, fallbacks, xpath = ranking.choose([cand("role", "role", 0.95), cand("text", "xpath", 0.8)])
    assert [f.strategy for f in fallbacks] == ["text"]
    assert xpath == "text-v"


def test_snake_makes_valid_identifiers() -> None:
    assert ranking.snake("Trade Date *") == "trade_date"
    assert ranking.snake("Instrument (ISIN)") == "instrument_isin"
    assert ranking.snake("1st leg") == "f_1st_leg"
    assert ranking.snake("***") == "field"


def test_make_keys_scopes_duplicates_by_group() -> None:
    keys = ranking.make_keys([("Amount", "Leg 1", "a"), ("Amount", "Leg 2", "b"), ("Currency", "Leg 1", "c")])
    assert keys == ["leg_1_amount", "leg_2_amount", "currency"]


def test_make_keys_numbers_remaining_duplicates() -> None:
    assert ranking.make_keys([("Name", None, "x"), ("Name", None, "y")]) == ["name", "name_2"]


def test_similarity_identical_is_one() -> None:
    fp = Fingerprint(tag="input", input_type="text", label="Settlement Account", name="acc", group="Settlement")
    assert ranking.similarity(fp, fp) == 1.0


def test_similarity_label_case_change_still_heals() -> None:
    stored = Fingerprint(
        tag="input",
        input_type="text",
        role="textbox",
        label="Settlement Account",
        name="settleAccount",
        group="Settlement",
    )
    found = stored.model_copy(update={"label": "Settlement account", "name": "settlementAccount", "id": "stl-acc"})
    assert ranking.similarity(stored, found) >= ranking.HEAL_THRESHOLD


def test_similarity_unrelated_field_stays_below_threshold() -> None:
    stored = Fingerprint(tag="input", input_type="number", label="Quantity", name="quantity", group="Trade details")
    found = Fingerprint(tag="input", input_type="text", label="Trader", name="trader", group="Trade details")
    assert ranking.similarity(stored, found) < ranking.HEAL_THRESHOLD


def test_similarity_penalises_different_tag() -> None:
    a = Fingerprint(tag="input", label="Comments")
    b = Fingerprint(tag="textarea", label="Comments")
    assert ranking.similarity(a, b) == 0.5


def test_reference_locators_are_never_chosen() -> None:
    reference = [cand(s, "css", 0.99) for s in sorted(ranking.REFERENCE_STRATEGIES)]
    assert ranking.choose(reference) == (None, [], None)
    primary, fallbacks, _ = ranking.choose([*reference, cand("id", "css", 0.86)])
    assert primary is not None and primary.strategy == "id"
    assert fallbacks == []


def test_default_ranking_is_by_score_alone() -> None:
    primary, _, _ = ranking.choose(
        [cand("id", "css", 0.86), cand("test-attr", "css", 0.98), cand("role", "role", 0.95)]
    )
    assert primary is not None and primary.strategy == "test-attr"


def test_an_excluded_type_is_never_chosen() -> None:
    candidates = [cand("role", "role", 0.95), cand("id", "css", 0.86), cand("name", "xpath", 0.8)]
    primary, fallbacks, xpath = ranking.choose(candidates, ["id"])
    assert primary is not None and primary.strategy == "id"
    assert (fallbacks, xpath) == ([], None)


def test_priority_order_beats_score() -> None:
    primary, fallbacks, _ = ranking.choose(
        [cand("role", "role", 0.95), cand("id", "css", 0.86), cand("name", "xpath", 0.8)], ["name", "id", "role"]
    )
    assert primary is not None and primary.strategy == "name"
    assert [f.strategy for f in fallbacks] == ["id", "role"]


def test_an_absolute_path_stays_the_last_resort_even_when_xpath_comes_first() -> None:
    candidates = [cand("positional", "xpath", 0.3), cand("role", "role", 0.95)]
    primary, _, _ = ranking.choose(candidates, ["xpath", "role"])
    assert primary is not None and primary.strategy == "role"
    primary, _, _ = ranking.choose([cand("positional", "xpath", 0.3)], ["xpath", "role"])
    assert primary is not None and primary.strategy == "positional"


def test_no_allowed_type_means_no_locator() -> None:
    assert ranking.choose([cand("role", "role", 0.95)], ["id"]) == (None, [], None)


@pytest.mark.parametrize(
    ("strategy", "kind", "expected"),
    [
        ("role", "role", "role"),
        ("role-only", "role", "role"),
        ("test-attr", "css", "semantic"),
        ("test-attr", "xpath", "semantic"),
        ("label", "label", "semantic"),
        ("placeholder", "xpath", "semantic"),
        ("id", "xpath", "id"),
        ("scoped-name", "xpath", "name"),
        ("css-path", "css", "css"),
        ("class-names", "css", "css"),
        ("text", "xpath", "xpath"),
        ("label-for", "xpath", "xpath"),
        ("positional", "xpath", "xpath"),
    ],
)
def test_strategies_map_to_their_settings_group(strategy: str, kind: str, expected: str) -> None:
    assert ranking.locator_type(cand(strategy, kind, 0.5)) == expected


def test_css_reference_locators_are_chosen_only_when_css_is_asked_for() -> None:
    css = cand("css-path", "css", 0.1)
    assert ranking.choose([css]) == (None, [], None)
    assert ranking.choose([css], ["role"]) == (None, [], None)
    primary, _, _ = ranking.choose([css], ["css"])
    assert primary is not None and primary.strategy == "css-path"
    assert ranking.choose([cand("xpath-path", "xpath", 0.1)], ["xpath"]) == (None, [], None)


def test_a_smart_locator_replaces_an_absolute_path_and_nothing_better() -> None:
    smart, path = cand("smart-anchor", "xpath", 0.55), cand("positional", "xpath", 0.3)
    primary, _, xpath = ranking.choose([path, smart])
    assert primary is not None and primary.strategy == "smart-anchor"
    assert xpath == "smart-anchor-v"
    primary, _, _ = ranking.choose([path, smart, cand("placeholder", "placeholder", 0.6)])
    assert primary is not None and primary.strategy == "placeholder"


def test_a_smart_locator_is_never_a_fallback() -> None:
    smart = cand("smart-anchor", "xpath", 0.55)
    assert ranking.choose([cand("role", "role", 0.95), smart])[1] == []
    assert ranking.choose([cand("role", "role", 0.95), smart, cand("smart-partial", "xpath", 0.53)])[1] == []


def test_settings_can_turn_smart_locators_off_or_put_them_first() -> None:
    smart, role = cand("smart-anchor", "xpath", 0.55), cand("role", "role", 0.95)
    assert ranking.locator_type(smart) == "smart"
    assert ranking.choose([smart], ["role"]) == (None, [], None)
    primary, _, _ = ranking.choose([role, smart], ["smart", "role"])
    assert primary is not None and primary.strategy == "smart-anchor"


@pytest.mark.parametrize(
    ("url", "expected"),
    [
        ("https://playwright.dev/docs/best-practices", "best_practices"),
        ("https://playwright.dev/docs/best-practices/", "best_practices"),
        ("https://site.example/a/b?tab=1#top", "b"),
        ("https://site.example/form.html", "form"),
        ("https://site.example/shop/index.html", "shop"),
        ("https://site.example/invoices/1234", "invoices"),
        ("https://site.example/My%20Page", "my_page"),
        ("https://www.saucedemo.com/", "saucedemo_com"),
        ("https://www.saucedemo.com", "saucedemo_com"),
        ("https://site.example/1234", "site_example"),
        ("file:///tmp/pages/trade_entry_v1.html", "trade_entry_v1"),
        ("app/trade_entry_v1.html", "trade_entry_v1"),
        ("/odoo/accounting", "accounting"),
        ("https://site.example/ธนาคาร", "page"),
        ("", "page"),
        ("https://site.example/reports/2024-report", "page_2024_report"),
    ],
)
def test_page_name_comes_from_the_url(url: str, expected: str) -> None:
    assert ranking.page_name_from_url(url) == expected
    assert ranking.page_name_from_url(url).isidentifier()
