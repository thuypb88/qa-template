"""Contract bucket: config loading, registry round trip, schema validity, generated code compiles."""

from __future__ import annotations

import re
from pathlib import Path

import jsonschema
import pytest

import locatorscan
from locatorscan import codegen, registry
from locatorscan.cli import main
from locatorscan.config import Workspace, load_workspace
from locatorscan.errors import ConfigError
from locatorscan.models import Fingerprint, LocatorSpec, RegistryField, RegistryPage, ScannerConfig, ScanResult


def _page() -> RegistryPage:
    spec = LocatorSpec(kind="label", value="Trade Date *", strategy="label", tier="BEST", score=0.93)
    fb = LocatorSpec(kind="xpath", value="//input[@name='class']", strategy="name", tier="GOOD", score=0.8)
    framed = LocatorSpec(kind="role", value="textbox", name='FX "Rate"', strategy="role", tier="BEST", score=0.95)
    fp = Fingerprint(tag="input", label="Trade Date")
    return RegistryPage(
        page="trade_entry",
        url="app/trade_entry.html",
        app_version="2026.3",
        fields={
            "trade_date": RegistryField(
                label="Trade Date",
                group="Trade details",
                kind="text",
                primary=spec,
                fallbacks=[fb],
                xpath="//input[@id='tradeDate']",
                fingerprint=fp,
                last_verified="2026-11-05",
            ),
            "class": RegistryField(
                label="Class", group=None, kind="text", primary=fb, fingerprint=fp, last_verified="2026-11-05"
            ),
            "fx_rate": RegistryField(
                label="FX Rate",
                group=None,
                kind="text",
                primary=framed,
                frame_path=["iframe#fx", 'iframe[name="deep"]'],
                fingerprint=fp,
                last_verified="2026-11-05",
            ),
        },
    )


def test_missing_config_file_is_a_config_error(tmp_path: Path) -> None:
    with pytest.raises(ConfigError):
        load_workspace(tmp_path / "nope.yaml")


def test_unknown_config_key_is_rejected(tmp_path: Path) -> None:
    cfg = tmp_path / "scanner.config.yaml"
    cfg.write_text("scope: main\ntimeout: 5\n", encoding="utf-8")
    with pytest.raises(ConfigError):
        load_workspace(cfg)


def test_config_paths_resolve_against_config_folder(tmp_path: Path) -> None:
    cfg = tmp_path / "scanner.config.yaml"
    cfg.write_text("registry_dir: locs\n", encoding="utf-8")
    ws = load_workspace(cfg)
    assert ws.registry_dir == tmp_path.resolve() / "locs"


def test_resolve_url_needs_base_url_for_unknown_paths(tmp_path: Path) -> None:
    ws = Workspace(config=ScannerConfig(), root=tmp_path)
    with pytest.raises(ConfigError):
        ws.resolve_url("trades/new")
    ws2 = Workspace(config=ScannerConfig(base_url="https://uat.example.com/"), root=tmp_path)
    assert ws2.resolve_url("/trades/new") == "https://uat.example.com/trades/new"


def test_registry_round_trip_is_lossless(tmp_path: Path) -> None:
    ws = Workspace(config=ScannerConfig(), root=tmp_path)
    original = _page()
    registry.save(ws, original)
    assert registry.load(ws, "trade_entry") == original


def test_generated_page_object_compiles_and_escapes(tmp_path: Path) -> None:
    source = codegen.page_object_source(_page(), "https://uat.example.com/trades/new")
    compile(source, "trade_entry_page.py", "exec")
    assert "class TradeEntryPage:" in source
    assert "def class_(self)" in source  # Python keyword renamed
    assert '.frame_locator("iframe#fx").frame_locator("iframe[name=\\"deep\\"]")' in source
    assert 'get_by_role("textbox", name="FX \\"Rate\\"", exact=True)' in source


def test_csv_has_one_row_per_field() -> None:
    lines = codegen.csv_source(_page()).strip().splitlines()
    assert len(lines) == 1 + 3


def test_scan_output_matches_its_json_schema() -> None:
    sample = ScanResult(
        page="p", url="u", app_version="1", scanned_at="2026-11-05T00:00:00+00:00", status="OK", fields=[]
    )
    jsonschema.validate(sample.model_dump(mode="json"), ScanResult.model_json_schema())


TEXT_SUFFIXES = {".py", ".js", ".css", ".md", ".sh", ".html", ".yaml"}


def test_shipped_files_name_no_particular_website() -> None:
    """The plugin is for any site: nothing it ships may depend on one."""
    root = Path(__file__).resolve().parents[2]
    names = ("odoo", "elephas", "tfmdev", "o_kanban", "o_action_manager", "eims")
    forbidden = re.compile("|".join(names), re.IGNORECASE)
    folders = ("src", "docs", "skills", "scripts", "examples/trade-entry/app")
    shipped = [root / name for name in ("scanner.config.yaml", "README.md", "CHANGELOG.md", "pyproject.toml")]
    shipped += [root / "examples" / "trade-entry" / "scanner.config.yaml"]
    shipped += [p for folder in folders for p in (root / folder).rglob("*") if p.suffix in TEXT_SUFFIXES]
    assert len(shipped) > 25
    assert [str(p) for p in shipped if forbidden.search(p.read_text(encoding="utf-8"))] == []


def test_version_is_the_same_in_the_package_and_the_build_file() -> None:
    build_file = (Path(__file__).resolve().parents[2] / "pyproject.toml").read_text(encoding="utf-8")
    assert f'version = "{locatorscan.__version__}"' in build_file


def test_version_flag(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as stopped:
        main(["--version"])
    assert stopped.value.code == 0
    assert capsys.readouterr().out.strip() == f"locatorscan {locatorscan.__version__}"
