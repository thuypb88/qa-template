"""Report layout and grouping. No browser: results are built by hand."""

from __future__ import annotations

import re

from locatorscan.models import (
    Candidate,
    FieldRecord,
    FieldState,
    FieldValidation,
    Fingerprint,
    FixProposal,
    LocatorSpec,
    PageValidation,
    RegistryField,
    RegistryPage,
    ScanResult,
)
from locatorscan.report import scan_html, validation_html
from locatorscan.report.scan import _region  # pyright: ignore[reportPrivateUsage]


def _spec(value: str = "Save", tier: str = "BEST") -> LocatorSpec:
    return LocatorSpec(kind="label", value=value, strategy="label", tier=tier, score=0.9)  # type: ignore[arg-type]


def _field(
    key: str, path: str | None, *, tier: str | None = "BEST", group: str | None = None, **kw: object
) -> FieldRecord:
    positional = {"kind": "xpath", "strategy": "positional", "tier": "OK", "score": 0.3}
    found = {"is_target": True, "match_count": 1}
    candidates = [Candidate.model_validate(positional | found | {"value": path})] if path else []
    data: dict[str, object] = {
        "key": key,
        "label": key.title(),
        "label_source": "text",
        "group": group,
        "kind": "action",
        "tag": "button",
        "input_type": None,
        "role": "button",
        "state": FieldState(visible=True, disabled=False, readonly=False, required=False),
        "frame_path": [],
        "in_shadow_dom": False,
        "primary": _spec(key, tier) if tier else None,
        "fallbacks": [],
        "xpath": f"//button[@name='{key}']",
        "candidates": candidates,
        "fingerprint": Fingerprint(tag="button"),
        "warnings": [],
    }
    return FieldRecord.model_validate(data | kw)


def _scan(*fields: FieldRecord, **kw: object) -> ScanResult:
    data: dict[str, object] = {
        "page": "p",
        "url": "https://x.test/p",
        "app_version": "1",
        "scanned_at": "2026-11-05T00:00:00+00:00",
        "status": "OK",
        "fields": list(fields),
    }
    return ScanResult.model_validate(data | kw)


def _headers(html: str) -> list[str]:
    return re.findall(r'<details class="category" open><summary>([^<]*)', html)


def test_region_is_the_innermost_landmark() -> None:
    assert _region("/html[1]/body[1]/header[1]/nav[1]/div[3]/button[1]") == (
        "header › nav[1]",
        "/html[1]/body[1]/header[1]/nav[1]",
    )
    assert _region("/html[1]/body[1]/div[1]/main[1]/div[1]/article[12]/button[1]") == (
        "main › article[12]",
        "/html[1]/body[1]/div[1]/main[1]/div[1]/article[12]",
    )


def test_region_without_a_usable_path_or_landmark() -> None:
    for path in (None, "//button[1]", "/html[1]/body[1]/div[1]/input[1]"):
        assert _region(path) == ("Outside page landmarks", None)


def test_scan_groups_by_region_in_page_order_with_counts() -> None:
    nav = "/html[1]/body[1]/header[1]/nav[1]"
    html = scan_html(
        _scan(
            _field("home", f"{nav}/button[1]"),
            _field("save", "/html[1]/body[1]/main[1]/article[2]/button[1]", tier="OK"),
            _field("menu", f"{nav}/button[2]", tier="GOOD"),
            _field("lost", "/html[1]/body[1]/main[1]/article[2]/button[2]", tier=None),
        )
    )
    assert _headers(html) == ["header › nav[1] (1 BEST, 1 GOOD)", "main › article[2] (1 OK, 1 NONE)"]
    assert f'<code class="prefix">{nav}</code>' in html


def test_named_group_and_frame_win_over_the_region() -> None:
    html = scan_html(
        _scan(
            _field("a", "/html[1]/body[1]/main[1]/input[1]", group="Billing"),
            _field("b", "/html[1]/body[1]/main[1]/input[2]", frame_path=["iframe#fx"]),
        )
    )
    assert _headers(html) == ["Billing (1 BEST)", "Frame iframe#fx › main[1] (1 BEST)"]


def test_scan_row_keeps_every_locator_and_warning() -> None:
    path = "/html[1]/body[1]/main[1]/button[1]"
    html = scan_html(_scan(_field("save", path, fallbacks=[_spec("Fallback", "GOOD")], warnings=["HIDDEN"])))
    for text in ("primary", "//button[@name=&#x27;save&#x27;]", path, "fallback 1", "Fallback", "HIDDEN"):
        assert text in html


def test_scan_row_shows_each_xpath_once() -> None:
    path = "/html[1]/body[1]/main[1]/button[1]"
    primary = LocatorSpec(kind="xpath", value=path, strategy="positional", tier="OK", score=0.3)
    assert scan_html(_scan(_field("save", path, primary=primary, xpath=path))).count(f"</span>xpath {path}") == 1
    assert ">xpath<" not in scan_html(_scan(_field("save", path, primary=primary, xpath=path)))


def test_summary_cards_and_frame_errors() -> None:
    html = scan_html(_scan(_field("a", None), _field("b", None, tier="OK"), frame_errors=["iframe#x timed out"]))
    assert re.findall(r'<div class="card ?\w*"><b>(\d+)</b><span>([^<]+)', html) == [
        ("2", "Total"),
        ("1", "Best"),
        ("0", "Good"),
        ("1", "OK"),
        ("0", "No locator"),
    ]
    assert _headers(html)[0] == "Frames not scanned (1 error)"
    assert "iframe#x timed out" in html


def test_page_text_is_escaped() -> None:
    html = scan_html(_scan(_field("x", None, label="<script>alert(1)</script>")))
    assert "<script>alert" not in html
    assert "&lt;script&gt;" in html


def _validation() -> tuple[PageValidation, RegistryPage]:
    proposal = FixProposal(
        reason="fingerprint match",
        matched_label="Qty",
        similarity=0.75,
        new_primary=_spec("Qty"),
        new_xpath=None,
        new_fingerprint=Fingerprint(tag="input"),
    )
    stored = RegistryField(
        kind="text", primary=_spec("Quantity"), fingerprint=Fingerprint(tag="input"), last_verified="2026-11-05"
    )
    results = [
        FieldValidation(key="ok", label="Fine", status="OK", used="primary"),
        FieldValidation(key="fb", label="Fall", status="FALLBACK_USED", used="fallback[1]"),
        FieldValidation(key="qty", label="Quantity", status="BROKEN", detail="no match", proposal=proposal),
        FieldValidation(key="dup", label="Dup", status="NON_UNIQUE"),
    ]
    v = PageValidation(
        page="p",
        url="https://x.test/p",
        registry_version="1",
        checked_version="2",
        checked_at="2026-11-05",
        results=results,
        new_fields=["Trader"],
    )
    return v, RegistryPage(page="p", url="https://x.test/p", app_version="1", fields={"qty": stored})


def test_validation_groups_by_outcome_with_problems_first() -> None:
    v, registry = _validation()
    assert _headers(validation_html(v, registry)) == [
        "Broken (1 failed)",
        "Not unique (1 failed)",
        "Fallback used (1 warning)",
        "OK (1 passed)",
        "New fields not in the registry (1 new)",
    ]


def test_validation_row_shows_stored_locator_and_proposal() -> None:
    v, registry = _validation()
    html = validation_html(v, registry)
    expected = (
        "Quantity",
        "proposed fix (BEST, needs approval)",
        "similarity 0.75",
        "matched &#x27;Qty&#x27;",
        "no match",
    )
    for text in expected:
        assert text in html
    assert re.findall(r'<div class="card ?\w*"><b>(\d+)</b><span>([^<]+)', html) == [
        ("4", "Total"),
        ("1", "Passed"),
        ("2", "Failed"),
        ("1", "Warnings"),
    ]


def _cand(strategy: str, value: str, count: int = 1, index: int | None = 0, kind: str = "css") -> Candidate:
    return Candidate.model_validate(
        {
            "kind": kind,
            "value": value,
            "strategy": strategy,
            "tier": "OK",
            "score": 0.1,
            "explanation": "why",
            "match_count": count,
            "is_target": count == 1 and index == 0,
            "target_index": index,
        }
    )


def _panel(*candidates: Candidate) -> str:
    return scan_html(_scan(_field("a", None, candidates=list(candidates))))


def test_locator_cards_follow_the_panel_order() -> None:
    html = _panel(
        _cand("xpath-position", "//div[position()=1]", kind="xpath"),
        _cand("id", "#a"),
        _cand("xpath-absolute", "/html/body/a", kind="xpath"),
        _cand("css-path", "main > a"),
        _cand("class-names", ".a"),
    )
    assert re.findall(r'class="loc-title">([^<]+)', html) == [
        "Class Names",
        "CSS",
        "Absolute XPath",
        "Position XPath",
        "Id (css)",
    ]


def test_a_repeated_locator_targets_the_element_by_position() -> None:
    html = _panel(_cand("css-path", "main > a", count=41, index=11))
    assert "page.locator(&#x27;main &gt; a&#x27;).nth(11)" in html
    assert "41 matches" in html
    assert "element 12 of 41 matches" in html


def test_a_locator_that_misses_the_element_gets_no_card() -> None:
    html = _panel(_cand("css-path", "main > a"), _cand("class-names", ".other", count=3, index=None))
    assert re.findall(r'class="loc-title">([^<]+)', html) == ["CSS"]
    assert "1 other candidate did not reach this element" in html


def test_structural_paths_are_marked_fragile() -> None:
    html = _panel(_cand("xpath-absolute", "/html/body/a", kind="xpath"), _cand("css-path", "main > a"))
    assert html.count(">FRAGILE<") == 1
    assert 'class="loc fragile"' in html


def test_the_same_code_is_listed_once() -> None:
    assert _panel(_cand("css-path", ".a"), _cand("class-names", ".a")).count('class="loc-title"') == 1
