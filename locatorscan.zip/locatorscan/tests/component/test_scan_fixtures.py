"""Component bucket: full scans of local fixture pages whose correct answers are known."""

from __future__ import annotations

import time
from collections.abc import Callable
from pathlib import Path

import pytest
from playwright.sync_api import sync_playwright

from locatorscan.config import Workspace
from locatorscan.engine import PlaywrightEngine
from locatorscan.errors import AuthRequiredError, BlockedError, NavError, NoFieldsError
from locatorscan.locators import build, in_frames, playwright_code
from locatorscan.models import ScannerConfig, ScanResult
from tests.conftest import by_key, page_url

Scan = Callable[[str], ScanResult]


def assert_every_primary_is_unique(result: ScanResult) -> None:
    """Re-open the page and prove each primary locator matches exactly one element."""
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page()
        page.goto(result.url)
        for f in result.fields:
            assert f.primary is not None, f.key
            assert build(in_frames(page, f.frame_path), f.primary).count() == 1, f.key
        browser.close()


def test_basic_form_finds_every_native_control(scan: Scan) -> None:
    result = scan("basic_form")
    fields = by_key(result)
    assert set(fields) == {
        "email",
        "phone",
        "age",
        "password",
        "date_of_birth",
        "bio",
        "country",
        "accept_terms",
        "client_s_reference",
        "save_profile",
    }
    assert result.skipped_hidden_inputs == 1
    assert all(f.primary and f.primary.tier == "BEST" for f in result.fields)
    assert fields["country"].kind == "choice" and fields["accept_terms"].kind == "toggle"
    assert fields["email"].state.required is True
    assert_every_primary_is_unique(result)


def test_quotes_and_apostrophes_produce_working_xpath(scan: Scan) -> None:
    ref = by_key(scan("basic_form"))["client_s_reference"]
    label_xpaths = [c for c in ref.candidates if c.strategy == "label-for"]
    assert label_xpaths and "concat(" in label_xpaths[0].value
    assert label_xpaths[0].is_target


def test_dynamic_ids_are_never_used(scan: Scan) -> None:
    result = scan("dynamic_ids")
    for f in result.fields:
        for c in f.candidates:
            assert "ember1043" not in c.value and "mat-input-7" not in c.value and "3f2a9c1e" not in c.value
    assert by_key(result)["account"].xpath == "//input[@id=//label[normalize-space()='Account']/@for]"


def test_duplicate_labels_are_scoped_by_group(scan: Scan) -> None:
    fields = by_key(scan("duplicate_labels"))
    assert set(fields) == {"buyer_name", "seller_name"}
    assert fields["buyer_name"].primary is not None
    assert fields["buyer_name"].primary.strategy == "scoped-label"
    assert "Buyer" in fields["buyer_name"].primary.explanation


def test_custom_widgets_are_found_by_aria_role(scan: Scan) -> None:
    fields = by_key(scan("custom_widgets"))
    assert fields["currency"].role == "combobox" and "CUSTOM_WIDGET" in fields["currency"].warnings
    assert fields["notes"].xpath == "//div[@aria-label='Notes']"


def test_frames_and_shadow_dom(scan: Scan) -> None:
    result = scan("frames_shadow")
    fields = by_key(result)
    assert fields["inner_field"].frame_path == ["iframe#pay"]
    assert fields["deep_field"].frame_path == ["iframe#pay", 'iframe[name="deep"]']
    assert fields["shadow_field"].in_shadow_dom and fields["shadow_field"].xpath is None
    assert_every_primary_is_unique(result)


def test_repeated_grid_rows_get_row_anchored_locators(scan: Scan) -> None:
    fields = by_key(scan("grid_rows"))
    assert fields["usd_vnd"].primary is not None and fields["usd_vnd"].primary.strategy == "text-anchor"
    assert all(c.match_count == 3 for c in fields["usd_vnd"].candidates if c.strategy == "name")


def _scan_with(tmp_path: Path, name: str, **config: object) -> ScanResult:
    ws = Workspace(config=ScannerConfig.model_validate({"scope": "main", **config}), root=tmp_path)
    return PlaywrightEngine(ws).scan(page_url(name), name)


def test_late_rendered_spa_is_found_by_settling_or_a_ready_selector(tmp_path: Path) -> None:
    with pytest.raises(NoFieldsError):
        _scan_with(tmp_path, "spa_no_form", settle_ms=0)
    assert {f.key for f in _scan_with(tmp_path, "spa_no_form", settle_ms=0, wait_for="#q").fields} == {"query", "go"}
    assert {f.key for f in _scan_with(tmp_path, "spa_no_form").fields} == {"query", "go"}


def test_fields_added_in_stages_are_all_found(tmp_path: Path) -> None:
    assert len(_scan_with(tmp_path, "late_fields", settle_ms=0).fields) == 1
    assert len(_scan_with(tmp_path, "late_fields").fields) == 3


def test_a_page_that_never_settles_still_scans_and_warns(tmp_path: Path, caplog: pytest.LogCaptureFixture) -> None:
    started = time.monotonic()
    result = _scan_with(tmp_path, "never_settles", timeout_ms=3000)
    assert time.monotonic() - started < 20
    assert result.fields
    assert "still changing" in caplog.text


@pytest.mark.parametrize(
    ("name", "error"),
    [("empty", NoFieldsError), ("needs_login", AuthRequiredError), ("captcha", BlockedError)],
)
def test_error_codes(scan: Scan, name: str, error: type[Exception]) -> None:
    with pytest.raises(error):
        scan(name)


def test_unreachable_url_is_nav_error(workspace: Workspace) -> None:
    with pytest.raises(NavError):
        PlaywrightEngine(workspace).scan("http://127.0.0.1:9/nothing", "x")


def test_scan_is_deterministic(scan: Scan) -> None:
    a, b = scan("basic_form"), scan("basic_form")
    strip = {"scanned_at"}
    assert a.model_dump(exclude=strip) == b.model_dump(exclude=strip)


@pytest.mark.parametrize("fixture", ["grid_rows", "basic_form", "duplicate_labels", "custom_widgets"])
def test_every_report_locator_resolves_to_the_scanned_element(workspace: Workspace, fixture: str) -> None:
    """The code the report offers for copying must hit the field, including `.nth(k)` on repeated matches."""
    result = PlaywrightEngine(workspace).scan(page_url(fixture), fixture)
    checked = 0
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page()
        page.goto(result.url)
        for f in result.fields:
            if f.primary is None:
                continue
            wanted = build(page, f.primary).element_handle()
            for c in f.candidates:
                if c.target_index is None:
                    continue
                code = playwright_code(c, [], c.target_index if c.match_count > 1 else None)
                found = eval(code, {"page": page})  # noqa: S307 - our own generated code, on a local fixture
                assert found.evaluate("(a, b) => a === b", wanted), code
                checked += 1
        browser.close()
    assert checked > 0


def test_a_page_of_only_buttons_is_scanned_not_reported_empty(tmp_path: Path) -> None:
    fields = _scan_with(tmp_path, "buttons_only", scope="body").fields
    assert sorted(f.label or "" for f in fields) == ["Search", "Toggle menu"]
    assert all(f.primary is not None for f in fields)


def test_standalone_buttons_stay_out_when_the_page_has_fields(tmp_path: Path) -> None:
    assert [f.label for f in _scan_with(tmp_path, "mixed_buttons", scope="body").fields] == ["Query"]


def test_all_buttons_includes_them_on_any_page(tmp_path: Path) -> None:
    fields = _scan_with(tmp_path, "mixed_buttons", scope="body", standalone_buttons="always").fields
    assert sorted(f.label or "" for f in fields) == ["Query", "Toggle menu"]


def test_a_page_with_nothing_still_reports_no_fields(tmp_path: Path) -> None:
    with pytest.raises(NoFieldsError):
        _scan_with(tmp_path, "empty", scope="body", settle_ms=0)
