"""The `stability` command, end to end, on pages that really change between loads."""

from __future__ import annotations

import json
import threading
from collections.abc import Iterator
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from locatorscan.cli import main
from tests.conftest import PAGES, page_url


@pytest.fixture
def project(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    (tmp_path / "scanner.config.yaml").write_text("scope: main\nvolatile_text: ['^alice$']\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    return tmp_path


def _results(project: Path, page: str) -> dict[str, dict[str, str]]:
    data = json.loads((project / "out" / "stability" / f"{page}.json").read_text(encoding="utf-8"))
    return {r["label"] or r["key"]: r for r in data["results"]}


def test_a_page_that_never_changes_is_stable(project: Path) -> None:
    assert main(["stability", "--url", page_url("basic_form"), "--page", "form"]) == 0
    assert {r["status"] for r in _results(project, "form").values()} == {"STABLE"}
    assert (project / "out" / "reports" / "form-stability.html").is_file()


def test_real_changes_between_loads_are_told_apart(project: Path) -> None:
    assert main(["stability", "--url", page_url("dynamic_reload"), "--page", "dyn"]) == 9
    results = list(_results(project, "dyn").items())
    status = {label: r["status"] for label, r in results}
    assert status["Stable"] == "STABLE"
    assert status["Held by label"] == "PARTLY_DYNAMIC"
    assert status["278"] == "VOLATILE_TEXT"
    assert sum(1 for label, s in status.items() if label.startswith("Run ") and s == "DYNAMIC") == 1
    assert sum(1 for s in status.values() if s == "DYNAMIC") == 2  # the button text and the unlabelled random id


def test_it_does_not_touch_the_scan_or_registry(project: Path) -> None:
    main(["stability", "--url", page_url("dynamic_reload"), "--page", "dyn"])
    assert not (project / "out" / "scans").exists()
    assert not (project / "locators").exists()


def test_runs_below_two_and_a_missing_state_file_are_rejected(project: Path) -> None:
    assert main(["stability", "--url", page_url("basic_form"), "--page", "p", "--runs", "1"]) == 8
    assert main(["stability", "--url", page_url("basic_form"), "--page", "p", "--compare-state", "none.json"]) == 8


@pytest.fixture
def served() -> Iterator[str]:
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self, format: str, *args: object) -> None:  # noqa: A002 - base class name
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), partial(Quiet, directory=str(PAGES)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{server.server_address[1]}"
    server.shutdown()
    server.server_close()


def _state(project: Path, origin: str, name: str, user: str) -> Path:
    path = project / f"{name}.json"
    storage = {"origin": origin, "localStorage": [{"name": "user", "value": user}]}
    path.write_text(json.dumps({"cookies": [], "origins": [storage]}), encoding="utf-8")
    return path


def test_a_second_user_exposes_text_that_depends_on_the_user(project: Path, served: str) -> None:
    alice = _state(project, served, "alice", "alice")
    bob = _state(project, served, "bob", "bob")
    (project / "scanner.config.yaml").write_text(f"scope: main\nstorage_state: {alice}\n", encoding="utf-8")
    assert main(["stability", "--url", f"{served}/per_user.html", "--page", "u"]) == 0  # one user alone sees nothing
    args = ["stability", "--url", f"{served}/per_user.html", "--page", "u", "--compare-state", str(bob)]
    assert main(args) == 9
    results = _results(project, "u")
    assert results["Stable action"]["status"] == "STABLE"
    assert results["alice"]["status"] == "DYNAMIC"
    assert json.loads((project / "out" / "stability" / "u.json").read_text())["runs"] == ["session 1", "state bob"]
