"""Smart locators on pages whose repeated content and generated ids defeat every other locator."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from playwright.sync_api import sync_playwright

from locatorscan.cli import main
from locatorscan.config import Workspace
from locatorscan.engine import PlaywrightEngine
from locatorscan.locators import build
from locatorscan.models import FieldRecord, ScannerConfig
from tests.conftest import page_url


def _scan(tmp_path: Path, page: str, url_suffix: str = "", **config: object) -> list[FieldRecord]:
    ws = Workspace(config=ScannerConfig.model_validate({"scope": "main", **config}), root=tmp_path)
    return PlaywrightEngine(ws).scan(page_url(page) + url_suffix, page).fields


def _named(fields: list[FieldRecord], label: str) -> list[FieldRecord]:
    return [f for f in fields if f.label == label]


def test_repeated_buttons_are_found_through_their_card(tmp_path: Path) -> None:
    buttons = _named(_scan(tmp_path, "repeated_cards"), "New")
    assert len(buttons) == 4
    for f in buttons:
        assert f.primary is not None and f.primary.strategy == "smart-anchor"
        assert "POSITIONAL_ONLY" not in f.warnings
    assert [f.primary.value for f in buttons if f.primary][0] == (
        "//article[.//*[normalize-space()='Bank BBL']]//button[@name='create']"
    )


def test_each_smart_locator_reaches_its_own_card_after_the_order_changes(tmp_path: Path) -> None:
    buttons = _named(_scan(tmp_path, "repeated_cards"), "New")
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page()
        page.goto(page_url("repeated_cards") + "#reverse")
        for f in buttons:
            assert f.primary is not None
            title = f.primary.explanation.split("'")[1]
            found = build(page, f.primary)
            assert found.count() == 1
            assert found.evaluate("(b) => b.closest('article').querySelector('h3').textContent") == title
        browser.close()


def test_div_cards_are_scoped_by_their_class_not_by_every_wrapper(tmp_path: Path) -> None:
    """Div-based cards: a bare //div scope would match every wrapper and so buttons across the whole page."""
    fields = _scan(tmp_path, "div_cards", scope="body")
    new = _named(fields, "New")
    assert len(new) == 3
    for f in new:
        assert f.primary is not None and f.primary.strategy == "smart-anchor"
        assert "contains(concat(' ', normalize-space(@class), ' '), ' card ')" in f.primary.value
    assert not [f for f in fields if f.primary and f.primary.strategy == "positional" and f.tag == "button"]


def test_div_card_locators_reach_their_own_card_after_a_reorder(tmp_path: Path) -> None:
    fields = _scan(tmp_path, "div_cards", scope="body")
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page()
        page.goto(page_url("div_cards") + "#reverse")
        checked = 0
        for f in fields:
            if f.primary is None or f.primary.strategy != "smart-anchor":
                continue
            title = f.primary.explanation.split("'")[1]
            found = build(page, f.primary)
            assert found.count() == 1, f.primary.value
            card = "(e) => e.closest('.card').querySelector('a.title').textContent.trim()"
            assert found.evaluate(card) == title, f.primary.value
            checked += 1
        browser.close()
    assert checked >= 12


def test_thai_text_can_anchor_and_amounts_cannot(tmp_path: Path) -> None:
    values = [c.value for f in _scan(tmp_path, "div_cards", scope="body") for c in f.candidates]
    smart = [v for v in values if ".//*[normalize-space()=" in v]
    assert [v for v in smart if "ธนาคารกรุงไทย" in v]
    assert not [v for v in smart if "฿" in v]
    assert not [v for v in smart if "To Review" in v]


def test_an_environment_id_is_not_used_as_a_name(tmp_path: Path) -> None:
    fields = _scan(tmp_path, "div_cards", scope="body")
    assert not [
        c.value for f in fields for c in f.candidates if c.strategy == "smart-anchor" and "@name='264'" in c.value
    ]


def test_a_title_can_identify_a_lone_button(tmp_path: Path) -> None:
    html = "<!doctype html><html><body><main><button title='Home Menu'></button></main></body></html>"
    (tmp_path / "title.html").write_text(html, encoding="utf-8")
    ws = Workspace(config=ScannerConfig(scope="main"), root=tmp_path)
    fields = PlaywrightEngine(ws).scan((tmp_path / "title.html").as_uri(), "title").fields
    assert fields[0].primary is not None
    assert fields[0].primary.value == "//button[@title='Home Menu']"


def test_a_number_is_never_an_anchor(tmp_path: Path) -> None:
    for f in _scan(tmp_path, "repeated_cards"):
        for c in f.candidates:
            if c.strategy == "smart-anchor":
                assert "Bank" in c.value or "Cash" in c.value or "Sales" in c.value


def test_volatile_text_is_never_an_anchor(tmp_path: Path) -> None:
    fields = _scan(tmp_path, "repeated_cards", volatile_text=["^Bank", "^Cash", "^Sales"])
    assert not [c for f in fields for c in f.candidates if c.strategy == "smart-anchor"]
    assert _named(fields, "New")[0].primary.strategy == "positional"  # type: ignore[union-attr]


def test_generated_numbers_are_ignored(tmp_path: Path) -> None:
    fields = _scan(tmp_path, "partial_ids")
    by_value = {f.primary.value: f for f in fields if f.primary}
    assert "//input[starts-with(@id, 'customer_field_')]" in by_value
    assert "//input[starts-with(@id, 'amount_field_')]" in by_value
    assert "//button[starts-with(normalize-space(), 'Item ')]" not in by_value  # exact text wins while it exists


def test_a_guid_gets_no_partial_match(tmp_path: Path) -> None:
    values = [c.value for f in _scan(tmp_path, "partial_ids") for c in f.candidates if c.strategy == "smart-partial"]
    assert values
    assert not [v for v in values if "3f2a" in v]


def test_settings_turn_them_off(tmp_path: Path) -> None:
    fields = _scan(tmp_path, "repeated_cards", locator_types=["role", "semantic", "id", "name", "css", "xpath"])
    assert _named(fields, "New")[0].primary.strategy == "positional"  # type: ignore[union-attr]


@pytest.fixture
def project(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    (tmp_path / "scanner.config.yaml").write_text("scope: main\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("locatorscan.console.interactive", lambda: False)
    return tmp_path


def test_stored_smart_locators_survive_a_reorder(project: Path) -> None:
    url = page_url("repeated_cards")
    assert main(["scan", "--url", url, "--page", "cards"]) == 0
    assert main(["review", "--page", "cards", "--yes", "--min-tier", "OK"]) == 0
    assert main(["validate", "--url", url + "#reverse"]) == 0
    data = json.loads((project / "out" / "validation" / "cards.json").read_text(encoding="utf-8"))
    assert {r["status"] for r in data["results"] if r["label"] == "New"} == {"OK"}


def test_stability_keeps_them_apart_when_the_order_changes(project: Path) -> None:
    assert main(["stability", "--url", page_url("repeated_cards") + "#shuffle", "--page", "cards", "--runs", "3"]) == 0
    data = json.loads((project / "out" / "stability" / "cards.json").read_text(encoding="utf-8"))
    statuses = {r["status"] for r in data["results"] if r["label"] == "New"}
    assert statuses <= {"STABLE", "PARTLY_DYNAMIC"}


def test_report_shows_the_smart_card_and_setting(project: Path) -> None:
    main(["scan", "--url", page_url("repeated_cards"), "--page", "cards"])
    html = (project / "out" / "reports" / "cards-scan.html").read_text(encoding="utf-8")
    assert "Smart Locator (anchored)" in html
    assert "Finds it through nearby text &#x27;Bank BBL&#x27;" in html
    assert "Smart (dynamic: anchored, partial match)" in html
