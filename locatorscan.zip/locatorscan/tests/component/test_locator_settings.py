"""Locator type settings: `locatorscan settings`, the `--types` override and what they do to a real scan."""

from __future__ import annotations

import json
import re
import stat
import threading
from collections.abc import Iterator
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest
import yaml
from playwright.sync_api import Page, sync_playwright

from locatorscan.cli import main
from locatorscan.config import Workspace
from locatorscan.engine import PlaywrightEngine
from locatorscan.errors import NavError
from locatorscan.models import ScannerConfig
from tests.conftest import PAGES, page_url

CONFIG = "# keep this comment\nscope: main\nheadless: true\n"


@pytest.fixture
def project(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    (tmp_path / "scanner.config.yaml").write_text(CONFIG, encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    return tmp_path


def _config(project: Path) -> str:
    return (project / "scanner.config.yaml").read_text(encoding="utf-8")


def _scan(project: Path, *global_args: str) -> dict[str, dict]:
    assert main([*global_args, "scan", "--url", page_url("basic_form"), "--page", "form"]) == 0
    data = json.loads((project / "out" / "scans" / "form.json").read_text(encoding="utf-8"))
    return {f["key"]: f for f in data["fields"]}


def test_set_saves_the_order_and_keeps_everything_else(project: Path) -> None:
    assert main(["settings", "--set", "id,role,xpath"]) == 0
    assert _config(project).startswith(CONFIG)
    assert yaml.safe_load(_config(project))["locator_types"] == ["id", "role", "xpath"]


def test_set_again_replaces_the_line_and_a_block_list_too(project: Path) -> None:
    (project / "scanner.config.yaml").write_text(
        "scope: main\nlocator_types:\n  - role\n  - id\nheadless: true\n", encoding="utf-8"
    )
    assert main(["settings", "--set", "name"]) == 0
    assert _config(project) == "scope: main\nlocator_types: [name]\nheadless: true\n"


def test_reset_removes_the_setting(project: Path) -> None:
    main(["settings", "--set", "id"])
    assert main(["settings", "--reset"]) == 0
    assert _config(project) == CONFIG


def test_settings_creates_a_missing_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    assert main(["settings", "--set", "role,id"]) == 0
    assert ScannerConfig.model_validate(yaml.safe_load(_config(tmp_path))).locator_types == ["role", "id"]


@pytest.mark.parametrize("bad", ["role,robot", "role,role", " , "])
def test_a_bad_list_is_refused_and_nothing_is_written(project: Path, bad: str) -> None:
    assert main(["settings", "--set", bad]) == 8
    assert _config(project) == CONFIG


def test_a_bad_config_file_is_refused(project: Path) -> None:
    (project / "scanner.config.yaml").write_text("locator_types: [robot]\n", encoding="utf-8")
    assert main(["settings"]) == 8


def test_the_saved_order_changes_the_primary(project: Path) -> None:
    default = _scan(project)
    assert any(f["primary"]["strategy"] == "role" or f["primary"]["kind"] == "label" for f in default.values())
    main(["settings", "--set", "xpath,id,name"])
    for f in _scan(project).values():
        if f["primary"]:
            assert f["primary"]["kind"] in ("xpath", "css") and f["primary"]["strategy"] not in ("role", "label")


def test_types_applies_to_one_run_only(project: Path) -> None:
    default = _scan(project)
    one_off = _scan(project, "--types", "xpath")
    assert {f["primary"]["kind"] for f in one_off.values() if f["primary"]} == {"xpath"}
    assert _config(project) == CONFIG
    assert {k: f["primary"] for k, f in _scan(project).items()} == {k: f["primary"] for k, f in default.items()}


def test_asking_for_css_alone_gets_css(project: Path) -> None:
    fields = _scan(project, "--types", "css")
    chosen = [f["primary"] for f in fields.values() if f["primary"]]
    assert chosen
    assert {p["kind"] for p in chosen} == {"css"}
    assert {p["strategy"] for p in chosen} <= {"class-names", "css-path"}


def test_a_field_with_nothing_allowed_says_so(project: Path) -> None:
    fields = _scan(project, "--types", "name")
    without = [f for f in fields.values() if f["primary"] is None]
    assert without
    assert all(f["warnings"] for f in without)
    assert {w for f in without for w in f["warnings"]} & {"NO_LOCATOR", "NON_UNIQUE"}


def test_report_shows_the_setting_and_hides_excluded_types(project: Path) -> None:
    _scan(project, "--types", "name,id")
    html = (project / "out" / "reports" / "form-scan.html").read_text(encoding="utf-8")
    assert "Locator types: name &gt; id" in html
    assert "locatorscan settings --set name,id" in html
    assert 'data-type="role" data-i' in html
    assert re.search(r'data-type="role" data-i="\d+" hidden', html)
    assert not re.search(r'data-type="name" data-i="\d+" hidden', html)


@pytest.fixture
def report(project: Path) -> Iterator[Page]:
    _scan(project)
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        page = browser.new_page()
        errors: list[str] = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.goto((project / "out" / "reports" / "form-scan.html").as_uri())
        page.locator("details.locators").first.evaluate("(d) => { d.open = true; }")
        yield page
        browser.close()
        assert errors == []


def _command(page: Page) -> str:
    return page.locator(".set-command").inner_text()


def _order(page: Page) -> list[str]:
    return page.locator(".set-order li:not([hidden])").evaluate_all("(ls) => ls.map((l) => l.dataset.type)")


def _card_types(page: Page) -> list[str]:
    cards = page.locator("details.locators").first.locator(".loc:not([hidden])")
    return cards.evaluate_all("(cs) => cs.map((c) => c.dataset.type)")


def test_panel_starts_on_the_default(report: Page) -> None:
    assert report.locator(".settings").get_attribute("open") is not None
    assert _command(report) == "locatorscan settings --reset"
    assert _order(report) == ["role", "semantic", "id", "name", "smart", "css", "xpath"]


def test_unticking_hides_the_type_everywhere_and_updates_the_command(report: Page) -> None:
    before = report.locator("details.locators .loc-count").first.inner_text()
    report.locator('.set-check input[data-type="xpath"]').uncheck()
    assert "xpath" not in _order(report)
    assert "xpath" not in _card_types(report)
    assert _command(report) == "locatorscan settings --set role,semantic,id,name,smart,css"
    assert int(report.locator("details.locators .loc-count").first.inner_text()) < int(before)
    report.locator('.set-check input[data-type="xpath"]').check()
    assert _order(report)[-1] == "xpath"


def test_arrows_change_the_priority_and_the_card_order(report: Page) -> None:
    report.locator('.set-order li[data-type="xpath"] .set-up').click()
    assert _order(report) == ["role", "semantic", "id", "name", "smart", "xpath", "css"]
    for _ in range(5):
        report.locator('.set-order li[data-type="xpath"] .set-up').click()
    assert _order(report)[0] == "xpath"
    assert _card_types(report)[0] == "xpath"
    assert report.locator(".set-order li .set-num").first.inner_text() == "1"
    assert _command(report).startswith("locatorscan settings --set xpath,role")


def test_dragging_changes_the_priority(report: Page) -> None:
    report.locator('.set-order li[data-type="css"]').drag_to(
        report.locator('.set-order li[data-type="role"]'), target_position={"x": 20, "y": 2}
    )
    assert _order(report)[0] == "css"
    assert _command(report).startswith("locatorscan settings --set css,")


def test_unticking_everything_blocks_the_command(report: Page) -> None:
    for box in report.locator(".set-check input").all():
        box.uncheck()
    assert _command(report) == "Tick at least one type"
    assert report.locator(".set-foot .copy").is_disabled()


def test_reset_returns_to_the_default(report: Page) -> None:
    report.locator('.set-check input[data-type="id"]').uncheck()
    report.locator('.set-order li[data-type="xpath"] .set-up').click()
    report.locator(".set-reset").click()
    assert _command(report) == "locatorscan settings --reset"
    assert _order(report) == ["role", "semantic", "id", "name", "smart", "css", "xpath"]
    assert report.locator('.set-check input[data-type="id"]').is_checked()


def test_copy_button_copies_the_command(report: Page) -> None:
    report.context.grant_permissions(["clipboard-read", "clipboard-write"])
    report.locator('.set-check input[data-type="css"]').uncheck()
    report.locator(".set-foot .copy").click()
    assert (
        report.evaluate("navigator.clipboard.readText()")
        == "locatorscan settings --set role,semantic,id,name,smart,xpath"
    )


def test_settings_with_nothing_saved_lists_every_type(project: Path, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["settings"]) == 0
    out = capsys.readouterr().out
    for word in ("role", "semantic", "id", "name", "smart", "css", "xpath", "ranked by score"):
        assert word in out


def test_wait_for_overrides_the_config_for_one_run(project: Path) -> None:
    url = page_url("basic_form")
    assert main(["scan", "--url", url, "--page", "form", "--wait-for", "main"]) == 0
    assert _config(project) == CONFIG
    (project / "scanner.config.yaml").write_text("scope: main\nwait_for: '#never'\ntimeout_ms: 500\n", encoding="utf-8")
    assert main(["scan", "--url", url, "--page", "form"]) == 3
    assert main(["scan", "--url", url, "--page", "form", "--wait-for", "main"]) == 0


def test_login_needs_a_person_at_a_terminal(project: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("locatorscan.console.interactive", lambda: False)
    assert main(["login", "--url", page_url("basic_form")]) == 8
    assert not (project / ".auth").exists()


def test_login_needs_a_place_for_the_session(project: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("locatorscan.console.interactive", lambda: True)
    assert main(["login", "--url", page_url("basic_form")]) == 8


def test_a_saved_session_is_private_and_holds_what_the_browser_had(tmp_path: Path) -> None:
    ws = Workspace(config=ScannerConfig(), root=tmp_path)
    path = tmp_path / ".auth" / "session.json"
    handler = partial(SimpleHTTPRequestHandler, directory=str(PAGES))
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        url = f"http://127.0.0.1:{server.server_address[1]}/basic_form.html"
        waited: list[bool] = []
        PlaywrightEngine(ws).save_session(url, path, lambda: waited.append(True))
    finally:
        server.shutdown()
        server.server_close()
    assert waited == [True]
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    assert stat.S_IMODE(path.parent.stat().st_mode) == 0o700
    assert set(json.loads(path.read_text(encoding="utf-8"))) == {"cookies", "origins"}


def test_an_unreachable_site_is_reported_when_signing_in(tmp_path: Path) -> None:
    ws = Workspace(config=ScannerConfig(timeout_ms=3000), root=tmp_path)
    with pytest.raises(NavError):
        PlaywrightEngine(ws).save_session("http://127.0.0.1:9/", tmp_path / "s.json", lambda: None)


def test_all_buttons_flag_applies_to_one_run(project: Path) -> None:
    (project / "scanner.config.yaml").write_text("scope: body\n", encoding="utf-8")
    url = page_url("mixed_buttons")
    assert main(["scan", "--url", url, "--page", "p", "--all-buttons"]) == 0
    data = json.loads((project / "out" / "scans" / "p.json").read_text(encoding="utf-8"))
    assert len(data["fields"]) == 2
    assert main(["scan", "--url", url, "--page", "p"]) == 0
    data = json.loads((project / "out" / "scans" / "p.json").read_text(encoding="utf-8"))
    assert len(data["fields"]) == 1


def test_a_hyphenated_page_name_gives_an_importable_page_object(project: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("locatorscan.console.interactive", lambda: False)
    assert main(["scan", "--url", page_url("basic_form"), "--page", "best-practices"]) == 0
    assert main(["review", "--page", "best-practices", "--yes"]) == 0
    assert main(["generate"]) == 0
    module = project / "generated" / "pages" / "best_practices_page.py"
    assert module.is_file()
    compile(module.read_text(encoding="utf-8"), str(module), "exec")
    assert "class BestPracticesPage" in module.read_text(encoding="utf-8")


def test_scan_without_a_page_name_takes_it_from_the_url(project: Path, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["scan", "--url", page_url("basic_form")]) == 0
    assert "Page name: basic_form (from the URL" in capsys.readouterr().out
    assert (project / "out" / "scans" / "basic_form.json").is_file()
    assert (project / "out" / "reports" / "basic_form-scan.html").is_file()
    assert main(["review", "--page", "basic_form", "--yes"]) == 0


def test_a_chosen_page_name_still_wins(project: Path, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["scan", "--url", page_url("basic_form"), "--page", "mine"]) == 0
    assert "from the URL" not in capsys.readouterr().out
    assert (project / "out" / "scans" / "mine.json").is_file()


def test_stability_without_a_page_name(project: Path) -> None:
    assert main(["stability", "--url", page_url("basic_form")]) == 0
    assert (project / "out" / "stability" / "basic_form.json").is_file()
