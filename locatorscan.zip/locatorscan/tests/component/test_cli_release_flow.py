"""Regression (drift) bucket: scan release 2026.3, validate on 2026.4, apply fixes, validate again."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from locatorscan.cli import main

DEMO_APP = Path(__file__).resolve().parents[2] / "examples" / "trade-entry" / "app"


@pytest.fixture
def project(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    if not DEMO_APP.exists():
        pytest.skip("demo app pages not present")
    shutil.copytree(DEMO_APP, tmp_path / "app")
    (tmp_path / "scanner.config.yaml").write_text('app_version: "2026.3"\nscope: main\n', encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("locatorscan.console.interactive", lambda: False)
    return tmp_path


def _statuses(project: Path) -> dict[str, str]:
    data = json.loads((project / "out" / "validation" / "trade_entry.json").read_text(encoding="utf-8"))
    return {r["key"]: r["status"] for r in data["results"]}


def test_release_flow(project: Path) -> None:
    assert main(["scan", "--url", "app/trade_entry_v1.html", "--page", "trade_entry"]) == 0
    assert main(["review", "--page", "trade_entry", "--yes"]) == 0
    assert main(["generate"]) == 0
    compile((project / "generated" / "pages" / "trade_entry_page.py").read_text(encoding="utf-8"), "po", "exec")

    # Unchanged registry on the same release: everything resolves by its primary.
    assert main(["validate"]) == 0
    assert set(_statuses(project).values()) == {"OK"}

    # Release 2026.4 changed labels, ids, a frame and removed a button.
    assert main(["--app-version", "2026.4", "validate", "--url", "app/trade_entry_v2.html"]) == 7
    s = _statuses(project)
    assert s["trade_date"] == "OK"  # id became dynamic, label locator held
    assert s["submit_trade"] == "OK"  # text changed, test id held
    assert s["instrument_isin"] == "FALLBACK_USED"
    assert s["settlement_account"] == "BROKEN"
    assert s["fx_rate"] == "MISSING_FRAME"
    assert s["save_draft"] == "BROKEN"

    # Without --yes and without a terminal, nothing is applied.
    before = (project / "locators" / "trade_entry.yaml").read_text(encoding="utf-8")
    assert main(["apply-fixes", "--page", "trade_entry"]) == 0
    assert (project / "locators" / "trade_entry.yaml").read_text(encoding="utf-8") == before

    assert main(["apply-fixes", "--page", "trade_entry", "--yes"]) == 0
    assert main(["--app-version", "2026.4", "validate", "--url", "app/trade_entry_v2.html"]) == 7
    s = _statuses(project)
    still_broken = {k for k, v in s.items() if v != "OK"}
    assert still_broken == {"quantity", "save_draft"}  # renamed beyond recognition / removed: human decides
