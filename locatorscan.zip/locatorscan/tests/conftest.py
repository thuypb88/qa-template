from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

import pytest

from locatorscan.config import Workspace
from locatorscan.engine import PlaywrightEngine
from locatorscan.models import FieldRecord, ScannerConfig, ScanResult

PAGES = Path(__file__).parent / "fixtures" / "pages"


@pytest.fixture
def workspace(tmp_path: Path) -> Workspace:
    """Defaults plus scope=main; output goes to a temp folder."""
    return Workspace(config=ScannerConfig(scope="main", timeout_ms=15_000), root=tmp_path)


def page_url(name: str) -> str:
    return (PAGES / f"{name}.html").resolve().as_uri()


@pytest.fixture
def scan(workspace: Workspace) -> Callable[[str], ScanResult]:
    def _scan(name: str) -> ScanResult:
        return PlaywrightEngine(workspace).scan(page_url(name), name)

    return _scan


def by_key(result: ScanResult) -> dict[str, FieldRecord]:
    return {f.key: f for f in result.fields}
