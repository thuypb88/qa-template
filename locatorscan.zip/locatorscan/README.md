# locatorscan

> **Created:** 2026-11-05 13:19:00 (UTC+7) · **Updated:** 2026-11-05 16:51:46 (UTC+7)

Point `locatorscan` at any web page. It finds the form fields and buttons, generates Playwright and XPath locators, proves
each one on the live page, and keeps the good ones in a versioned registry. After each app release it re-checks them and
proposes fixes you approve.

**Version 1.0.0** · Python 3.11+ · Playwright · [Changelog](CHANGELOG.md)

| Read this | For |
|---|---|
| [User guide](docs/USER-GUIDE.md) | Installing and using it, every command, troubleshooting |
| [System design](docs/SYSTEM-DESIGN.md) | How it works, why it is built this way, known limitations |
| [Trade entry example](examples/trade-entry/) | A full run on local pages, including a simulated release |
| [Agent skill](skills/scanning-form-locators/SKILL.md) | Letting an AI agent drive the tool |

## Quick start

```bash
pip install dist/locatorscan-1.0.0-py3-none-any.whl   # or, from the repo: pip install -e ".[dev]"
python -m playwright install chromium

locatorscan scan --url https://any-site.example/form
```

Then open `out/reports/form-scan.html`. The page name comes from the URL; choose your own with `--page`. Next steps are in the [user guide](docs/USER-GUIDE.md#3-the-basic-workflow).

## What it does

| Command | Purpose |
|---|---|
| `scan` | Find fields, verify locators, write a report |
| `review` | Accept locators into the registry |
| `generate` | Build Playwright Page Objects and a CSV from the registry |
| `validate` | Re-check the registry on a new release; exit 7 if locators broke |
| `apply-fixes` | Apply the fix proposals you approve |
| `stability` | Find locators that change between scans; exit 9 if a primary cannot be trusted |
| `settings` | Choose which locator types are used, and their priority |
| `login` | Sign in by hand and save the session for later scans |
| `schema` | Write JSON Schemas of the output files |

## Project layout

```text
.
├── src/locatorscan/            The package
│   ├── cli.py              Commands and exit codes
│   ├── models.py           Data contracts for every file read or written
│   ├── ranking.py          Choosing the primary, fallbacks, locator types, fix similarity
│   ├── stability.py        Comparing scans
│   ├── registry.py         Reading and writing the registry and output files
│   ├── codegen.py          Page Objects and CSV
│   ├── locators.py         Locator specs to Playwright objects and Python code
│   ├── engine/             Browser session and in-page discovery (discover.js)
│   └── report/             HTML reports, one module per report, with assets/ for CSS and JavaScript
├── tests/                  unit/ (no browser), component/ (real browser), fixtures/pages/
├── docs/                   User guide and system design
├── examples/trade-entry/   Worked example on local pages
├── skills/                 Agent skill: instructions and command reference
├── scripts/build_release.py  Runs every check, builds the release, tests it in a clean environment
└── scanner.config.yaml     Common config, for any site
```

Generated and private, ignored by git: `out/`, `locators/`, `generated/`, `dist/`, `.auth/`.

## Development

```bash
pip install -e ".[dev]"
python -m pytest -q                        # all tests
ruff check src tests && ruff format --check src tests
pyright --pythonpath "$(which python)"     # strict
python scripts/build_release.py            # all of the above, then dist/
```
