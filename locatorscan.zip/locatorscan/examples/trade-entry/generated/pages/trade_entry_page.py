"""Generated from locators/trade_entry.yaml by locscan (app version 2026.4). Do not edit.

Change locators through the registry (`locscan review`, `locscan apply-fixes`), then run `locscan generate`.
"""

from __future__ import annotations

from playwright.sync_api import Locator, Page


class TradeEntryPage:
    URL = 'file:///home/claude/locscan-demo/demo/app/trade_entry_v1.html'

    def __init__(self, page: Page) -> None:
        self.page = page

    def goto(self) -> None:
        self.page.goto(self.URL)

    @property
    def trade_id(self) -> Locator:
        """Trade ID (Trade details) - BEST, role.
        Fallbacks: css #tradeId; xpath //input[@name='tradeId']
        XPath: //input[@id='tradeId']
        """
        return self.page.get_by_role("textbox", name="Trade ID", exact=True)

    @property
    def trade_date(self) -> Locator:
        """Trade Date (Trade details) - BEST, label.
        Fallbacks: css #tradeDate; xpath //input[@name='tradeDate']
        XPath: //input[@id='tradeDate']
        """
        return self.page.get_by_label("Trade Date *", exact=True)

    @property
    def instrument_isin(self) -> Locator:
        """Instrument (ISIN) (Trade details) - BEST, role.
        Fallbacks: css #instrumentId; xpath //input[@name='isin']
        XPath: //input[@id='instrumentId']
        """
        return self.page.get_by_role("textbox", name="ISIN", exact=True)

    @property
    def quantity(self) -> Locator:
        """Quantity (Trade details) - BEST, role.
        Fallbacks: xpath //input[@name='quantity']
        XPath: //input[@id=//label[normalize-space()='Quantity']/@for]
        """
        return self.page.get_by_role("spinbutton", name="Quantity", exact=True)

    @property
    def counterparty(self) -> Locator:
        """Counterparty (Trade details) - BEST, role.
        Fallbacks: label 'Counterparty'
        XPath: //*[@role='combobox'][@aria-labelledby=//*[normalize-space()='Counterparty']/@id]
        """
        return self.page.get_by_role("combobox", name="Counterparty", exact=True)

    @property
    def buy(self) -> Locator:
        """Buy (Side) - BEST, role.
        Fallbacks: xpath //input[@name='side'][@value='BUY']
        XPath: //input[@name='side'][@value='BUY']
        """
        return self.page.get_by_role("radio", name="Buy", exact=True)

    @property
    def sell(self) -> Locator:
        """Sell (Side) - BEST, role.
        Fallbacks: xpath //input[@name='side'][@value='SELL']
        XPath: //input[@name='side'][@value='SELL']
        """
        return self.page.get_by_role("radio", name="Sell", exact=True)

    @property
    def leg_1_amount(self) -> Locator:
        """Amount (Leg 1) - GOOD, name.
        Fallbacks: xpath //section[h2[normalize-space()='Leg 1']]//label[normalize-space()='Amount']/following::input[1]
        XPath: //input[@name='leg1Amount']
        """
        return self.page.locator("xpath=//input[@name='leg1Amount']")

    @property
    def leg_1_currency(self) -> Locator:
        """Currency (Leg 1) - GOOD, id.
        Fallbacks: xpath //select[@name='leg1Currency']; xpath //section[h2[normalize-space()='Leg 1']]//label[normalize-space()='Currency']/following::select[1]
        XPath: //select[@id='l1-ccy']
        """
        return self.page.locator("css=#l1-ccy")

    @property
    def leg_2_amount(self) -> Locator:
        """Amount (Leg 2) - GOOD, name.
        Fallbacks: xpath //section[h2[normalize-space()='Leg 2']]//label[normalize-space()='Amount']/following::input[1]
        XPath: //input[@name='leg2Amount']
        """
        return self.page.locator("xpath=//input[@name='leg2Amount']")

    @property
    def leg_2_currency(self) -> Locator:
        """Currency (Leg 2) - GOOD, id.
        Fallbacks: xpath //select[@name='leg2Currency']; xpath //section[h2[normalize-space()='Leg 2']]//label[normalize-space()='Currency']/following::select[1]
        XPath: //select[@id='l2-ccy']
        """
        return self.page.locator("css=#l2-ccy")

    @property
    def settlement_date(self) -> Locator:
        """Settlement Date (Settlement) - GOOD, name.
        Fallbacks: xpath //*[normalize-space(text())='Settlement Date']/following::input[1]
        XPath: //input[@name='settleDate']
        """
        return self.page.locator("xpath=//input[@name='settleDate']")

    @property
    def settlement_account(self) -> Locator:
        """Settlement Account (Settlement) - BEST, test-attr.
        Fallbacks: role textbox 'Settlement account'; css #stl-acc
        XPath: //input[@data-testid='settlement-account-input']
        """
        return self.page.locator("css=[data-testid=\"settlement-account-input\"]")

    @property
    def comments(self) -> Locator:
        """Comments (Trade entry) - BEST, role.
        Fallbacks: css #comments; xpath //textarea[@name='comments']
        XPath: //textarea[@id='comments']
        """
        return self.page.get_by_role("textbox", name="Comments", exact=True)

    @property
    def confirm_trade_details(self) -> Locator:
        """Confirm trade details (Trade entry) - BEST, role.
        Fallbacks: xpath //input[@name='confirm']
        XPath: //input[@name='confirm']
        """
        return self.page.get_by_role("checkbox", name="I confirm the trade details", exact=True)

    @property
    def save_draft(self) -> Locator:
        """Save draft (Trade entry) - BEST, role.
        Fallbacks: xpath //button[normalize-space()='Save draft']
        XPath: //button[normalize-space()='Save draft']
        """
        return self.page.get_by_role("button", name="Save draft", exact=True)

    @property
    def submit_trade(self) -> Locator:
        """Submit trade (Trade entry) - BEST, test-attr.
        Fallbacks: role button 'Submit trade'
        XPath: //button[@data-testid='submit-trade']
        """
        return self.page.locator("css=[data-testid=\"submit-trade\"]")

    @property
    def notional(self) -> Locator:
        """Notional (Trade entry) - BEST, role.
        Fallbacks: css input[name='notional']; placeholder '0.00'
        """
        return self.page.get_by_role("textbox", name="Notional", exact=True)

    @property
    def fx_rate(self) -> Locator:
        """FX Rate (FX) - BEST, role.
        Fallbacks: css #fx; xpath //input[@name='fxRate']
        XPath: //input[@id='fx']
        """
        return self.page.frame_locator("iframe#fx-panel").get_by_role("textbox", name="FX Rate", exact=True)

    @property
    def refresh_rate(self) -> Locator:
        """Refresh rate (FX) - BEST, role.
        Fallbacks: xpath //button[normalize-space()='Refresh rate']
        XPath: //button[normalize-space()='Refresh rate']
        """
        return self.page.frame_locator("iframe#fx-panel").get_by_role("button", name="Refresh rate", exact=True)
