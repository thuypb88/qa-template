#!/usr/bin/env bash
# End-to-end demo: scan release 2026.3, generate a Page Object, then check the registry
# against release 2026.4, apply the approved fixes, and regenerate.
set -u
cd "$(dirname "$0")"
rm -rf out locators generated

step() { printf '\n\033[1m== %s\033[0m\n' "$1"; }

step "1. Scan the trade entry page (release 2026.3)"
locatorscan scan --url app/trade_entry_v1.html --page trade_entry || exit $?

step "2. Accept BEST and GOOD locators into the registry"
locatorscan review --page trade_entry --yes || exit $?

step "3. Generate the Page Object and CSV"
locatorscan generate || exit $?

step "4. Release 2026.4 ships. Validate the registry against it (exit 7 = broken locators found)"
locatorscan --app-version 2026.4 validate --url app/trade_entry_v2.html
echo "exit code: $?"
cp out/reports/trade_entry-validation.html out/reports/trade_entry-validation-release-day.html

step "5. Proposals are listed, nothing changes without --yes"
locatorscan apply-fixes --page trade_entry < /dev/null

step "6. After review, apply the proposals"
locatorscan apply-fixes --page trade_entry --yes || exit $?

step "7. Validate again: only fields that need a human remain"
locatorscan --app-version 2026.4 validate --url app/trade_entry_v2.html
echo "exit code: $?"

step "8. Regenerate the Page Object from the fixed registry"
locatorscan generate || exit $?

echo
echo "Reports: out/reports/trade_entry-scan.html"
echo "         out/reports/trade_entry-validation-release-day.html (before fixes)"
echo "         out/reports/trade_entry-validation.html (after fixes)"
