"""Example test that uses the generated Page Object. Run after `bash run_demo.sh` (or scan/review/generate).

    cd examples/trade-entry && python -m pytest tests -q
"""

from __future__ import annotations

import sys
from collections.abc import Iterator
from pathlib import Path

import pytest
from playwright.sync_api import Page, sync_playwright

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "generated"))
pytest.importorskip("pages.trade_entry_page", reason="run `locatorscan generate` first")
from pages.trade_entry_page import TradeEntryPage  # noqa: E402

V2 = (Path(__file__).resolve().parents[1] / "app" / "trade_entry_v2.html").as_uri()


@pytest.fixture
def page() -> Iterator[Page]:
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        yield browser.new_page()
        browser.close()


def test_fill_trade_on_current_release(page: Page) -> None:
    trade = TradeEntryPage(page)
    page.goto(V2)
    trade.trade_date.fill("2026-11-05")
    trade.instrument_isin.fill("US0378331005")
    trade.buy.check()
    trade.leg_1_amount.fill("1000000")
    trade.leg_1_currency.select_option("USD")
    trade.leg_2_amount.fill("26150000000")
    trade.leg_2_currency.select_option("VND")
    trade.settlement_account.fill("VCB-001-778899")
    trade.notional.fill("1000000")  # inside a shadow root
    trade.fx_rate.fill("26150")  # inside an iframe
    trade.confirm_trade_details.check()
    assert trade.leg_2_amount.input_value() == "26150000000"
    assert trade.submit_trade.is_enabled()
