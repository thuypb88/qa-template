# locatorscan system design

> **Created:** 2026-11-05 15:44:50 (UTC+7) · **Updated:** 2026-11-05 15:56:23 (UTC+7)

For engineers who will maintain or extend `locatorscan`, or review its design. For using it, see the
[user guide](USER-GUIDE.md).

## 1. Purpose

UI automation breaks when its locators break, and writing good locators by hand is slow. `locatorscan` generates locators from
the live page, proves each one, stores the good ones as reviewed data, and detects drift on each release.

| Goals | Non-goals |
|---|---|
| Works on any website, with no per-site code | Running tests or checking behaviour |
| Every stored locator was verified on a real page | Typing, clicking or submitting anything on the page |
| A person stays in control of what enters the registry | Applying fixes silently |
| The same input gives the same output | Bypassing CAPTCHA or bot protection |

## 2. Context

```mermaid
flowchart LR
  person([Tester or SDET]) -->|commands| cli[locatorscan CLI]
  agent([AI agent, through the skill]) -->|commands| cli
  ci([CI pipeline]) -->|validate, exit code| cli
  cli -->|drives, read-only| browser[Chromium or Chrome]
  browser -->|loads| site[(Any website)]
  cli -->|writes| files[(Registry, reports, Page Objects)]
  tests[Playwright tests] -->|import| files
```

## 3. Components

```mermaid
flowchart TB
  cli[cli.py<br/>commands, exit codes]
  config[config.py<br/>workspace, paths]
  engine[engine/playwright_engine.py<br/>session, load, settle, verify, heal]
  discover[engine/discover.js<br/>in-page discovery, candidates]
  ranking[ranking.py<br/>choose, types, similarity]
  stability[stability.py<br/>compare scans]
  registry[registry.py<br/>YAML and JSON files]
  codegen[codegen.py<br/>Page Objects, CSV]
  report[report/<br/>HTML reports]
  locators[locators.py<br/>spec to Playwright or Python]
  models[models.py<br/>Pydantic contracts]

  cli --> config & engine & stability & registry & codegen & report
  engine --> discover & ranking & locators
  stability --> ranking & locators
  report --> ranking & locators
  codegen --> locators
  engine & stability & registry & codegen & report & ranking & locators --> models
```

| Module | Responsibility | Depends on a browser? |
|---|---|---|
| `models.py` | One source of truth for every file; JSON Schemas are generated from it | No |
| `ranking.py` | Pure rules: eligibility, primary, fallbacks, fix similarity | No |
| `stability.py` | Pure comparison of scans passed in as data | No |
| `report/` | Pure rendering: results in, HTML out | No |
| `registry.py`, `codegen.py` | File formats | No |
| `engine/` | The only code that touches a browser, behind the `LocatorEngine` protocol | Yes |
| `cli.py` | Wiring, messages and exit codes | Through `engine/` |

The logic that decides anything is pure, so it can be tested in milliseconds without a browser.

## 4. Scan flow

```mermaid
sequenceDiagram
  participant C as CLI
  participant E as Engine
  participant P as Page
  participant R as Ranking
  C->>E: scan(url, page)
  E->>P: open, wait_for
  E->>E: stop on login redirect or CAPTCHA
  loop until the field count holds for settle_ms, 15 s at most
    E->>P: count fields in every frame
  end
  E->>P: run discover.js in each frame
  P-->>E: fields with candidate locators
  loop each candidate, within the scan budget
    E->>P: count matches, check it is the scanned element
  end
  E->>R: choose(candidates, locator_types)
  R-->>E: primary, fallbacks, best XPath
  E-->>C: ScanResult
  C->>C: write JSON and HTML report
```

`discover.js` keeps each element it finds in `window.__locatorscan.fields`, so verification can check identity: a candidate is
accepted only if it matches **exactly one element, and that element is the field being scanned**. Generating a locator is
cheap and may be wrong; verification is what makes the output trustworthy.

## 5. Choosing a locator

| Score | Strategy | Tier | Type |
|---|---|---|---|
| 0.98 | Test attribute | BEST | `semantic` |
| 0.95 | Role and accessible name | BEST | `role` |
| 0.93 | Label | BEST | `semantic` |
| 0.86 | Stable id | GOOD | `id` |
| 0.82 | Label `for` indirection | GOOD | `xpath` |
| 0.80 | Name, labelled-by, text | GOOD | `name`, `xpath` |
| 0.74–0.78 | Aria-label, scoped by group, label anchor | GOOD | `xpath`, `name` |
| 0.64–0.66 | Layout text anchor | OK | `xpath` |
| 0.58–0.60 | Placeholder | OK | `semantic` |
| 0.50–0.55 | Smart: anchored, partial match, attribute | OK | `smart` |
| 0.30 | Absolute path | OK | `xpath` |
| 0.10 | Reference: class names, CSS path, structural XPath, role only | OK | `css`, `xpath`, `role` |

Rules, all in `ranking.choose`:

- **Default:** highest score wins.
- **With `locator_types`:** only listed types count, earlier types win, and score decides within a type. An absolute path
  stays the last resort whatever the order.
- **Fallbacks:** up to two, each from a different strategy family, so they fail for different reasons. Absolute paths and
  smart locators are never fallbacks.
- **Reference locators** are for people to copy from the report and are never chosen. The exception is CSS once `css` is
  listed, because nothing else is plain CSS.

**Smart anchors.** The nearest repeated ancestors are searched for visible text that no sibling has. Real cards and rows
(`article`, `li`, `tr`, `section`) are preferred. A `div` needs a stable class, because a bare `//div[...]` also matches every
wrapper around it. Numbers, amounts, counts such as `59 To Review` and `volatile_text` matches are never anchors.

## 6. Drift and fix proposals

```mermaid
flowchart TD
  start[Stored field] --> frame{Frame present?}
  frame -- no --> missing[MISSING_FRAME]
  frame -- yes --> primary{Primary matches one?}
  primary -- yes --> ok[OK]
  primary -- no --> fallback{A fallback matches one?}
  fallback -- yes --> used[FALLBACK_USED<br/>propose a new primary]
  fallback -- no --> count{Any matches at all?}
  count -- yes --> many[NON_UNIQUE]
  count -- no --> broken[BROKEN]
  missing & many & broken --> heal[Compare fingerprint with unclaimed fields]
  heal --> sim{Similarity at least 0.55?}
  sim -- yes --> proposal[Propose a fix]
  sim -- no --> human[Report; a person decides]
```

A fingerprint stores tag, type, role, label, name, stable id, group and placeholder. Fields already claimed by a working
locator can't be proposed, so one element can't satisfy two fields. Proposals are only applied by `apply-fixes`, after
approval.

## 7. Stability

`stability` scans the page several times, each in a fresh browser context, then compares the results as data. Fields are
paired across runs by primary locator, then position, then identity. Pairing by primary comes first because, when cards
reorder, a position would pair a field with whichever field moved into its place.

If a run hits the scan budget, a missing field proves nothing, so those fields are counted as `not_compared`.

## 8. Data contracts

| File | Model | Written by | Purpose |
|---|---|---|---|
| `scanner.config.yaml` | `ScannerConfig` | You, `settings` | Settings |
| `out/scans/<page>.json` | `ScanResult` | `scan` | Every candidate and its verification |
| `locators/<page>.yaml` | `RegistryPage` | `review`, `apply-fixes` | The reviewed source of truth |
| `out/validation/<page>.json` | `PageValidation` | `validate` | Status and proposals |
| `out/stability/<page>.json` | `PageStability` | `stability` | Status per field across runs |
| `generated/` | From the registry | `generate` | Page Objects and CSV |

All models forbid unknown fields, so a typo fails loudly. `locatorscan schema` writes JSON Schemas for scans, registry,
validation and stability.

## 9. Failure model

| Situation | Behaviour |
|---|---|
| Page unreachable, or not ready | Stop: exit 2, or exit 3 |
| Redirected to sign-in | Stop: exit 4, never guess credentials |
| CAPTCHA or bot protection | Stop: exit 5, never bypass |
| Nothing found in scope | Stop: exit 6 |
| Scan budget used up | Keep results, status `PARTIAL` |
| Page never stops changing | Stop waiting after 15 s or half of `timeout_ms`, warn, and scan what is there |
| A frame can't be read | Record it in `frame_errors`, show it in the report, continue |
| A locator can't be evaluated | Reject that candidate, continue |

Exit codes are the API for CI: 7 and 9 mean results to read, the others mean the tool couldn't finish.

## 10. Security

| Concern | Design |
|---|---|
| Changing the application | The engine never types, clicks or submits. Discovery only reads the DOM and stores references on `window.__locatorscan` in that page. Opening a page still runs the site's own code |
| Credentials | Never accepted. A person signs in by hand; `login` stores only the browser session |
| Session file | Mode 600, folder mode 700, git-ignored, and excluded from the release. It is as powerful as being logged in |
| Hostile page text | Reports are generated with every page value HTML-escaped, and load nothing external |
| Data in output | Reports and scans contain page text and may contain test data; `out/` is git-ignored |
| Unattended fixes | `apply-fixes` without `--yes` and without a terminal lists proposals and changes nothing |

## 11. Quality and release

| Layer | What it proves | Speed |
|---|---|---|
| `tests/unit` | Ranking, comparison, rendering and contracts, with hand-built data | Under 1 s |
| `tests/component` | Full commands in a real browser on 18 fixture pages, including report controls | Minutes |
| Clean install | The built package works outside the repo, with its data files | At release |

`scripts/build_release.py` is the only way to make a release. It stops at the first failure:

1. `ruff` lint and format, `pyright` strict, then all tests.
2. Build the wheel and source distribution.
3. Install the wheel in a new virtual environment, then run scan, review and generate on an example page.
4. Bundle the wheel, docs, skill, example and config; refuse if anything private is included; write checksums.

A guard test fails if a known site name enters a shipped file, because the tool must stay independent of any website.

**Decisions**

| Decision | Why | Cost |
|---|---|---|
| Registry as reviewed YAML, not locators resolved at run time | Changes are visible in code review, and tests don't need the tool | Needs a re-scan to pick up changes |
| Heuristics first, no AI model | Deterministic, offline, free and explainable | Won't understand a page's meaning |
| Generate many candidates, then verify | Simple rules, and wrong guesses can't reach the output | One browser call per candidate |
| New locator kinds only replace an absolute path | Existing good results never change | Some weak forms stay rated OK |
| Settling on field count, not network idle | Single-page apps often never reach network idle | A long pause can still look settled |
| Static HTML reports with no server | Can be shared and archived; work offline | The settings form can't save, so it gives a command |
| Flat modules, one sub-package each for engine and reports | A 3,000-line tool doesn't need more layers | Revisit if a second engine arrives |

## 12. Known limitations

| Limitation | Effect | Workaround |
|---|---|---|
| Text anchor outranks placeholder | A nearby heading can be picked over the input's own placeholder | Exclude or reorder types; a ranking change is the real fix |
| `volatile_text` is manual | Only number-only text is flagged automatically, so a user name isn't | Add a pattern, or use `--compare-state` |
| `stability` doesn't block `review` | Flagged locators can still enter the registry | Read the stability report first |
| Stability on unchanged data | Can't reveal what changes with data | Re-run after the data changes |
| Settling can be fooled by pauses over `settle_ms` | Fields missed, still reported as OK | `--wait-for`, or raise `settle_ms` |
| Smart anchors depend on data | Renamed cards, or other environments, break them | Test attributes |
| One session per config | Multiple sites need multiple configs | `--config` |
| `login` | Not yet exercised with a real person signing in; only its saving and error handling are tested | Check on first use |
| Output | Playwright for Python Page Objects only; no Selenium | Use the CSV or XPath |
| Form validation checks, parameterised locators | Not built | |

## 13. Extending it

| To add | Change |
|---|---|
| A locator form | Add a candidate in `discover.js`, a type mapping and any eligibility rule in `ranking.py`, a title in `report/scan.py`, and tests with a fixture page |
| A report | A module in `report/` using `layout.py` |
| An engine | Implement `LocatorEngine` in `engine/base.py`; the registry and reports don't change |
| A command | A `cmd_*` function and parser entry in `cli.py`, with any new exit code in `errors.py` |

Run any new locator form against real pages before trusting it: smart locators passed their first fixtures, then produced
nothing on a real page.
