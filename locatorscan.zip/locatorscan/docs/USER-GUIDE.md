# locatorscan user guide

> **Created:** 2026-11-05 15:44:50 (UTC+7) · **Updated:** 2026-11-05 16:51:46 (UTC+7)

For testers and SDETs who want reliable locators for a web page. No knowledge of the tool's code is needed.

## 1. Install

You need Python 3.11 or newer.

```bash
python3 -m venv ~/.venvs/locatorscan
source ~/.venvs/locatorscan/bin/activate
pip install locatorscan-1.0.0-py3-none-any.whl
python -m playwright install chromium
locatorscan --version
```

To use your installed Google Chrome instead of downloading Chromium, add `browser_channel: chrome` to the config.

## 2. Where to run it

Run `locatorscan` from a folder of your choice. It reads `scanner.config.yaml` there if there is one, and writes its output
beside it. The tool works without a config; the one in the release is a sensible start for any site.

| Output | Contents | Keep in git? |
|---|---|---|
| `out/reports/` | HTML reports | No |
| `out/scans/`, `out/validation/`, `out/stability/` | Raw results as JSON | No |
| `locators/` | The registry: the locators you accepted, one YAML per page | Yes, if your tests use it |
| `generated/` | Page Objects and CSV, rebuilt from the registry | Your choice |
| `.auth/` | Your sign-in session | **Never** |

## 3. The basic workflow

```bash
locatorscan scan --url https://any-site.example/form --page my_form   # 1. find fields, verify locators
#            open out/reports/my_form-scan.html and read it
locatorscan review --page my_form                                     # 2. accept locators into the registry
locatorscan generate                                                  # 3. build the Page Object

# after each release of the app
locatorscan --app-version 2.4 validate                                # 4. re-check; exit 7 if some broke
locatorscan apply-fixes --page my_form                                # 5. approve the proposed fixes
locatorscan generate                                                  # 6. rebuild the Page Object
```

`--page` becomes the file names and the Page Object class: `my_form` gives `MyFormPage`. On `scan` and `stability` it is
optional, and the name then comes from the URL, so `https://any-site.example/docs/best-practices` gives `best_practices`.
A URL with no usable path takes its host name. Two URLs that end the same way get the same name, and the second scan replaces
the first, so pass `--page` when that matters.

`review` asks about each field in a terminal. With `--yes` it accepts by tier instead, BEST and GOOD by default. Add
`--min-tier OK` to accept smart locators too, which are rated OK.

## 4. Sites that need signing in

```bash
locatorscan login --url https://any-site.example/
```

A browser opens. Sign in by hand, including any MFA, then press Enter in the terminal. The session is saved to the
`storage_state` file in your config, and later commands use it. `locatorscan` never sees your password.

The session file is as powerful as being logged in: don't share or commit it. When it expires, commands stop with
`AUTH_REQUIRED` (exit 4). Run `login` again. For a second site, use a second config with its own `storage_state`, and pass
it with `--config`.

## 5. Reading a scan report

Fields are grouped by where they sit on the page. Each row shows a tier, the label and the primary locator.

| Tier | Meaning |
|---|---|
| BEST | Test attribute, role with a name, or label |
| GOOD | Stable id, name, text or label-based XPath |
| OK | Works today, but weaker: placeholder, smart locator or absolute path. Read these before accepting |
| NONE | Nothing unique was found. Ask developers for a test attribute |

Open **CSS & XPath** on a field to see every locator that reaches it, with Playwright code to copy. A badge shows `✓ 1` if
the locator is unique, or how many elements it matches; in that case the code picks the right one with `.nth(k)`.
**FRAGILE** cards depend on the exact page structure.

| Warning | Meaning |
|---|---|
| `POSITIONAL_ONLY` | Only an absolute path works |
| `VOLATILE_TEXT` | The locator relies on text that is only a number or date, or matches `volatile_text` |
| `UNLABELLED` | No proper label; the name comes from a weak source such as a title or placeholder |
| `LABEL_FROM_LAYOUT` | The label was guessed from nearby text |
| `HIDDEN` | Not visible when scanned; a test may need to open a menu first |
| `CUSTOM_WIDGET` · `SHADOW_DOM` | Not a native control · Inside a shadow root, so XPath cannot reach it |
| `NON_UNIQUE` · `NO_LOCATOR` | Candidates matched several elements · Nothing matched |

## 6. Choosing locator types

Open the **Locator type settings** panel at the top of a scan report. Tick types and reorder them, and the cards update
straight away. The panel gives you the command that saves your choice:

```bash
locatorscan settings                                 # show the current setting
locatorscan settings --set role,semantic,id,name     # save: order is priority, a type left out is excluded
locatorscan settings --reset                         # back to the default
locatorscan --types role,xpath scan --url <url> --page my_form   # this run only, not saved
```

| Type | Includes |
|---|---|
| `role` | `get_by_role` |
| `semantic` | Test attributes, labels, placeholders |
| `id` · `name` | Stable ids · `name` attributes |
| `smart` | Anchored, partial-match and attribute locators |
| `css` | Class-based and structural CSS |
| `xpath` | Text, label-anchored and structural XPath, absolute path last |

By default every type is on and ranked by score. A new setting takes effect at the next scan. To change the registry,
re-scan and review. `validate` keeps checking the locators already stored.

## 7. Smart locators

When a field has nothing unique, such as the same **New** button on every card, `locatorscan` tries these before falling back
to an absolute path:

| Form | Example | Keeps working when |
|---|---|---|
| Anchored | `//article[.//*[normalize-space()='Bank BBL']]//button[@name='create']` | Cards or rows are added, removed or reordered |
| Partial match | `//input[starts-with(@id, 'customer_field_')]` | An id ends in a generated number |
| Attribute | `//button[@title='Home Menu']` | The layout changes |

An anchor is still data. If the card is renamed, or named differently elsewhere, the locator breaks. For critical tests,
ask developers for a test attribute.

## 8. Finding dynamic locators

```bash
locatorscan stability --url <url> --page my_form                 # scan twice, compare
locatorscan stability --url <url> --page my_form --runs 3 --strict
locatorscan stability --url <url> --page my_form --compare-state .auth/other_user.json   # last run as another user
```

To make `other_user.json`, sign in as that user with a config whose `storage_state` points there.

| Status | Meaning | Exit 9 |
|---|---|---|
| `DYNAMIC` | The primary changed between runs | Yes |
| `NOT_IN_ALL_RUNS` | The field was missing from a run | Yes |
| `VOLATILE_TEXT` | The primary relies on number-only text or a `volatile_text` pattern | Yes |
| `PARTLY_DYNAMIC` | The primary held; another locator changed | With `--strict` |
| `POSITION_ONLY` | Unchanged, but relies on page position | With `--strict` |
| `NO_LOCATOR` · `STABLE` | Nothing to compare · Nothing changed | No |

`STABLE` means nothing changed between those runs. One user on unchanged data can't reveal what changes with users or
data: use `--compare-state` for users, and run again after the data changes. `stability` only reports, so `review` still
accepts flagged fields: check its report before you accept.

## 9. Configuration

All settings are optional. Paths are relative to the config file.

| Setting | Default | Purpose |
|---|---|---|
| `app_version` | `unversioned` | Release label stored with the registry |
| `base_url` | none | Lets `--url` be a path |
| `browser_channel` | none | `chrome` uses installed Google Chrome |
| `headless` | `true` | `false` to watch the browser |
| `storage_state` | none | Session file; `login` writes it |
| `scope` | `body` | CSS root that limits the scan |
| `wait_for` | `load` | `load`, `domcontentloaded`, `networkidle` or a CSS selector |
| `settle_ms` | `1000` | Wait until the field count holds this long; `0` turns it off |
| `timeout_ms` | `30000` | Page load timeout and scan budget |
| `test_attributes` | `data-testid`, `data-qa`, `data-cy`, `data-test` | Tried first |
| `deny_list` | framework id patterns | Regexes; matching ids, names and test ids are never used |
| `standalone_buttons` | `auto` | Buttons outside a form or group: `auto` only when a page has no other fields, `always` includes them |
| `volatile_text` | none | Regexes for text that changes with user or data, such as a user name |
| `locator_types` | none | See section 6 |
| `login_url_patterns` | `/login`, `/signin`, `/sso/` | A redirect here stops with `AUTH_REQUIRED` |
| `registry_dir`, `out_dir`, `generated_dir` | `locators`, `out`, `generated` | Output folders |

Global options go **before** the command: `--config`, `--app-version`, `--types`, `-v`, `--version`.
`scan` and `stability` also take `--scope`, `--wait-for` and `--all-buttons` per run.

## 10. Using it in CI

Run `validate` after a deployment, and fail the pipeline on its exit code. For example:

```bash
locatorscan --app-version "$BUILD_ID" validate --strict
```

Keep `locators/` in git, publish `out/reports/` as a build artifact, and provide the session through your CI's secret store.
Never apply fixes automatically: a fix proposal is a guess based on similarity.

## 11. Exit codes

| Code | Name | Meaning | What to do |
|---|---|---|---|
| 0 | OK | Done | |
| 2 | NAV_ERROR | URL unreachable or HTTP error | Check the URL and network |
| 3 | TIMEOUT | Page never became ready | Raise `timeout_ms`, or fix `--wait-for` |
| 4 | AUTH_REQUIRED | Redirected to a sign-in page | Run `locatorscan login` |
| 5 | BLOCKED | CAPTCHA or bot protection | Stop: the tool never bypasses it. Ask for a test environment |
| 6 | NO_FIELDS | No fields inside `scope` | Check `--scope`, the sign-in, or the wait |
| 7 | LOCATORS_BROKEN | `validate` found broken or non-unique locators | Read the report, then run `apply-fixes` |
| 8 | CONFIG_ERROR | Bad config, or a missing scan or registry | Read the message |
| 9 | DYNAMIC_LOCATORS | `stability` found a primary it can't trust | Read the report |

## 12. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `Executable doesn't exist` | The browser isn't installed for this Playwright version | `python -m playwright install chromium`, or set `browser_channel: chrome` |
| Far fewer fields than expected | The page paused for over a second while loading | Pass `--wait-for "<selector of late content>"`, or raise `settle_ms` |
| `Fields were still changing` warning | The page keeps adding fields | Check the result, and narrow it with `--scope` |
| Status `PARTIAL` | The scan ran out of budget | Raise `timeout_ms` |
| Timeout waiting for `networkidle` | The page keeps a connection open, as many single-page apps do | Use the default `load` |
| Most fields are `OK` or `POSITIONAL_ONLY` | The page has repeated controls with nothing unique | Ask developers for test attributes |
| `NAV_ERROR ... returned HTTP 404` | The URL has no page; a page that opens in a browser may have redirected or used different text | Open the URL in a browser and copy its address |
| `NO_FIELDS` on a page with content | The page has no form controls or buttons; links are not scanned | Check the page, the sign-in, or `--scope` |
| Header or toolbar buttons are missing | Buttons outside a form or group are left out when a page has other fields | Pass `--all-buttons` |
| Too many fields from menus and headers | The whole page is in scope | Pass `--scope main` or a tighter selector |

## 13. Try the example

```bash
cd examples/trade-entry
bash run_demo.sh                 # scans a page, simulates a release, validates, applies fixes
python -m pytest tests -q        # uses the generated Page Object
```

`run_demo.sh` deletes and rebuilds its own `out/`, `locators/` and `generated/` each time. Exit code 7 during its run is
expected: some locators are meant to break.
