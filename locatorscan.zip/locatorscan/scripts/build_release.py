#!/usr/bin/env python3
"""Build a release: run every check, build the package, test it in a clean environment, bundle it.

Usage: python scripts/build_release.py [--skip-checks]
It stops at the first failure and leaves no release behind. Needs the dev extras: pip install -e ".[dev]"
"""

from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
import tarfile
import tempfile
import venv
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
BUNDLED = ("README.md", "CHANGELOG.md", "scanner.config.yaml", "docs", "skills", "examples/trade-entry")
NEVER_IN_EXAMPLE = {"out", "locators", "generated", "__pycache__", ".pytest_cache"}
PRIVATE = {".auth", "session.json", ".env"}


def step(title: str) -> None:
    print(f"\n== {title}", flush=True)


def run(*command: str | Path, cwd: Path = ROOT) -> str:
    done = subprocess.run([str(c) for c in command], cwd=cwd, text=True, capture_output=True, check=False)
    if done.returncode != 0:
        sys.exit(f"FAILED: {' '.join(str(c) for c in command)}\n{done.stdout}\n{done.stderr}")
    return done.stdout


def version() -> str:
    found = run(
        sys.executable,
        "-c",
        "import sys; sys.path.insert(0, 'src'); import locatorscan; print(locatorscan.__version__)",
    )
    return found.strip()


def checks() -> None:
    python = Path(sys.executable)
    step("Lint and format")
    run(python, "-m", "ruff", "check", "src", "tests", "scripts")
    run(python, "-m", "ruff", "format", "--check", "src", "tests", "scripts")
    step("Types (pyright strict)")
    print(run(python, "-m", "pyright", "--pythonpath", python).strip().splitlines()[-1])
    step("All tests")
    print(run(python, "-m", "pytest", "-q").strip().splitlines()[-1])


def build() -> tuple[Path, Path]:
    step("Build the wheel and source distribution")
    shutil.rmtree(DIST, ignore_errors=True)
    shutil.rmtree(ROOT / "build", ignore_errors=True)
    run(sys.executable, "-m", "build", "--outdir", DIST)
    wheel = next(DIST.glob("*.whl"))
    sdist = next(DIST.glob("*.tar.gz"))
    print(wheel.name, sdist.name)
    with zipfile.ZipFile(wheel) as z:
        names = z.namelist()
    for needed in (
        "locatorscan/engine/discover.js",
        "locatorscan/report/assets/report.css",
        "locatorscan/report/assets/report.js",
    ):
        if needed not in names:
            sys.exit(f"FAILED: {needed} is not in the wheel")
    with tarfile.open(sdist) as t:
        refuse_private(t.getnames(), sdist.name)
    refuse_private(names, wheel.name)
    return wheel, sdist


def smoke_test(wheel: Path, expected: str) -> None:
    """The wheel must work on its own: no repo on the path, data files included, a real browser run."""
    step("Install the wheel in a clean environment and use it")
    with tempfile.TemporaryDirectory(prefix="locatorscan-smoke-") as tmp:
        home = Path(tmp)
        venv.create(home / "venv", with_pip=True)
        bin_dir = home / "venv" / "bin"
        run(bin_dir / "pip", "install", "-q", wheel)
        work = home / "work"
        work.mkdir()
        shown = run(bin_dir / "locatorscan", "--version", cwd=work).strip()
        if shown != f"locatorscan {expected}":
            sys.exit(f"FAILED: expected locatorscan {expected}, got {shown}")
        run(bin_dir / "python", "-m", "playwright", "install", "chromium", cwd=work)
        page = ROOT / "tests" / "fixtures" / "pages" / "repeated_cards.html"
        run(bin_dir / "locatorscan", "scan", "--url", page.as_uri(), "--page", "cards", cwd=work)
        run(bin_dir / "locatorscan", "review", "--page", "cards", "--yes", "--min-tier", "OK", cwd=work)
        run(bin_dir / "locatorscan", "generate", cwd=work)
        report = (work / "out" / "reports" / "cards-scan.html").read_text(encoding="utf-8")
        for expected_text in ("Locator type settings", "Smart Locator (anchored)", ".set-order", "function apply"):
            if expected_text not in report:
                sys.exit(f"FAILED: the report has no {expected_text!r}")
        for output in ("locators/cards.yaml", "generated/pages/cards_page.py", "generated/cards.csv"):
            if not (work / output).is_file():
                sys.exit(f"FAILED: {output} was not written")
        print(shown, "· scan, review and generate worked")


def refuse_private(names: list[str], where: str) -> None:
    for name in names:
        if PRIVATE & set(Path(name).parts):
            sys.exit(f"FAILED: {where} contains a private file: {name}")


def bundle_files() -> list[tuple[Path, str]]:
    files: list[tuple[Path, str]] = []
    for entry in BUNDLED:
        source = ROOT / entry
        if source.is_file():
            files.append((source, entry))
            continue
        for path in sorted(source.rglob("*")):
            relative = path.relative_to(ROOT)
            if path.is_file() and not (NEVER_IN_EXAMPLE & set(relative.parts)):
                files.append((path, str(relative)))
    return files


def bundle(wheel: Path, sdist: Path, name: str) -> Path:
    step("Bundle the release")
    target = DIST / f"{name}.zip"
    files = [*bundle_files(), (wheel, wheel.name)]
    refuse_private([arcname for _, arcname in files], target.name)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
        for path, arcname in files:
            z.write(path, f"{name}/{arcname}")
    lines = [f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n" for p in (wheel, sdist, target)]
    (DIST / "SHA256SUMS").write_text("".join(lines), encoding="utf-8")
    print(target.name, f"{len(files)} files, {target.stat().st_size // 1024} KB")
    return target


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--skip-checks", action="store_true", help="only to re-bundle; never for a release you hand over"
    )
    args = parser.parse_args()
    current = version()
    print(f"Releasing locatorscan {current}")
    if not args.skip_checks:
        checks()
    wheel, sdist = build()
    smoke_test(wheel, current)
    bundle(wheel, sdist, f"locatorscan-{current}")
    step(f"Release ready: {DIST}")
    for path in sorted(DIST.iterdir()):
        print(" ", path.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
