# Registry and scan files

Full JSON Schemas: `locatorscan schema --out schemas`.

## Registry: `locators/<page>.yaml` (in git)

```yaml
page: trade_entry
url: app/trade_entry_v1.html      # as given to scan: absolute, base_url-relative, or local file
app_version: '2026.3'
fields:
  trade_date:                     # key = Page Object attribute name
    label: Trade Date
    group: Trade details
    kind: text                    # text | choice | toggle | action
    primary: {kind: label, value: Trade Date *, strategy: label, tier: BEST, score: 0.93, explanation: ...}
    fallbacks:
    - {kind: css, value: '#tradeDate', strategy: id, tier: GOOD, score: 0.86, ...}
    xpath: //input[@id='tradeDate']
    frame_path: []                # e.g. ['iframe#fx-widget'] for fields inside frames
    in_shadow_dom: false
    fingerprint: {tag: input, input_type: date, label: Trade Date, name: tradeDate, id: tradeDate, group: ...}
    last_verified: '2026-11-05'
```

Locator `kind`: `role` (value = role, `name` = accessible name), `label`, `placeholder`, `css`, `xpath`.

## Scan output: `out/scans/<page>.json`

Same field data plus `label_source`, `state` (visible, disabled, readonly, required), every evaluated
`candidates[]` entry with `match_count` and `is_target`, and `warnings`. Scan status is `OK` or `PARTIAL`
(scan budget ran out; results kept).

## Validation output: `out/validation/<page>.json`

Per field: `status` (OK, FALLBACK_USED, BROKEN, NON_UNIQUE, MISSING_FRAME), `used` (primary or
fallback[n]), `detail` (match counts), optional `proposal` (new primary, fallbacks, xpath, frame path,
fingerprint, similarity, reason). Page level: `new_fields` found on the page but not in the registry.
