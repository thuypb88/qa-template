# locatorscan command reference

Global options (before the command): `--version`, `--config <file>` (default `./scanner.config.yaml`),
`--app-version <label>` (overrides `app_version` for this run), `--types <list>` (locator types for this run only), `-v` (verbose logging).

| Command | Purpose | Key options | Writes |
| --- | --- | --- | --- |
| `scan` | Find fields, generate and verify locators | `--url` (required), `--page` (default: from the URL), `--scope <css>`, `--wait-for <state or css>`, `--all-buttons` | `out/scans/<page>.json`, `out/reports/<page>-scan.html` |
| `review` | Accept scanned fields into the registry | `--page`, `--yes`, `--min-tier BEST\|GOOD\|OK` (default GOOD) | `locators/<page>.yaml` |
| `generate` | Page Objects and CSV from the registry | `--page` (default: all) | `generated/pages/<page>_page.py`, `generated/<page>.csv` |
| `validate` | Re-check registry locators on the live page | `--page`, `--url` (override), `--strict` (fallback counts as failure) | `out/validation/<page>.json`, `out/reports/<page>-validation.html` |
| `stability` | Scan a page several times and flag locators that change | `--url` (required), `--page` (default: from the URL), `--scope`, `--runs` (default 2), `--compare-state <session file>` (another user, last run), `--strict` (position-only and partly dynamic fail too) | `out/stability/<page>.json`, `out/reports/<page>-stability.html` |
| `settings` | Show or save which locator types to use, and their priority | `--set role,semantic,id` · `--reset` | `locator_types` in the config file |
| `login` | A person signs in, in a browser it opens; the session is saved | `--url` (required) | The `storage_state` file |
| `apply-fixes` | Apply proposals from the last validation | `--page`, `--yes` | `locators/<page>.yaml` |
| `schema` | JSON Schemas of the data contracts | `--out <dir>` | `<dir>/*.schema.json` |

`--url` accepts an absolute URL, a path joined to `base_url`, or a local HTML file relative to the config.

Without `--yes`, `review` and `apply-fixes` ask per field when a terminal is attached. With no terminal,
`review` accepts by tier, and `apply-fixes` only lists the proposals and changes nothing. Pass
`apply-fixes --yes` only after the user approves the proposals.

## Config keys (`scanner.config.yaml`)

| Key | Default | Notes |
| --- | --- | --- |
| `app_version` | `unversioned` | Label stored with the registry |
| `base_url` | none | For relative `--url` paths |
| `browser_channel` | none | `chrome` uses installed Google Chrome |
| `headless` | `true` | `false` to watch the browser |
| `storage_state` | none | Session file from a manual login; keep out of git |
| `scope` | `body` | CSS root that limits the scan |
| `wait_for` | `load` | `load`, `domcontentloaded`, `networkidle`, or a CSS selector |
| `settle_ms` | `1000` | After `wait_for`, wait until the field count holds this long (15 s at most); `0` turns it off |
| `timeout_ms` | `30000` | Page load timeout and scan budget |
| `test_attributes` | `data-testid, data-qa, data-cy, data-test` | Tried first |
| `deny_list` | framework id patterns | Regexes; matching ids, names and test ids are never used |
| `login_url_patterns` | `/login, /signin, /sso/` | Redirects here raise AUTH_REQUIRED |
| `locator_types` | none | Ordered list of `role`, `semantic`, `id`, `name`, `smart`, `css`, `xpath`. Order is priority; a type left out is excluded. Unset: rank by score |
| `standalone_buttons` | `auto` | Buttons outside a form or group: `auto` only when a page has no other fields, `always` includes them |
| `volatile_text` | none | Regexes for visible text that changes with user or data, e.g. a user name. Number-only text is always flagged |
| `registry_dir`, `out_dir`, `generated_dir` | `locators`, `out`, `generated` | Relative to the config |
