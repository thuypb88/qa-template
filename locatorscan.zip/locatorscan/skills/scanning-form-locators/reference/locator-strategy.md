# How locators are chosen

Every candidate is evaluated on the live page in its own frame. It is kept only if it matches exactly one
element and that element is the field being scanned (identity check). The highest-scoring survivor is the
primary.

| Score | Strategy | Example | Tier |
| --- | --- | --- | --- |
| 0.98 | Test attribute | `[data-testid="submit-trade"]` | BEST |
| 0.95 | Role + accessible name | `get_by_role("textbox", name="Comments")` | BEST |
| 0.93 | Label | `get_by_label("Trade Date *")` | BEST |
| 0.86 | Stable id | `#tradeDate` | GOOD |
| 0.82 | Label `for` indirection | `//input[@id=//label[normalize-space()='Quantity']/@for]` | GOOD |
| 0.80 | name / aria-label / labelled-by / button text | `//input[@name='leg1Amount']` | GOOD |
| 0.77 | Scoped by group | `//fieldset[legend[normalize-space()='Buyer']]//label[...]/following::input[1]` | GOOD |
| 0.74 | Label anchor | `//label[normalize-space()='Amount']/following::input[1]` | GOOD |
| 0.66 | Layout text anchor (grids) | `//*[normalize-space(text())='USD/VND']/following::input[1]` | OK |
| 0.60 | Placeholder | `get_by_placeholder("0.00")` | OK |
| 0.50–0.55 | Smart: anchored to nearby text, partial match, attribute | `//article[.//*[normalize-space()='Bank BBL']]//button[@name='create']` | OK, never a fallback |
| 0.30 | Absolute position | `/html[1]/body[1]/...` | OK, never a fallback |

The label-`for` indirection survives dynamic ids, because the id is read from the label at run time.

**Fallbacks** (up to two) come from a different strategy family than the primary, so they fail for different
reasons. Families: label text (role, label, label-for, label anchor, labelled-by, text), id, name, test
attribute, placeholder. If only one family exists (a button known only by its text), one fallback of a
different locator kind is kept.

**Locator type settings** (`locator_types`) replace the score order: only the listed types count and earlier types win,
with score deciding inside a type. An absolute path stays the last resort. Class-based and structural CSS are reference
locators, shown for copying; they can only be chosen when `css` is listed.

**Never used:** ids, names and test ids that match the `deny_list` (Ember, Angular Material, React, GUIDs,
CSS-module hashes, 4+ digit runs).

**XPath** is reported for every field outside shadow DOM (best verified XPath candidate). XPath cannot enter
shadow roots; those fields get role/label/CSS locators only and the `SHADOW_DOM` warning.

## Warnings

| Warning | Meaning |
| --- | --- |
| `UNLABELLED` | Only placeholder/title/name found; name the field manually |
| `LABEL_FROM_LAYOUT` | Label taken from nearby text (grid cell), not a real label |
| `CUSTOM_WIDGET` | ARIA widget, not a native control |
| `SHADOW_DOM` | Inside an open shadow root; no XPath |
| `HIDDEN` | Zero size or not displayed at scan time |
| `NON_UNIQUE` / `NO_LOCATOR` | No candidate matched exactly this element |
| `POSITIONAL_ONLY` | Only the absolute path works; fragile |

## Healing (validate)

When the primary and fallbacks all fail, discovered fields on the page are compared with the stored
fingerprint: label 0.35, name 0.2, id 0.15, input type 0.1, group 0.1, placeholder 0.05, role 0.05,
halved if the tag differs. The best match at or above 0.55 becomes a proposal. Fields that resolved by a
fallback get a proposal for a new primary. Proposals need the user's approval.
