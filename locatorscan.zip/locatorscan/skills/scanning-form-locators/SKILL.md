---
name: scanning-form-locators
description: Scans web pages for form fields and generates verified, ranked XPath and Playwright locators, keeps them in a versioned YAML registry, generates Page Objects, and re-validates them after app releases with fix proposals. Use when the user asks for locators, XPath, form fields, Page Objects, broken selectors, or checking locators after a release.
---

# Scanning form locators

All work goes through the `locatorscan` command line. Run it from the folder that holds `scanner.config.yaml`.
Check the setup once per session: `bash scripts/check_setup.sh`.

## New page: scan → review → generate

Copy this checklist and tick it off:

```
- [ ] 1. locatorscan scan --url <url> --page <page_name>
- [ ] 2. Show the user the scan table; point out NONE, OK-tier and warning rows
- [ ] 3. locatorscan review --page <page_name> --yes   (accepts BEST and GOOD)
- [ ] 4. List skipped / manual fields for the user to decide
- [ ] 5. locatorscan generate
```

`page_name` is snake_case and becomes the registry file and Page Object class (`trade_entry` → `TradeEntryPage`).
`locatorscan` waits for the fields on a page to settle. If a page pauses for long between stages, pass `--wait-for <css selector>`.

## After an app release: validate → apply-fixes → generate

```
- [ ] 1. locatorscan --app-version <new> validate [--page <p>] [--url <url>]
- [ ] 2. Show the user each FALLBACK_USED / BROKEN / MISSING_FRAME row and its proposal
- [ ] 3. Only after the user approves: locatorscan apply-fixes --page <p> --yes
- [ ] 4. locatorscan validate again; continue only when no proposal remains
- [ ] 5. locatorscan generate
```

Fields still BROKEN with no proposal, and "new fields not in the registry", need the user: usually a re-scan.

## Rules

- Never apply fix proposals without the user's explicit approval. A proposal is a guess based on similarity.
- The scanner is read-only. Never add steps that type into fields or submit forms.
- Never put credentials in commands, config or files. For pages behind login the user runs
  `locatorscan login --url <url>` and signs in by hand; it works on any site.
- `AUTH_REQUIRED` (exit 4): ask the user to run `locatorscan login` again. `BLOCKED` (exit 5): stop and tell the
  user; never try to get past CAPTCHA or bot protection.
- Never hand-edit files in `generated/`. Change the registry through review / apply-fixes, then regenerate.

## Exit codes

| Code | Name | Meaning |
| --- | --- | --- |
| 0 | OK | Done |
| 2 | NAV_ERROR | URL unreachable or HTTP error |
| 3 | TIMEOUT | Page never became ready |
| 4 | AUTH_REQUIRED | Redirected to login |
| 5 | BLOCKED | CAPTCHA or bot protection |
| 6 | NO_FIELDS | No fields inside `scope` |
| 7 | LOCATORS_BROKEN | validate found broken or non-unique locators |
| 8 | CONFIG_ERROR | Bad config, missing scan or registry |
| 9 | DYNAMIC_LOCATORS | `stability` found a primary that changed, relies on volatile text, or was not found in every run |

## More detail

- Commands and flags: [reference/cli.md](reference/cli.md)
- How locators are chosen and rated: [reference/locator-strategy.md](reference/locator-strategy.md)
- Registry and scan file formats: [reference/registry-schema.md](reference/registry-schema.md)
