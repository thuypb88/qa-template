#!/usr/bin/env bash
# Checks that locatorscan and a Playwright browser are available. Prints the fix for anything missing.
set -u
ok=1
if ! command -v locatorscan >/dev/null 2>&1; then
  echo "MISSING: locatorscan command. Install from the repo: pip install locatorscan-<version>-py3-none-any.whl (or pip install -e . from the repo)"
  ok=0
fi
if ! python3 -c "import playwright" >/dev/null 2>&1; then
  echo "MISSING: playwright Python package. Run: pip install playwright"
  ok=0
elif ! python3 - <<'EOF' >/dev/null 2>&1
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    p.chromium.launch().close()
EOF
then
  echo "MISSING: Playwright Chromium. Run: python3 -m playwright install chromium"
  echo "         (or set browser_channel: chrome in scanner.config.yaml to use installed Google Chrome)"
  ok=0
fi
if [ ! -f scanner.config.yaml ]; then
  echo "NOTE: no scanner.config.yaml here; defaults will be used (scope: body, wait_for: load)."
fi
if [ "$ok" = 1 ]; then echo "locatorscan setup OK"; else exit 1; fi
