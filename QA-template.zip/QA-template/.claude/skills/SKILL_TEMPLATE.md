---
name: <group>-<objective, a noun or verb; lowercase-hyphen; = folder name>
description: <Group>[ <order>] (<role: writer | reviewer | router>, <level IT / ST>, <packs>): <objective in one clause>. <Verb> <what> from <inputs> and write <output file>. Use for "<trigger in the user's words>", "<another>", or <re-run condition>. Not for: <neighbour case> → <other-skill>; <neighbour case> → <other-skill>.
metadata:
  group: <flow | plan | req | design | check | auto | run | learn — must equal the name prefix>
  order: "<step id in the chain: -1, 0, 1 … 6, A1, A2, A3, E0, E, E+, ST; or - for none>"
---

<!--
SKILL TEMPLATE — not a skill (Claude Code loads only <folder>/SKILL.md). Rules: standards/skill-architecture.md.
1. Pick the group by the question the skill answers (catalog: .claude/skills/README.md). No group fits, or the input,
   output and triggers overlap an existing skill → add a mode (references/<mode>.md) to that skill instead.
2. Copy to .claude/skills/<group>-<objective>/SKILL.md; replace every <placeholder>; delete these comments.
   agentskills.io format (Claude Code, Codex, Copilot, Gemini CLI): name = folder, lowercase-hyphen, ≤ 64 chars.
   Description ≤ 1024 chars: "<Group>: objective" → what (inputs → output) → "Use for …" → "Not for: … → skill".
3. Shared rules live in standards/ (core-rules R1–R10, review-protocol P1–P7, conventions, methods/) and
   packs/<pack>/: link to them, never copy them. Never link into another skill's references/.
4. SKILL.md ≤ ~120 lines. Section order is fixed: contract → Modes (only if any) → Steps → Rules → Pitfalls (only
   with evidence) → Done when (required). Long formats and per-mode detail go to references/, each with a "when".
5. Add a row in the group's table of .claude/skills/README.md, template-dev/tests/skill-evals/<name>.json (≥ 3 cases incl. a
   near miss), run python3 scripts/workspace/sync_agents.py and template-dev/tests/selftest.py, then review it with check-skill.
-->

# <Group>: <objective>

> **Created:** <YYYY-MM-DD HH:MM> · **Updated:** <YYYY-MM-DD HH:MM> (<timezone>)

**In:** <target and files read>. **Out:** <files written; fixed title lines the scripts read>. **Rules:** <R-rules,
pack rules, project rules that start or matter here>. **Next:** `<next-skill>`.
**Stop if** <upstream missing / stale> → `<skill to run first>`. Never fill a gap by guessing.
**Modes:** <only when the skill has them: mode → [references/<mode>.md](references/<mode>.md), when to pick it>

Read lean: `slice.py toc` → `section`; never a whole file over ~40 KB. Read the lessons that name this skill.

## Steps

1. <Read …>
2. <Write … with citations>
3. <Run the check script; fix every Error>

## Required sections | Checklist

1. **<Section>.** <content, fixed columns and why>

## Rules

- No invention: unknowns are `Q-xxx: assumed …`.
- IDs stable: never renumber; append.
- Generated files are regenerated, never edited.

## Pitfalls

- <L-Tnn / L-nnn references, plus mistakes seen in past runs>

## Done when

- [ ] <every section / check present>
- [ ] <check script clean; version bumped; `project/status.md` + `log.md` updated>
- [ ] Report <counts>; suggest `<next-skill>`.
