---
applyTo: "**/3-test-cases/test-cases.json"
---
# Test case JSON (any level folder)

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:48 (UTC+7)

The skill is `.github/skills/design-cases/SKILL.md` (reviewing: `check-design`). Fields: `standards/conventions.md` §4;
pack block: `packs/<pack>/tc-fields.md` (the module's pack is in `project.json`).

- `steps` and `expected_result` have the same count, in order, unnumbered; one behaviour per TC (R4).
- Title `[<Level-1 item>] <behaviour>`; values only from `project.json › values` + the pack's extra types (R5, R8).
- Preconditions: one baseline item, then only this TC's specials (R3). Concrete data, or `Q-xxx: assumed …` in notes (R6, R8).
- Steps and results stay at the pack surface (R2): UI = screen, API = HTTP response, ETL = query result.
- Never renumber `tc_id`; append. **Bump `version` on every change**, then run
  `python3 scripts/export_testcases.py <target>` (it refuses on any Error). Never edit the `.xlsx`.
- Before finishing: `python3 scripts/export_testcases.py <target> --check` and `python3 scripts/workspace/guard.py check`.
