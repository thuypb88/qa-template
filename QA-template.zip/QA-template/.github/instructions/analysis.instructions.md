---
applyTo: "**/1-analysis.md"
---
# Analysis (any level folder)

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:50 (UTC+7)

The skill is `.github/skills/design-analysis/SKILL.md` (11 required sections); pack sections: `packs/<pack>/analysis.md`.

- Every statement cites a source line `[KEY:line](path#Lnn)`, a requirement ID or a client document; every unknown is a
  `Q-xxx` with the proposed assumption. Never resolve a source conflict silently (R1).
- The TCOND table starts `ID | Condition | Requirement | Type`; **Observable in** names a place at the pack surface;
  internal-only checks go to "Out of black-box scope" (R2).
- Keep live TCOND / Q IDs on a rewrite; never reuse an ID. Don't edit downstream mindmaps or test cases from here.
