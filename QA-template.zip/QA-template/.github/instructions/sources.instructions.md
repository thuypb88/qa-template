---
applyTo: "sources/**"
---
# sources/ is read-only

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:50 (UTC+7)

Client documents (added by the user) and generated copies (`parsed/`, `trace/`). Never edit, create or delete files here.
Re-extract with `python3 scripts/extract_text.py` or the parsers in `scripts/parsers/`; trace a change with the
`plan-changes` skill; raise a problem in a source as a finding or a `Q-xxx`.
