---
applyTo: "**/2-mindmap.md"
---
# Scenario mindmap (any level folder)

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:48 (UTC+7)

The skill is `.github/skills/design-scenarios/SKILL.md`. Layout and leaf prefixes: `packs/<pack>/scenarios.md`.

- Title line exactly `# <module name>: test mindmap`. Level 1 = the analysis inventory items in order; level 2 = the
  pack layout's areas in order; cross-cutting branches last. Never organise by requirement ID.
- Scenario table columns are fixed: `Scenario ID | <Level-1> | Area | Requirement | Refs | Scenario | Type | Priority |
  Technique`. Mermaid leaves quoted `id["[X] text"]`, one per table row.
- Each variant (R10) and each language (R6.3) gets its own scenario. Never renumber `TS-xxx`; append.
- Before finishing: `python3 scripts/check_scenarios.py <target>` (0 Error) and `python3 scripts/workspace/guard.py check`.
