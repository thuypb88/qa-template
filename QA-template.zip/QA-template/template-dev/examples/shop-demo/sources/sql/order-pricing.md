# Order pricing view (demo spec)

PRC-01 `v_order_total` returns one row per order that is not cancelled: `order_id`, `total`.
PRC-02 `total` = sum over the order's lines of `qty * unit_price * (100 - discount_pct) / 100`, rounded to 2 decimals.
PRC-03 A line with no discount (`discount_pct` NULL) is charged in full (no discount).
PRC-04 Orders with status `CANCELLED` are not returned.
