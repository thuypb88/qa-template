# Shop SRS v1.0

## FR-010 Checkout
The checkout page shows Name, Email, Card number. Email is mandatory, max 100 characters.

## FR-011 Payment result
Approved payment shows "Thank you for your order".
