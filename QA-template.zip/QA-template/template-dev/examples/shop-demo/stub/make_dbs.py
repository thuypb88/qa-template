"""Build the self-test's source and target SQLite databases. Target segment of C3 is wrong on purpose (planted defect)."""
import sqlite3
import sys

src, tgt = sqlite3.connect(sys.argv[1]), sqlite3.connect(sys.argv[2])
src.executescript("drop table if exists erp_cust; create table erp_cust(cust_id text, first_nm text, last_nm text, seg_cd text);"
                  "insert into erp_cust values (' C1','An','Nguyen','R'), ('C2','Bo','Tran','C'), ('C3','Chi','Le','X');")
tgt.executescript("drop table if exists dim_customer; create table dim_customer(customer_no text, full_name text, segment text);"
                  "insert into dim_customer values ('C1','An Nguyen','RETAIL'), ('C2','Bo Tran','CORP'), ('C3','Chi Le','RETAIL');")
src.commit()
tgt.commit()
