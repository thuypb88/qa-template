"""Stub of the Orders API for the self-test: python3 orders_stub.py <port>."""
import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n) or b"{}")
        if not self.headers.get("Authorization"):
            return self.reply(401, {"code": "AUTH_REQUIRED"})
        if "currency" not in body:
            return self.reply(400, {"code": "CURRENCY_REQUIRED"})
        return self.reply(201, {"id": "o1", "status": "NEW", "total": body.get("amount")})


HTTPServer(("127.0.0.1", int(sys.argv[1])), Handler).serve_forever()
