"""Build the self-test's SQL database (SQLite). v_order_total ignores PRC-03 on purpose (planted defect): a NULL
discount makes the line total NULL instead of charging it in full."""
import sqlite3
import sys

db = sqlite3.connect(sys.argv[1])
db.executescript("""
drop view if exists v_order_total;
drop table if exists order_line;
drop table if exists orders;
create table orders(order_id text primary key, status text not null);
create table order_line(order_id text not null references orders(order_id), line_no int not null,
                        qty int not null, unit_price numeric not null, discount_pct numeric,
                        primary key (order_id, line_no));
create view v_order_total as
  select o.order_id, round(sum(l.qty * l.unit_price * (100 - l.discount_pct) / 100.0), 2) as total
  from orders o join order_line l on l.order_id = o.order_id
  where o.status <> 'CANCELLED'
  group by o.order_id;
""")
db.commit()
