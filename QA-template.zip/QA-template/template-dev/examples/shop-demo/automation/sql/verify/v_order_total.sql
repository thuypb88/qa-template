-- Verification script for v_order_total (module S1) · dialect sqlite · rows: tc_id, result, detail
SELECT 'TC-S1-001' AS tc_id,
       CASE WHEN (SELECT total FROM v_order_total WHERE order_id = 'S1-O1') = 23.55 THEN 'PASS' ELSE 'FAIL' END AS result,
       'S1-O1 total ' || IFNULL((SELECT total FROM v_order_total WHERE order_id = 'S1-O1'), 'NULL') || ', expected 23.55' AS detail
UNION ALL
SELECT 'TC-S1-002',
       CASE WHEN (SELECT total FROM v_order_total WHERE order_id = 'S1-O2') = 12.00 THEN 'PASS' ELSE 'FAIL' END,
       'S1-O2 total ' || IFNULL((SELECT total FROM v_order_total WHERE order_id = 'S1-O2'), 'NULL') || ', expected 12.00'
UNION ALL
SELECT 'TC-S1-003',
       CASE WHEN (SELECT COUNT(*) FROM v_order_total WHERE order_id = 'S1-O3') = 0 THEN 'PASS' ELSE 'FAIL' END,
       (SELECT COUNT(*) FROM v_order_total WHERE order_id = 'S1-O3') || ' row(s) for S1-O3, expected 0';
