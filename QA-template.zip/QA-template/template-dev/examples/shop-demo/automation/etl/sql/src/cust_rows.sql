select trim(cust_id) as customer_no,
       first_nm || ' ' || last_nm as full_name,
       case seg_cd when 'R' then 'RETAIL' when 'C' then 'CORP' else 'OTHER' end as segment
from erp_cust
