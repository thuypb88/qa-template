select count(*) from dim_customer
