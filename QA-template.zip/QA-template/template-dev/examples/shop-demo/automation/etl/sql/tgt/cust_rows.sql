select customer_no, full_name, segment from dim_customer
