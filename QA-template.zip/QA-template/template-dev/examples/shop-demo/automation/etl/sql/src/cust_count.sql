select count(*) from erp_cust
