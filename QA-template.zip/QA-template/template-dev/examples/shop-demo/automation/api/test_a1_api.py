"""Data-driven runner for API test cases: one pytest test per Auto TC of an API module, driven by its `api` block.

Copy per module (test_<id>_api.py) and set MODULE. TCs whose steps need more than one request (write → read back)
get their own hand-written test named test_TC_<id>_<nnn>_<what>.
"""
import pytest

from api_client import check_expect
from tc_binding import tc_params

MODULE = "A1"


@pytest.mark.parametrize("tc", tc_params(MODULE, pack="api") if MODULE else [])
def test_api_tc(tc, api, token, fixture_body):
    b = tc["api"]
    resp = api.request(b["method"], b["endpoint"], token=token(b.get("auth")), body=fixture_body(b.get("request")))
    check_expect(resp, b["expect"])
