# D1 - Sales mart load: test mindmap

> **Created:** 2026-10-16 09:00 · **Updated:** 2026-10-16 10:48 (UTC+7)

### DIM_CUSTOMER

```mermaid
mindmap
  root((DIM_CUSTOMER))
    Completeness
      c1["[R] Row count equals source"]
    Transformation
      t1["[P] Mapped values per rule"]
```

| Scenario ID | Target table | Area | Requirement | Refs | Scenario | Type | Priority | Technique |
|---|---|---|---|---|---|---|---|---|
| TS-001 | DIM_CUSTOMER | Completeness | MAP-DIM_CUSTOMER | ETL-C01 | Target row count equals the source count after the load | Reconciliation | P1 - Critical | reconciliation |
| TS-002 | DIM_CUSTOMER | Transformation | MAP-DIM_CUSTOMER | MAP-DIM_CUSTOMER-01…03 | Every fixture row gets the mapped customer_no, full_name and segment | Functional | P1 - Critical | equivalence partitioning |
