# S1 - Order pricing: test mindmap

> **Created:** 2026-10-16 11:50 · **Updated:** 2026-10-16 10:48 (UTC+7)

### v_order_total

```mermaid
mindmap
  root((v_order_total))
    Business rules
      r1["[P] Total applies the line discount"]
      r2["[P] No discount when discount is NULL"]
    Result set
      s1["[P] Cancelled orders are not returned"]
```

| Scenario ID | DB object | Area | Requirement | Refs | Scenario | Type | Priority | Technique |
|---|---|---|---|---|---|---|---|---|
| TS-001 | v_order_total | Business rules | PRC-02 | SQL-R01 | The total sums qty × price less the line discount, rounded to 2 decimals | Functional | P1 - Critical | equivalence partitioning |
| TS-002 | v_order_total | Business rules | PRC-03 | SQL-R04 | A line with a NULL discount is charged in full | Functional | P1 - Critical | equivalence partitioning |
| TS-003 | v_order_total | Result set | PRC-04 | SQL-R03 | A cancelled order is not returned | Functional | P2 - High | equivalence partitioning |
