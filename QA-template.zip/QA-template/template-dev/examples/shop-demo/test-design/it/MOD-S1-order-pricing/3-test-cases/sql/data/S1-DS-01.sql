-- S1-DS-01 · dialect sqlite · used by TC-S1-001..003
-- S1-O1: two lines, 10 % discount on line 1 (PRC-02) · S1-O2: one line, NULL discount (PRC-03) · S1-O3: cancelled (PRC-04)
DELETE FROM order_line WHERE order_id LIKE 'S1-%';
DELETE FROM orders WHERE order_id LIKE 'S1-%';
INSERT INTO orders (order_id, status) VALUES ('S1-O1', 'OPEN'), ('S1-O2', 'OPEN'), ('S1-O3', 'CANCELLED');
INSERT INTO order_line (order_id, line_no, qty, unit_price, discount_pct) VALUES
  ('S1-O1', 1, 2, 10.00, 10), ('S1-O1', 2, 1, 5.55, 0), ('S1-O2', 1, 3, 4.00, NULL), ('S1-O3', 1, 1, 99.00, 0);
