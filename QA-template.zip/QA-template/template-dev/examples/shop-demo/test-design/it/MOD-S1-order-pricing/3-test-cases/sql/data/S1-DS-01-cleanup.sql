-- S1-DS-01 cleanup · dialect sqlite · children first, marked rows only
DELETE FROM order_line WHERE order_id LIKE 'S1-%';
DELETE FROM orders WHERE order_id LIKE 'S1-%';
