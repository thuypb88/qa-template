# A1 - Orders API: test mindmap

> **Created:** 2026-10-16 09:00 · **Updated:** 2026-10-16 10:48 (UTC+7)

### POST /v1/orders

```mermaid
mindmap
  root((POST /v1/orders))
    Contract
      c1["[P] Valid order created as NEW"]
    Request validation
      v1["[N] Missing currency rejected"]
      v2["[B] Amount 0.01 accepted"]
    Auth
      a1["[S] No token refused"]
```

| Scenario ID | Resource / Endpoint | Area | Requirement | Refs | Scenario | Type | Priority | Technique |
|---|---|---|---|---|---|---|---|---|
| TS-001 | POST /v1/orders | Contract | API-001 | TCOND-001 | A valid USD order returns 201 with status NEW | Functional | P1 - Critical | use case |
| TS-002 | POST /v1/orders | Request validation | API-001 | TCOND-002 | An order without currency returns 400 | Negative | P2 - High | equivalence partitioning |
| TS-003 | POST /v1/orders | Request validation | API-001 | TCOND-004 | Amount 0.01 is accepted with 201 | Boundary | P2 - High | boundary value |
| TS-004 | POST /v1/orders | Auth | API-002 | TCOND-003 | A request without a token returns 401 | Security | P1 - Critical | authentication |
