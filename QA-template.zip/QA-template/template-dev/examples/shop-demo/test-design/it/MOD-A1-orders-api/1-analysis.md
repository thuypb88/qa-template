# A1 - Orders API: analysis

> **Created:** 2026-10-16 09:00 · **Updated:** 2026-10-16 10:48 (UTC+7)

Demo excerpt: only the sections the self-test needs (§3 inventory, §8 conditions). A real analysis has all 11.

## 3. Inventory: endpoints

| Endpoint (METHOD path) | Resource | Purpose | Auth / roles | Request | Responses | Idempotent | Source |
|---|---|---|---|---|---|---|---|
| POST /v1/orders | Orders | Create an order | buyer | OrderIn | 201, 400, 401 | no | [OAS:11](../../sources/parsed/api/orders-openapi-inventory.md#L11) |

## 8. Testable conditions

| ID | Condition | Requirement | Type | Endpoint | Observable in |
|---|---|---|---|---|---|
| TCOND-001 | A valid order is created with status NEW | API-001 | positive | POST /v1/orders | status 201, body $.status |
| TCOND-002 | An order without currency is rejected | API-001 | negative | POST /v1/orders | status 400 |
| TCOND-003 | A request without a token is refused | API-002 | security | POST /v1/orders | status 401 |
| TCOND-004 | Amount 0.01 is accepted | API-001 | boundary | POST /v1/orders | status 201 |
