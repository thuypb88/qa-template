# Shop demo: a worked example with all four packs

> **Created:** 2026-10-16 09:00 · **Updated:** 2026-10-16 10:53 (UTC+7)

An overlay for a project made from the template: one shop tested at four surfaces.

| Module | Pack | Layout | What is here |
|---|---|---|---|
| W1 — Web checkout | `ui` | form | profile only (no artifacts: the UI pack is shown by the template itself) |
| A1 — Orders API | `api` | resource | analysis, mindmap and test cases excerpts; `automation/api/test_a1_api.py` |
| D1 — Sales mart load | `etl` | table | mindmap, test cases; `automation/etl/test_d1_etl.py` + `etl/sql/{src,tgt}/` queries |
| S1 — Order pricing | `sql` | object | mindmap, test cases, data scripts `S1-DS-01` (+ cleanup); `automation/sql/test_s1_sql.py` + `sql/verify/v_order_total.sql` |

```text
shop-demo/
├── project.json        the profile: four modules, levels TEST (IT, mocks) and STAGING (ST, real systems)
├── sources/            requirements/srs.md · api/orders-openapi.json · etl/customer-sttm.csv · sql/order-pricing.md
├── test-design/it/     MOD-A1-orders-api/ · MOD-D1-sales-mart-load/ · MOD-S1-order-pricing/
├── automation/         api/ · etl/ · sql/ — data-driven tests bound to the TC IDs
└── stub/               orders_stub.py (the Orders API) · make_dbs.py (ETL source + target) · make_sql_db.py (SQL)
```

[template-dev/tests/selftest.py](../../tests/selftest.py) copies the template into a temporary folder, lays this
overlay on top (this README stays out) and runs the whole tool chain on it. Three runs are real, and each has one
defect planted **on purpose**, so a green run proves the tests can fail:

| Run | Against | Must pass | Must fail (planted) |
|---|---|---|---|
| A1 API | `stub/orders_stub.py` on a free port | 4 / 4 | — (cycle C1 is recorded instead) |
| D1 ETL | two SQLite files from `stub/make_dbs.py` | TC-D1-001 row count | TC-D1-002: customer C3 segment `OTHER` loaded as `RETAIL` |
| S1 SQL | SQLite from `stub/make_sql_db.py` | TC-S1-001, TC-S1-003 | TC-S1-002: a NULL discount gives a NULL total (expected 12.00); test data is cleaned up afterwards |

The artifacts are excerpts, not models of completeness: a real analysis has all 11 sections.
