# Skill behaviour evals

> **Created:** 2026-10-16 09:48 · **Updated:** 2026-10-16 10:48 (UTC+7)

One file per skill: `<skill>.json` = `{"skill": "<name>", "cases": [{"name", "prompt", "assertions": [...]}]}`.
At least three cases per skill — the success path, incomplete input, and a near miss that must go to a neighbour —
each with two or more assertions about the answer's content. `template-dev/tests/selftest.py` checks the shape (the file names an
existing skill, ≥ 3 cases, ≥ 2 assertions where the case is not a routing check). To run: give each prompt to an agent
with the skill available and judge every assertion PASS / FAIL; compare before and after a skill change. The
`check-skill` skill adds or updates these files.
