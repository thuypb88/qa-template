#!/usr/bin/env python3
"""Template self-test: build a project from the template + template-dev/examples/shop-demo/ and run the whole tool chain on it.

    python3 template-dev/tests/selftest.py                          # temp dir, removed afterwards
    python3 template-dev/tests/selftest.py --keep /tmp/shop         # keep the built project for a look
    python3 template-dev/tests/selftest.py --python .venv/bin/python   # interpreter with pytest for the run steps

Run it before every template release (and commit the result line in CHANGELOG.md). Steps: create the project
(template_sync --new), validate project.json, extract + parse the sources, init_project, the checkers on clean and
broken artifacts, the Excel export, the guard hooks, a commit through the hooks (and one that must fail), change
tracing, pipeline_status, and — when pytest is available — a real API run against a stub, a real ETL
reconciliation and a real SQL verification run on SQLite, each with one planted defect. Exit 1 when any step fails. Standard library only.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

TPL = Path(__file__).resolve().parents[2]
DEMO = TPL / "template-dev/examples/shop-demo"
RESULTS: list[tuple[bool, str, str]] = []
GROUPS = {"flow", "plan", "req", "design", "check", "auto", "run", "learn", "sql"}  # skill-architecture.md §3, §3a
OLD_NAMES_OK = {"CHANGELOG.md", "template-manifest.json", "standards/skill-architecture.md"}


def step(name: str, ok: bool, detail: str = "") -> bool:
    RESULTS.append((ok, name, detail))
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  — {detail}" if detail and not ok else ""))
    return ok


def run(args, cwd, py=sys.executable, stdin=None, env=None):
    cmd = [py, *args] if args[0].endswith(".py") else args
    r = subprocess.run(cmd, cwd=cwd, input=stdin, capture_output=True, text=True, env={**os.environ, **(env or {})})
    return r.returncode, r.stdout + r.stderr


def hook(proj: Path, tool: str, path: str, **inp) -> int:
    payload = json.dumps({"tool_name": tool, "tool_input": {"file_path": str(proj / path), **inp}})
    return run(["scripts/workspace/guard.py", "hook", "pre"], proj, stdin=payload)[0]


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def skill_problems(root: Path) -> list[str]:
    """Every SKILL.md: name = folder = <group>-<objective>, description 1..1024 chars, metadata.group + order, a
    Done-when list; every relative link in the skills and standards/methods resolves and none reaches into another
    skill's references/; no skill name retired in v1.5.0 is still used (template-manifest.json › renamed_skills)."""
    import re
    probs: list[str] = []
    skills = root / ".claude/skills"
    for f in sorted(skills.glob("*/SKILL.md")):
        m = re.match(r"---\n(.*?)\n---\n", f.read_text(encoding="utf-8"), re.S)
        fm = dict(re.findall(r"^(\w+): (.*)$", m.group(1), re.M)) if m else {}
        if fm.get("name") != f.parent.name:
            probs.append(f"{f.parent.name}: name {fm.get('name')!r}")
        if not 0 < len(fm.get("description", "")) <= 1024:
            probs.append(f"{f.parent.name}: description length {len(fm.get('description', ''))}")
        meta = re.search(r"^metadata:\n  group: (\S+)\n  order: \"([^\"]+)\"$", m.group(1), re.M) if m else None
        if not meta or meta.group(1) not in GROUPS or not f.parent.name.startswith(meta.group(1) + "-"):
            probs.append(f"{f.parent.name}: metadata.group {meta.group(1) if meta else 'missing'!s} (must be the name prefix)")
        if "\n## Done when\n" not in f.read_text(encoding="utf-8"):
            probs.append(f"{f.parent.name}: no '## Done when' section")
    for f in sorted([*skills.rglob("*.md"), *(root / "standards/methods").glob("*.md")]):
        text = re.sub(r"`[^`\n]*`", "", re.sub(r"```.*?```", "", f.read_text(encoding="utf-8"), flags=re.S))
        for target in re.findall(r"\]\(([^)\s]+)\)", text):
            path = target.split("#")[0]
            if path and not re.match(r"[a-z]+:", path) and "<" not in path and not (f.parent / path).exists():
                probs.append(f"{f.relative_to(root)}: broken link {target}")
            dest = (f.parent / path).resolve()
            if path and "<" not in path and skills in dest.parents and "references" in dest.parts and skills / f.relative_to(skills).parts[0] not in dest.parents:
                probs.append(f"{f.relative_to(root)}: links into another skill's references ({target}); use standards/methods/")
    old = json.loads((root / "template-manifest.json").read_text(encoding="utf-8"))["renamed_skills"]["renamed"]
    pat = re.compile(r"`/?(" + "|".join(map(re.escape, old)) + r")[`\s]|(?<![\w./-])(" + "|".join(
        re.escape(k) for k in old if "-" in k) + r")(?![\w/-]|\.\w)")
    for f in sorted(root.rglob("*")):
        rel = f.relative_to(root).as_posix()
        if (f.suffix in {".md", ".py", ".json"} and f.is_file() and rel not in OLD_NAMES_OK
                and not {".git", ".agents", "node_modules", ".venv", "venv"} & set(f.relative_to(root).parts)
                and not rel.startswith(".github/skills/")):
            hit = pat.search(f.read_text(encoding="utf-8", errors="replace"))
            if hit:
                probs.append(f"{rel}: retired skill name {hit.group(0).strip()!r}")
    for f in sorted((root / "template-dev/tests/skill-evals").glob("*.json")):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except ValueError as e:
            probs.append(f"{f.name}: invalid JSON ({e})")
            continue
        cases = d.get("cases", [])
        if d.get("skill") != f.stem or not (skills / f.stem / "SKILL.md").is_file():
            probs.append(f"{f.name}: skill {d.get('skill')!r} is not an existing skill named like the file")
        if len(cases) < 3:
            probs.append(f"{f.name}: {len(cases)} case(s), need >= 3")
        for c in cases:
            need = 1 if str(c.get("name", "")).startswith("near-miss") else 2
            if not c.get("prompt") or len(c.get("assertions", [])) < need:
                probs.append(f"{f.name}: case {c.get('name')!r} needs a prompt and >= {need} assertion(s)")
    return probs


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--keep", type=Path)
    ap.add_argument("--python", default=sys.executable, help="interpreter with pytest for the run steps")
    a = ap.parse_args()
    if os.sep in a.python:  # a relative path would be read from inside the built project
        a.python = str(Path(a.python).absolute())
    base = a.keep.resolve() if a.keep else Path(tempfile.mkdtemp(prefix="qa-selftest-"))
    if a.keep and base.exists():
        shutil.rmtree(base)
    proj = base / "shop"
    probs = skill_problems(TPL)
    step("skills: names, groups, links, retired names, evals", not probs, "; ".join(probs[:5]))
    try:
        # 1. create + overlay
        rc, out = run([str(TPL / "scripts/workspace/template_sync.py"), "--new", str(proj)], TPL)
        step("template_sync --new", rc == 0 and (proj / "CLAUDE.md").is_file(), out)
        shutil.copytree(DEMO, proj, dirs_exist_ok=True,  # the demo's own README stays out (the seeded one is kept)
                        ignore=lambda d, names: ["README.md"] if Path(d) == DEMO else [])
        subprocess.run(["git", "config", "user.email", "selftest@example.com"], cwd=proj)
        subprocess.run(["git", "config", "user.name", "selftest"], cwd=proj)
        rc, out = run(["scripts/qa_config.py", "--validate"], proj)
        step("project.json valid", rc == 0, out)
        # 2. sources
        rc, out = run(["scripts/extract_text.py"], proj)
        step("extract_text", rc == 0 and (proj / "sources/parsed/requirements/srs.md.md").is_file(), out)
        rc, out = run(["scripts/parsers/openapi_inventory.py", "sources/api/orders-openapi.json"], proj)
        inv = proj / "sources/parsed/api/orders-openapi-inventory.md"
        step("openapi_inventory", rc == 0 and "POST /v1/orders" in inv.read_text() and "$.amount" in inv.read_text(), out)
        rc, out = run(["scripts/parsers/sttm_inventory.py", "sources/etl/customer-sttm.csv"], proj)
        sttm = proj / "sources/parsed/etl/customer-sttm-inventory.md"
        step("sttm_inventory", rc == 0 and "MAP-DIM_CUSTOMER-03" in sttm.read_text(), out)
        # 3. folders
        rc, out = run(["scripts/init_project.py"], proj)
        scope = proj / "test-design/it/MOD-A1-orders-api/0-scope.md"
        step("init_project", rc == 0 and scope.is_file() and (proj / "AGENTS.md").is_file()
             and (proj / "sources/trace/source-baseline.json").is_file(), out)
        cop = proj / ".github/copilot-instructions.md"
        step("Copilot mirror", cop.is_file() and (proj / ".github/skills/design-analysis/SKILL.md").is_file()
             and (proj / ".github/instructions/test-cases.instructions.md").is_file()
             and "](../standards/core-rules.md)" in cop.read_text()
             and run(["scripts/workspace/sync_agents.py", "--check"], proj)[0] == 0
             and hook(proj, "Write", ".github/skills/design-analysis/SKILL.md", content="x") == 2, str(cop))
        rc2, out2 = run(["scripts/init_project.py", "--check"], proj)
        step("init_project idempotent", rc2 == 0 and "0 file(s) to write" in out2, out2)
        rc, out = run(["scripts/workspace/setup_workspace.py", "--check"], proj)
        step("setup_workspace --check: reports, writes nothing", rc == 0 and "0 error(s)" in out
             and "init_project.py — 4 module(s)" in out and not (proj / ".venv").exists()
             and not (proj / ".claude/settings.local.json").exists(), out)
        # 4. checkers, clean
        for key in ("A1", "D1", "S1"):
            rc, out = run(["scripts/check_scenarios.py", key], proj)
            step(f"check_scenarios {key} clean", rc == 0 and " 0 Error" in out, out)
            rc, out = run(["scripts/export_testcases.py", key], proj)
            step(f"export_testcases {key}", rc == 0 and "_Test_Cases_v0.1.xlsx" in out, out)
        # 5. checkers, broken
        w = proj / "test-design/it/MOD-W1-checkout"
        (w / "2-mindmap.md").write_text(
            "# W1 - Web checkout: test mindmap\n\n| Scenario ID | Form / Screen | Area | Requirement | Refs | Scenario | Type | "
            "Priority | Technique |\n|---|---|---|---|---|---|---|---|---|\n| TS-001 | Checkout | Teleport | FR-010 | | x | UI | "
            "P9 | — |\n", encoding="utf-8")
        (w / "3-test-cases").mkdir(exist_ok=True)
        (w / "3-test-cases/test-cases.json").write_text(json.dumps({"module": "W1 - Web checkout", "version": "0.1",
            "test_cases": [{"tc_id": "TC-W1-001", "scenario_id": "TS-009", "test_type": "UI", "priority": "P2 - High",
                            "title": "no prefix", "steps": ["1. Open", "Pay"], "expected_result": ["database row as expected"],
                            "status": "Done"}]}), encoding="utf-8")
        rc, out = run(["scripts/check_scenarios.py", "W1"], proj)
        step("check_scenarios catches errors", rc == 1 and "Area 'Teleport'" in out and "Type 'UI'" in out, out)
        rc, out = run(["scripts/export_testcases.py", "W1"], proj)
        step("export_testcases refuses errors", rc == 1 and "NOT written" in out and "steps numbered" in out
             and "R-UI1" in out, out)
        shutil.rmtree(w / "3-test-cases")
        (w / "2-mindmap.md").unlink()
        # 6. guard hooks
        step("guard blocks sources/", hook(proj, "Write", "sources/x.md", content="x") == 2)
        step("guard blocks .xlsx", hook(proj, "Write", "test-design/it/MOD-A1-orders-api/3-test-cases/a.xlsx", content="") == 2)
        step("guard blocks template-owned", hook(proj, "Edit", "standards/core-rules.md", old_string="a", new_string="b") == 2)
        step("guard blocks 0-scope outside MANUAL", hook(proj, "Edit", "test-design/it/MOD-A1-orders-api/0-scope.md",
                                                          old_string="| Security techniques | full |",
                                                          new_string="| Security techniques | none |") == 2)
        step("guard allows MANUAL block", hook(proj, "Edit", "test-design/it/MOD-A1-orders-api/0-scope.md",
                                               old_string="## Questions to raise first\n",
                                               new_string="## Questions to raise first\n\n- Q-001\n") == 0)
        step("guard allows project/", hook(proj, "Edit", "project/log.md", old_string="a", new_string="b") == 0)
        # 7. commits through the hooks
        subprocess.run(["git", "add", "-A"], cwd=proj)
        r = subprocess.run(["git", "commit", "-q", "-m", "selftest: set-up"], cwd=proj, capture_output=True, text=True)
        step("commit passes the guard", r.returncode == 0, r.stdout + r.stderr)
        backups = base / "SHOP-backups"
        step("post-commit backup", (backups / "SHOP.git").is_dir() and any((backups / "bundles").glob("*.bundle")),
             str(list(base.iterdir())))
        tags = subprocess.run(["git", "tag"], cwd=proj, capture_output=True, text=True).stdout
        step("suite version tags", "tc/MOD-A1-orders-api/v0.1" in tags, tags)
        tcj = proj / "test-design/it/MOD-D1-sales-mart-load/3-test-cases/test-cases.json"
        d = json.loads(tcj.read_text())
        d["test_cases"][0]["priority"] = "P2 - High"
        tcj.write_text(json.dumps(d, indent=2), encoding="utf-8")
        subprocess.run(["git", "add", "-A"], cwd=proj)
        r = subprocess.run(["git", "commit", "-q", "-m", "must fail"], cwd=proj, capture_output=True, text=True)
        step("commit refused without version bump", r.returncode != 0 and "version" in (r.stdout + r.stderr),
             r.stdout + r.stderr)
        subprocess.run(["git", "reset", "-q", "--hard", "HEAD"], cwd=proj)
        # 8. change control + status
        srs = proj / "sources/requirements/srs.md"
        srs.write_text(srs.read_text().replace("max 100", "max 120"), encoding="utf-8")
        rc, out = run(["scripts/trace_changes.py", "--json"], proj)
        ch = json.loads(out).get("changes", []) if rc == 0 else []
        step("trace_changes finds the edit + reader", len(ch) == 1 and ch[0]["change"] == "changed"
             and any(x.startswith("W1") for x in ch[0]["read_by"]), out)
        rc, out = run(["scripts/pipeline_status.py", "--json"], proj)
        st = json.loads(out) if rc == 0 else {}
        nxt = {f["key"]: f["next"] for f in st.get("folders", [])}
        step("pipeline_status next steps", st.get("source_changes") == 1 and nxt.get("A1") == "check-design"
             and nxt.get("W1") == "design-analysis", out[-400:])
        subprocess.run(["git", "checkout", "-q", "--", "sources"], cwd=proj)
        # 9. real runs (need pytest)
        has_pytest = subprocess.run([a.python, "-c", "import pytest"], capture_output=True).returncode == 0
        if not has_pytest:
            rc, out = run(["scripts/run_tests.py", "D1"], proj)
            step("run_tests reports a missing runner as set-up error", rc == 2 and "not installed" in out, out)
            print("SKIP  API / ETL runs (no pytest; pass --python <interpreter with pytest>)")
        else:
            dbs = base / "db"
            dbs.mkdir()
            subprocess.run([a.python, str(proj / "stub/make_dbs.py"), str(dbs / "src.db"), str(dbs / "tgt.db")], check=True)
            env = {"ETL_SOURCE_DSN": f"sqlite:///{dbs / 'src.db'}", "ETL_TARGET_DSN": f"sqlite:///{dbs / 'tgt.db'}"}
            rc, out = run(["scripts/run_tests.py", "D1"], proj, py=a.python, env=env)
            res = (proj / "runs/d1/results.csv").read_text() if (proj / "runs/d1/results.csv").is_file() else ""
            step("ETL run: count passes, planted defect fails", rc == 1 and "TC-D1-001,[DIM_CUSTOMER] Row count equals the "
                 "source,Auto,Passed" in res and "TC-D1-002" in res and "segment 'OTHER'→'RETAIL'" in res, out[-600:])
            subprocess.run([a.python, str(proj / "stub/make_sql_db.py"), str(dbs / "shop.db")], check=True)
            rc, out = run(["scripts/run_tests.py", "S1"], proj, py=a.python, env={"SQL_DSN": f"sqlite:///{dbs / 'shop.db'}"})
            res = (proj / "runs/s1/results.csv").read_text() if (proj / "runs/s1/results.csv").is_file() else ""
            import sqlite3
            with sqlite3.connect(dbs / "shop.db") as c:
                left = str(c.execute("select count(*) from orders").fetchone()[0])
            step("SQL run: verification script, planted defect fails, data cleaned up", rc == 1
                 and "TC-S1-001,[v_order_total] Total applies the line discount,Auto,Passed" in res
                 and "TC-S1-003,[v_order_total] Cancelled orders are not returned,Auto,Passed" in res
                 and "S1-O2 total NULL, expected 12.00" in res and left == "0", out[-600:] + res)
            port = free_port()
            stub = subprocess.Popen([a.python, "-I", str(proj / "stub/orders_stub.py"), str(port)])
            time.sleep(0.8)
            try:
                env = {"API_BASE_URL": f"http://127.0.0.1:{port}", "API_TOKEN_BUYER": "selftest-token"}
                rc, out = run(["scripts/run_tests.py", "A1", "--record", "C1"], proj, py=a.python, env=env)
            finally:
                stub.terminate()
            d = json.loads((proj / "test-design/it/MOD-A1-orders-api/3-test-cases/test-cases.json").read_text())
            step("API run: 4/4 passed, cycle C1 recorded", rc == 0 and d["version"] == "0.2"
                 and all(t.get("result") == "Passed" and t.get("cycle") == "C1" for t in d["test_cases"])
                 and (proj / "test-design/it/MOD-A1-orders-api/3-test-cases/history/MOD-A1-orders-api_Test_Cases_v0.1.xlsx").is_file(),
                 out[-600:])
        # 9b. manual results back into the JSON (record_manual.py)
        a1 = proj / "test-design/it/MOD-A1-orders-api/3-test-cases/test-cases.json"
        v0 = json.loads(a1.read_text())["version"]
        bad = base / "manual-bad.csv"
        bad.write_text("tc_id,result\nTC-A1-999,Passed\nTC-A1-001,Maybe\n")
        rc_bad, out_bad = run(["scripts/record_manual.py", "A1", str(bad), "--cycle", "C2"], proj)
        good = base / "manual.csv"
        good.write_text("tc_id,title,automation,priority,result,tester,notes,defect_id\n"
                        "TC-A1-001,x,Manual,P1,blocked,tester1,,DEF-001\nTC-A1-002,x,Manual,P2,,,,\n")
        rc, out = run(["scripts/record_manual.py", "A1", str(good), "--cycle", "C2"], proj)
        d = json.loads(a1.read_text())
        t1 = next(t for t in d["test_cases"] if t["tc_id"] == "TC-A1-001")
        step("record_manual: refuses bad rows, records results", rc_bad == 2 and "TC-A1-999" in out_bad
             and "Maybe" in out_bad and rc == 0 and t1.get("result") == "Blocked" and t1.get("cycle") == "C2"
             and t1.get("defect_id") == "DEF-001" and d["version"] != v0, out_bad[-300:] + out[-300:])
        # 10. template_sync on the project: nothing to update
        rc, out = run([str(proj / "scripts/workspace/template_sync.py"), "--from", str(TPL)], proj)
        step("template_sync dry run: up to date", rc == 0 and "up to date" in out, out)
        # 11. a project on the old layout (brain/, knowledge/, modules/, system-test/, flat scripts/) is moved to
        #     project/, standards/, test-design/it|st/ and scripts/workspace/; project.json and the hooks path follow
        pj = json.loads((proj / "project.json").read_text())
        pj["levels"]["IT"]["folder"], pj["levels"]["ST"]["folder"] = "modules", "system-test"
        (proj / "project.json").write_text(json.dumps(pj, indent=2) + "\n")
        shutil.move(proj / "test-design/it", proj / "modules")
        if (proj / "test-design/st").exists():
            shutil.move(proj / "test-design/st", proj / "system-test")
        (proj / "test-design").rmdir()
        shutil.move(proj / "project/rules.md", proj / "rules.tmp")
        shutil.move(proj / "project", proj / "brain")
        shutil.move(proj / "standards/template-lessons.md", proj / "lessons.tmp")
        shutil.move(proj / "standards", proj / "knowledge")
        shutil.move(proj / "rules.tmp", proj / "knowledge/project-rules.md")
        shutil.move(proj / "lessons.tmp", proj / "knowledge/lessons.md")
        #     … and flat scripts/ (guard, backup, sync_agents, template_sync, git-hooks) with the old hooks path
        for n in ("guard.py", "backup.py", "sync_agents.py", "template_sync.py", "git-hooks"):
            shutil.move(proj / "scripts/workspace" / n, proj / "scripts" / n)
        (proj / "scripts/workspace/setup_workspace.py").unlink()  # 1.11.0, not in the old layout
        (proj / "scripts/workspace").rmdir()
        subprocess.run(["git", "config", "core.hooksPath", "scripts/git-hooks"], cwd=proj)
        rc, out = run([str(TPL / "scripts/workspace/template_sync.py"), "--from", str(TPL), "--apply"], proj)
        rc2, out2 = run([str(proj / "scripts/workspace/template_sync.py"), "--from", str(TPL)], proj)
        lv = json.loads((proj / "project.json").read_text())["levels"]
        step("template_sync moves the old layout", rc == 0 and "move    brain → project" in out
             and (proj / "test-design/it/MOD-A1-orders-api/3-test-cases/test-cases.json").is_file()
             and not (proj / "modules").exists() and not (proj / "system-test").exists()
             and lv["IT"]["folder"] == "test-design/it" and lv["ST"]["folder"] == "test-design/st"
             and (proj / "project/rules.md").is_file() and (proj / "project/log.md").is_file()
             and (proj / "standards/template-lessons.md").is_file() and (proj / "standards/methods").is_dir()
             and not (proj / "brain").exists() and not (proj / "knowledge").exists()
             and (proj / "scripts/workspace/guard.py").is_file() and not (proj / "scripts/guard.py").exists()
             and (proj / "scripts/workspace/git-hooks/pre-commit").is_file()
             and subprocess.run(["git", "config", "core.hooksPath"], cwd=proj, capture_output=True,
                                text=True).stdout.strip() == "scripts/workspace/git-hooks"
             and "up to date" in out2, out + out2)
    finally:
        if not a.keep:
            shutil.rmtree(base, ignore_errors=True)
    failed = [n for ok, n, _ in RESULTS if not ok]
    print(f"\nselftest: {len(RESULTS) - len(failed)}/{len(RESULTS)} passed" + (f" · FAILED: {', '.join(failed)}" if failed else ""))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
