# plans/

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:50 (UTC+7)

Forward-looking QA documents the team writes (project-owned, in git). Client test plans stay in `sources/testing/`.
Proposals (stories, use cases, discovery findings) are never a test basis on their own: once the BA / client confirms
one, the user adds the confirmed version to `sources/`, then `plan-changes` → `design-analysis`.

| Path | Holds | Written by |
|---|---|---|
| `test-strategy.md` | Our test strategy, or `test-strategy-review.md` for a review of the client's plan | `plan-strategy` |
| `discovery/<date>-<slug>.md` | Ask-why findings for a vague request / CR: layers, assumptions, open questions | `req-elicit` |
| `requirement-reviews/<date>-<slug>.md` | Shift-left review of a requirement document: RQ-NNN questions for the BA / client | `req-review` |
| `stories/<date>-<slug>.md` | Proposed user stories and Given-When-Then criteria (status Proposed until the PO confirms) | `req-write` |
| `use-cases/<UC-ID>_<slug>.md`, `use-cases/README.md` | Proposed use case specifications, the list, reviews | `req-write` |
| `regression/<date>-<slug>.md` | The regression set for a build / fix / release, with reasons and commands | `run-select` |
| `sprints/<sprint>.md` | Sprint test record: scope, gate board, DoD, carry-over | `flow-cadence` |
| `releases/<release>.md` | Release record: scope, gates, evidence pack, go / no-go, post-release log | `flow-cadence` |
