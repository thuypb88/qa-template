# sources/

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:48 (UTC+7)

Inputs to the test design. Agents never write here; `scripts/workspace/guard.py` blocks it.

| Folder | Holds | Who writes |
|---|---|---|
| `client/` | The client's originals, as received (BRD, paper forms, decks, data classification) | the user |
| `requirements/` | SRS / functional spec / user stories / UI spec | the user |
| `api/` | OpenAPI / Swagger / Postman collections, interface specs (API pack) | the user |
| `etl/` | Source-to-target mappings, DDL, job designs, data dictionaries (ETL pack) | the user |
| `sql/` | Stored procedures, functions, views, DDL, job scripts, database specs (SQL pack) | the user |
| `testing/` | Test plan, test case template, test strategy | the user |
| `parsed/` | Markdown copies with line numbers, for citations | `scripts/extract_text.py`, `scripts/parsers/*` |
| `trace/` | Accepted source baseline and the change report | `scripts/trace_changes.py` |

After adding or replacing a file: `python3 scripts/extract_text.py`, then run the `plan-changes` skill.
