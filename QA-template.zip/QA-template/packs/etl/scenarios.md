# ETL pack: scenario design

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 08:34 (UTC+7)

| Layout | Level 1 | Level 2 (Area), in this order |
|---|---|---|
| `table` | one branch per target table (load order: dimensions before facts) | Completeness → Transformation → Data quality → Keys & integrity → History → Rejects |
| `job` | one branch per job / pipeline step | Full load → Incremental load → Re-run & recovery → Scheduling & dependencies → Error handling |

Cross-cutting last: Performance, Security, Audit, E2E.

**Leaf prefixes → type:** `[P]` Functional · `[R]` Reconciliation · `[DQ]` Data Quality · `[N]` Negative ·
`[B]` Boundary · `[PF]` Performance · `[S]` Security · `[E2E]` E2E.

## Easy-to-miss coverage

1. **Both directions** of every key diff (source-not-in-target *and* target-not-in-source).
2. **Every rule on every partition**: one fixture row per partition, including null, empty string, max length,
   unicode, negative and zero amounts, dates at month / year end and DST changes.
3. **Second run**: every job run twice, and run after a failure.
4. **History**: one change, two changes in one batch, a change back to an old value, a delete.
5. **Late and early data**: facts before dimensions, records with future dates.
6. **Reject path keeps the good rows**: a batch with one bad row still loads the rest.
7. **Counts tie out**: run audit counts = reconciliation counts.
