# ETL pack: data checklist

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

Applied by `design-cases` (checklist pass) to every row of the analysis's **Mapping inventory** (target tables)
and **Job inventory**. Write a TC only for a check that applies and no TC covers; cite the ID in `notes`. Oracle
**S** = the mapping / DDL / job design states it (else Blocked + `Q-xxx`); **H** = heuristic, written as
`Q-ETL-xxx: assumed …`, P3 or lower.

## C: Completeness (Area: Completeness)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| ETL-C01 | Row count | every target table | Source count (after the documented filters) = target count + rejected count | S | IT | Reconciliation / Auto |
| ETL-C02 | Key coverage | every target table | Every source business key is in the target or the reject table (row diff on keys, both directions) | S | IT | Reconciliation / Auto |
| ETL-C03 | Measure totals | numeric measures | Sum / min / max per measure equal on both sides, within the stated tolerance | S | IT | Reconciliation / Auto |
| ETL-C04 | Filters | filtered loads | Rows the mapping excludes are not loaded, and only those | S | IT | Functional / Auto |

## T: Transformation (Area: Transformation)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| ETL-T01 | Rule per column | every mapped column | Each transformation rule on a fixture row per partition gives the exact expected value | S | IT | Functional / Auto |
| ETL-T02 | Lookups | lookup / code mappings | Every code maps to its target value; an unknown code goes to the documented default or reject | S | IT | Functional / Auto |
| ETL-T03 | Types and precision | typed columns | Dates, timezones, decimals, rounding, string length and truncation as the DDL / mapping say | S | IT | Boundary / Auto |
| ETL-T04 | Defaults and nulls | nullable / defaulted columns | Null and empty source values give the documented target value | S | IT | Functional / Auto |
| ETL-T05 | Character data | text columns | Unicode, diacritics, CJK, leading / trailing spaces and line breaks survive or are cleaned as documented | H | IT | Localization / Auto |

## Q: Data quality, keys and integrity (Areas: Data quality, Keys & integrity)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| ETL-Q01 | Uniqueness | keys | No duplicate primary / business key in the target | S | IT | Data Quality / Auto |
| ETL-Q02 | Not null | mandatory columns | No null in a NOT NULL / mandatory column | S | IT | Data Quality / Auto |
| ETL-Q03 | Referential integrity | foreign keys | Every foreign key resolves; orphans go to the documented unknown member or reject | S | IT | Data Quality / Auto |
| ETL-Q04 | Domain values | enumerated columns | Only allowed values / ranges are present | S | IT | Data Quality / Auto |
| ETL-Q05 | Surrogate keys | dimensions | Surrogate keys are unique, stable across reloads, and the unknown member exists | S | IT | Data Quality / Auto |

## H: History and loads (Areas: History, Incremental load, Full load)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| ETL-H01 | SCD behaviour | history tables | Type 1 overwrites; type 2 closes the old row (end date, current flag) and opens a new one, once per change | S | IT | Functional / Auto |
| ETL-H02 | Incremental window | incremental / CDC loads | Only rows changed since the watermark are loaded; the watermark moves | S | IT | Functional / Auto |
| ETL-H03 | Late-arriving data | facts with dimensions | A fact before its dimension row is handled as documented (inferred member / hold / reject) | S | IT | Functional / Auto |
| ETL-H04 | Deletes | sources with deletes | Hard / soft deletes in the source give the documented target result | S | IT | Functional / Auto |
| ETL-H05 | Full reload | full loads | A full reload gives the same target as the incremental history (row diff empty) | H | IT | Reconciliation / Auto |

## R: Rejects, re-run and recovery (Areas: Rejects, Re-run & recovery, Error handling)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| ETL-R01 | Reject rows | rejecting rules | A bad row goes to the reject table with the documented reason code; the good rows still load | S | IT | Negative / Auto |
| ETL-R02 | Re-run idempotent | every job | Running the job twice on the same input gives the same target (no duplicates) | S | IT | Functional / Auto |
| ETL-R03 | Failure mid-run | every job | A failure mid-run (killed job, bad file) leaves the target as before, or resumes as documented | S | IT | Negative / Auto |
| ETL-R04 | Bad input file | file feeds | Missing, empty, wrong header, wrong delimiter / encoding, truncated file → documented error, no partial load | S | IT | Negative / Auto |
| ETL-R05 | Run audit | every job | The run log / audit table shows read / written / rejected counts equal to the reconciliation | S | IT | Functional / Auto |

## X: Moved to ST (R9)

| ID | Name | Check |
|---|---|---|
| ETL-X01 | Volume and window | Production-like volume finishes inside the batch window |
| ETL-X02 | Schedule and dependencies | The real scheduler runs jobs in order; a failed upstream holds the downstream |
| ETL-X03 | End-to-end lineage | A known source row reaches the consuming report / API with the expected value |
| ETL-X04 | Masking | PII in non-production targets is masked per the data classification |
