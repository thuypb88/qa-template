# ETL pack: test case block

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 08:34 (UTC+7)

Every ETL test case adds an `etl` object to the common fields. `check_testcases.py` checks the required keys and
the enum values; the export shows them as the Mapping Rule / Load / Reconcile / Source Query / Target Query /
Tolerance columns.

```json
"etl": {
  "rule_id": "MAP-DIM_CUSTOMER-07",
  "job": "LOAD_DIM_CUSTOMER",
  "load": "incremental",
  "fixture": "ETL-FX-DIM_CUSTOMER-03",
  "reconcile": "row_diff",
  "source_sql": "automation/etl/sql/src/dim_customer_07.sql",
  "target_sql": "automation/etl/sql/tgt/dim_customer_07.sql",
  "keys": ["customer_no"],
  "tolerance": 0,
  "expect": {"diff_rows": 0}
}
```

| Key | Required | Meaning |
|---|---|---|
| `rule_id` | yes | Mapping rule (`MAP-…`), DQ rule (`DQ-…`) or job ID under test |
| `reconcile` | yes | `count`, `sum`, `row_diff`, `rule`, `null_check`, `duplicate_check`, `ri_check`, `schema`, `history`, `custom` |
| `load` | no | `full`, `incremental`, `cdc`, `rerun`, `backfill` |
| `job` / `fixture` | no | Job to run; fixture set to load first |
| `source_sql` / `target_sql` | for count / sum / row_diff | Query files; both sides return the same columns |
| `keys` / `tolerance` | no | Diff keys; absolute tolerance for numeric measures (default 0) |
| `expect` | no | Exact expected numbers (`count`, `sum`, `diff_rows`, `rows`) |

`automation/etl/reconcile.py` runs these blocks (count, sum, row_diff, null / duplicate / RI checks) over any
DB-API connection.
