# ETL pack: analysis sections

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

`design-analysis` writes the common sections and fills these with ETL content. Start from the parsed mapping:
`python3 scripts/parsers/sttm_inventory.py <mapping.xlsx>` writes `sources/parsed/etl/<name>-inventory.md` with
one `MAP-<TABLE>-<nn>` rule per mapped column.

## §3 Inventory: target tables and jobs

- **Mapping inventory:** `Target table | Grain | Source tables | Keys (business / surrogate) | Load type (full /
  incremental / CDC) | History (none / SCD1 / SCD2) | Rules (MAP-…) | Source`.
- **Job inventory:** `Job / step | Reads | Writes | Schedule / trigger | Depends on | Restart behaviour | Source`.

These become mindmap level 1 (`layout: table` or `job`) and the TC title prefixes.

## §5 Data & field rules

Per target table: `Target column | Type (DDL) | Null | Source column(s) | Rule ID | Transformation (exact) |
Default / unknown | Reject when | Source`. Plus:
- **Data quality rules**: `DQ ID | Table.column | Rule | Action on breach (reject / flag / default)`.
- **Code / lookup tables** with every value.

## §6 Feeds and dependencies

`Upstream feed / system | Format (table, CSV, JSON, API) | Arrival / schedule | IT stand-in (fixture file / seeded
schema) | ST: real feed | Late / missing behaviour`.

## §8 Testable conditions: "Observable in"

`Observable in` = the query or table that shows the result (`target DIM_CUSTOMER`, `reject table`, `run audit`).
Internal-only conditions (e.g. an engine's temp tables) → **Out of black-box scope**.

## §11 Fixtures

Fixture sets per rule (`ETL-FX-<table>-<nn>`: the rows and why each exists), seed scripts, the reset procedure,
the SQL files for both sides, and the tolerance per measure.
