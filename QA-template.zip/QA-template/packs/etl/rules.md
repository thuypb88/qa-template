# ETL pack: rules (R-ETL)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:29 (UTC+7)

Applies to every module with `"pack": "etl"` in `project.json` (data pipelines, warehouse loads, migrations,
interfaces that move files or tables). Adds to the core rules ([standards/core-rules.md](../../standards/core-rules.md)).

## R-ETL1. Surface and oracle

1. A step is a data action a tester can repeat: load fixture *cust-delta-02* into `SRC.CUSTOMER`, run job
   `LOAD_DIM_CUSTOMER`, run query `sql/tgt/dim_customer_07.sql`.
2. An expected result is a query result with an exact value: a count, a sum, an empty diff, a named row's column
   values, the job status, the reject table content. Never "data is correct" or "as expected". **[script Warning]**
3. Every reconciliation names **both sides** (source query and target query) and the **tolerance** (0 unless the
   mapping says otherwise, e.g. rounding to 2 decimals).
4. The TC carries an `etl` block (see [tc-fields.md](tc-fields.md)). Query files live in
   `automation/etl/sql/{src,tgt}/` and are versioned with the TC.

## R-ETL2. The mapping is the source of truth

- The source-to-target mapping (STTM) gives, per target column: source table / column, transformation rule, key,
  nullable, default, data type. Parse it with `python3 scripts/parsers/sttm_inventory.py <file.xlsx>`; cite rule IDs
  (`MAP-<TABLE>-<nn>`) or the sheet + row.
- A rule the mapping states ambiguously ("standardise the name") → `Q-xxx` with the assumed exact rule.
- DDL (types, lengths, constraints) and the job design (schedule, dependencies, load type) are sources too.

## R-ETL3. Structure

- `layout: table`: level 1 = target table, areas Completeness → Transformation → Data quality → Keys & integrity
  → History → Rejects.
- `layout: job`: level 1 = job / pipeline step, areas Full load → Incremental load → Re-run & recovery →
  Scheduling & dependencies → Error handling.
- Title prefix `[<TARGET_TABLE>]` or `[<JOB_NAME>]`.

## R-ETL4. Test data

- Each TC names a **fixture set**: small, hand-made rows that hit exactly the rule under test (one row per
  partition: valid, null, boundary, duplicate key, orphan foreign key, late-arriving, unicode, max length).
- Volume tests use generated data with a stated row count and seed; they are Performance, not Functional.
- Production data only at ST and only masked; say so in the precondition.

## R-ETL5. Levels

- **IT**: dev / test database with fixture sets; upstream feeds replaced by fixture files; one pipeline at a time.
- **ST**: production-like volumes, the real schedule and upstream systems, end-to-end lineage to the consuming
  report or API, recovery from a failed run.

## R-ETL6. Security and audit

PII columns masked or encrypted in the target as the data classification says; access to target schemas per role;
audit columns (`load_id`, `load_ts`, `source_system`) filled on every row; run log shows row counts read / written /
rejected that match the reconciliation.
