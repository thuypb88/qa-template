# UI pack: scenario design

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 09:07 (UTC+7)

Read by `design-scenarios` for UI modules.

## Layout

| Layout | Level 1 | Level 2 (Area), in this order |
|---|---|---|
| `form` | one branch per form / screen (inventory order) | Display → Field validation → Buttons → Output |
| `flow` | one branch per flow step | Main flow → Alternate flow → Exception → Business rule |

Cross-cutting branches last: Localization, Compatibility, Security, Accessibility, E2E.

## Leaf prefixes → test type

`[P]` positive, `[UI]` display, `[C]` compatibility → Functional · `[N]` Negative · `[B]` Boundary ·
`[L]` Localization · `[S]` Security · `[A]` Accessibility · `[E2E]` E2E.

## Easy-to-miss coverage (from ALPHA reviews)

1. **Input = output.** One Output scenario per form / screen: the result (printout, preview, detail, export) shows
   every entered value under its label, in order.
2. **Every refused transition, including the way back.** Re-test a gate (preview, submit, approve) after passing it
   once: Back, clear a field, then try every path — the module's button and the host's command (browser Back,
   refresh, direct URL, Ctrl+P).
3. **Every partition on every variant.** When a condition lists several forms, each gets valid, invalid and boundary.
4. **Relational limits.** `≥ / ≤ / > / <` between fields: the failing off-point and the passing on-point.
5. **Every control's options** (lists, radios) shown in a Display scenario.
6. **Shared page, still one variant per row.** "Forms B, C, D have no Terms" = three scenarios.
7. **Reachable trigger.** A tester can cause it through the UI, and nothing contradicts it.
