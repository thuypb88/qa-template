# UI pack: analysis sections

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

`design-analysis` writes the common sections (see the skill) and fills these pack sections with UI content.

## §3 Inventory: forms / screens

`Name as labelled | Kind (screen / modal / form / page / email / printout) | Fields | Buttons / actions | Messages |
Roles | Source`

- These names become mindmap level 1 and the TC title prefixes (R-UI2). Use the label the user sees, never an
  internal name.
- List them in the order a tester meets them.
- A flow module that handles a variant set (R10) adds **Variants handled by this flow**:
  `Flow step | Variant | Valid: tester sees | Invalid: tester sees | Source / Q-xxx`, one row per step × variant.

## §5 Data & field rules

One table per form / screen:
`Field | Type | Mandatory | Format / Length | Validation | Default | Labels (one column per project language) |
Message | Source`, plus state / transition tables for statuses and button states.

- Mark free-text fields as **free text** (R6.3 needs them).
- When a field-mapping workbook is a source (`sources.field_mapping`), it is the newest field definition: one row
  per field in form order, citing sheet + row. Unconfirmed values (highlighted, `[bracketed]`) = assumption + `Q-xxx`.

## §6 Integrations as the tester sees them

For each external system the module touches: what it feeds, where the effect shows in the UI, and the IT fixture
that stands in for it (`external_systems[].it` in `project.json`).

## §8 Testable conditions: "Observable in"

The TCOND table's `Observable in` column names a UI place (screen, message, printout, email, scanner app).
Internal-only conditions go to the sub-table **Out of black-box scope** (covering layer: UT / API / ETL / SAST).
