# UI pack: rules (R-UI)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:29 (UTC+7)

Applies to every module with `"pack": "ui"` in `project.json`, and to UI test cases at ST. Adds to the core rules
([standards/core-rules.md](../../standards/core-rules.md)); where they disagree, the core rules win.

## R-UI1. Black box, through the UI

1. Steps are UI actions: open, select, type, click, upload, print, scan, send an email, open a screen. Name the
   screen, page, form, field and button exactly as labelled on screen (labels in their own language).
2. Expected results are what the tester can see: the screen, a field state, a message (exact text), a button
   state, a status or column value on a screen, the printed or downloaded output, the email received, the result
   shown by a scanner app.
3. Not allowed: SQL, database rows, log files, API calls, endpoints, HTTP codes, payload internals, internal field
   or variable names, browser devtools. **[script: `forbidden_terms` Warning]**
4. A behaviour checked only inside the system → find where it shows in the UI ("row created" → "the item is
   listed on the Inquiry screen"). Nowhere → list it under **Out of black-box scope** (covered by UT / API / ETL
   tests), no manual TC.
5. A module that needs an internal check as well gets a second pack (an `api` or `etl` module) — never a UI TC
   with a DB step.

## R-UI2. Structure

- **Form / screen modules** (`layout: form`): one branch per form or screen, each in the order
  Display → Field validation → Buttons → Output. Title prefix `[<Form / Screen>]`.
- **Flow modules** (`layout: flow`): one branch per flow step, each Main flow → Alternate flow → Exception →
  Business rule. Title prefix `[<Flow step>]`, or `[<Flow step> – <Variant>]` when a variant set applies (R10).
- Cross-cutting branches last: Localization, Compatibility, Security, Accessibility, E2E.

## R-UI3. Security techniques (test type `Security`, through the UI)

Applied by each module's `security` value in `project.json`: `full` = every technique that applies, `limited` =
the techniques listed in the module's `security_techniques`, `none` = out of black-box scope.

| Technique | What to test (black box) |
|---|---|
| Authentication | Open a screen URL without signing in; session timeout; Back after logout; expired / invalid SSO return |
| Authorization / RBAC | Per role in the RBAC matrix: menus and buttons shown, refused actions refused; forbidden screen by URL; changed item ID in the URL (IDOR) |
| Input injection | `<script>alert(1)</script>`, `' OR '1'='1`, `=1+1` in an exported field, very long / Unicode input: shown as plain text or rejected, no script run, no system error |
| File upload | Wrong type, double extension (`a.pdf.exe`), renamed executable, oversize, empty, password-protected |
| Sensitive data exposure | PII masked on screen; no PII or IDs in URLs; error pages without stack trace; downloads limited to the role |
| Session management | Two sessions for one user; sign-in on a second browser; idle timeout |
| Audit of security events | Sign-in, refused access and permission changes appear on the audit screen |

## R-UI4. GUI checklist

[checklist.md](checklist.md) is applied to every row of the analysis's **Forms / screens inventory** by
`design-cases` (UI pass). A UI test case cites its `GUI-xxx` ID in `notes`; the export derives the **Checklist**
column from it.
