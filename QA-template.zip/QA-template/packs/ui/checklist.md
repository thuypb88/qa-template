# UI pack: GUI checklist

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

Standard GUI checks for every screen and form. `design-cases` (UI pass) applies them to each row of a
module's **Forms / screens inventory** and writes a UI test case only for a check that applies and that no
existing TC covers. `check-design` uses the same list to judge UI coverage. Origin: ALPHA GUI checklist (2026-10-13).

## How to read the table

- **ID** `GUI-<group><nn>`: cite it in the TC `notes` and in the module's `3-test-cases/checklist-pass.md`. Never
  renumber; append new IDs at the end of their group.
- **Name**: short, unique; the export writes `<ID> <Name>` in the **Checklist** column of every TC citing the ID.
- **Applies to**: skip the check (N/A) when the screen has no such element.
- **Oracle**: **S** (source) — the value must be in the analysis, else the check is Blocked with a `Q-xxx`;
  **H** (heuristic) — a generic expectation no source states: write it as `Q-UI-xxx: assumed <behaviour>`, priority
  P3 or lower.
- **Level**: `IT` checks are written per module; `ST` checks (browsers, resolution, keyboard, screen reader,
  responsive) belong to the ST suite (R9).
- **Type / Automation**: defaults for the TC (no `UI` test type: a GUI check is typed by its purpose).

## Excluded: covered by other rules

Don't repeat these here. They have their own TCs elsewhere.

- Field validation partitions and boundaries (min-1 / min / max / max+1, mandatory empty): R7.
- Free-text input in each project language: R6.3.
- RBAC menus and buttons per role, URL tampering and injection: R-UI3 Security.
- Every variant of a variant set in a flow: R10.

## 1. Web screens

### D: Display (Area: Display)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| GUI-D01 | Screen title and menu | every screen | The screen title and the highlighted main menu item match the screen opened | S | IT | Functional / Auto |
| GUI-D02 | Labels and order | every screen | Every label, column header, button caption and section heading is shown with the exact text and in the order given in the analysis (labels in every project language as written) | S | IT | Functional / Auto |
| GUI-D03 | Mandatory marker | forms, modals | Mandatory fields carry the mandatory marker (e.g. `*`), and optional fields don't | S | IT | Functional / Auto |
| GUI-D04 | Default values | every screen | On open, every field, filter, tab and toggle shows its default value or state | S | IT | Functional / Auto |
| GUI-D05 | Placeholder and helper text | inputs | Placeholder and helper text are shown as designed, and the placeholder clears once the field holds a value | S | IT | Functional / Auto |
| GUI-D06 | Read-only fields | read-only fields | Read-only fields look read-only and can't be edited, focused for typing or pasted into | S | IT | Functional / Auto |
| GUI-D07 | Long value shown | lists, detail fields | A value at the field's max length (or the longest fixture value) is shown in full, or cut off with a visible way to read all of it (tooltip, wrap, detail view). It doesn't overlap other elements. | H | IT | Boundary / Auto + Manual |
| GUI-D08 | Empty-state message | lists, search | A search or filter with no match shows the empty-state message, not an empty grid with no text | S | IT | Functional / Auto |
| GUI-D09 | Loading indicator | slow actions | During a search, load or save, a loading indicator is shown, and the action's button can't be clicked again until it finishes | H | IT | Functional / Auto |
| GUI-D10 | Date and amount format | dates, amounts | Dates, times and amounts are shown in the display format the analysis gives (e.g. `dd/MM/yyyy HH:mm`, thousands separator) | S | IT | Functional / Auto |

### F: Input controls (Area: Field validation)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| GUI-F01 | Option list | dropdowns, radios | The option list holds exactly the options in the analysis, in that order, with the default selected | S | IT | Functional / Auto |
| GUI-F02 | Spaces trimmed | text inputs | Leading and trailing spaces are trimmed, or flagged, as the analysis says. A value of only spaces counts as empty. | H | IT | Functional / Auto |
| GUI-F03 | Paste rules | text inputs | Text pasted into a field follows the same max-length and character rules as typed text | H | IT | Functional / Auto |
| GUI-F04 | Date picker | date pickers | The picker opens on the default or selected date. Disabled dates (future or out of range, per the rule) can't be picked. A date typed by hand in a wrong format is flagged. | S | IT | Functional / Auto |
| GUI-F05 | Digits only | numeric inputs | Letters and symbols are refused or flagged in digit-only fields | S | IT | Negative / Auto |
| GUI-F06 | Field error message | validated fields | The error message is shown next to the field it concerns, with the exact text, and disappears once the value is corrected | S | IT | Negative / Auto |

### B: Buttons and actions (Area: Buttons)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| GUI-B01 | Button states | buttons | Each button is enabled or disabled in each screen state, as the analysis's state rules say (one TC per state change) | S | IT | Functional / Auto |
| GUI-B02 | Double click | save / submit / decision buttons | A quick double click creates one result: one item, one decision, one message | H | IT | Functional / Auto |
| GUI-B03 | Cancel discards | modals, edit screens | Cancel or close (X) discards the changes. Reopening shows the previous values. | S | IT | Functional / Auto |
| GUI-B04 | Destructive confirmation | destructive actions | Delete, deactivate, reject and similar actions show a confirmation with the exact text. Cancel in the confirmation changes nothing. | S | IT | Functional / Auto |
| GUI-B05 | Success message | actions with feedback | After success, the success message or toast with the exact text is shown, and the screen shows the new state | S | IT | Functional / Auto |
| GUI-B06 | Enter runs search | search forms | Pressing Enter in a search field runs the search, the same as clicking Search | H | IT | Functional / Auto |

### L: Lists and grids (Area: Display, or Buttons for row actions)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| GUI-L01 | Default sort | grids | The default sort column and direction on open match the analysis | S | IT | Functional / Auto |
| GUI-L02 | Column sort | sortable columns | Clicking a sortable header sorts ascending, then descending, and shows the sort indicator | S | IT | Functional / Auto |
| GUI-L03 | Paging | paged grids | Page size options, the default page size, next / previous / first / last and the total count match the analysis, and the count matches the rows | S | IT | Functional / Auto |
| GUI-L04 | Back to page 1 | paged grids | Changing a filter or the sort goes back to page 1 | H | IT | Functional / Auto |
| GUI-L05 | List state kept | grids with a detail view | After opening a row's detail and going back, the list keeps its filters, sort and page | H | IT | Functional / Auto |

### N: Navigation and browser (Area: Buttons)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| GUI-N01 | Back after action | screens after a save or decision | Browser Back after the action doesn't repeat it and doesn't show the old editable state | H | IT | Functional / Auto |
| GUI-N02 | Refresh | every screen | Refresh (F5) keeps the user signed in and reloads the screen with the state the analysis gives (default state or kept filters) | H | IT | Functional / Auto |
| GUI-N03 | Unsaved changes | edit screens, modals | Leaving with unsaved changes shows the unsaved-changes prompt, or discards the changes without a prompt, as the analysis says | S | IT | Functional / Auto |
| GUI-N04 | Direct URL | detail screens | Opening the detail screen's URL directly, in a new tab, shows the same item for a signed-in user | H | IT | Functional / Auto |

### M: Messages (Area: Display)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| GUI-M01 | Friendly error | system errors | When a service is unavailable (mock fixture), a friendly error message is shown, with no stack trace, code or raw server text, and the screen stays usable | S | IT | Negative / Auto |
| GUI-M02 | Message language | every message | Messages appear in the same UI language as the screen's labels | S | IT | Localization / Auto |

### X: Moved to ST (R9). Not written at IT.

| ID | Name | Check |
|---|---|---|
| GUI-X01 | Browsers | Supported browsers and versions from the test plan |
| GUI-X02 | Resolution and zoom | Screen resolutions (e.g. 1366×768, 1920×1080) and browser zoom 125 % / 200 %: no overlap, no lost controls |
| GUI-X03 | Keyboard only | Keyboard only: Tab order follows the visual order, the focus is visible, Esc closes modals, focus stays inside an open modal |
| GUI-X04 | Screen reader and contrast | Screen reader names for controls; colour contrast (axe-core plus a manual walk-through) |
| GUI-X05 | Responsive layout | Responsive layout when the window is resized |

## 2. Fillable PDF forms (optional: only when the project has them)

All of these are `test_type` Functional, `automation` Manual (or Auto when the form logic can be run headless),
Level IT. Use the form name as the title prefix, and give each form of a variant set its own TC (R10).

| ID | Name | Applies to | Check | Oracle | Area |
|---|---|---|---|---|---|
| GUI-P01 | Layout vs paper form | every form | The layout matches the client's paper form (client documents): section order, labels, boxes, logo and footer | S | Display |
| GUI-P02 | Tab order | every form | Tab moves through the fields in the order of the form's reading order, as the field mapping lists them | S | Display |
| GUI-P03 | Tooltips | fields with a tooltip | Hovering a field shows its tooltip or helper text exactly as designed | S | Display |
| GUI-P04 | Mandatory marked | mandatory fields | Mandatory fields are marked, and an empty mandatory field is highlighted when the form is checked | S | Field validation |
| GUI-P05 | Long text fits | fixed-size fields | Text at the field's max length fits the box: auto-size or wrap, with nothing cut off on screen or in print | H | Field validation |
| GUI-P06 | Radio exclusive | radio / checkbox groups | Options in one group exclude each other where the form says only one may be chosen | S | Field validation |
| GUI-P07 | A4 print | every form | Print to A4 from Reader: one form per page, nothing cut off at the margins, the QR is printed in full | S | Output |
| GUI-P08 | Zoom | every form | At 100 % and 150 % zoom in Reader, labels and field values don't overlap | H | Display |
