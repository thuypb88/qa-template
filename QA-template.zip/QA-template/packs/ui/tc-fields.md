# UI pack: test case block

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:29 (UTC+7)

UI test cases use only the common fields ([standards/conventions.md](../../standards/conventions.md) §4). There is
no `ui` block: the screen is in the title prefix, the actions in `steps`, what the tester sees in
`expected_result`. A UI test case from the GUI checklist cites its `GUI-xxx` ID in `notes`.
