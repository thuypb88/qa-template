# SQL pack: database object checklist

> **Created:** 2026-10-16 11:10 · **Updated:** 2026-10-16 12:05 (UTC+7)

Applied by `sql-cases` (checklist pass) to every row of the analysis's **Database objects** inventory. Write a TC
only for a check that applies and no TC covers; cite the ID in `notes`. Oracle **S** = the spec / DDL states it (else
Blocked + `Q-xxx`); **H** = heuristic, written as `Q-SQL-xxx: assumed …`, P3 or lower.

## V: Parameters & validation (Area: Parameters & validation)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| SQL-V01 | Required parameter | every required input | NULL / missing value gives the documented error, and nothing is written | S | IT | Negative / Auto |
| SQL-V02 | Range and domain | numeric / coded inputs | Min, max, one outside each end, zero, negative; an unknown code | S | IT | Boundary / Auto |
| SQL-V03 | Length and precision | string / decimal inputs | Max length and one over (truncation or error, as documented); scale and rounding | S | IT | Boundary / Auto |
| SQL-V04 | Dates and times | date / time inputs | Month / year end, leap day, min / max date, time zone and DST where the spec names a zone | S | IT | Boundary / Auto |
| SQL-V05 | Defaults | parameters with defaults | Omitting the parameter gives the documented default behaviour | S | IT | Functional / Auto |
| SQL-V06 | Type conversion | inputs compared with other types | A value needing implicit conversion (e.g. '001' vs 1) behaves as documented | H | IT | Negative / Auto |

## R: Business rules and results (Areas: Business rules, Result set)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| SQL-R01 | Rule per partition | every business rule | One call per equivalence class of the rule, each with the exact effect | S | IT | Functional / Auto |
| SQL-R02 | Result shape | objects returning rows | Column names, order, types and sort order as documented | S | IT | Functional / Auto |
| SQL-R03 | Zero, one, many | objects returning rows | No match gives 0 rows (not an error, unless documented); one; many; paging limits | S | IT | Boundary / Auto |
| SQL-R04 | NULL in data | nullable columns used in filters / joins / aggregates | Rows with NULL are included or excluded exactly as documented | S | IT | Functional / Auto |
| SQL-R05 | Duplicates | lookups assumed unique | A duplicate where uniqueness is not enforced gives the documented result or error | H | IT | Negative / Auto |
| SQL-R06 | Outputs | OUT parameters / return codes | Every documented value is reachable and exact | S | IT | Functional / Auto |

## E: Side effects, transactions and errors (Areas: Side effects, Transactions & errors)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| SQL-E01 | Writes | objects that write | Exactly the documented rows / columns change (read back), audit and history rows included | S | IT | Functional / Auto |
| SQL-E02 | No collateral change | objects that write | Neighbouring rows (other keys, statuses) are unchanged | S | IT | Data Integrity / Auto |
| SQL-E03 | Atomicity | multi-step writes | An error after the first write leaves no partial change (or the documented partial state) | S | IT | Transaction / Auto |
| SQL-E04 | Error contract | every documented error | Error number / SQLSTATE and message text exact; the transaction state after it as documented | S | IT | Negative / Auto |
| SQL-E05 | Constraints | writes touching keys / FKs / checks | A violation gives the documented error; no orphan or duplicate is created | S | IT | Data Integrity / Auto |
| SQL-E06 | Triggers | tables with triggers | A multi-row statement fires the trigger logic for every row | H | IT | Functional / Auto |
| SQL-E07 | Re-run | jobs, retries, submit actions | Calling twice gives the documented result (idempotent, or the second refused) | S | IT | Functional / Auto |

## C: Concurrency (Area: Concurrency)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| SQL-C01 | Same row, two sessions | objects updating shared rows | No lost update; the loser gets the documented error or waits | H | IT | Transaction / Manual |
| SQL-C02 | Unique under race | inserts with unique keys | Two concurrent inserts: one succeeds, one gets the documented error | H | IT | Transaction / Manual |

## X: Cross-cutting (Areas: Performance, Security, Audit)

| ID | Name | Applies to | Check | Oracle | Area |
|---|---|---|---|---|---|
| SQL-X01 | Permissions | every callable object | The allowed role can call it; another role gets the permission error | S | Security |
| SQL-X02 | Injection | objects building dynamic SQL | A parameter with quotes / `;` / comment markers is treated as data | H | Security |
| SQL-X03 | Volume target | objects with a documented time / volume target | Response time at the documented row count, measured on the test database | S | Performance |
| SQL-X04 | Audit trail | objects the spec says are audited | Who, when, what before / after recorded | S | Audit |
