# SQL pack: test case block

> **Created:** 2026-10-16 11:10 · **Updated:** 2026-10-16 12:05 (UTC+7)

Every SQL test case adds a `sql` object to the common fields. `export_testcases.py --check` checks the required keys
and the enum values; the export shows them as the DB Object / Call / Oracle / Data Script / Verify / Verification
columns.

```json
"sql": {
  "object": "dbo.usp_transfer",
  "object_type": "procedure",
  "call": "EXEC dbo.usp_transfer @from_acc = 'S1-ACC-01', @to_acc = 'S1-ACC-02', @amount = 100.00",
  "data_set": "S1-DS-02",
  "data_script": "3-test-cases/sql/data/S1-DS-02.sql",
  "cleanup_script": "3-test-cases/sql/data/S1-DS-02-cleanup.sql",
  "oracle": "table_state",
  "readback": "SELECT acc_no, balance FROM dbo.account WHERE acc_no IN ('S1-ACC-01', 'S1-ACC-02') ORDER BY acc_no",
  "expect": {"rows": [["S1-ACC-01", 400.00], ["S1-ACC-02", 600.00]]},
  "verify": "proc",
  "verify_ref": "qa.verify_usp_transfer"
}
```

| Key | Required | Meaning |
|---|---|---|
| `object` | yes | Object under test, schema-qualified |
| `object_type` | no | `procedure`, `function`, `view`, `trigger`, `query`, `job` |
| `call` | yes | The exact statement a tester runs (dialect of `project.json › sql.dialect`) |
| `oracle` | yes | `result_set`, `out_params`, `return_code`, `error`, `table_state`, `no_side_effect` |
| `data_set` / `data_script` / `cleanup_script` | no | Data set ID (analysis §11) and its scripts, relative to the module folder |
| `readback` | for `table_state`, `no_side_effect` | The query that reads the state back |
| `expect` | yes for Auto | Exact values: `rows` (list of rows), `count`, `out` (`{name: value}`), `return_code`, `error` (`{"code": …, "message": …}`) |
| `verify` | yes | `proc` (verification stored procedure / function), `script` (verification SQL script), `manual` |
| `verify_ref` | for `proc` / `script` | `qa.<name>` for a procedure; `automation/sql/verify/<file>.sql` for a script |

## Data scripts (`3-test-cases/sql/data/`)

`<MOD>-DS-<nn>.sql` creates one data set; `<MOD>-DS-<nn>-cleanup.sql` removes exactly those rows. Both are
idempotent (delete-then-insert or `MERGE` / `INSERT … WHERE NOT EXISTS`), insert parents before children and
delete in reverse, tag every row with the run marker (a key prefix such as `S1-` or a `created_by = 'QA-<MOD>'`
column), and use only synthetic values. Header comment: data set ID, dialect, the TCs that use it, what each row is
for.

## Verification contract

A verification (procedure, function or script) returns rows `(tc_id, result, detail)`, `result` = `PASS` or `FAIL`,
one row per TC it checks. `automation/sql/sql_verify.py` calls it in the project's dialect and the runner maps the rows to
the TC IDs. Templates per dialect: [dialects.md](dialects.md) § Verification.
