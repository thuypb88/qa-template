# SQL pack: analysis sections

> **Created:** 2026-10-16 11:10 · **Updated:** 2026-10-16 12:05 (UTC+7)

`design-analysis` writes the common sections and fills these with SQL content. Start from the study cards
(`sql-study` → `<folder>/sql-study/<object>.md`): they list each object's interface, effects and the rules found in
the code (as questions until the spec confirms them, R-SQL2).

## §3 Inventory: database objects

`Object | Type (procedure / function / view / trigger / job / query) | Purpose (spec ref) | Inputs (name, type,
null, default) | Outputs (result set columns / OUT params / return code) | Reads | Writes | Raises (error no. /
SQLSTATE, message) | Transaction (own / caller's / none) | Called by | Source`.

These become mindmap level 1 (`layout: object`) or the steps of a flow (`layout: flow`), and the TC title prefixes.

## §5 Data & field rules

Per object: `Parameter / column | Type (DDL) | Null | Valid range / values | Rule ID | Rule (exact) | On invalid
(error, default, ignored) | Source`. Plus:
- **Business rules**: `Rule ID | Object | Condition | Effect (rows / values / error) | Source`.
- **Side effects**: `Object | Table written | Insert / update / delete | Columns | Audit / history rows | Source`.
- **Integrity**: keys, unique constraints, foreign keys, check constraints and triggers touched by the objects.

## §6 Dependencies

`Called / read object | Owner (this module, other module, external system) | IT stand-in (seeded table, stub
procedure, synonym to a test copy) | ST: real object | Failure behaviour (error, retry, partial commit)`.

## §8 Testable conditions: "Observable in"

`Observable in` = the result set, the OUT parameter / return code, the raised error, or the query that reads the
table back (`SELECT … FROM ACCOUNT WHERE id = …`). Internal-only effects (temp tables, a variable, an execution
plan) → **Out of black-box scope**, except performance conditions with a stated target.

## §11 Fixtures

Data sets per object or flow (`<MOD>-DS-<nn>`: the rows, why each exists, the rule or boundary it serves), the data
and cleanup scripts (`3-test-cases/sql/data/`), stubs for dependencies, the run marker, and the reset procedure.
