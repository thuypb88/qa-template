# SQL pack: rules (R-SQL)

> **Created:** 2026-10-16 11:10 · **Updated:** 2026-10-16 10:29 (UTC+7)

Applies to every module with `"pack": "sql"` in `project.json`: stored procedures, functions, views, triggers,
scheduled jobs and business queries tested at the database level. Adds to the core rules
([standards/core-rules.md](../../standards/core-rules.md)). Engine syntax: [dialects.md](dialects.md).

## R-SQL1. Surface and oracle

1. A step is something a caller does: run data script `S1-DS-03`, `EXEC usp_transfer @from=…`, `SELECT … FROM
   vw_balance WHERE …`. No step reads the procedure's source to "see what it does".
2. An expected result is exact and observable from outside the object: the rows and columns returned (or "0 rows"),
   an output parameter value, a return code, an error (number / SQLSTATE and message text), or a **table state read
   back by a named query** after the call. Never "works correctly", "as expected", "no errors". **[script Warning]**
3. Refusals check **no side effect** as well as the error: the rows that must not change are read back.
4. The TC carries a `sql` block ([tc-fields.md](tc-fields.md)) naming the object, the exact call, the oracle kind and
   how it is verified.

## R-SQL2. Sources of truth

- The specification of the object (SRS / design document / ticket) states what it must do. The **SQL source code is
  evidence of what it does**, never the oracle: a rule found only in the code goes to the analysis as `Q-xxx:
  assumed <rule as implemented>` until a person confirms it (core R1). Otherwise tests built from the code pass by
  construction.
- DDL (types, lengths, NULL, defaults, keys, constraints, triggers) is a source for boundaries and integrity.
- `sql-study` cards (`<folder>/sql-study/`) cite the code by file and line; analysis rows cite the spec.

## R-SQL3. Structure

- `layout: object`: level 1 = DB object (`usp_transfer`, `fn_fee`, `vw_balance`), areas Parameters & validation →
  Business rules → Result set → Side effects → Transactions & errors → Concurrency.
- `layout: flow`: level 1 = business flow across objects (open account → deposit → close), areas Happy path →
  Alternative paths → Failure & rollback → Data integrity.
- TC title prefix: `[<object or flow>]`.

## R-SQL4. Data and environments

- Test data is **synthetic**, created by scripts that are idempotent (re-runnable), tagged with a run marker and
  removed by a matching cleanup script ([tc-fields.md](tc-fields.md) › data scripts). Never copy production rows;
  masked copies only when the project rules allow them.
- Connection strings, accounts and passwords come from environment variables (`SQL_DSN`, …), never from files in the
  repo. IT runs only against the test database named in `project.json › levels`; nothing in the pack may point at
  UAT or production (core R9).
- Verification objects are created in a **separate schema** (default `qa`) and dropped by their own cleanup; they
  never alter product objects or data outside the test data set.

## R-SQL5. Automation

- Every verification — stored procedure or script — returns rows `(tc_id, result, detail)` with `result` in
  `PASS | FAIL`, one row per TC it checks. The runner (`automation/sql/`) maps them to the TC IDs; a TC with no row
  is **No result**, never Passed.
- A verification compares against values written in the TC (from the source), never against a value computed by the
  object under test.
- Each verification arranges its own data, acts once, asserts, and rolls back or cleans up; tests do not depend on
  each other's order.
