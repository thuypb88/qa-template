# SQL pack: scenario design

> **Created:** 2026-10-16 11:10 · **Updated:** 2026-10-16 12:05 (UTC+7)

| Layout | Level 1 | Level 2 (Area), in this order |
|---|---|---|
| `object` | one branch per DB object (callers before callees when both are tested) | Parameters & validation → Business rules → Result set → Side effects → Transactions & errors → Concurrency |
| `flow` | one branch per business flow across objects | Happy path → Alternative paths → Failure & rollback → Data integrity |

Cross-cutting last: Performance, Security, Audit.

**Leaf prefixes → type:** `[P]` Functional · `[B]` Boundary · `[N]` Negative · `[TX]` Transaction ·
`[DI]` Data Integrity · `[PF]` Performance · `[S]` Security.

## Easy-to-miss coverage

1. **NULL is its own partition** for every nullable parameter and column: `= NULL` never matches, `NOT IN` with a
   NULL returns nothing, aggregates skip NULLs, `COUNT(col)` ≠ `COUNT(*)`.
2. **Empty and many**: zero rows, exactly one, many, and duplicates where the code may assume uniqueness (a scalar
   subquery or `SELECT INTO` that suddenly gets two rows).
3. **Boundaries in the column's own unit**: max length (and one over: truncation or error?), precision and scale
   (rounding mode), min / max dates, month and year end, time zone and DST, negative and zero amounts.
4. **Failure in the middle**: an error after the first write — is everything rolled back, or is a partial commit
   documented? Nested transactions and savepoints; the caller's open transaction.
5. **Side effects both ways**: what must change (rows, audit, history) and what must not (other customers, other
   statuses). Triggers fire once per statement, not per row, unless written for sets.
6. **Re-run / idempotency**: the same call twice (double submit, retried job).
7. **Concurrency**: two sessions on the same row (lost update, deadlock, unique violation), long locks.
8. **Types and collation**: implicit conversion (string vs number keys), case and accent sensitivity, Unicode,
   trailing spaces in comparisons.
9. **Permissions**: the role that should call it can; a role that should not gets the documented error.
10. **Volume**: the documented peak row count, when a performance target exists.
