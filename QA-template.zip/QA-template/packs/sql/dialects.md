# SQL pack: dialects

> **Created:** 2026-10-16 11:10 · **Updated:** 2026-10-16 10:43 (UTC+7)

The SQL skills are engine-neutral; the dialect comes from `project.json › sql.dialect` (`sqlserver`, `oracle`,
`postgres`, `mysql`; `sqlite` for the template self-test only). Read only the column / section of your dialect.
Verify every syntax point against the engine version in `project.json › sql.version` when it matters.

## Quick reference

| Topic | SQL Server (T-SQL) | Oracle (PL/SQL) | PostgreSQL (PL/pgSQL) | MySQL / MariaDB |
|---|---|---|---|---|
| Call a procedure | `EXEC s.p @a = 1` | `BEGIN s.p(a => 1); END;` | `CALL s.p(1)` | `CALL s.p(1)` |
| Call a function | `SELECT s.f(1)` | `SELECT s.f(1) FROM dual` | `SELECT s.f(1)` | `SELECT s.f(1)` |
| Raise an error | `THROW 50001, 'msg', 1` | `RAISE_APPLICATION_ERROR(-20001, 'msg')` | `RAISE EXCEPTION 'msg' USING ERRCODE = 'P0001'` | `SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'msg'` |
| Catch an error | `BEGIN TRY … END TRY BEGIN CATCH … END CATCH` | `EXCEPTION WHEN OTHERS THEN …` | `EXCEPTION WHEN OTHERS THEN …` (a sub-transaction) | `DECLARE CONTINUE HANDLER FOR SQLEXCEPTION …` |
| Error number / text | `ERROR_NUMBER()`, `ERROR_MESSAGE()` | `SQLCODE`, `SQLERRM` | `SQLSTATE`, `SQLERRM` | `GET DIAGNOSTICS CONDITION 1 @s = RETURNED_SQLSTATE, @m = MESSAGE_TEXT` |
| Transaction | `BEGIN TRAN … COMMIT / ROLLBACK`; `@@TRANCOUNT` | implicit; `COMMIT`, `ROLLBACK`, `SAVEPOINT` | caller's transaction; sub-transaction per `BEGIN … EXCEPTION` block | `START TRANSACTION … COMMIT / ROLLBACK` |
| Upsert (data scripts) | `MERGE` or `IF NOT EXISTS … INSERT` | `MERGE INTO … USING dual` | `INSERT … ON CONFLICT DO NOTHING / UPDATE` | `INSERT … ON DUPLICATE KEY UPDATE` |
| Identity / sequence | `IDENTITY`, `SET IDENTITY_INSERT t ON` for fixed keys | `GENERATED AS IDENTITY`, sequences | `GENERATED … AS IDENTITY`, `setval` | `AUTO_INCREMENT` |
| String concat / NULL | `CONCAT()` (NULL → ''), `+` (NULL → NULL) | `||` (NULL → as ''); '' **is** NULL | `||` (NULL → NULL), `CONCAT()` | `CONCAT()` (NULL → NULL) |
| Current time | `SYSDATETIME()`, `SYSDATETIMEOFFSET()` | `SYSTIMESTAMP` | `now()` (transaction start), `clock_timestamp()` | `NOW(6)` |
| Top N | `TOP (n)` / `OFFSET … FETCH` | `FETCH FIRST n ROWS ONLY` | `LIMIT n` | `LIMIT n` |
| Plan | `SET STATISTICS IO, TIME ON`; actual plan | `EXPLAIN PLAN FOR …`; `DBMS_XPLAN.DISPLAY_CURSOR` | `EXPLAIN (ANALYZE, BUFFERS)` | `EXPLAIN ANALYZE` (8.0.18+) |
| Locks / blocking | `sys.dm_tran_locks`, `sys.dm_exec_requests` | `v$lock`, `v$session` | `pg_locks`, `pg_stat_activity` | `performance_schema.data_locks` |
| Unit-test framework | tSQLt | utPLSQL | pgTAP | (none common; MyTAP) |

**Traps worth a test in every dialect:** `NULL` comparisons and `NOT IN` with NULLs; Oracle's `'' = NULL`;
implicit conversions in joins and filters; collation (case / accent) in comparisons and unique keys; `DATE` with or
without time; rounding of `DECIMAL` vs `FLOAT`; MySQL silent truncation when strict mode is off.

## Verification (contract: rows `tc_id, result, detail`)

One verification object per DB object or flow, in schema `qa`. Each TC block: arrange → act once → assert →
**undo its own changes** → record the row. The runner calls it as shown and maps the rows by `tc_id`.

### SQL Server — `EXEC qa.verify_<object>`

A table variable survives `ROLLBACK`, so results are kept while the test's changes are undone.

```sql
CREATE OR ALTER PROCEDURE qa.verify_usp_transfer AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @r TABLE (tc_id varchar(40), result varchar(4), detail nvarchar(4000));
  DECLARE @b1 decimal(18,2), @b2 decimal(18,2);
  -- TC-S1-001 · [usp_transfer] Moves the amount between two accounts
  BEGIN TRAN;
  BEGIN TRY
    EXEC dbo.usp_transfer @from_acc = 'S1-ACC-01', @to_acc = 'S1-ACC-02', @amount = 100.00;
    SELECT @b1 = balance FROM dbo.account WHERE acc_no = 'S1-ACC-01';
    SELECT @b2 = balance FROM dbo.account WHERE acc_no = 'S1-ACC-02';
    INSERT @r SELECT 'TC-S1-001',
      CASE WHEN @b1 = 400.00 AND @b2 = 600.00 THEN 'PASS' ELSE 'FAIL' END,
      CONCAT('balances ', @b1, ' / ', @b2, ', expected 400.00 / 600.00');
  END TRY
  BEGIN CATCH
    INSERT @r VALUES ('TC-S1-001', 'FAIL', CONCAT('error ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()));
  END CATCH;
  IF @@TRANCOUNT > 0 ROLLBACK;
  -- TC-S1-002 · expected error: the CATCH block is the PASS path; check ERROR_NUMBER() and the readback
  SELECT tc_id, result, detail FROM @r;
END;
```

### Oracle — `SELECT tc_id, result, detail FROM TABLE(qa.verify_<object>())`

An autonomous-transaction function may run DML and must end with `ROLLBACK`; the collection it returns is kept.
Data scripts must be committed before the call (the autonomous transaction does not see uncommitted rows).

```sql
CREATE OR REPLACE TYPE qa.verify_row AS OBJECT (tc_id VARCHAR2(40), result VARCHAR2(4), detail VARCHAR2(4000));
/
CREATE OR REPLACE TYPE qa.verify_tab AS TABLE OF qa.verify_row;
/
CREATE OR REPLACE FUNCTION qa.verify_usp_transfer RETURN qa.verify_tab IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  r qa.verify_tab := qa.verify_tab();
  b1 NUMBER; b2 NUMBER;
  PROCEDURE add(t VARCHAR2, ok BOOLEAN, d VARCHAR2) IS
  BEGIN r.EXTEND; r(r.COUNT) := qa.verify_row(t, CASE WHEN ok THEN 'PASS' ELSE 'FAIL' END, d); END;
BEGIN
  -- TC-S1-001
  BEGIN
    app.usp_transfer(p_from => 'S1-ACC-01', p_to => 'S1-ACC-02', p_amount => 100);
    SELECT balance INTO b1 FROM app.account WHERE acc_no = 'S1-ACC-01';
    SELECT balance INTO b2 FROM app.account WHERE acc_no = 'S1-ACC-02';
    add('TC-S1-001', b1 = 400 AND b2 = 600, 'balances ' || b1 || ' / ' || b2 || ', expected 400 / 600');
  EXCEPTION WHEN OTHERS THEN add('TC-S1-001', FALSE, 'error ' || SQLCODE || ': ' || SQLERRM);
  END;
  ROLLBACK;
  RETURN r;
END;
/
```

### PostgreSQL — `SELECT tc_id, result, detail FROM qa.verify_<object>()`

Each TC runs in a `BEGIN … EXCEPTION` block (a sub-transaction); raising a private SQLSTATE at its end undoes the
TC's changes, while PL/pgSQL variables keep the verdict.

```sql
CREATE OR REPLACE FUNCTION qa.verify_usp_transfer()
RETURNS TABLE (tc_id text, result text, detail text) LANGUAGE plpgsql AS $$
DECLARE b1 numeric; b2 numeric; res text; det text;
BEGIN
  -- TC-S1-001
  BEGIN
    CALL app.usp_transfer('S1-ACC-01', 'S1-ACC-02', 100.00);
    SELECT balance INTO b1 FROM app.account WHERE acc_no = 'S1-ACC-01';
    SELECT balance INTO b2 FROM app.account WHERE acc_no = 'S1-ACC-02';
    res := CASE WHEN b1 = 400.00 AND b2 = 600.00 THEN 'PASS' ELSE 'FAIL' END;
    det := format('balances %s / %s, expected 400.00 / 600.00', b1, b2);
    RAISE EXCEPTION 'undo' USING ERRCODE = 'QA001';
  EXCEPTION
    WHEN SQLSTATE 'QA001' THEN NULL;
    WHEN OTHERS THEN res := 'FAIL'; det := format('error %s: %s', SQLSTATE, SQLERRM);
  END;
  tc_id := 'TC-S1-001'; result := res; detail := det; RETURN NEXT;
END $$;
```

### MySQL / MariaDB — `CALL qa.verify_<object>()`

A `MEMORY` temporary table is not transactional, so its rows survive the `ROLLBACK`.

```sql
DELIMITER //
CREATE PROCEDURE qa.verify_usp_transfer()
BEGIN
  DECLARE b1, b2 DECIMAL(18,2);
  DECLARE err_state CHAR(5) DEFAULT NULL; DECLARE err_msg TEXT;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    GET DIAGNOSTICS CONDITION 1 err_state = RETURNED_SQLSTATE, err_msg = MESSAGE_TEXT;
  DROP TEMPORARY TABLE IF EXISTS qa_r;
  CREATE TEMPORARY TABLE qa_r (tc_id VARCHAR(40), result VARCHAR(4), detail TEXT) ENGINE = MEMORY;
  -- TC-S1-001
  START TRANSACTION;
  CALL app.usp_transfer('S1-ACC-01', 'S1-ACC-02', 100.00);
  SELECT balance INTO b1 FROM app.account WHERE acc_no = 'S1-ACC-01';
  SELECT balance INTO b2 FROM app.account WHERE acc_no = 'S1-ACC-02';
  INSERT INTO qa_r VALUES ('TC-S1-001',
    IF(err_state IS NULL AND b1 = 400.00 AND b2 = 600.00, 'PASS', 'FAIL'),
    IFNULL(CONCAT('error ', err_state, ': ', err_msg), CONCAT('balances ', b1, ' / ', b2, ', expected 400.00 / 600.00')));
  ROLLBACK;
  SET err_state = NULL;
  SELECT tc_id, result, detail FROM qa_r;
END //
DELIMITER ;
```

### Script verification (any dialect, and where creating objects is not allowed)

A `.sql` file of plain statements separated by `;` at the end of a line (no procedural blocks); the **last
statement** returns the `tc_id, result, detail` rows. The runner runs it in a transaction and rolls it back.

```sql
SELECT 'TC-S1-003' AS tc_id,
       CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS result,
       COUNT(*) || ' orphan order line(s)' AS detail
FROM order_line ol LEFT JOIN orders o ON o.order_id = ol.order_id
WHERE o.order_id IS NULL AND ol.order_id LIKE 'S1-%';
```

### Existing frameworks

A team already on tSQLt, utPLSQL or pgTAP keeps it: name each framework test after the TC ID and either export the
framework's JUnit report into `runs/<key>/` or wrap the results in a verification that returns the contract rows.
