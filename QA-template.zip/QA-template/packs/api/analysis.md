# API pack: analysis sections

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

`design-analysis` writes the common sections and fills these with API content. Start from the parsed contract:
`python3 scripts/parsers/openapi_inventory.py <spec.json|yaml>` writes `sources/parsed/api/<name>-inventory.md`.

## §3 Inventory: endpoints

`Endpoint (METHOD path) | Resource | Purpose | Auth / roles | Request (params, body schema) | Responses (codes) |
Idempotent | Source`

- One row per method + path in the contract, in contract order. These become mindmap level 1 and TC title prefixes.
- Endpoints in the requirements but not in the contract (or the reverse) → `Q-xxx`.

## §5 Data & field rules

Per request / response schema: `Field (JSON path) | In (body / query / path / header) | Type | Required | Format /
Enum / Range | Default | Read-only | Source`. Plus:
- **State model** per stateful resource: `From | Action (endpoint) | To | Refused with`.
- **Error model**: `Code | HTTP status | When | Message`.

## §6 Dependencies and mocks

`Dependency | Called by (endpoint) | IT stand-in (mock server + scenarios: ok / error / slow) | ST: real system |
Failure behaviour`.

## §8 Testable conditions: "Observable in"

`Observable in` = the response element (`status`, `header Location`, `body $.items[0].status`) or the read-back
request. Conditions visible only in the DB or logs → **Out of black-box scope**.

## §11 Fixtures

Auth tokens per role (named `TOKEN-<role>`), request bodies (`fixtures/api/<name>.json`, valid + one invalid per
rule), mock-server scenarios, seeded objects with known IDs (own and foreign, for BOLA).
