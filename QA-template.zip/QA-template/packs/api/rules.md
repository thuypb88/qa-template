# API pack: rules (R-API)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:29 (UTC+7)

Applies to every module with `"pack": "api"` in `project.json`, and to API test cases at ST. Adds to the core
rules ([standards/core-rules.md](../../standards/core-rules.md)).

## R-API1. Surface and oracle

1. A step is one HTTP exchange or one set-up action: "Send POST /v1/orders with body *order-valid* as role
   *buyer*", "Reset the mock payment service to *declined*". Name the method, path, role and fixture.
2. An expected result is what the response shows: status code, the named headers, exact body values at named JSON
   paths, schema match, or the state read back through the API ("GET /v1/orders/{id} returns status = PAID").
3. Not allowed as the oracle: database rows, log files, "works correctly". A side effect visible only in a DB
   belongs to an `etl` module or to the DEV's own tests (**Out of black-box scope**). **[script Warning]**
4. The TC carries an `api` block (see [tc-fields.md](tc-fields.md)); `steps` / `expected_result` still read as
   plain sentences, 1:1 (R4).

## R-API2. Contract first

- The contract (OpenAPI / Postman collection / interface spec) is the source of truth for paths, methods, fields,
  types, required flags, enums, formats and status codes. Cite it as `[OAS:<path> <method>]` or the line of the
  parsed inventory (`sources/parsed/api/<name>-inventory.md`).
- A response the contract does not define (e.g. an undocumented 500) is a defect or a `Q-xxx`, never an expected
  result.
- Spec vs. requirement differences → `Q-xxx`, never a silent pick (core R1.4).

## R-API3. Structure

- `layout: resource`: level 1 = resource or endpoint (`Orders`, `POST /v1/orders`), areas Contract → Request
  validation → Auth → Business rule → Errors → State.
- `layout: flow`: level 1 = API flow step (`Create order → Pay → Ship`), areas Main → Alternate → Exception →
  Business rule.
- Title prefix: `[<METHOD> <path>]` or `[<Resource>]`.

## R-API4. Levels

- **IT**: against the service under test with every dependency stubbed (mock server, `external_systems[].it =
  mock`). Fixtures: request bodies, auth tokens per role, mock responses.
- **ST**: the real dependencies; only chains across services, smoke, and the integration points (INT rows).
  Do not repeat field validation at ST.

## R-API5. Security (OWASP API Top 10, per the module's `security` value)

Broken object-level authorization (another user's ID), broken authentication (no / expired / tampered token),
property-level authorization (mass assignment, excess fields in the response), resource consumption (page size,
payload size, rate limit), function-level authorization (admin endpoint as user), sensitive business flows,
SSRF in URL fields, misconfiguration (CORS, verbose errors, TLS), inventory (old versions still served), unsafe
consumption of third-party APIs.
