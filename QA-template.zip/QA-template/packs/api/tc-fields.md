# API pack: test case block

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 08:34 (UTC+7)

Every API test case adds an `api` object to the common fields. `check_testcases.py` checks the required keys and the
`method` values; the export shows them as the Method / Endpoint / Auth / Request / Expected Response columns.

```json
"api": {
  "method": "POST",
  "endpoint": "/v1/orders",
  "auth": "TOKEN-buyer",
  "request": "fixtures/api/order-valid.json",
  "mock": {"payment": "approved"},
  "expect": {"status": 201, "schema": "Order", "headers": {"Location": "/v1/orders/{id}"},
             "body": {"$.status": "NEW", "$.total": 125.50}}
}
```

| Key | Required | Meaning |
|---|---|---|
| `method` | yes | GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS |
| `endpoint` | yes | Path as in the contract, with `{params}` |
| `expect.status` | yes | The one status code this TC expects |
| `expect.schema` / `headers` / `body` | no | Schema name; exact header values; JSON path → exact value |
| `auth` | no | Token fixture name (`TOKEN-<role>`), or `none` |
| `request` | no | Fixture file or inline object; data-driven rows list their variants in `test_data` |
| `mock` | no | Mock-server scenario per dependency (IT) |

A multi-request TC (write → read back) keeps the first request in `api` and states each later request in its step.
