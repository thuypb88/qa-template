# API pack: endpoint checklist

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

Applied by `design-cases` (checklist pass) to every row of the analysis's **Endpoint inventory**. Write a TC
only for a check that applies and that no existing TC covers; cite the ID in `notes`. Oracle **S** = the contract
or requirement states it (else Blocked + `Q-xxx`); **H** = heuristic, written as `Q-API-xxx: assumed …`, P3 or
lower. Never renumber IDs.

## C: Contract (Area: Contract)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| API-C01 | Response schema | every endpoint | The success response matches the documented schema: required fields present, types, formats, enums | S | IT | Contract / Auto |
| API-C02 | Status codes | every endpoint | Each documented status code can be produced and no undocumented one is returned for valid input | S | IT | Contract / Auto |
| API-C03 | Content type | every endpoint | `Content-Type` and charset match the contract; a wrong `Accept` gives the documented error | S | IT | Contract / Auto |
| API-C04 | Error body | error responses | Error responses use the documented error model (code, message, field) | S | IT | Contract / Auto |
| API-C05 | Versioning | versioned APIs | The documented version is served; a retired version gives the documented response | S | IT | Contract / Auto |

## V: Request validation (Area: Request validation)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| API-V01 | Required fields | request bodies, params | Each required field missing in turn → documented 4xx naming the field | S | IT | Negative / Auto |
| API-V02 | Types and formats | typed fields | Wrong type, format, enum value → 4xx; boundary min-1 / min / max / max+1 for lengths and numbers | S | IT | Boundary / Auto |
| API-V03 | Unknown fields | request bodies | Unknown or read-only fields are rejected or ignored as the contract says (never applied) | H | IT | Negative / Auto |
| API-V04 | Malformed body | request bodies | Invalid JSON, empty body, wrong encoding → 400 with no stack trace | H | IT | Negative / Auto |
| API-V05 | Query params | list endpoints | Filters, sort, unknown params, injection strings in params | S | IT | Negative / Auto |
| API-V06 | Payload size | request bodies, uploads | A body / field / file over the documented maximum → the documented 413 / 4xx, nothing stored | S | IT | Boundary / Auto |
| API-V07 | No side effect on refusal | write endpoints | After a refused request (any 4xx), reading back shows nothing created or changed — the error body alone does not prove it | H | IT | Negative / Auto |

## A: Auth (Area: Auth)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| API-A01 | No / bad token | protected endpoints | Missing, expired, malformed, wrong-audience token → 401 | S | IT | Security / Auto |
| API-A02 | Role matrix | protected endpoints | Each role in the RBAC matrix: allowed → 2xx, refused → 403 | S | IT | Security / Auto |
| API-A03 | Object ownership | endpoints with IDs | Another user's / tenant's object ID → 403 / 404, no data returned (BOLA) | S | IT | Security / Auto |
| API-A04 | Response properties | responses | No property the role may not see (PII, internal flags) | S | IT | Security / Auto |
| API-A05 | Revoked access | protected endpoints | A token issued before logout / user disabled / role removed is refused (within the documented window) | S | IT | Security / Auto |

## P: Pagination and collections (Area: Business rule)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| API-P01 | Page size | paged lists | Default, max and max+1 page size; total count matches the items | S | IT | Boundary / Auto |
| API-P02 | Stable order | paged lists | Paging through returns every item once, in the documented order — including items with equal sort keys (the documented tie-breaker) | H | IT | Functional / Auto |
| API-P03 | Empty list | lists | No match → 200 with an empty list (not 404), as documented | S | IT | Functional / Auto |
| API-P04 | Cursor misuse | cursor-paged lists | A tampered, expired or other-query cursor → the documented 4xx, never another user's / query's page | S | IT | Negative / Auto |

## I: Idempotency and state (Area: State)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| API-I01 | Repeat request | POST / PUT / DELETE | The same request twice (or with the same idempotency key) creates one effect | S | IT | Functional / Auto |
| API-I02 | Allowed transitions | stateful resources | Every allowed state transition succeeds; every refused one gives the documented 409 / 422 | S | IT | Functional / Auto |
| API-I03 | Concurrency | updatable resources | Two updates with the same version / ETag: one wins, the other gets 409 / 412 | S | IT | Negative / Auto |
| API-I04 | Read back | write endpoints | After a write, GET shows exactly the written values | S | IT | Functional / Auto |
| API-I05 | Idempotency key reuse | endpoints with an idempotency key | The same key with a **different** body → the documented conflict (409 / 422), not the first response replayed; after the key's lifetime it counts as new | S | IT | Negative / Auto |

## E: Errors and dependencies (Area: Errors)

| ID | Name | Applies to | Check | Oracle | Level | Type / Automation |
|---|---|---|---|---|---|---|
| API-E01 | Dependency down | calls to externals | Mock dependency down / slow → documented 502 / 503 / 504, no stack trace, no partial write | S | IT | Negative / Auto |
| API-E02 | Timeouts | slow dependencies | Response within the documented timeout; retry behaviour as documented | S | IT | Negative / Auto |
| API-E03 | No leakage | every error | Error bodies show no stack trace, SQL, server version or internal host | H | IT | Security / Auto |
| API-E04 | Error consistency | every endpoint | The same kind of error (validation, not found, forbidden) gives the same status code and error-model shape on every endpoint | H | IT | Contract / Auto |

## X: Moved to ST (R9)

| ID | Name | Check |
|---|---|---|
| API-X01 | Real dependencies | The chain with the real external systems (INT rows) |
| API-X02 | Load and rate limit | Throughput, latency percentiles, rate-limit headers under load (k6 / JMeter) |
| API-X03 | Transport | TLS versions, CORS, security headers on the real gateway |
