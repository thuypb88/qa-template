# API pack: scenario design

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 09:16 (UTC+7)

| Layout | Level 1 | Level 2 (Area), in this order |
|---|---|---|
| `resource` | one branch per resource or endpoint (contract order) | Contract → Request validation → Auth → Business rule → Errors → State |
| `flow` | one branch per API flow step | Main flow → Alternate flow → Exception → Business rule |

Cross-cutting last: Security, Performance, Compatibility, E2E.

**Leaf prefixes → type:** `[P]` Functional · `[CT]` Contract · `[N]` Negative · `[B]` Boundary · `[S]` Security ·
`[PF]` Performance · `[E2E]` E2E.

## Easy-to-miss coverage

1. **Every documented status code** has a scenario that produces it.
2. **Every required field** missing in turn — one data-driven scenario per endpoint, one row per field in the TC.
3. **Write → read back** for every write endpoint.
4. **Refused transitions** of each state model, not only the happy path.
5. **Foreign object IDs** (BOLA) for every endpoint that takes an ID.
6. **Dependency failure** per dependency the endpoint calls (down, slow, bad response).
7. **Idempotency** for every POST / PUT / DELETE the contract marks idempotent (or that money / state depends on),
   including the same key with a different body.
8. **Refusal leaves no trace:** after a refused write, read back — an error status alone does not prove nothing was
   stored.
9. **Revoked access:** a token from before logout / role removal is refused.
