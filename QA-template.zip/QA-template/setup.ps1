<#
.SYNOPSIS
    Install and set up a QA workspace (the template or a project) on this machine. Safe to re-run.

.DESCRIPTION
    PowerShell front end of scripts/workspace/setup_workspace.py, which does the work (one place for the logic):
      0. -InstallPrereqs: install what is missing with winget (Windows): Python 3.12, Git, Node LTS (UI pack only);
         elsewhere it prints the install command
      1. find Python >= 3.10 (py launcher, python3, python; the Microsoft Store stub is skipped)
      2. run setup_workspace.py: prerequisites, .venv + packages, Playwright, git hooks, init_project /
         sync_agents, Claude Code PATH (.claude/settings.local.json), verify
    Works in Windows PowerShell 5.1 and PowerShell 7 (Windows, Linux, macOS).

.EXAMPLE
    .\setup.ps1                          # set up this workspace
.EXAMPLE
    .\setup.ps1 -InstallPrereqs          # first install Python / Git / Node with winget, then set up
.EXAMPLE
    .\setup.ps1 -Check                   # report what is missing; change nothing
.EXAMPLE
    .\setup.ps1 -Packs all -SelfTest     # template: every pack, then the self-test
.EXAMPLE
    .\setup.ps1 -New ..\ACME-QA          # template: new project there, then set it up

.NOTES
    Blocked by the execution policy? Run once:  powershell -ExecutionPolicy Bypass -File .\setup.ps1
#>
[CmdletBinding()]
param(
    [switch]$Check,           # report only; install and write nothing
    [string]$Packs,           # ui,api,etl,sql or all (default: the packs in project.json)
    [string]$Driver,          # DB driver for a dialect: sqlserver, oracle, postgres, mysql, sqlite
    [string]$Venv,            # venv folder (default .venv)
    [switch]$NoVenv,          # install into the found Python instead (CI, containers)
    [switch]$NoClaudeEnv,     # leave .claude/settings.local.json alone
    [switch]$ScaffoldUi,      # scaffold Playwright in automation/ui now
    [string]$New,             # (template only) create a new project there, then set it up
    [switch]$SelfTest,        # (template only) run template-dev/tests/selftest.py after
    [switch]$InstallPrereqs   # install missing Python / Git / Node with winget first (Windows)
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Root = $PSScriptRoot
$OnWindows = $env:OS -eq 'Windows_NT'
$env:PYTHONUTF8 = '1'          # UTF-8 output from every Python tool, whatever the console code page
$env:PYTHONIOENCODING = 'utf-8'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }

function Find-Python {
    # The first interpreter >= 3.10 as @(exe, args...); $null when none.
    $candidates = @()
    if ($OnWindows) { $candidates += , @('py', '-3') }
    $candidates += , @('python3')
    $candidates += , @('python')
    foreach ($c in $candidates) {
        $cmd = Get-Command $c[0] -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $cmd) { continue }
        if ($cmd.Source -like '*\WindowsApps\*') { continue }  # the Store stub only opens the Store
        $extra = @($c | Select-Object -Skip 1)
        try {
            $ok = & $cmd.Source @extra -c 'import sys; print(sys.version_info >= (3, 10))' 2>$null
        } catch { continue }
        if ($LASTEXITCODE -eq 0 -and "$ok".Trim() -eq 'True') { return , (@($cmd.Source) + $extra) }
    }
    return $null
}

function Update-SessionPath {
    # winget changes the machine / user PATH; read it back into this session.
    if ($OnWindows) {
        $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                    [Environment]::GetEnvironmentVariable('Path', 'User')
    }
}

function Test-Tool([string]$Name) {
    return [bool](Get-Command $Name -CommandType Application -ErrorAction SilentlyContinue)
}

function Install-Prereq([string]$Name, [string]$WingetId, [string]$Hint) {
    if ($OnWindows -and (Test-Tool 'winget')) {
        Write-Host "  installing $Name ($WingetId) with winget ..."
        & winget install --id $WingetId -e --silent --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) { Write-Warning "winget could not install $Name (exit $LASTEXITCODE): $Hint" }
        Update-SessionPath
    } else {
        Write-Warning "$Name missing: $Hint"
    }
}

function Get-ProjectPacks {
    try {
        $p = Get-Content (Join-Path $Root 'project.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        return @($p.modules | ForEach-Object { if ($_.PSObject.Properties['pack']) { $_.pack } else { 'ui' } })
    } catch { return @() }
}

Write-Host "setup.ps1: $Root"

# 0 - prerequisites (opt-in install)
if ($InstallPrereqs -and -not $Check) {
    Write-Host '0. install prerequisites'
    if (-not (Find-Python)) {
        Install-Prereq 'Python 3.12' 'Python.Python.3.12' 'https://www.python.org/downloads/ (tick "Add python.exe to PATH"); Linux: sudo apt install python3 python3-venv'
    } else { Write-Host '  Python present' }
    if (-not (Test-Tool 'git')) {
        Install-Prereq 'Git' 'Git.Git' 'https://git-scm.com/downloads; Linux: sudo apt install git'
    } else { Write-Host '  Git present' }
    $wantUi = ($Packs -eq 'all') -or ("$Packs" -split ',' -contains 'ui') -or (-not $Packs -and (Get-ProjectPacks) -contains 'ui')
    if ($wantUi -and -not (Test-Tool 'node')) {
        Install-Prereq 'Node LTS' 'OpenJS.NodeJS.LTS' 'https://nodejs.org/ (LTS); Linux: nvm install --lts'
    } elseif ($wantUi) { Write-Host '  Node present' }
    if (-not (Test-Tool 'pdftotext')) {
        Write-Host '  pdftotext (PDF sources, optional): Windows: winget search poppler, or https://github.com/oschwartz10612/poppler-windows (add its bin\ to PATH); Linux: sudo apt install poppler-utils'
    }
}

$py = Find-Python
if (-not $py) {
    Write-Error ('Python 3.10+ not found. Re-run with -InstallPrereqs, or install it from https://www.python.org/downloads/ ' +
                 '(Windows: tick "Add python.exe to PATH"; turn off the "App execution aliases" for python.exe).')
    exit 1
}

# 1 - hand over to setup_workspace.py
if ($New -and -not [IO.Path]::IsPathRooted($New)) {  # relative to where you are, not to the workspace
    $New = [IO.Path]::GetFullPath((Join-Path (Get-Location).Path $New))
}
$argv = @((Join-Path $Root 'scripts/workspace/setup_workspace.py'))
if ($Check)       { $argv += '--check' }
if ($Packs)       { $argv += @('--packs', $Packs) }
if ($Driver)      { $argv += @('--driver', $Driver) }
if ($Venv)        { $argv += @('--venv', $Venv) }
if ($NoVenv)      { $argv += '--no-venv' }
if ($NoClaudeEnv) { $argv += '--no-claude-env' }
if ($ScaffoldUi)  { $argv += '--scaffold-ui' }
if ($New)         { $argv += @('--new', $New) }
if ($SelfTest)    { $argv += '--selftest' }

$exe = $py[0]
$pre = @($py | Select-Object -Skip 1)
Push-Location $Root
try {
    & $exe @pre @argv
    $rc = $LASTEXITCODE
} finally {
    Pop-Location
}
if ($rc -eq 0 -and -not $Check -and -not $NoVenv -and -not $New) {
    $venvDir = if ($Venv) { $Venv } else { '.venv' }
    $act = if ($OnWindows) { "$venvDir\Scripts\Activate.ps1" } else { "$venvDir/bin/Activate.ps1" }
    Write-Host "PowerShell: . $act  (then python3 scripts/pipeline_status.py)"
}
exit $rc
