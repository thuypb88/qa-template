# test-reports/

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:43 (UTC+7)

Test summary / exit reports for a cycle, sprint, level or release (`run-report` skill), one file each:
`<YYYY-MM-DD>-<slug>.md`. Project-owned and in git, unlike `runs/` (raw run output, not in git). Every number in a
report is recomputed from the recorded results in `test-cases.json` and from `project/defects.md`.
