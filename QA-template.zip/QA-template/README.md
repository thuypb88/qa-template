# QA-template — standard QA workspace

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 14:12 (UTC+7)

A reusable, agent-ready QA workspace: one method, one design system, four test types (UI, API, ETL, SQL). Give it a client's documents and
it produces analysis → scenarios → test cases (JSON + Excel) → automated tests → execution results, per module and for
the whole system — with every rule backed by a script and a guard, and a shared **project memory** that learns across reviews.
Distilled from the ALPHA QA workspace (2026-10).

## What is in it

| Layer | Where | What it gives every project |
|---|---|---|
| **Profile** | [project.json](project.json) | The only project-specific file: modules (pack + layout), levels and environments, external systems, variant sets, languages, ID formats, values, runners |
| **Method** | [.claude/skills/](.claude/skills/README.md) | 32 skills in eight groups by objective, named `<group>-<objective>`: `flow-` · `plan-` · `req-` · `design-` · `check-` · `auto-` · `run-` · `learn-`, plus the domain group `sql-` — each works at IT and ST and for every pack (ui · api · etl · sql) |
| **Standards** | [standards/](standards/) | Template-owned, the same in every project: core rules R1–R10, review protocol P1–P7, conventions (the design system), methods, cross-project lessons `L-Tnn` |
| **Test-type packs** | [packs/](packs/) | `ui` · `api` · `etl` · `sql`: rules, checklist, analysis sections, scenario layout, TC block, machine-readable `pack.json` |
| **Project memory** | [project/](project/index.md) | Project-owned, what any agent or person reads: project rules, system map, status, questions, decisions (ADR), lessons, change-impact records, defects, log |
| **Tools** | [scripts/](scripts/) | Standard-library Python. QA tools you run: config, init, extract, parsers (OpenAPI, STTM), checkers, Excel export, slicer, status, change tracing, runner, manual results. `scripts/workspace/`: the plumbing that runs on its own or on upgrade — setup, guard, backup, agent sync, template sync, git hooks |
| **Automation** | [automation/](automation/README.md) | Playwright (UI), pytest + API client (API), pytest + reconcile library (ETL), pytest + verification procedures (SQL), all bound to TC IDs |
| **Guardrails** | `scripts/workspace/guard.py`, [.claude/settings.json](.claude/settings.json), `scripts/workspace/git-hooks/` | Generated / template-owned files can't be hand-edited; checker Errors, version bumps, Excel export, stamps and agent sync are enforced at edit, end of turn and commit |

## Start a new project

```powershell
cd QA-template
.\setup.ps1 -New ..\ACME-QA -InstallPrereqs -Packs all   # copy the template, git init, hooks, .venv + packages
cd ..\ACME-QA
# put the client documents in sources\ (client\, requirements\, api\, etl\, sql\, testing\ — see sources/README.md)
claude                                                   # then: /plan-setup
```

Without PowerShell (Linux, macOS): `python3 scripts/workspace/setup_workspace.py --new ../ACME-QA --packs all`.

`plan-setup` reads the documents, drafts `project.json` and the project memory (`project/`), lists its assumptions as
`Q-INIT-nnn`, **waits for your confirmation**, then builds the module folders. From there `/flow-next` always names the
next skill. Examples: [template-dev/examples/alpha.project.json](template-dev/examples/alpha.project.json) (UI only),
[template-dev/examples/shop-demo/](template-dev/examples/shop-demo/README.md) (UI + API + ETL + SQL, with artifacts and tests).

## Set up a machine

[setup.ps1](setup.ps1) installs and sets up everything a workspace needs. Run it in a project folder after a fresh
clone, a new module pack or a template upgrade. It is safe to re-run: each run only does what is still missing.

### Set up everything

Windows (PowerShell 5.1 or 7), in the project folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1 -InstallPrereqs -Packs all -ScaffoldUi
```

Linux / macOS: install PowerShell 7 once (`sudo snap install powershell --classic`, macOS
`brew install --cask powershell`), then:

```bash
pwsh ./setup.ps1 -InstallPrereqs -Packs all -ScaffoldUi
```

The same without PowerShell: `python3 scripts/workspace/setup_workspace.py --packs all --scaffold-ui`.

### Switches

| PowerShell | Python flag | Effect |
|---|---|---|
| `-InstallPrereqs` | — | Install the missing Python 3.12, Git and (UI pack) Node LTS with winget on Windows; elsewhere print the install command |
| `-Packs all` | `--packs all` | Set up every pack (`ui,api,etl,sql`, or a list such as `ui,api`). Default: the packs in `project.json › modules`; api, etl, sql before `/plan-setup` |
| `-ScaffoldUi` | `--scaffold-ui` | Create the Playwright project in `automation/ui/` and install Chromium (needs Node) |
| `-Driver postgres` | `--driver postgres` | DB driver: sqlserver → pyodbc, oracle → oracledb, postgres → psycopg, mysql → pymysql. Default: `project.json › sql.dialect` |
| `-Check` | `--check` | Only report what is missing; install and write nothing |
| `-NoVenv` | `--no-venv` | Install into the found Python instead of `.venv/` (CI, containers) |
| `-Venv <dir>` | `--venv <dir>` | Another venv folder (default `.venv`) |
| `-NoClaudeEnv` | `--no-claude-env` | Leave `.claude/settings.local.json` alone |
| `-New <dir>` | `--new <dir>` | Template only: create a new project there, then set it up |
| `-SelfTest` | `--selftest` | Template only: run the self-test afterwards (creates `.venv/` in the template) |

### What it does

`setup.ps1` finds Python ≥ 3.10 (py launcher, `python3`, `python`; the Microsoft Store stub is skipped) and hands
over to [scripts/workspace/setup_workspace.py](scripts/workspace/setup_workspace.py):

| Step | What it does |
|---|---|
| 1. prerequisites | Python ≥ 3.10 and git (errors); `pdftotext` for PDF sources and Node for the UI pack (warnings with the install command) |
| 2. Python env | `.venv/` with openpyxl, PyYAML, pytest and the DB driver; on Windows also a `python3.exe` (the hooks call `python3`) |
| 3. Playwright | UI pack only, when Node is there: `npm install` in `automation/ui/` and the Chromium browser |
| 4. workspace | `git init` + `core.hooksPath`; a project with modules: `init_project.py`; otherwise `sync_agents.py` |
| 5. Claude Code | `.claude/settings.local.json` (per machine, git-ignored) puts the venv first on `PATH`, so hooks, tools and `run_tests.py` use it also when Claude Code starts from VS Code |
| 6. verify | `project.json` valid, `guard.py check`, and the runner variables still unset |

Nothing is installed system-wide except by `-InstallPrereqs`.

### After setup

1. Read the summary: `0 error(s)` means done; each `!` line names what is missing and how to fix it. Fix it (for
   example install Node) and run the same command again.
2. Restart Claude Code (in VS Code: *Developer: Reload Window*) so it uses the venv.
3. Before `run-tests`, set the runner variables the summary lists (`UI_BASE_URL`, `API_BASE_URL`, `ETL_SOURCE_DSN`,
   `ETL_TARGET_DSN`, `SQL_DSN`) in your shell or the CI secrets; never commit them.
4. To run the tools by hand, activate the venv first: `. .venv\Scripts\Activate.ps1` (Windows),
   `. .venv/bin/Activate.ps1` (pwsh on Linux / macOS) or `source .venv/bin/activate` (bash).

The template repo itself keeps no `.venv/`: run the full setup in a project, not in `QA-template/`.

## The pipeline

```mermaid
flowchart LR
    I[plan-setup] --> T[plan-changes] --> S[plan-scope] --> A[design-analysis] --> R1{{check-design}} --> D[design-scenarios] --> R2{{check-design}} --> W[design-cases] --> R3{{check-design}} --> AD[auto-decide] --> AT[auto-write] --> X[run-tests]
    R1 & R2 & R3 & X -.-> RT[learn-retro → project/]
```

| Level | Folder | Environment | External systems |
|---|---|---|---|
| IT — one module at a time | `test-design/it/MOD-<id>-<slug>/` | `project.json › levels.IT.env` | mocks / fixtures |
| ST — the whole system | `test-design/st/` | `levels.ST.env` | real / sandbox |

Each folder holds `0-scope.md` → `1-analysis.md` → `2-mindmap.md` → `3-test-cases/test-cases.json` (+ generated
Excel), each with its review ([standards/conventions.md](standards/conventions.md) §2).

## Test-type packs

| Pack | Surface (R2) | Inventory (mindmap level 1) | Areas | TC block | Automation |
|---|---|---|---|---|---|
| `ui` | what the tester sees | forms / screens, or flow steps | Display → Field validation → Buttons → Output | — | Playwright |
| `api` | the HTTP exchange | resources / endpoints, or API flow steps | Contract → Request validation → Auth → Business rule → Errors → State | `api {method, endpoint, auth, request, expect}` | pytest + `api_client` (data-driven) |
| `etl` | query results | target tables, or jobs | Completeness → Transformation → Data quality → Keys & integrity → History → Rejects | `etl {rule_id, reconcile, source_sql, target_sql, …}` | pytest + `reconcile` (data-driven) |
| `sql` | what a caller of the DB object gets back | DB objects (procedures, functions, views), or business flows | Parameters & validation → Business rules → Result set → Side effects → Transactions & errors → Concurrency | `sql {object, call, oracle, verify, …}` | pytest + `sql_verify` (verification procedures / scripts) |

One system tested at two surfaces = two modules (e.g. `W1` UI checkout and `A1` Orders API). A new test type (mobile,
performance, data migration) = a new pack folder with the same six files; no new skills.

## Standards and project memory

Two folders, split by owner:

- `standards/` is the **template's**: the rules every project follows (core rules, review protocol, conventions,
  methods) and the cross-project lessons `L-Tnn`. `template_sync` overwrites it; the guard blocks hand edits.
- `project/` is the **project's** shared memory, in git, readable by Claude, Codex and people alike: its own rules
  (`rules.md`, `PR-n`), system map, status, questions, decisions, lessons, change impact, defects and log. Agents'
  personal memory only points here.

`learn-retro` turns review findings and corrections into lessons (`L-nnn`, with evidence and a count), decisions into
ADRs, and repeated lessons into lasting fixes: a skill pitfall, a project rule, a script / guard check. Lessons general
enough for every project are promoted to [standards/template-lessons.md](standards/template-lessons.md) (`L-Tnn`),
which reaches every project on the next `template_sync`.

A **second agent** can review what the first wrote: set `project.json › agents.reviewer` (`codex` or `copilot`);
the review protocol (P7) makes the reviewer record itself and surface disagreements.

## Other agents: Codex and GitHub Copilot

Claude Code is the source (`CLAUDE.md`, `.claude/skills/`); `python3 scripts/workspace/sync_agents.py` writes the mirrors listed
in `project.json › agents.mirrors`:

| Agent | Instructions | Skills | Extra |
|---|---|---|---|
| Codex | `AGENTS.md` | `.agents/skills/` | — |
| GitHub Copilot (cloud agent, CLI, VS Code, Visual Studio agent mode) | `.github/copilot-instructions.md` (CLAUDE.md + a Copilot preface, links rebased) | `.github/skills/` | `.github/instructions/*.instructions.md`: path rules (`applyTo`) for test cases, mindmaps, analyses, `sources/`, `automation/` |

The skills use the agentskills.io `SKILL.md` format, which all three read, so the skill copies are identical. Copilot
runs none of the Claude Code hooks: its instructions tell it to run `python3 scripts/workspace/guard.py check` before finishing,
and the git pre-commit hook enforces the same rules for every agent. Copilot also scans `.claude/skills/` and
`.agents/skills/`; if it lists a skill twice, remove the mirror you don't use from `agents.mirrors`.

## Folder layout

```text
<project>/
├── project.json · CLAUDE.md · AGENTS.md (generated) · README.md · CHANGELOG.md · TEMPLATE_VERSION · setup.ps1
│   template-manifest.json (what the template owns, seeds, moved and renamed)
│
│   ── inputs ─────────────────────────────────────────────────────────────────────────────
├── sources/        read-only: client/ requirements/ api/ etl/ sql/ testing/ · parsed/ + trace/ (generated)
│
│   ── rules (template-owned) ─────────────────────────────────────────────────────────────
├── standards/      core-rules · review-protocol · conventions · skill-architecture · template-lessons · methods/
├── packs/          ui/ api/ etl/ sql/ — pack.json, rules, checklist, analysis, scenarios, tc-fields
│
│   ── project work (project-owned, in git) ───────────────────────────────────────────────
├── project/        memory: index · rules · system-map · status · questions · lessons · defects · log ·
│                   decisions/ · change-impact/
├── plans/          strategy, discovery, requirement reviews, stories, use cases, regression sets, sprints, releases
├── test-design/    the test basis per level: 0-scope → 1-analysis → 2-mindmap → 3-test-cases/
│   ├── it/         INDEX.md (generated) · MOD-<id>-<slug>/ per module (IT)
│   └── st/         the whole system (ST): + nfr-plan.md
├── automation/     tc_binding.py · pytest.ini · ui/ · api/ · etl/ · sql/
├── test-reports/   test summary / exit reports (run-report)
│
│   ── tooling ────────────────────────────────────────────────────────────────────────────
├── scripts/        QA tools · parsers/ · workspace/ (setup_workspace, guard, backup, sync_agents, template_sync, git-hooks/)
├── .claude/        settings.json (hooks, permissions) · skills/ (source)
├── .agents/        Codex skills (generated, with AGENTS.md)
├── .github/        copilot-instructions.md + skills/ (generated) · instructions/ (Copilot path rules)
├── .harness/       check-baseline.json: ratcheted checker Errors (guard.py baseline)
│
│   ── generated, not in git ──────────────────────────────────────────────────────────────
├── .venv/          Python env (setup_workspace.py) · .claude/settings.local.json: per-machine PATH
├── runs/           raw run output from run_tests.py: run-summary, results.csv, JUnit, manual checklists, evidence
└── ../<CODE>-backups/    mirror + daily bundles (outside the repo)
```

Only in the template repo, never copied to projects: `template-dev/` — `tests/` (self-test, skill evals) and
`examples/` (sample profiles, the `shop-demo` project).

## Upgrading a project

```bash
cd ../ACME-QA
python3 scripts/workspace/template_sync.py --from ../QA-template          # dry run: add / update / move / seed / stale
python3 scripts/workspace/template_sync.py --from ../QA-template --apply  # then read CHANGELOG.md, init_project.py, commit
```

A project older than **1.10.0** still has `scripts/template_sync.py`: run the template's copy instead
(`python3 ../QA-template/scripts/workspace/template_sync.py --from ../QA-template --apply`). Moved folders
(`template-manifest.json › moved`) are `git mv`ed first and the git hooks path follows; the CHANGELOG entry of every
version in between lists what to do by hand.

The template owns rules, packs, scripts and skills (`template-manifest.json › template_owned`; the guard blocks hand
edits in projects). The project owns `project.json`, `project/`, `plans/`, `test-design/`,
`test-reports/`, its sources and its automated tests. Improve a skill or rule in the template, run the self-test, bump `TEMPLATE_VERSION`, then sync each project.

## Self-test

```bash
python3 template-dev/tests/selftest.py --python ../ACME-QA/.venv/bin/python   # 36 checks, with a project's venv (pytest)
python3 template-dev/tests/selftest.py                                        # without pytest: API / ETL / SQL runs skipped
```

On Windows: `python template-dev\tests\selftest.py --python ..\ACME-QA\.venv\Scripts\python.exe`.
`setup.ps1 -SelfTest` also works but leaves a `.venv/` in the template.

It builds a project from the template plus [template-dev/examples/shop-demo/](template-dev/examples/shop-demo/README.md),
runs every tool and hook on it, commits through the hooks, traces a source change, runs a real API test against a stub
and real ETL and SQL runs on SQLite with planted defects, records manual results, and upgrades a copy on the old
folder layout with `template_sync`. It also checks every skill (name, group, links, retired names) and the shape of
the behaviour evals in `template-dev/tests/skill-evals/`. Run it before every template release.

## Working on the template itself

`project.json` here is the skeleton new projects start from (`guard.template_dev: true` lets you edit template-owned
files in this repo only). A release: change the template, run the self-test, bump `TEMPLATE_VERSION` and
`project.json › template_version`, add a CHANGELOG entry (what changed, migration, self-test result), add a
`template-manifest.json › moved` pair for every renamed path, run `scripts/workspace/sync_agents.py`, commit and tag
`v<version>`. Keep scripts standard-library; keep skills under ~200 lines with long formats in
`references/`; every rule a script can check goes into the script and the guard (L-T17).
