# Lessons: cross-project (template-owned)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

Lessons that hold for any project. They travel with the template; `template_sync.py` brings new ones to every
project. Project-only lessons stay in `project/lessons.md`. A project lesson seen in two projects (or obviously general)
is promoted here by the `learn-retro` skill's **Promote to template** list. Skills point to the IDs that concern them.

Format: `L-Tnn · Where it bites · Lesson · Evidence (project, artifact, date)`.

| ID | Where | Lesson | Evidence |
|---|---|---|---|
| L-T01 | design-analysis, check-design | **Claiming a source gap without reading it.** Open the source before writing "not stated"; a missing section is often in another file or an image. | ALPHA: test plan §3.4 called empty; it held the full mocking table (2026-10-12) |
| L-T02 | design-analysis, design-scenarios | **Neighbour conflicts.** Read the hand-offs of the modules on both sides; raise one question citing both when they disagree. | ALPHA E5 vs E6 session-expired behaviour (Q-ST-047) |
| L-T03 | design-scenarios | **"Any variant" conditions hide the one that behaves differently.** One scenario per variant (R10). | ALPHA five forms (2026-10-13) |
| L-T04 | design-cases | **Porting old bodies.** Rewriting a suite by copying the previous version left 107 TCs with stale bodies and filler steps while the script was clean. Write each TC from its scenario and field table; run `slice.py tc --patterns`. | ALPHA E1 v0.5 |
| L-T05 | check-design | **A clean script is not quality.** Scripts check structure and counts, not whether a body tests its title. | ALPHA E1 v0.5 (Pass with fixes → should have been Rework) |
| L-T06 | check-design | **Spot-checking only.** 20 of 262 TCs checked missed a suite-wide defect. Scan the whole suite for patterns first; one finding can cover them all. | ALPHA E1 v0.5 |
| L-T07 | design-cases, design-analysis | **Invented fixture data** (user IDs, accounts, names). Use the analysis §11 fixture names, or an assumed value + `Q-xxx` for the QA lead. | ALPHA E6 staff IDs |
| L-T08 | design-cases | **Real external systems at IT.** IT uses mocks / fixtures only (R9). | ALPHA E1: 14 TCs used a real mailbox |
| L-T09 | design-cases | **Generic set-up repeated in every TC** hides the one condition that matters. One baseline item (R3.3). | ALPHA 2026-10-13 QA lead comment |
| L-T10 | all writers | **Generating artifacts from a scratchpad script.** It is lost at session end; after the first build, edit the file directly. | ALPHA E1 mindmap and TCs |
| L-T11 | check-design | **Silent picks.** A source conflict resolved without a `Q-xxx` is a finding even when the pick looks right. | ALPHA E7 mock direction |
| L-T12 | check-design | **One upstream cause = one finding** (Fix upstream), listing the affected items. | ALPHA E6 TR-001 |
| L-T13 | design-scenarios | **100 % condition coverage ≠ done.** Walk the pack's "easy-to-miss" list per level-1 item by hand. | ALPHA E1 mindmap: 2 High at 100 % TCOND |
| L-T14 | auto-decide | **Trusting a keyword tagger.** A TC that POSTs to an API was tagged as plain UI Auto. Decide gate by gate. | ALPHA E4 TC-006 |
| L-T15 | auto-decide, status | **Stale counts.** Always recount from the JSON; a suite grew 192 → 565 TCs between docs. | ALPHA E1 feasibility |
| L-T16 | design-analysis | **Literal wording of the test plan.** "Mock server X" when X actually calls us means we are the server. Raise a `Q-xxx` with the assumption. | ALPHA E7 partner system |
| L-T17 | all | **Rules only in prose drift.** Put each rule that a script can check into a script and the guard (ratchet the existing errors). | ALPHA harness guard (2026-10-15) |
| L-T18 | all | **Large artifacts blow the context.** Map first (`slice.py toc`), then read the section the step needs. | ALPHA E1: 1.4 MB JSON |
