# Conventions: the workspace design system

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 14:18 (UTC+7)

The fixed shapes every project built from this template shares: folders, file names, IDs, statuses, document
headers, test case fields, Excel columns and commit messages. Skills and scripts depend on them; change them here
and in the scripts together, in the template, never in one project.

## 1. Folder ownership

| Path | Owner | Edited by hand? |
|---|---|---|
| `project.json` | project (`plan-setup`) | yes, the one project file |
| `standards/`, `packs/`, `scripts/` (incl. `workspace/`), `.claude/skills/`, `automation/*/conftest.py` | template | no — change the template, then `template_sync.py` |
| `project/`, `automation/` tests and data | project | yes |
| `plans/` (strategy, discovery findings, requirement reviews, proposed stories and use cases, regression sets, sprint and release records), `test-reports/` | project (planning, requirements, workflow and report skills) | yes — proposals become a test basis only when the confirmed version is added to `sources/` |
| `sources/` (except `parsed/`, `trace/`) | client documents | no — the user adds / replaces files |
| `sources/parsed/`, `sources/trace/` | scripts | no (generated) |
| `test-design/it/<MOD>/0-scope.md` | `init_project.py` + `plan-scope` skill | only inside `<!-- MANUAL:START/END -->` |
| `test-design/it/<MOD>/sources.json` | `init_project.py` | no (generated) |
| `test-design/it/<MOD>/1-…`, `2-…`, `3-test-cases/test-cases.json` | writer skills | yes (through the skills) |
| `*.xlsx` under `test-design/` | `export_testcases.py` | no (generated from the JSON) |
| `AGENTS.md`, `.agents/skills/` (Codex) · `.github/copilot-instructions.md`, `.github/skills/` (GitHub Copilot) · `GEMINI.md`, `.gemini/skills/` (Gemini CLI) | `sync_agents.py` | no (copies of `CLAUDE.md`, `.claude/skills/`) |
| `.github/instructions/*.instructions.md` (Copilot path rules) | template | no — change the template |
| `runs/` | `run_tests.py` (raw run output: results, JUnit, manual checklists, evidence) | no; not in git |
| `.harness/check-baseline.json` | `guard.py baseline` (checker Errors that already exist) | no (generated) |
| `template-dev/` (`tests/`, `examples/`) | template repo only (self-test, skill evals, sample projects) | not copied into projects |

`scripts/workspace/guard.py` blocks edits to the "no" rows.

## 2. Level folder layout

```text
<level folder>/                  test-design/it/MOD-<id>-<slug>/  or  test-design/st/
├── 0-scope.md                   generated + MANUAL block (scope, dependencies, readiness, first questions)
├── sources.json                 generated: this module's sources and their hashes
├── 0-sources/                   optional: links / copies of the module's sources
├── 1-analysis.md                + 1-analysis-review.md
├── 2-mindmap.md                 + 2-mindmap-review.md
├── nfr-plan.md                  test-design/st/ only: non-functional plan (design-nfr)
├── exploratory/                 ET-NNN-<slug>.md session charters, logs, debriefs (run-explore)
└── 3-test-cases/
    ├── test-cases.json          the source of truth
    ├── <suite>_Test_Cases_v<version>.xlsx    generated (<suite> = module folder, or ST); older ones in history/
    ├── checklist-pass.md        the pack checklist matrix (UI pass / API / ETL checklist)
    ├── test-cases-review.md
    ├── automation-plan.md       from auto-decide
    ├── automation-review.md     optional, from review (automation)
    ├── test-data.md             data requirements, sets, cleanup (design-data)
    └── history/
```

## 3. IDs

Formats come from `project.json › ids` (defaults below). IDs are never renumbered and never reused; new items take
the next free number. The one exception is a scenario rebuild with a **TS mapping** section.

| Item | Default | Scope |
|---|---|---|
| Module folder | `MOD-{id}-{slug}` | project |
| Business rule | `BR-<req>-<n>` | module |
| Acceptance criterion | `AC-NN` | module |
| Test condition | `TCOND-NNN` | module / ST |
| Scenario | `TS-NNN` | module / ST |
| Test case | `TC-{id}-NNN` · `TC-ST-NNN` | module · ST |
| Question | `Q-NNN` · `Q-ST-NNN` · `Q-UI-NNN` / `Q-API-NNN` / `Q-ETL-NNN` (heuristic checklist) · `Q-INIT-NNN` | module · ST · pack · set-up |
| Fixture | `<KIND>-<name>` (e.g. `TOKEN-buyer`, `ETL-FX-DIM_CUSTOMER-03`, `MOCK-PAYMENT-declined`) | module |
| Mapping rule (ETL) | `MAP-<TABLE>-NN` | module |
| Checklist check | `GUI-xNN` · `API-xNN` · `ETL-xNN` | pack |
| Review finding | `RV-` · `MR-` · `TR-` · `AR-` (ST: `SR-` · `SMR-` · `STR-` · `SAR-`) | review |
| Requirement review finding | `RQ-NNN` | project (`plans/requirement-reviews/`) |
| User story (proposed) | `US-<code>-NNN`, or the client's scheme | project (`plans/stories/`) |
| Use case (proposed) | `UC-<module>-NN` (`.AC.n` alternative, `.EX.n` exception), or the client's scheme | project (`plans/use-cases/`) |
| Test data requirement | `TDR-NNN` | folder (`test-data.md`) |
| Non-functional item | `NFR-NNN` | ST (`nfr-plan.md`) |
| Exploratory session | `ET-NNN` | folder (`exploratory/`) |
| Defect | `DEF-NNN` (+ the tracker's ID when there is one) | project (`project/defects.md`) |
| Follow-up | `FU-NNN` | `project/status.md` |
| Decision | `ADR-NNN` | `project/decisions/` |
| Lesson | `L-NNN` | `project/lessons.md` |

## 4. Test case fields (`test-cases.json`)

```json
{
  "module": "<module name exactly as in project.json>",
  "version": "0.1",
  "test_cases": [{
    "tc_id": "TC-E4-001", "scenario_id": "TS-001", "srs_ref": ["FR-010"], "use_case": "UC-002",
    "test_type": "Functional", "priority": "P2 - High",
    "title": "[<Level-1 item>] <behaviour>", "description": "<why this row exists>",
    "preconditions": ["<baseline item>", "<special condition>"],
    "steps": ["…"], "test_data": {"<name>": "<value>"}, "expected_result": ["…one per step…"],
    "status": "Not Started", "notes": "TS-001 · Area: … · Technique: … · Q-004: assumed …",
    "automation": "Auto", "automation_note": "",
    "pack": "ui", "api": {}, "etl": {}
  }]
}
```

- `pack` only when it differs from the module's pack (mixed ST suites); the `api` / `etl` block only for that pack.
- Lists are unnumbered; the export numbers them.
- Bump `version` on every change (0.1 → 0.2; a rebuild may go to 1.0). The export names the Excel by it and moves
  older Excel files to `history/`. Execution results (`cycle`, `result`, `executed_on`, `defect_id`, `tester`) are
  added by `run_tests.py --record <cycle>` (automated) and `record_manual.py <target> <csv> --cycle <cycle>` (manual).
  Results: Passed · Failed · Skipped · Blocked · Not Run.

## 5. Excel columns

`TC ID · Module · Scenario · Requirement · Use Case · Test Type · Priority · Title · Description · Preconditions ·
Test Steps · Test Data · Expected Result · Status · Automation · Automation Note · Checklist · Notes`, then the pack
columns (`packs/<pack>/pack.json › excel_columns`), then any execution columns. Sheet 2 is **RTM** (requirement →
TCs), sheet 3 **Summary** (counts by type / priority / status / automation).

## 6. Document header

Every hand-written Markdown doc, rule and skill starts with:

```markdown
# <Title>

> **Created:** YYYY-MM-DD HH:MM · **Updated:** YYYY-MM-DD HH:MM (<project timezone>)
```

Keep Created; set Updated whenever the content changes (the guard checks this at commit). Generated files carry a
`Generated on` line instead. Artifact titles are fixed so scripts can find them: `# <module name>: analysis`,
`# <module name>: test mindmap`, `# <module name>: <artifact> review`.

## 7. Citations

`[KEY:line](relative/path#Lnn)` for parsed sources (a citation-key table opens every analysis), `(FR-xxx)` for a
requirement, `Source: <doc> §<section> p.<n>` for client documents, `Q-xxx` for an assumption. Links are relative
to the file that holds them.

## 8. Language

Docs, reviews and test case content in `project.document_language` (default English). UI labels exactly as shown, in
their own language (English in parentheses when useful).

## 9. Git

Commit after each change set, with a message naming the folder, artifact and version:
`E4 test cases v0.3: review fixes TR-001…007`. Local only unless `project.json › git.local_only` is false. The
post-commit hook tags each suite version (`tc/<folder>/v<version>`) and backs up (`scripts/workspace/backup.py`).
