# Core rules (R1–R10)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:43 (UTC+7)

The rules every analysis, scenario set and test case follows, for every project and test type. Writer skills follow
them; the `check-design` skill checks them. **[script]** = also checked by `scripts/check_testcases.py` or
`scripts/check_scenarios.py`. Each pack adds its own rules (`packs/<pack>/rules.md`: R-UI, R-API, R-ETL, R-SQL), and the
project adds `project/rules.md` (PR-n). Order of precedence: core → pack → project; a project rule may
tighten a core rule, never loosen it.

Origin: the ALPHA QA workspace (2026-10), generalised. The values these rules refer to (levels, environments,
external systems, languages, variant sets, ID formats, allowed values) live in `project.json`.

## R1. Sources

1. Read the client documents (`sources.client_docs`) as well as the module's own sources (`0-sources/`). Copy any
   new client file in before you start, and run the `plan-changes` skill.
2. Coverage is measured against the client's acceptance criteria as well as the requirement IDs (FR / UC / API /
   mapping rule). A criterion with no test is a gap, even at 100 % requirement coverage.
3. When an expected value comes from a client document, not the spec, cite it (`Source: BRD §S1 p.5`).
4. When two sources disagree, don't pick one silently: raise a `Q-xxx` with both pieces of evidence and the
   proposed assumption.
5. The project names its newest definition per kind of source in `sources.precedence` (e.g. "the field-mapping
   workbook beats the SRS for fields"). Follow it, and still raise each difference as a `Q-xxx`.
6. Never write into `sources/`. Extract binary documents with `scripts/extract_text.py` (it writes
   `sources/parsed/`, which is generated).

## R2. Observable at the pack's surface

Every step is something a tester (or a script acting as one) does at the module's surface, and every expected result
is something observable there. The surface is defined by the pack: **UI** = the screen and its output (R-UI1),
**API** = the HTTP exchange (R-API1), **ETL** = query results over source and target (R-ETL1), **SQL** = what a caller of the database object gets back:
rows, output parameters, return codes, errors, table state read back by a query (R-SQL1). A check that can't
be observed at the surface goes to **Out of black-box scope** with the layer that covers it — never a test case
that peeks under the surface. **[script: forbidden terms per pack]**

## R3. Preconditions

1. One condition per item. Each is something a tester can set up: a role, a fixture, data in a given state, a
   build, a tool.
2. Don't number them; the export does. **[script]**
3. Only the conditions special to this TC. The generic set-up is **one** baseline item from the analysis §11
   (`"<Project> <env> is running normally"`, `"… connected to <system> (mock data)"`, naming only the systems
   this TC uses). Never "browser is open", "network is available", "services are up".

## R4. Steps ↔ expected results

1. `expected_result` has exactly one entry per step, in the same order. **[script]**
2. Every step has an observable result, set-up steps included; a step with nothing to observe is merged into the
   next one.
3. Don't number steps or results. **[script]**
4. One TC verifies one behaviour. Positive and negative checks are separate TCs; so are variants with different
   expected results.
5. One outcome per entry: not "rejected or rounded", not "as expected", not "works correctly". If the rule is
   open, use the analysis's assumption and cite the `Q-xxx`. **[script: vague words]**

## R5. Title and structure

1. Title = `[<Level-1 item>] <behaviour verified>`; the level-1 item is the inventory name (screen, endpoint,
   target table, flow step). **[script]**
2. Test cases follow the scenario order, which follows the pack layout (level 1 → areas, then cross-cutting
   branches). Never organise by requirement ID in a form / resource / table module.
3. The structure is set in `2-mindmap.md`; `design-cases` keeps it. **[script: check_scenarios.py]**

## R6. Test data

1. Concrete values: real lengths, formats, codes and messages from the analysis or the client documents. Not
   "valid value", not "max length".
2. Unknown value → an assumed value with its `Q-xxx`, or `status` Blocked with the reason in `notes`.
3. **Languages.** When `project.json` lists more than one language, every free-text input gets one Localization
   TC per language (`R6.3`), with a sample that would expose a font or encoding error (diacritics, CJK). Digit-only
   fields don't. A module that only shows text entered elsewhere gets one per language per variant.

## R7. Test techniques

Name the technique in `notes` when it isn't obvious from the type.

| Technique | Use for |
|---|---|
| Equivalence partitioning | Formats, option lists, roles, codes |
| Boundary value (min-1 / min / max / max+1) | Lengths, amounts, dates, sizes, counts, page sizes |
| Decision table | Combined conditions (type × branch, role × status) |
| State transition | Statuses, button states, resource states, job states |
| Use case / E2E | Main and alternate flows across modules |
| Pairwise | Many independent parameters (forms, configurations) |
| Error guessing / exploratory | Unusual input, interrupted flows |
| Reconciliation (ETL) | Counts, sums, key diffs between two data sets |

Security techniques are per pack (R-UI3, R-API5, R-ETL6), applied by the module's `security` value.

## R8. Fields and values

- `test_type`, `priority`, `status`, `automation` use only the values in `project.json › values` (plus the pack's
  `extra_test_types`). **[script]**
- Every open question a TC relies on is in `notes` as `Q-xxx: assumed <value>`. **[script]**
- `notes` keep one order so they filter well: `TS-xxx · Area: … · Technique: … · <checklist ID / R6.3 / R10> ·
  Q-xxx: assumed …`, then any remark. No version history in notes.
- `description` says why the row exists in one sentence; it doesn't repeat the title.
- One row, one status: partitions with different expected results are separate rows. One rule checked item by
  item (each required field emptied in turn) may stay in one row, one step per item.
- An open question with no usable assumption makes the row Blocked (`Blocked: Q-xxx <reason>`); when answered, the
  row goes back to Not Started and keeps its ID.
- `automation` says how the TC runs (Auto / Manual / Auto + Manual); `automation_note` says why or what it needs.
  Set by `auto-decide`.

## R9. Test levels

The levels, environments and folders are in `project.json › levels`. The default pair:

| | **IT** (per module) | **ST** (whole system) |
|---|---|---|
| Folder | `test-design/it/<MOD-folder>/` | `test-design/st/` |
| Question | Does each module meet its spec at its surface? | Does the business flow work end to end with the real systems? |
| External systems | Mocks / fixtures (`external_systems[].it`) | Real or sandbox (`external_systems[].st`) |
| Scope | Fields, rules, states, RBAC per screen / endpoint / table, the module's flows | E2E chains, UC walkthroughs, integrations (INT rows), RBAC matrix end to end, smoke, NFRs, the checklist `X` rows |
| Not here | What the test plan marks "out of scope for IT" → listed as **Moved to ST**, never dropped | Field-level checks IT already covers (reference the IT TCs) |
| IDs | `TC-<id>-NNN`, `Q-NNN` | `TC-ST-NNN`, `Q-ST-NNN` |

1. Fixtures may be named in preconditions; steps and results still follow R2.
2. In ST, a step done by another team is written as a request, and its effect is checked at the surface.
3. Name environments exactly as `project.json` does; never use a bare word that also names a test level.

## R10. Variant coverage

`project.json › variant_sets` lists sets whose members behave differently (e.g. the five instruction forms, the
three source systems, the two customer types). A flow that handles a variant set covers **each member**: a valid
and an invalid case each, in its own scenario and TC, titled `[<Flow step> – <Variant>]`. Never "any form", never
one TC listing all members. The project names which modules handle which set (`modules[].variants`).
