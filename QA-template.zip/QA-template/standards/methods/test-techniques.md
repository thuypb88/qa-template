# Test design techniques: how to apply them

> **Created:** 2026-10-16 09:16 · **Updated:** 2026-10-16 10:50 (UTC+7)

Read by `design-scenarios` when it fills the **Technique** column, and by `check-design` (scenarios, test cases) when it
judges whether a technique was applied or only named. A technique is evidence of *how* the scenario set was derived;
naming it without doing its steps is a finding (Med).

## 1. Which technique for which rule shape

| The analysis shows… | Technique | Section |
|---|---|---|
| a field / parameter / column with types or allowed values | equivalence partitioning | §2 |
| a min / max, length, amount, date or count limit | boundary value analysis | §3 |
| an outcome that depends on two or more conditions together | decision table | §4 |
| a status field, lifecycle or workflow (BR states, allowed / refused moves) | state transition | §5 |
| several independent factors (variants, roles, channels, languages, browsers) whose combinations explode | pairwise | §6 |
| a dependency, a write, a retry, a timeout, a permission | failure paths | §7 |
| a use case (normal / alternative / exception courses) or Given-When-Then criteria | use-case / scenario testing | §10 |
| anything left after §2–§7, or a rule with defect history | edge dimensions / error guessing | §8 |

Most items need more than one: a validated field is §2 + §3; a decision button is §4 + §7. Write each in the
column as `equivalence partitioning + boundary value`.

**Common rule for every technique:** derive only from values the analysis cites. An unknown limit, precision,
precedence or error code is never filled from habit — the scenario says `Q-xxx: assumed …`, or is Blocked.

## 2. Equivalence partitioning

1. Partition by **behaviour**, not by the shape of the input: two values are in one class only if the source gives
   them the same outcome (accepted, the same error message / status code / reject reason).
2. Keep invalid classes apart when their outcomes differ: "empty" (mandatory message) and "wrong format" (format
   message) are two scenarios, not one "invalid value".
3. Dependent fields partition together (region × postcode, role × action): the class is the pair.
4. One representative per class; the representative keeps every condition that defines the class.
5. Values the source does not classify stay an open class with a `Q-xxx`, not silently "valid".

**Done when:** every class the source names has a scenario; every distinct error outcome has its own; unclassified
values are questions.

## 3. Boundary value analysis

1. Per limit, record from the source: the bound, inclusive or exclusive, the **unit and smallest step** (1 for
   integers; the currency's minor unit for amounts; the stated precision for decimals; the day / second / timezone for
   dates), and for text whether the length counts characters, bytes or code points.
2. Scenarios: below, on, and above each bound (`min-1 / min / max / max+1` in that step). Integer step 1 is wrong for
   amounts (0.01?), byte-limited text with diacritics / CJK, or date-times.
3. Unknown step or unit → write the bound symbolically (`max+1 step`) and raise `Q-xxx`; never invent 0.01 or a
   timezone.
4. Boundaries pair with partitions (§2): the boundary scenario belongs to the class it sits in.

**Done when:** every cited limit has its on / off pairs with the right step; text limits say what is counted.

## 4. Decision table

1. List the **conditions** (discrete; split a continuous condition into the source's ranges), the **actions /
   outcomes**, and any stated precedence.
2. For a small table (≤ 4 conditions), enumerate every combination and match it to a rule. Look for:
   - **no rule matches** a legal combination → gap, `Q-xxx`;
   - **two rules match** with different outcomes → conflict, `Q-xxx` (never choose by row order);
   - a rule **no combination reaches** → dead rule, question.
3. Merge columns ("don't care") only when the source shows the outcome does not depend on that condition; list the
   merged combinations in the scenario's Refs.
4. One scenario per rule column (plus its key boundary from §3). Large tables → pairwise (§6) for the legal
   combinations plus every rule column at least once.

**Done when:** every rule column has a scenario; gaps, overlaps and dead rules are questions.

## 5. State transition

1. Build the table from the source: `state | event | guard | action / side effect | next state`; mark the initial and
   final states.
2. Scenarios for every **allowed** transition and every **refused** event per state the user (or caller / job) can
   trigger at the surface — the refused one shows the documented message / status code and the state unchanged.
3. Guards are boundaries: true and false side of each guard (§3 when it is a limit).
4. The expected result names the **next state and the side effect** a tester can see (notification, list entry,
   balance, audit line on screen). A failure mid-transition: the state the source promises (unchanged, or the
   documented intermediate) — unknown → `Q-xxx`.
5. States no event reaches, or events with no defined outcome → questions.
6. Long flows (ST, E2E): one scenario per path the business cares about (happy path, each rejection, each
   re-submission), not every path.

**Done when:** every allowed edge, every refused event per reachable state and every guard side has a scenario.

## 6. Pairwise (all-pairs)

1. List the factors and their values from the analysis (R10 variant sets, roles, languages, channels…) and the
   **constraints** (combinations that cannot exist).
2. Generate the smallest set of legal combinations in which every pair of values appears at least once; a combination
   that breaks a constraint is not a test.
3. Add, on top, the higher-order combinations a risk or defect history points at (three factors that interact).
4. Pairwise never replaces R10 / R6.3: each variant and each language still gets its own valid + invalid scenario;
   pairwise only chooses the *mix* of the other factors.
5. Say in Refs that the set is pairwise, with the factor list, so a reviewer can recompute it.

**Done when:** every legal pair is covered (list the uncovered ones, if any, with the reason), constraints applied.

## 7. Failure paths

Walk each class per item; each one that applies at the surface is a scenario, otherwise Out of black-box scope.

| Class | Scenario shape | Expected result names |
|---|---|---|
| Invalid input | one violated constraint, everything else valid | the documented message / status / reject reason |
| Not allowed | wrong role, other owner's object, expired session / token | the refusal **and** that nothing changed |
| Dependency down / slow / bad answer | per dependency (IT: the mock's fault scenario) | the documented message / status; no partial write |
| Timeout | the documented timeout passes | what the user / caller sees, the state after |
| Retry / repeat | double submit, same request twice, re-run of a job | one effect, not two |
| Partial failure | a batch / multi-step action fails half-way | the documented state: all, nothing, or the listed partial |
| Recovery | after the failure is fixed, retry / resume | the action completes once; no stale or duplicate data |

- **A refusal is two checks:** the message and the absence of a side effect (read back, list, balance). An error
  message alone does not prove nothing was written.
- Error codes, messages, timeouts and retry counts come from the source; unknown → `Q-xxx`.

## 8. Edge dimensions and error guessing

Last pass per item, for what §2–§7 did not produce. Only dimensions that apply and whose expected outcome the source
gives (or a `Q-xxx` assumes):

- **value:** empty, only spaces, zero, negative, max length, leading zeros, special and Unicode characters;
- **time:** month end, leap day, midnight, timezone and DST change, a date in the past / future, an expired item;
- **state:** an item edited or deleted by someone else meanwhile; a stale page (Back / Refresh);
- **volume / order:** empty list, one item, page boundary, many items; arrival out of order;
- **concurrency:** two users / requests on the same item;
- **defect history:** what broke before in this module or a neighbour (`project/lessons.md`, defects in runs).

## 9. Priority by risk

Priority = impact if it fails × how likely it fails × how hard it is to notice. Without real data say so and judge
qualitatively; never compute a score that looks precise. P1 / P2: money, state, security, data loss, hand-offs,
legal text; P3 / P4: cosmetic, rare and visible. A lowered priority is explained in the scenario text.

## 10. Use-case and scenario testing

For a module or ST chain described by use cases or Given-When-Then criteria:

1. **One scenario per course:** the normal course; each alternative course (it must still reach the
   postconditions, via its rejoin step); each exception (its trigger at the stated step, the system response, the
   final state — rolled back or the documented partial state).
2. **Expected results = postconditions** the tester can see (status, record on a list, notification, document); an
   exception's expected result = its response **and** its final state.
3. **Preconditions** become the TC's special preconditions; the use case's *assumptions* are not preconditions —
   an unverified one is a `Q-xxx`.
4. **Missing courses** are gaps, not freedom: a step with a validation and no exception, a branch without a rejoin,
   an external call without a failure path → `Q-xxx` (and techniques §7 for the failure classes).
5. **Given-When-Then criteria:** each *Then* (and each *And*) is checked; a criterion with several *When* is split
   into several scenarios.
6. ST walkthroughs follow the user-goal use cases end to end; IT keeps only the module's own steps and mocks the
   rest (R9).
