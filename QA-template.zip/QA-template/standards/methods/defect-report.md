# Defect report and run summary: formats

> **Created:** 2026-10-16 09:16 · **Updated:** 2026-10-16 10:43 (UTC+7)

Read by `run-tests` when a failure is triaged as a **product defect**, and when writing the run summary's
conclusion.

## 1. Defect report (one per product defect, in `runs/<key>/defects.md` and the chat)

```markdown
### <TC ID> — <what is wrong, at the surface, in one line>

| Field | Value |
|---|---|
| Environment · build | <env name exactly as project.json> · <build / version / commit, or "unknown"> |
| Found by | <TC ID> (<automated run <date> / manual>) · cycle <name or —> |
| Preconditions | <the TC's baseline + specials, with the fixture names> |
| Steps | 1. … (the TC's steps, with the data actually used) |
| Expected | <the TC's expected result, with its source citation / requirement ID> |
| Actual | <what happened, exact text / status / values> |
| Reproducible | <n of m runs> (rerun with `run_tests.py <target> --grep <TC ID>`) |
| Impact | <who / what is affected; blocks which TCs or flows> |
| Severity · priority (proposed) | <Critical / Major / Minor / Trivial> · <P1–P4>, with one line why |
| Evidence | <paths under runs/: screenshot, trace, response body, query output> |
| Notes | <open questions, suspected area — marked as a guess, never as the cause> |
```

- The title says the symptom, not the cause ("Approve shows error 500 for amount 0.01", not "rounding bug").
- Facts and guesses apart: a suspected cause is a note, never the title.
- Severity by impact on the user / data / money / legal, not by how annoying the failure is. The DEV team's tracker
  decides; the report proposes. `defect_id` goes into the TC only when the user gives one.
- One report per root symptom: ten TCs failing on the same login error are one defect listing the ten TCs.

## 2. Flaky and environment failures

- A test that fails, then passes on an unchanged rerun, is **Flaky**, not Passed: report "passed 1 of 2" and keep it
  in the triage table.
- Never add retries or longer timeouts to make it green. Look for the cause first: shared data, order dependence,
  waiting on a time instead of a state, a slow mock, a clock / timezone.
- Quarantine (skip with a reason) only with the user's OK, naming an owner and the exit condition (e.g. "fixed wait
  on the result grid; 5 green runs"). A quarantined TC counts as **No result**, never Passed.

## 3. Run summary conclusion (`runs/run-summary.md`, last section)

- **Tested / not tested:** the targets and packs that ran; what did not run and why (Manual residue, Blocked, No
  result, runner missing).
- **Counts are executed counts.** Planned or Auto-tagged TCs are not executed TCs; an empty defect list is not "zero
  defects" when tests did not run. If nothing ran, the status is **"not executed / not enough evidence"**.
- **Failures before percentages:** list every failed or No-result P1 / P2 TC by ID before any pass rate. A 98 % pass
  rate with one failed P1 is a failed P1.
- **Gate view** per exit criterion of the test plan (when it has them): Met · Not met · Blocked (could not run) ·
  Unknown (no evidence). Missing evidence is never Met.
- **Release position:** a recommendation with its reasons ("not ready: TC-E4-012 P1 failed, defect raised"). The
  decision belongs to the people the test plan names.
