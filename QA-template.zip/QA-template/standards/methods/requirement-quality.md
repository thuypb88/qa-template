# Requirement quality: rules, gaps, ambiguity, conflicts, testability

> **Created:** 2026-10-16 09:16 · **Updated:** 2026-10-16 10:50 (UTC+7)

Read by `design-analysis` while writing §2 (rules), §8 (TCONDs) and §9 (questions), by `check-design` (analysis) to judge
them, and by the requirements skills (`req-elicit`, `req-review`, `req-write`). The aim: every rule is atomic and testable, and every gap becomes a question someone can answer and close.

## 1. Atomic business rules (§2 `BR-<req>-n`)

A rule is atomic when it has one trigger and one outcome. Read each requirement for these parts and write one BR per
outcome:

| Part | Question | Example |
|---|---|---|
| Actor | who acts / who is affected | "a Checker" |
| Trigger + preconditions | when does the rule fire, in which state | "on Approve, when the request is Pending" |
| Outcome | what changes that a tester can see | "status becomes Approved; the maker gets a notification" |
| Constraint | limit, format, permission, invariant | "the checker cannot be the maker" |
| Exception | the stated exception, or `missing` | "missing → Q-012" |

Merge sentences into one BR only when the source says they are one rule; similar wording in two places is two rules
until proven otherwise.

## 2. Gap kinds (§9 **Kind** column)

| Kind | Means | Example |
|---|---|---|
| `missing rule` | behaviour that must exist is not defined | what happens on a duplicate submit |
| `missing material` | a document the sources refer to is absent | "see the message catalogue" — not supplied |
| `ambiguous` | the wording allows two or more readings | "the amount must not exceed the limit" — which limit? |
| `conflict` | two sources (or rules) cannot both hold in the same scope | SRS 50 chars, mock-up 40 chars |
| `untestable` | no observable outcome or no decision criterion | "the page loads fast" |
| `stale` | the source's version or applicability is unclear | a 2024 test plan vs a 2026 SRS |

An item the sources explicitly exclude is **not** a gap (it goes to §1 out of scope). Before writing `missing`, open
the other sources and the images (L-T01).

## 3. Ambiguity: where to look

Check each rule for these seven kinds; words such as "fast", "normal", "appropriate", "when necessary", "supported",
"etc." are testable only when the source defines the criterion.

1. **Actor** — who may act, who approves, who is affected.
2. **Reference** — which object, field, state or document a word or pronoun points at.
3. **Scope / quantity** — which items, how many, are bounds included.
4. **Condition** — when the rule holds, combinations, exceptions.
5. **Time / order** — "immediately", "before", retry windows, the clock and timezone used.
6. **Outcome** — what success looks like at the surface; what failure shows.
7. **Constraint** — role, data, channel, platform, regulation, environment.

## 4. Conflicts

- Compare **the same object, action and scope**: different conditions or versions are not a conflict (they may be
  `ambiguous` or `stale`).
- Check small sets too: three rules can be impossible together though each pair is fine. Name every rule in the set.
- "Must" against "should" is not a precedence decision. `project.json › sources.precedence` may settle which source
  wins; still raise the question when the loser is a client document (R1).
- Never pick a side silently (L-T11): both statements, both citations, the proposed assumption.

## 5. Testability (feeds §8 and, later, `auto-decide`)

For each rule ask:

| Property | Question | If no |
|---|---|---|
| Observable | can the tester see the outcome at the pack surface? | Out of black-box scope (covering layer), not a TCOND |
| Decidable | is there an exact expected value (text, status, count, code)? | `untestable` / `ambiguous` question |
| Controllable | can the test set up the state (data, time, a failure, a job run)? | note the hook it will need (fixture, clock, fault switch, run-job-now) in §11 |
| Isolated | can it run without another team's system at this level? | IT: name the mock / fixture; else Moved to ST |
| Repeatable | same input → same result (no live clock, random IDs, shared data)? | note the control needed in §11 |

## 6. A question someone can close (§9 rows)

Each `Q-xxx` row carries:

- **Kind** (§2) and the **smallest phrase** that causes it, cited;
- **Readings** — for `ambiguous`, at least two plausible readings and what each would change in the tests; for
  `conflict`, Evidence A and Evidence B;
- **Proposed assumption** — the reading the tests use until answered (`Q-xxx: assumed …`), never presented as fact;
- **Owner** — the role that can decide (BA, client, DEV, QA lead, ops);
- **Blocks** — the TCONDs / requirements that depend on it, so the answer can be traced back.

Ask the smallest question that decides it ("Is the 40-character limit counted before or after trimming?"), not
"please clarify the field". Order §9 by what it blocks: P1 / P2 behaviour first.

## 7. Requirement layers (is anything missing above or below the functions?)

| Layer | Answers | Empty when… | What testing loses |
|---|---|---|---|
| Business | why — goal, problem, measurable target | a feature with no reason or KPI | no basis for priority by risk |
| Stakeholder | who needs what, in which situation | behaviour with no named role | RBAC and persona coverage guessed |
| Functional | what the system does | only needs, no behaviour | nothing to derive TCONDs from |
| Non-functional | how well: time, volume, security, availability, compliance | functions with no quality attribute | no NFR targets (→ `design-nfr` questions) |
| Transition | how to get from today to the new state: data migration, parallel run, cutover, training, rollback | the future state agreed, the move not | no migration / cutover / rollback tests |

Show the layer status (✅ clear · 🟡 partial · ⛔ empty) when reviewing a raw request or a thin document.

## 8. User stories and acceptance criteria

A story is testable when it passes **INVEST** — Independent (testable without another story's result; a dependency
is named), Negotiable (what and why, not how), Valuable (*so that* states an outcome, not a restated *I want*),
Estimable, Small (one sprint; signals of too big: "and" in the title, several personas, all of CRUD, more than ~8
criteria), **Testable** (criteria a tester can decide).

- **Persona** is a specific role in a state ("a checker with approval rights"), never "a user".
- **Criteria** in Given-When-Then, one scenario each, at least: one happy path, one edge (boundary, limit, timing,
  concurrency), one negative (invalid, refused, failure). *Given* = a checkable precondition; *When* = one action;
  *Then* = an observable result with the exact message / state / value, and **And** nothing else changed where that
  matters.
- Red flags: vague words ("fast", "user-friendly", "etc."), implementation in a criterion (endpoint, table, framework),
  pixel-level UI, several scenarios in one criterion, no criteria at all.
- For test design: each *Then* is a TCOND; each criterion → at least one scenario.

## 9. Use cases

A use case is testable when it has **one primary actor, one goal, one session** (user-goal level: after it the actor
has achieved something worth stopping for; a step such as "verify OTP" is an *include*, a whole life cycle is several
use cases) and these parts are sound:

- **Name** verb + object ("Approve loan request"); a specific actor; description = why + what + outcome.
- **Preconditions** checkable before the start (not motivations, not business rules, not assumptions);
  **postconditions** = the verifiable end *state* (records, statuses, notifications), not actions.
- **Normal course** numbered, one action per step, actor and system alternating, no if / else inside, from the
  trigger to the postconditions.
- **Alternative courses** still reach the goal: each says "at step N, if <condition>", its own steps (Na, Nb…) and
  where it rejoins.
- **Exceptions** fail the goal: each has trigger + system response + final state (rolled back? partial?). Expect
  the common ones: invalid input, rule violation, external system failure / timeout, permission, concurrency, session
  timeout.
- Includes point to existing use cases; special (non-functional) requirements don't repeat functional rules; open
  points as TBDs with an owner.
- For test design: the normal course, each alternative and each exception is one scenario; postconditions are the
  expected results; preconditions become the TC preconditions (`design-scenarios` techniques §10).
