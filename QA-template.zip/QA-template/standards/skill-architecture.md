# Skill architecture — grouped by objective (v1.5.0)

> **Created:** 2026-10-16 09:56 · **Updated:** 2026-10-16 14:18 (UTC+7)

**Status:** Accepted by the user 2026-10-16 (D1–D4 below, plus "make it clearer"); implemented in template v1.5.0. **Replaces:** the seven life-cycle categories of
v1.3–1.4 (`workflow · plan · requirements · design · automation · execution · knowledge`).
**Studied:** `EIMS/sources/skills-refer/` — awesome-qa-skills (directory guide, style guide, virtual domains,
composition routes, `discover-testing` router), BA Zone `product-discovery` / `user-story-ac-writer` /
`use-case-writer`, ELI5. Ideas only; no text copied (PolyForm Noncommercial / MIT).

## 1. What is not clean today (28 skills)

| # | Problem | Evidence |
|---|---|---|
| P1 | **Names clash.** Two names differ by one word; three skills are called "review". | `discover` (router) vs `discovery` (elicitation); `review` vs `requirement-review` vs `skill-review` |
| P2 | **Groups are life-cycle stages, not objectives.** One category holds unrelated goals. | *plan* = set-up + change control + strategy + scope; *knowledge* = retro + skill upkeep + explain; *design* holds the reviewer and the NFR plan |
| P3 | **The grouping is invisible where a skill is picked.** `metadata.category` is not shown in the `/` menu, Codex or Copilot; names sort A–Z, so groups scatter. | `analyze, automate-decide, automate-test, daily-workflow, defect-management, design-scenarios, discover, discovery…` |
| P4 | **Two owners for one output.** | regression set: `trace-changes` §6 *and* `regression-select`; four orchestrators (`discover` + three `*-workflow`) each with its own gate table |
| P5 | **Skills read each other's insides.** | `analyze/references/requirement-quality.md` read by 5 skills; `execute-test/references/defect-report.md` by 3; `design-scenarios/references/techniques.md` by 2 |
| P6 | **Near-twin skills.** Same rules, same "Proposed" status, same output folder pattern. | `user-story-ac` and `use-case-spec` (both: QA drafts a requirement proposal) |
| P7 | **Uneven skeleton.** Sections differ (Modes, Pitfalls, Done when, Required sections) without a reason. | workflows vs writers vs requirements skills |

## 2. Design principles (adapted from the reference set)

1. **One skill = one objective = one primary output.** Add or keep a skill only when its input, primary output and
   triggers are bounded independently of every other skill (awesome-qa-skills directory rule).
2. **Group by the question the user is asking**, not by when in the life-cycle it happens (awesome-qa-skills
   "virtual domains"). Eight questions → eight groups.
3. **The group is visible in the name**: `<group>-<objective>`. Folders stay flat (`skills/<name>/SKILL.md`, the only
   layout all three agents discover); a prefix is the only grouping that every picker shows and sorts.
4. **Orchestrators route, workers work.** One router (one primary + at most one helper, never a menu dump); one
   cadence skill for day / sprint / release gates. Neither writes test artifacts.
5. **Thin entry, deep reference.** `SKILL.md` ≤ ~120 lines: contract, steps, rules, done-when. Modes and long formats
   go to the skill's own `references/<mode>.md`, read only when that mode runs (style guide: progressive disclosure).
6. **Shared method lives outside skills** (`standards/methods/`). A skill links to its own references and to
   `standards/`, never into another skill's folder.
7. **Writer ≠ reviewer.** Every artifact a writer produces has a `check-*` skill; the reviewer never fixes.
8. **Description = trigger contract**: `<Group>: <objective>. <What, inputs → output>. Use for "<user's words>"…
   Not for: <neighbour case> → <skill>.` (BA Zone / ELI5 style: concrete trigger phrases, VI phrases kept.)

## 3. The eight groups

| Prefix | Objective — the question it answers | Skills | Primary output |
|---|---|---|---|
| `flow-` | **Where are we and what next?** Route and pace the work | `flow-next`, `flow-cadence` | chat; `plans/sprints/`, `plans/releases/` |
| `plan-` | **What do we test, how, and is our basis current?** | `plan-setup`, `plan-strategy`, `plan-scope`, `plan-changes` | `project.json`, `plans/test-strategy.md`, `0-scope.md`, `project/change-impact/` |
| `req-` | **Is the requirement good enough to test?** (QA side; proposals only) | `req-elicit`, `req-review`, `req-write` | `plans/discovery/`, `plans/requirement-reviews/`, `plans/stories/`, `plans/use-cases/` |
| `design-` | **What exactly do we test, with which data?** | `design-analysis`, `design-scenarios`, `design-cases`, `design-data`, `design-nfr` | `1-analysis.md`, `2-mindmap.md`, `test-cases.json`, `test-data.md`, `nfr-plan.md` |
| `check-` | **Is our own work right?** (independent reviewer) | `check-design`, `check-automation`, `check-skill` | `*-review.md`; skill fixes on OK |
| `auto-` | **What do we automate, and build it** | `auto-decide`, `auto-write` | `automation-plan.md`, `automation/<pack>/` |
| `run-` | **Does the build work, and what do we tell people?** | `run-select`, `run-tests`, `run-explore`, `run-defects`, `run-report` | `plans/regression/`, `runs/`, `exploratory/`, `project/defects.md`, `test-reports/` |
| `learn-` | **What did we learn, and can others understand it?** | `learn-retro`, `learn-explain` | `project/`; chat |

26 skills (from 28). Sorted A–Z the groups now cluster: `auto · check · design · flow · learn · plan · req · run`.

### 3a. Domain group `sql-` (v1.6.0, D5)

One exception to principle 2, chosen by the user: database work gets its own group so every SQL request has a
findable skill, **on top of** a `sql` pack that lets the pipeline treat procedures, functions, views and triggers as
module items. The group is still built by objective inside, and ownership is split so nothing overlaps:

| Skill | Objective | Relation to the objective groups |
|---|---|---|
| `sql-study` | understand database code; one card per object | feeds `design-analysis` (pack sql) |
| `sql-explain` | explain a query, procedure, plan or error | `learn-explain` hands SQL here |
| `sql-debug` | root-cause a database problem from evidence | hands product defects to `run-defects` |
| `sql-data` | test data / cleanup scripts for the planned sets | `design-data` plans the sets, `sql-data` scripts them |
| `sql-cases` | test cases for pack-sql modules (step 5) | replaces `design-cases` for pack sql; `check-design` reviews |
| `sql-verify` | verification procedures / scripts (A2) | replaces `auto-write` for pack sql; `check-automation` reviews |

A new domain group needs the same justification: a technology with its own end-to-end workflow, a pack behind it,
and an owner split written down like the table above. 32 skills in nine groups.

```mermaid
flowchart LR
    FN{{flow-next}} -.routes.-> plan & req & design & check & auto & run & learn
    FC[[flow-cadence: day · sprint · release]] -.gates.-> run
    subgraph plan[plan-]
        PS[setup] --> PT[strategy] --> PC[changes] --> PSc[scope]
    end
    subgraph req[req-]
        RE[elicit] --> RR[review]
        RW[write]
    end
    subgraph design[design-]
        DA[analysis] --> DS[scenarios] --> DC[cases] --> DD[data]
        DN[nfr]
    end
    subgraph check[check-]
        CD[design]
        CA[automation]
        CS[skill]
    end
    subgraph auto[auto-]
        AD[decide] --> AW[write]
    end
    subgraph run[run-]
        RS[select] --> RT[tests] --> RD[defects] --> RP[report]
        RX[explore]
    end
    subgraph learn[learn-]
        LR[retro]
        LE[explain]
    end
    plan --> req --> design --> auto --> run --> learn
    DA & DS & DC -. reviewed by .-> CD
    AW -. reviewed by .-> CA
```

## 4. Old → new

| Old (v1.4) | New | Change |
|---|---|---|
| `discover` | `flow-next` | rename only; ends the `discover` / `discovery` clash (P1) |
| `daily-workflow`, `sprint-workflow`, `release-workflow` | `flow-cadence` | **merge**: one gate engine, modes `day · sprint · release` in `references/{day,sprint,release}.md` (P4) |
| `qa-init` | `plan-setup` | rename |
| `test-strategy` | `plan-strategy` | rename; modes write / review / section unchanged |
| `scope` | `plan-scope` | rename |
| `trace-changes` | `plan-changes` | rename; **drops its regression-set section** — the impact record lists affected TCs, `run-select` owns the set (P4) |
| `discovery` | `req-elicit` | rename (P1) |
| `requirement-review` | `req-review` | rename |
| `user-story-ac`, `use-case-spec` | `req-write` | **merge**: modes `story · use-case` in `references/{user-story,use-case}.md`; shared Proposed-status rules once (P6) |
| `analyze` | `design-analysis` | rename; `references/requirement-quality.md` → `standards/methods/requirement-quality.md` (P5) |
| `design-scenarios` | `design-scenarios` | unchanged name; `references/techniques.md` → `standards/methods/test-techniques.md` (P5) |
| `write-test-cases` | `design-cases` | rename |
| `test-data` | `design-data` | rename |
| `nfr-testing` | `design-nfr` | rename |
| `review` (analysis / scenarios / TCs) | `check-design` | rename; keeps `references/{analysis,scenarios,test-cases}.md` |
| `review automation` | `check-automation` | **split out** with `references/automation.md`: different input (code), different findings (AR-/SAR-) |
| `skill-review` | `check-skill` | rename; moves from *knowledge* to *check* (it reviews our own deliverable) |
| `automate-decide` | `auto-decide` | rename |
| `automate-test` | `auto-write` | rename |
| `regression-select` | `run-select` | rename; sole owner of regression sets |
| `execute-test` | `run-tests` | rename; `references/defect-report.md` → `standards/methods/defect-report.md` (P5) |
| `exploratory-testing` | `run-explore` | rename |
| `defect-management` | `run-defects` | rename |
| `test-report` | `run-report` | rename |
| `retro` | `learn-retro` | rename |
| `explain` | `learn-explain` | rename |

Behaviour evals follow their skill: `template-dev/tests/skill-evals/{discovery,requirement-review,user-story-ac,use-case-spec,explain}.json`
→ `req-elicit`, `req-review`, `req-write` (cases of both merged files, tagged by mode), `learn-explain`.

## 5. Standard `SKILL.md` skeleton (all 26)

```markdown
---
name: <group>-<objective>
description: <Group>: <objective in one clause>. <What it does, inputs → output file>. Use for "<user's words>", …
  Not for: <neighbour case> → <skill>; <neighbour case> → <skill>.
metadata:
  group: <flow | plan | req | design | check | auto | run | learn>
  order: <step id in the chain, e.g. 1, 3, A1, E; "-" for none>
---

# <Group>: <objective>

> **Created:** … · **Updated:** … (UTC+7)

**In:** … **Out:** … **Rules:** … **Next:** `<skill>`. **Stop if** <upstream missing / stale> → `<skill>`.
**Modes:** <only when the skill has them: mode → references/<mode>.md>

## Steps
## Rules
## Pitfalls        (only lessons with evidence: L-Tnn / L-nnn)
## Done when
```

- `metadata.category` → `metadata.group` (value = the name prefix; selftest checks they match) plus `order`, so
  `flow-next` and the catalog can sort the chain without a hard-coded list.
- Fixed order of sections; a section with nothing to say is left out, not filled.
- Long tables (gate boards, 13-field use case, 20-point checks, ELI5 audience table) live in `references/`.

## 6. Shared methods (`standards/methods/`)

| File | From | Read by |
|---|---|---|
| `requirement-quality.md` | `analyze/references/` | `req-elicit`, `req-review`, `req-write`, `design-analysis`, `plan-strategy` |
| `test-techniques.md` | `design-scenarios/references/techniques.md` | `design-scenarios`, `design-data`, `plan-strategy` |
| `defect-report.md` | `execute-test/references/` | `run-tests`, `run-defects`, `run-report` |

Per-skill `references/` hold only that skill's own modes and formats.

## 7. Migration (done in template v1.5.0)

1. `template-manifest.json › renamed_skills` (old → new, merges noted) — the single source for every step below.
2. `git mv` the 21 renamed folders; build the 2 merged skills + `check-automation`; move the 3 shared references.
3. Rewrite every reference to an old name with the map: skills, `README` catalog, `CLAUDE.md`, `AGENTS.md`,
   `standards/*`, `packs/*`, `plans/README.md`, `.github/instructions/*`, `scripts/pipeline_status.py` (`STEPS` and the
   `nxt` tuples → new names), `template-dev/tests/skill-evals/`.
4. `template-dev/tests/selftest.py`: `CATEGORIES` → `GROUPS`; check `name` starts with `metadata.group` + `-`; fail on any old name
   in the repo (except `CHANGELOG.md` and the rename map); fail on a link into another skill's folder.
5. `scripts/workspace/template_sync.py --apply` on an existing project: delete the old skill folders listed in the map (project
   overrides are reported, not deleted). `python3 scripts/workspace/sync_agents.py` for the Codex / Copilot / Gemini mirrors.
6. `SKILL_TEMPLATE.md` and the catalog `README.md` rewritten to §3 and §5; CHANGELOG + `TEMPLATE_VERSION` 1.5.0;
   selftest green.

## 8. Decisions (D1–D4 taken as recommended, 2026-10-16; D5 by the user, v1.6.0)

| # | Decision | Taken | Alternative not taken |
|---|---|---|---|
| D1 | Show the group in the skill **name** (`design-cases`) | yes — the only grouping visible in every picker (reverses the v1.3 choice of frontmatter-only categories) | keep v1.4 names, regroup only `metadata` + catalog |
| D2 | Merge the three workflows into `flow-cadence` | yes | keep three `flow-day / flow-sprint / flow-release` |
| D3 | Merge `user-story-ac` + `use-case-spec` into `req-write` | yes | keep `req-story` + `req-usecase` |
| D4 | Split `check-automation` out of `review` | yes | keep it as a mode of `check-design` |
| D5 | SQL skill set: a `sql` pack **and** a `sql-` domain group (study, explain, debug, data, cases, verify), engine-neutral with SQL Server / Oracle / PostgreSQL / MySQL dialect notes | both (user's choice) | pack + two skills only; six objective-named skills |
