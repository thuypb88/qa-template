# Status

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 08:34 (UTC+7)

## 1. Board

"Stale" = built on an older upstream artifact or older rules. `python3 scripts/pipeline_status.py` gives the
machine view; this board adds what the scripts can't know.

| Folder | Analysis | Scenarios | Test cases | Latest review | Next step |
|---|---|---|---|---|---|

## 2. Follow-ups: open

IDs `FU-NNN` are never reused. Done or overtaken → move the row to §3 with the date and outcome.

| ID | Folder / file | What to do | Origin | Run with | Opened |
|---|---|---|---|---|---|

## 3. Follow-ups: closed

| ID | Outcome | Closed |
|---|---|---|
