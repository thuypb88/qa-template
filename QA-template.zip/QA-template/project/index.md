# Project memory

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

The project's shared memory: what any agent (Claude, Codex) or person needs to know that the artifacts don't say on
their own. Read this file first (keep it under 5 KB); open the others only when the task needs them. Personal agent
memory keeps only pointers here — project facts live in git, where every agent can read them.

| File | Holds | Updated by |
|---|---|---|
| [rules.md](rules.md) | Project rules `PR-n` on top of the core and pack rules | `plan-setup`, `learn-retro`, by hand |
| [system-map.md](system-map.md) | Modules, interfaces, data flows, roles, glossary | `plan-setup`, `design-analysis` (ST), by hand |
| [status.md](status.md) | Status board per level folder, open follow-ups `FU-NNN`, closed follow-ups | every writer / reviewer run |
| [questions.md](questions.md) | Cross-module register of open questions that block work | `design-analysis`, `check-design` |
| [decisions/](decisions/) | `ADR-NNN`: who decided what, when, why (QA lead calls, scope changes) | when a decision is made |
| [lessons.md](lessons.md) | Project lessons `L-NNN` from reviews and runs, and candidates for the template | `learn-retro` |
| [log.md](log.md) | Newest first, one line per change set | every run |
| [change-impact/](change-impact/) | One record per source change: what changed, decision per module | `plan-changes` |
| [defects.md](defects.md) | Defect register `DEF-NNN`: status, severity, TCs, retests | `run-defects` |

Cross-project lessons: [standards/template-lessons.md](../standards/template-lessons.md) (template-owned, L-Tnn).

## Now

<!-- 3–6 lines: the current focus, the next step, the blocking questions. Rewrite, don't append. -->
_Project not initialised yet: run `plan-setup`._
