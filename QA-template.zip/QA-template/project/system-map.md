# System map

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 08:34 (UTC+7)

## Modules

<!-- Generated rows between the markers are rewritten by scripts/init_project.py; the rest is hand-written. -->
<!-- MODULES:START -->
<!-- MODULES:END -->

## Interfaces and data flows

| ID | From → To | What moves | Format / protocol | IT stand-in | ST | Source |
|---|---|---|---|---|---|---|

## Roles

| Role | Can | Cannot | Source |
|---|---|---|---|

## Glossary

| Term | Meaning | Source |
|---|---|---|
