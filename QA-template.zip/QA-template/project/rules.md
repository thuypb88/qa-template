# Project rules (PR-n)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

Rules that hold for this project only, on top of [core-rules.md](../standards/core-rules.md) and the pack rules. Written by
`plan-setup` and kept up to date by the project. Every rule cites its source (a document line, or the person and date
of the decision, with an `ADR-NNN` in `project/decisions/`). A project rule may tighten a core rule, never loosen it.

<!-- Template: replace this section with the project's rules. Examples from ALPHA:

## PR-1. Field mapping workbook is the newest form definition

Source: QA lead, 2026-10-13 (ADR-002). `sources/srs/Form_Field_Mapping_v0_1.xlsx` defines, per form,
the field list in order, labels in EN / VI / ZH, mandatory, type, validation and Preview errors. It beats the SRS
and dev notes; each difference is a Q-xxx (core R1.5).

## PR-2. IT runs in the SIT environment with mock data

Source: QA lead, 2026-10-13 (ADR-001); the test plan still says DEV. Write "ALPHA SIT", never bare "SIT".
-->

_No project rules yet._
