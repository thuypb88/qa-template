# Open questions

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 08:34 (UTC+7)

The cross-module register of questions that block work. `Q-NNN` numbers are per module (read the Folder column);
system questions are `Q-ST-NNN`. The module analysis is the master copy of each question; this register tracks who
was asked and the answer.

| Folder | Q ID | Topic | Blocks | Assumed | Asked (who, when) | Answer (who, when) | Status |
|---|---|---|---|---|---|---|---|
