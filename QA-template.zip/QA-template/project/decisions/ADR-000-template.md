# ADR-000: <decision title>

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 08:34 (UTC+7)

- **Status:** proposed | accepted | superseded by ADR-NNN
- **Decided by:** <name / role>, <date>
- **Context:** <what forced the decision; the conflicting sources or options>
- **Decision:** <the rule, exactly as the team will apply it>
- **Consequences:** <which rules, skills, modules, TCs change; follow-ups FU-NNN>
- **Evidence:** <link to the message, meeting note, or document line>
