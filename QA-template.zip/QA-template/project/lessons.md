# Lessons: this project

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

Lessons from this project's reviews, runs and corrections. The `learn-retro` skill adds them; skills read the rows that
name them. Cross-project lessons are in [standards/template-lessons.md](../standards/template-lessons.md).

| ID | Where | Lesson | Evidence | Seen | Action |
|---|---|---|---|---|---|

`Seen` counts occurrences. **Action**: `noted` · `→ skill <name>` (added to its pitfalls) · `→ rule <ID>` ·
`→ script <name>` · `promote` (candidate for the template lessons).

## Promote to template

Lessons general enough for every project. Copy them into the template's `standards/template-lessons.md` (as L-Tnn), then
mark them `promoted` here.

| ID | Why it is general |
|---|---|
