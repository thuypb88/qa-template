# Defects

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:50 (UTC+7)

The project's defect register, kept by the `run-defects` skill. `DEF-NNN` is the local ID (never reused); the
team's tracker ID goes in **Tracker** when there is one. Newest first; closed rows stay as history. Status: New ·
Open · Fixed · Retest · Closed · Reopened · Rejected · Duplicate · Deferred (the last three with who decided).

| DEF ID | Tracker | Title | Severity | Priority | Status | Folder | TCs | Found (build, date) | Fixed in | Retest (build, date, result) | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
