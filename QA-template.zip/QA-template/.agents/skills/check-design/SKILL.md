---
name: check-design
description: Check steps 2, 4 and 6 (reviewer, IT or ST, every pack): review the analysis, scenarios or test cases. Review a folder's analysis (1-analysis.md), scenarios (2-mindmap.md), or test cases (3-test-cases/test-cases.json) against its upstream artifact, the sources, the client documents and the core / pack / project rules, following the review protocol (severity, verdict, evidence, fixes), and write the matching review file; then offer to apply the fixes. Use for "review / check the E4 analysis | mindmap | scenarios | test cases", "is the ST suite ready?", "review all modules". Not for: writing them → design-analysis / design-scenarios / design-cases; automated tests → check-automation; a requirement document → req-review; a skill → check-skill.
metadata:
  group: check
  order: "2·4·6"
---

# Check: analysis, scenarios or test cases

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:34 (UTC+7)

**In:** a target (module id, `st`, `all`) and the artifact (`analysis`, `scenarios` / `mindmap`, `test-cases`). If the user
names no artifact, review the latest step that exists without a current review (`pipeline_status.py`).
**Out:** the review file (overwrite); fixes to the artifact only if approved. **Rules:**
[standards/review-protocol.md](../../../standards/review-protocol.md) P1–P7; core, pack and project rules.
**Next:** the next writer (`design-scenarios` / `design-cases` / `auto-decide`), then `learn-retro` if findings
repeat a pattern.

| Artifact | Checklist | Script | Review file | Finding IDs |
|---|---|---|---|---|
| analysis | [references/analysis.md](references/analysis.md) | — | `1-analysis-review.md` | `RV-` (ST `SR-`) |
| scenarios | [references/scenarios.md](references/scenarios.md) | `check_scenarios.py <target>` | `2-mindmap-review.md` | `MR-` (ST `SMR-`) |
| test cases | [references/test-cases.md](references/test-cases.md) | `export_testcases.py <target> --check` + `slice.py tc <target> --patterns` | `3-test-cases/test-cases-review.md` | `TR-` (ST `STR-`) |

**Stop if** the artifact is missing (name its writer). Say in the header when it is older than its upstream.

## Steps

1. **Lessons first** (P1.5): `project/lessons.md` and the L-T rows naming `check-design` or this artifact's writer.
2. **Script** (when the table names one): copy its numbers into the header; Errors are findings; read each Warning's
   item before raising it (false positive → row with **No change**).
3. **Whole-artifact scan before spot-checks** (L-T06): the TOC (`slice.py toc`), or `slice.py tc --stats` and
   `--patterns` for test cases.
4. **Checklist** for the artifact — read only the reference file you need.
5. **Spot-check** the riskiest items first (P1.3), opening each source at the cited line.
6. **Write** the review file in the format below.
7. **Report and offer fixes** (P5). Applying: only the reviewed artifact; append IDs; re-run the script (and the
   export + `version` bump for test cases); append `## Revision log`; name the downstream skill to re-run.
8. `project/status.md` board row + `project/log.md`; commit `<id> <artifact> review: <verdict>` (and the fixes, if applied,
   as their own commit).

## Output format

```markdown
# <name>: <analysis | test mindmap | test case> review

**Verdict:** Pass | Pass with fixes | Rework
**Reviewed:** <date> · **Reviewer:** <agent model> · **Items checked:** <n> · **Spot-checked:** <n>
**Coverage:** <requirements a/b> · <ACs a/b> · <TCONDs / scenarios a/b> · **Script:** <e> Error · <w> Warning

## Findings
| ID | Severity | Item / section | Check | Rule | Review comment | Evidence | Suggested fix |
|---|---|---|---|---|---|---|---|

## Fix order
1. <High findings, grouped by the fix that clears them; Fix upstream ones first, naming the writer>
2. <Med> · 3. <Low>
**Re-check after fixing:** <the script(s) to re-run, the items to re-read, the downstream skill to re-run>

## Missing items
## Out of black-box scope   (test cases)
## Questions for BA / client
- Q-xxx (items affected): …
```

- **Review comment:** what is wrong and which defect it would miss, or why it can't run.
- **Suggested fix**, ready to apply: `<field>: "<new value>"` · **Split** into A + B · **Add note** "Q-xxx: assumed …" ·
  **Mark Blocked** until Q-xxx · **Delete / merge** with … · **Fix upstream** in `<file>` · **No change**.
- One rule broken in many places = one finding with the count and IDs (P2).
- **Fix order** follows severity (never a Low before a High) and groups findings one edit clears; it is the work list
  the writer applies.

## All modules (P6)

One target at a time; a summary table in chat (folder · verdict · items · coverage · High / Med); for test cases also
`test-design/it/test-cases-review-summary.md`.

## Pitfalls

L-T05 (clean script ≠ quality), L-T06 (spot-checking only), L-T11 (silent picks), L-T12 (one upstream cause = one
finding), L-T01 (trusting the artifact about its sources) in [standards/template-lessons.md](../../../standards/template-lessons.md).

## Done when

- [ ] Script numbers in the header; whole-artifact scan done; checklist complete.
- [ ] Spot-check count met (analysis ≥ 10 rules, scenarios ≥ 10 rows, test cases ≥ 15 TCs, all P1
  first).
- [ ] Every finding has evidence and a fix in one of the forms above; Fix order written.
