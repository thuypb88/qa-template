# Review checklist: scenarios (2-mindmap.md)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:29 (UTC+7)

Run `python3 scripts/check_scenarios.py <target>` first (P1.2).

1. **Coverage.** Every TCOND, requirement and AC reaches a scenario (the script lists the gaps; confirm each). Items in
   Out of black-box scope / Moved to ST are really there for a reason. The analysis review's open findings are applied.
2. **Depth — the pack's easy-to-miss list** (`packs/<pack>/scenarios.md`), per level-1 item, by hand (L-T13). A clean
   script with 100 % TCOND coverage still misses these.
3. **Correctness.** Spot-check ≥ 10 rows (P1 first): the scenario states the behaviour the TCOND and its source say,
   with the exact value; type matches the behaviour (refused = Negative, limit = Boundary, positive outcome =
   Functional); twins share type and priority.
   **Technique applied, not only named** ([standards/methods/test-techniques.md](../../../../standards/methods/test-techniques.md)):
   boundaries in the field's own step and unit, one scenario per distinct invalid outcome, every refused event per
   state, every decision-table rule, a pairwise set that a reviewer can recompute. Duplicates (same trigger, action,
   outcome) merged.
4. **Layout (R5).** Pack layout: level 1 = inventory items in order, areas in layout order, cross-cutting last. A
   by-requirement tree in a form / resource / table module = Rework. ST: the group layout.
5. **R10 / R6.3 / Security.** One scenario per variant (valid + invalid); one per language per input; the module's
   security techniques present (full / limited).
6. **Level fit (R9).** IT: nothing needs a real external system. ST: no repeated IT field checks; every INT row and E2E
   chain present.
7. **Structure.** Title; overview + one block per item; leaves quoted, unique, ≤ 8 words; leaves ↔ rows 1:1; fixed table
   columns; TS in order; Coverage check section; TS mapping when TCs exist and the tree was rebuilt.

Header coverage line: `TCONDs a/b · Requirements a/b · ACs a/b`. Findings the TCs will need → list them for
`design-cases`.
