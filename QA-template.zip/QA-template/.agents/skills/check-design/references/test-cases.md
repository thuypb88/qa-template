# Review checklist: test cases (3-test-cases/test-cases.json)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

```bash
python3 scripts/export_testcases.py <target> --check   # numbers → header (P1.2)
python3 scripts/slice.py tc <target> --stats            # items, types, priorities, automation
python3 scripts/slice.py tc <target> --patterns         # templated bodies across the WHOLE suite (L-T04, L-T06)
```

Read TCs with `slice.py tc <target> --priority P1`, `--form "<item>"` or `--ids …`, never the whole JSON.

0. **Both directions of the trace.** Forward: every scenario / TCOND / requirement / AC reaches a TC. Backward: every
   TC points at a live scenario and requirement — an **orphan** (no TS, a retired TCOND, a requirement not in the
   analysis) is either a missing upstream item (Fix upstream) or a TC to delete.
1. **Rules.**
   - **R1** every AC and client-document item has a TC (a gap = Missing TC, even at 100 % requirement coverage).
   - **R2** steps and results at the pack surface; a check under the surface is rewritten to where it shows, else Out
     of black-box scope — your fixes too.
   - **R3 / R4** one precondition per item, the one baseline item (a list of generic items = one Low finding per
     suite); one outcome per expected result, 1:1 with steps.
   - **R5** `[Item]` titles; pack layout order. **R6** concrete data; **R6.3** languages. **R7** security techniques.
   - **R8** values; every open question used is in `notes` as `Q-xxx: assumed …`.
   - **R9** IT fixtures only, nothing from Moved to ST; ST real systems, no IT repeats. **R10** each variant, valid +
     invalid (Med).
2. **Coverage depth.** The TC verifies its TCOND, not a neighbour. Validated items: empty, invalid, min-1 / min / max /
   max+1. State machines: every allowed and refused transition. Every alternate / exception flow. Open findings of the
   upstream reviews applied.
3. **Correctness.** Spot-check ≥ 15 TCs, all P1 first: every value in `test_data` / `expected_result` (lengths,
   formats, codes, messages, labels, status codes, rule outputs, counts) matches the BR rule and its source line.
   Invented values and silent picks of an open question are findings.
4. **Executability.** Concrete role / item / state / fixture; real labels or paths in runnable order; no "valid value";
   no dependency on another TC's result.
5. **Atomicity and decidability.** One behaviour per TC; every step has its own observable result, and each expected
   result names the exact text / state / value ("works as expected", "successfully", "correctly" without the value =
   Med, one finding for the suite). Negative TCs break one constraint with all other data valid. Refusals read back
   that nothing changed where the source says so.
6. **Pack block.** API: method, endpoint, auth fixture, request fixture, `expect.status` and the exact body values the
   steps claim. ETL: rule ID exists in the mapping, reconcile kind fits the check, both queries named, tolerance stated.
7. **Classification.** `test_type` fits; priority by risk; duplicates merged or justified; `automation` set only where
   `auto-decide` ran.
8. **Checklist pass.** With `checklist-pass.md`: spot-check 5 covered cells and 5 new TCs (S check uses a source value,
   H check states its `Q-*-xxx`). Without it: list the clearly missing checks of the pack checklist (Low; Med for
   double submit on a decision button, BOLA on an ID endpoint, re-run idempotency on a job).
9. **NFR and E2E.** Testable NFRs have TCs; ≥ 1 E2E TC crosses into the neighbouring module (IT, mocked).

Severity: **High** = wrong expected result or data, or a P1 / P2 behaviour uncovered; **Med** = a rule break; **Low**
= numbering, wording. Header coverage line: `scenarios a/b · TCONDs a/b · requirements a/b`.
