---
name: req-review
description: Requirements: review a written requirement document, shift-left (before design-analysis, or for a new story / CR). Review a requirement document - SRS, user stories, BRD, API spec, mapping sheet - for completeness, clarity, testability, consistency with the other sources, feasibility and scope, and send the BA / client a prioritised list of answerable questions (RQ-NNN with the quoted phrase, kind, readings, impact, owner, what it blocks) in plans/requirement-reviews/<date>-<slug>.md; the accepted questions go to project/questions.md. Use for "review the requirements", "check this SRS / user story before we start", "questions for the BA", "is this spec testable", "static testing of the requirements". Full module analysis → design-analysis; what changed between versions → plan-changes.
metadata:
  group: req
  order: "-"
---

# Requirements: review a requirement document

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** the document(s) under review (`sources/…`, parsed copies in `sources/parsed/`; the user may paste a story),
the other sources for cross-checks, `project/questions.md` (don't re-ask). **Out:**
`plans/requirement-reviews/<YYYY-MM-DD>-<slug>.md`; on the user's OK, rows in `project/questions.md`; a `project/log.md`
line. **Rules:** core R1; [standards/methods/requirement-quality.md](../../../standards/methods/requirement-quality.md)
(gap kinds, ambiguity checks, conflicts, testability, closable questions). **Next:** `design-analysis` once the P1 questions
are answered or assumed.

## Steps

1. **Map the document** (`slice.py toc`); list its requirements / stories / endpoints / mapping rules with their IDs.
2. **Seven dimensions per requirement:**

   | Dimension | Gap signal |
   |---|---|
   | Complete | only the happy path; no failure, permission, limit or recovery rule; AC missing |
   | Clear | words like "fast", "normal", "as needed", "etc."; pronouns; undefined terms |
   | Testable | no observable outcome or no exact value to compare |
   | Consistent | differs from another source, a neighbour module, the client documents, a mock-up |
   | Feasible | depends on something not available (a system, data, an environment) at the level it is tested |
   | Scoped | version, role, channel, platform or data boundary unclear |
   | Layered | business reason, stakeholder, NFR or transition (migration, cutover, rollback) missing (reference §7) |

   **By document form:** user stories → the INVEST and criteria checks (reference §8: specific persona, distinct
   *so that*, ≥ 3 Given-When-Then criteria covering happy / edge / negative); use cases → the use-case checks (§9:
   user-goal level, checkable pre / postconditions, no branches in the normal course, anchored alternatives,
   exceptions with trigger / response / final state). Drafting replacements is not this skill's job — suggest
   `req-write` or `req-write` when the client asks QA to propose them.

3. **Cross-check** each finding against the other sources and the images before calling it missing (L-T01).
4. **Write the findings** — one per root problem, not per sentence:

   `RQ-NNN | Requirement | Quoted phrase (cited) | Kind | Readings / Evidence A–B | Impact on testing | Priority |
   Question | Owner | Blocks`

   Kinds as in the reference §2 (missing rule / missing material / ambiguous / conflict / untestable / stale). The
   question is the smallest one that decides it, ideally with options ("A: counted after trimming; B: before").
5. **Summary at the top:** documents and versions reviewed; counts by kind and priority; the 3–5 questions to ask
   first; what cannot start until they are answered.
6. **Hand-over:** on the user's OK, copy the accepted RQs into `project/questions.md` (Folder = the module, or
   `project`), keeping the RQ ID in the Topic; `design-analysis` later turns them into `Q-xxx` in its §9.

## Rules

- Findings, not rewrites: propose wording only as an option for the owner to accept.
- Never pick a side of a conflict; never fill a gap with a "usual" value.
- Priority by what it blocks: P1 = blocks a P1 behaviour's tests or a hand-off.
- Clean requirements are reported as clean; don't manufacture findings.

## Done when

- [ ] Every requirement walked through the seven dimensions; findings cited and deduplicated.
- [ ] Each RQ has kind, question, owner and Blocks; summary with the first questions.
- [ ] Report counts and the review path; suggest `design-analysis` (or wait for answers on the P1 RQs).
