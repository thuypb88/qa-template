---
name: req-write
description: Requirements: draft or fix requirement text from the QA side, as proposals for the PO / BA to confirm. Form story - As a <specific persona> / I want / So that, INVEST check, split advice, Given-When-Then criteria (happy, edge, negative) in plans/stories/. Form use-case - find the use cases of a feature at user-goal level, write the 13 fields (normal course, alternatives with rejoin step, exceptions with trigger / response / final state), the 20-point check and the test seeds per course in plans/use-cases/, or review the client's use cases. Confirmed text enters the test basis only via sources/. Use for "write acceptance criteria", "this story has no AC", "refine / split this story", "Given When Then", "write the use case", "split this feature into use cases", "review the UC", "viết user story", "viết AC", "tiêu chí nghiệm thu", "viết use case", "đặc tả use case". Not for: a vague request with no text → req-elicit; findings on a written document → req-review; test cases → design-cases.
metadata:
  group: req
  order: "-"
---

# Requirements: write stories or use cases (proposals)

> **Created:** 2026-10-16 10:20 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** the feature / story / BRD text (`sources/`, `slice.py section`, a pasted ticket, or `plans/discovery/…`),
`project/system-map.md` (actors, roles, glossary), `project.json › external_systems`. **Out:** per form below, status
**Proposed**; open questions into `project/questions.md` on the user's OK. **Rules:** core R1;
[standards/methods/requirement-quality.md](../../../standards/methods/requirement-quality.md) §8 (stories), §9 (use
cases). **Next:** the PO / BA confirms → the user saves the confirmed text under `sources/` → `plan-changes` →
`design-analysis`.

## Forms — read only the one you run

| Form | When | Reference | Output |
|---|---|---|---|
| **story** | agile / sprint projects; a story without criteria | [references/user-story.md](references/user-story.md) — modes write · refine · complete | `plans/stories/<date>-<slug>.md` |
| **use-case** | projects specified by use cases; ST walkthroughs that need them | [references/use-case.md](references/use-case.md) — modes list · write · review · section | `plans/use-cases/<UC-ID>_<slug>.md`, `README.md` |

Pick the form the project already uses (`sources/requirements/`); if none, ask. Say which form and mode you use.

## Steps

1. **Facts before writing:** actor / persona, goal, business value, the module it belongs to. Missing → at most
   three questions; never invent a persona, a value or a number.
2. **Draft** in the form's layout (reference).
3. **Check** with the form's own list: INVEST + criteria rules (story) or the 20-point check (use case).
4. **Mark every unknown** `TBD-n` with a question, owner and what it blocks.
5. **Write** the file with the header **Status: Proposed — awaiting PO / BA confirmation**.

## Rules

- QA proposes; the PO / BA decides. A proposal is never a test basis or an expected result until it is in a
  confirmed source (R1); until then `design-analysis` may use it only as `Q-xxx: assumed …`.
- In review / refine modes: findings and proposed wording as options; the client's text is not rewritten.
- No implementation detail (endpoints, tables, components) and no pixel-level UI, unless the spec is an interface
  spec.

## Done when

- [ ] Form and mode named; the form's check table complete; ❌ fixed or flagged.
- [ ] Unknowns are TBDs with owners; status Proposed; next step named (confirmation → `sources/` → `plan-changes`).
