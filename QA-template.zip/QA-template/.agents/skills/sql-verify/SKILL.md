---
name: sql-verify
description: SQL automation (after auto-decide; IT or ST; modules with pack sql): write the verification stored procedures, functions or scripts that check the Auto test cases inside the database. Per DB object or flow, one verification in schema qa, in the project's dialect (SQL Server, Oracle, PostgreSQL, MySQL; plain script where objects can't be created) - each TC block arranges, calls the object once, asserts the TC's exact expected values, undoes its own changes and returns rows (tc_id, result PASS / FAIL, detail) - plus the deploy / drop scripts and the pytest runner file, then sets sql.verify / verify_ref in the TCs and runs them once with scripts/run_tests.py. Use for "create stored procedure to verify the tests", "automate the SQL test cases", "verification proc for usp_transfer", "tSQLt / utPLSQL / pgTAP tests", "viết store procedure kiểm tra test case". Not for: UI / API / ETL automation → auto-write; deciding what to automate → auto-decide; reviewing them → check-automation.
metadata:
  group: sql
  order: "A2"
---

# SQL: verification procedures

> **Created:** 2026-10-16 11:30 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** the module's Auto TCs (`slice.py tc <target> --ids …`, `automation-plan.md` wave), their `sql` blocks and
data scripts, the dialect and version (`project.json › sql`), the object sources / study cards. **Out:**
`automation/sql/verify/<name>.<dialect>.sql` (one verification each), `automation/sql/verify/deploy-<MOD>.<dialect>.sql`
and `drop-<MOD>.<dialect>.sql`, `automation/sql/test_<id>_sql.py` (copy of `test_example_sql.py`, `MODULE` set);
`sql.verify` / `verify_ref` in the TCs (bump `version`). **Rules:** [packs/sql/rules.md](../../../packs/sql/rules.md)
R-SQL4, R-SQL5; contract and templates per dialect in [packs/sql/dialects.md](../../../packs/sql/dialects.md) §
Verification; [automation/README.md](../../../automation/README.md). **Next:** `check-automation`, then `run-tests`.
**Stop if** a TC has no exact expected value → back to `sql-cases`; no `sql.dialect` → ask (`plan-setup`).

## Steps

1. **Group** the Auto TCs by object (or flow); one verification per group, named `qa.verify_<object>`.
2. **Choose the form:** `proc` (procedure / function in schema `qa`) by default; `script` when the team may not create
   objects in the test database or the dialect is `sqlite`; a framework (tSQLt / utPLSQL / pgTAP) only when the
   project already uses one — then test names carry the TC IDs and the results map to the same contract.
3. **Write each TC block** from the dialect template: a comment line `-- TC-… · <title>`; arrange (data comes from
   the TC's data script, loaded by the runner; only TC-specific tweaks here); act — the TC's `call` exactly; assert
   against the TC's `expect` values written as literals; for errors, the CATCH / EXCEPTION path is the PASS path and
   checks the number and message; for refusals and writes, read back; undo (rollback / sub-transaction / autonomous
   rollback per the template); record one row with a `detail` that shows actual vs expected.
4. **Deploy / drop scripts:** create schema `qa` if missing, the helper types (Oracle), each verification; the drop
   script removes them all. Nothing outside schema `qa` is created or altered.
5. **Runner:** copy `automation/sql/test_example_sql.py` to `test_<id>_sql.py`, set `MODULE`. Set each TC's
   `sql.verify` and `verify_ref` (`qa.verify_<object>` or `automation/sql/verify/<file>.sql`).
6. **Run once:** deploy, then `python3 scripts/run_tests.py <target> --pack sql` with `SQL_DSN` (+ `SQL_DRIVER`,
   `SQL_DIALECT`). A failure is triaged like any run (product / script / TC / environment, `run-tests` §triage);
   no database → say the verifications are unexecuted.
7. `project/log.md`; commit `<id> sql verify <objects>`.

## Rules

- **Would it fail on a wrong build?** Assert the TC's own values; never compare the object's output with a value
  the same object (or a copy of its logic) computed.
- Every TC block ends with exactly one row for its TC ID, also when the call raises an unexpected error (FAIL with
  the error text) — a missing row is NO RESULT, never a pass.
- Each block undoes its changes; verifications don't depend on each other's order and can run alone.
- Credentials only from the environment; deploy only to the test database of the level.

## Done when

- [ ] Every Auto TC of the wave has a block in a verification and a row in its output.
- [ ] Deploy and drop scripts; runner file; TCs updated (`verify`, `verify_ref`, `version`).
- [ ] Run once (or stated unexecuted); results and triage reported; suggest `check-automation`.
