---
name: check-skill
description: Check: review a skill as a contract (template or project). Review one skill, or all, as a contract - trigger quality of the description (role, what, "Use for" phrases in the user's words, the neighbour hand-off), group (= name prefix) and order, In / Out / Rules / Next / Stop if, steps an agent can follow without guessing, references loaded on demand with a "when", rules linked not copied (core, pack, project, conventions), files and scripts it names exist, Done when checkable, size, overlap with other skills - and report blocking issues, suggestions and gaps; apply fixes on the user's OK, then sync the agent copies and run the self-test. Use for "review the design-analysis skill", "check our skills before the release", "is this SKILL.md good", "why didn't the skill trigger", "write a new skill". Lessons from project work → learn-retro.
metadata:
  group: check
  order: "-"
---

# Check: a skill

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:48 (UTC+7)

**In:** `.claude/skills/<name>/SKILL.md` and its `references/`; [README.md](../README.md) (catalog, groups); [standards/skill-architecture.md](../../../standards/skill-architecture.md) (design rules);
[SKILL_TEMPLATE.md](../SKILL_TEMPLATE.md); the rules it cites; the scripts it names; `project/lessons.md` /
[standards/template-lessons.md](../../../standards/template-lessons.md) rows that name it. **Out:** the review in chat (or
`project/log.md` for a project override); on the user's OK, the edited skill, `python3 scripts/workspace/sync_agents.py`,
`python3 template-dev/tests/selftest.py` (template). **Next:** none, or `learn-retro` if the review found a recurring failure.

In a project, template-owned skills are read-only: findings become a **Promote to template** row (`learn-retro`), or a
project skill in its own folder. In the template repo, edit and release (TEMPLATE_VERSION, CHANGELOG).

## Checklist

1. **Trigger (description, ≤ 1024 chars).** Role and step first; what it reads and writes; "Use for" phrases in the
   user's words (including the non-English or casual ones the team uses); the neighbour case → `<other-skill>`.
   Test it: write five requests that *should* trigger it and three near misses that should go to a neighbour; each
   must be decidable from the descriptions alone. Two skills claiming the same request = blocking.
2. **Group** in `metadata.group` equals the name prefix and the README group; the skill answers that group's question; `order` is set. Input, output and triggers do not overlap another skill (else it should be a mode).
3. **Contract line.** In, Out (exact files and fixed titles scripts read), Rules (by ID), Next, Stop if (upstream
   missing / stale).
4. **Executable steps.** An agent can follow them without guessing: concrete commands, file names, the order; no
   "analyse thoroughly". Lean reading (`slice.py`) for big inputs.
5. **Progressive disclosure.** Long formats in `references/`, each linked with *when* to read it; nothing in a
   reference the SKILL.md needs on every run. SKILL.md under ~200 lines.
6. **No copied rules.** Core R1–R10, packs, review protocol, conventions are linked, not restated (restatements drift,
   L-T17); project values come from `project.json`, never hard-coded names.
7. **Everything it names exists.** Scripts and their options (`--help`), files, folders, IDs in `conventions.md`;
   the self-test's "skills: frontmatter + links" step checks links and frontmatter.
8. **Done when** is checkable (counts, script results, files), and the report line tells the user what to do next.
9. **Pitfalls** cite lessons (L-Tnn / L-nnn) with real evidence; no generic advice.
10. **Overlap and gaps** with the other skills: the same output written by two skills, or a step no skill owns.
11. **Behaviour evals** in `template-dev/tests/skill-evals/<name>.json` (template repo): at least three cases (the success path,
    incomplete input, a near miss that belongs to a neighbour), each a realistic `prompt` and two or more checkable
    `assertions` about the answer, not its wording (one is enough for a `near-miss-…` routing case). The self-test checks their shape; to run one, give the prompt to an agent with
    the skill and judge each assertion PASS / FAIL, before and after a change (A/B).

## Report

```markdown
**Skill:** <name> · **Verdict:** Pass | Pass with fixes | Rework
| # | Severity (Blocking / Suggestion) | Where | Issue | Why it matters | Fix |
**Trigger test:** <should-trigger 5/5 · near-miss 3/3, or the misses>
**Not checked:** <runtime behaviour on a real module, unless a run was done>
```

## Rules

- Evidence: every finding names the line or the missing file. A static review says nothing about how the skill
  performs on real input; say so, and suggest a trial run on one module for big changes.
- New skill: copy `SKILL_TEMPLATE.md`, name it `<group>-<objective>`, add a README row in its group and an eval file, then sync and self-test.

## Done when

- [ ] Eleven checks done; trigger test written; evals present or proposed; verdict with fixes.
- [ ] If applied: skill edited, Updated stamp set, `sync_agents.py` run, self-test green, CHANGELOG line (template).
