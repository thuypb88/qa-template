---
name: auto-decide
description: Automation A1: what and how to automate (after the test case review). Decide for every test case of a folder (or all) whether and how to automate it with a fixed gate tree (surface, oracle, surface purity, controllability / test hooks, data, stability, level), for every pack (Playwright for UI, pytest + api_client for API, pytest + reconcile for ETL, verification procedures / scripts for SQL); set automation / automation_note in test-cases.json, write 3-test-cases/automation-plan.md (specs, readiness, waves, blockers, manual residue) and refresh automation/docs/automation-feasibility.md. Use for "what can we automate in E4", "re-tag automation", "update the automation feasibility", or after a suite changes version. Writing the tests → auto-write (SQL: sql-verify).
metadata:
  group: auto
  order: "A1"
---

# Automation: decide what and how to automate

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** `3-test-cases/test-cases.json` (+ its review), `1-analysis.md` (fixtures, open `Q-xxx`),
`automation/docs/automation-feasibility.md` (hooks H1…, frameworks; created on the first run). **Out:** `automation` /
`automation_note` per TC (version bumped, Excel re-exported); `3-test-cases/automation-plan.md`; the folder's rows in
the feasibility doc. **Rules:** R2, R8, R9, R10. **Next:** `auto-write`.
**Stop if** the JSON is missing. Unreviewed or Rework → decide anyway; the plan header says it may change.

## 1. Gate tree (per TC, gates in order, first hit wins)

Read title, preconditions, steps, expected, notes. Batch with `slice.py tc <target> --form "<item>"`, or `--grep` for
gate words (`print|scan|Reader|physical|nightly|timeout|clock|exploratory`).

| Gate | Question | If… | Decision (`automation` · `automation_note`) |
|---|---|---|---|
| **G1 Surface** | Where does the tester act / look? | the pack's runner reaches it (browser UI, HTTP, SQL) | → G2 |
| | | a desktop app / native dialog / paper / physical device / phone / scanner | Manual · `<the thing>, not reachable by the runner` (or Auto + Manual when a part is) |
| | | load / throughput | Auto · `k6 / JMeter performance script` |
| **G2 Oracle** | Can a script decide pass / fail? | exact text / state / status / body value / count / diff | → G3 |
| | | look and feel (layout, colour, font) | Auto + Manual · `Screenshot comparison automated; visual sign-off manual` |
| | | accessibility | Auto + Manual · `axe-core automated; screen reader and keyboard walk-through manual` |
| | | judgement / exploratory | Manual · `Exploratory` |
| **G3 Surface purity** | Steps and results only at the pack surface (R2)? | a UI TC with a DB / API step; an API TC asserting a DB row | keep Auto · `Off-surface step: rewrite (R2) before automating`; readiness **Rewrite (R2)**; raise to the writer |
| **G4 Control** | Can the test set up the state? Each need = a hook `Hn` in the feasibility doc | waits for a scheduled job / poll | `Needs 'run job now' trigger (H2)` |
| | | a failure on purpose | `Needs fault switch / mock error scenario (H3)` |
| | | timeout / session expiry | `Needs short timeout config (H4)` |
| | | time of day, date boundaries | `Needs clock control (H5)` |
| | | "ask ops to change data / config" | `Needs a control endpoint (H6)` |
| | | nothing | empty note |
| **G5 Data** | Concrete and resettable by a fixture (H1)? | no: "valid value", data from another TC, unknown fixture | keep Auto; readiness **Blocked (data)**; raise it |
| **G6 Stability** | Is an expected value an open `Q-xxx`? | yes | keep Auto; readiness **Deferred (Q-xxx)**; don't script an unconfirmed value |
| **G7 Level** | IT or ST? | IT | by G1–G6 |
| | | ST | Auto only for smoke + the regression selection, our side only; other teams' steps Manual; else Manual · `ST cycle 1 manual; regression candidate` |

- **Hooks** are numbered once per project in the feasibility doc (§Hooks: H1 fixture reset, H2 run job now, H3 fault
  switches, H4 short timeouts, H5 clock, H6 control endpoint, H7 mock login / tokens, …); add new ones there first.
- **Readiness** (plan only): Ready · Blocked (Hn) · Rewrite (R2) · Blocked (data) · Deferred (Q-xxx). Manual has none.
- **Low value** (still Auto, last in its wave) only if P3 / P4, one-off, and it needs a page object / fixture nobody
  else uses. Never for P1 / P2, RBAC, state, security, reconciliation.

## 2. Specs (input for auto-write)

- **One spec per level-1 item** (screen / endpoint group / target table / job), named per pack:
  UI `automation/ui/tests/<id>/<item>.spec.ts`; API `automation/api/test_<id>_<item>.py`; ETL
  `automation/etl/test_<id>_<table>.py`; SQL `automation/sql/verify/verify_<object>.<dialect>.sql` (written by
  `sql-verify`).
- **Data-driven rows:** TCs differing only by data (R10 variants, R6.3 languages, boundaries, roles, required fields)
  are one parametrised test, one row per TC ID. API / ETL TCs whose block fully describes them go to the
  data-driven runner (`test_example_api.py` / `test_example_etl.py` pattern) — no hand-written test.
- **Waves:** smoke + auth / RBAC first; then P1 / P2 by module order; then the rest; nightly CI last. Within a wave:
  Ready before Blocked, P1 before P4.

## 3. Outputs

1. **JSON:** set the two fields; bump `version` (minor); `python3 scripts/export_testcases.py <target>` (0 Error). Never
   change TC content here; wrong content → *Raise to the writer*.
2. **`3-test-cases/automation-plan.md`:** header (date, TC version, review state); counts (Auto / Auto + Manual /
   Manual; Ready / Blocked by hook / Rewrite / Deferred); the spec table (`Spec | Pack | TCs | Data-driven | Fixtures /
   hooks | Readiness | Wave`); blockers (`Hook / question | TCs | Owner`); *Changes to the tags* (TC · old → new · gate);
   *Raise to the writer*; the manual residue list.
3. **Feasibility doc** (`automation/docs/automation-feasibility.md`, project-owned): one row per folder (counts,
   readiness, first spec), the hooks table, frameworks per pack. Create it on the first run.

## Rules

- Values only `Auto` / `Manual` / `Auto + Manual`. Keep `automation_note` strings identical across TCs (the plan groups
  on them).
- **The surface is the oracle.** A hook only sets up state.
- Read-only: TC IDs, `sources/`, analysis, mindmap.

## Pitfalls

L-T14 (trusting a keyword tagger), L-T15 (stale counts) in [standards/template-lessons.md](../../../standards/template-lessons.md).
"Needs … hook" is Auto waiting on DEV, not Manual — count it apart.

## Done when

- [ ] Every TC through G1–G7; every change listed with its gate; export 0 Error; `version` bumped.
- [ ] Plan counts = JSON; every Auto TC in exactly one spec row; feasibility doc rows match.
- [ ] Report Auto / Auto + Manual / Manual, Ready vs Blocked by hook, R2 rewrites, the first spec; suggest
  `auto-write` wave 1 (or the writer first for R2 rewrites).
