---
name: check-automation
description: Check A3 (reviewer, after auto-write; IT or ST, every pack): review the automated tests. For one spec, wave or folder under automation/<pack>/ ask of every test "would it fail on a wrong build?" - binding to its TC, strength (Strong / Weak / Fake, with the smallest wrong build that still passes), surface, expected values from the source, side-effect checks, locators, waits, mocks and fixtures, data isolation, secrets, SQL verification procedures - and write 3-test-cases/automation-review.md with AR- findings (ST SAR-); then offer the fixes to auto-write (SQL: sql-verify). Use for "review the automated tests of E4", "are these Playwright / pytest tests any good?", "check wave 1", "why is this test always green?". Not for: the test cases themselves → check-design; writing or fixing tests → auto-write; a failed run → run-tests.
metadata:
  group: check
  order: "A3"
---

# Check: automated tests

> **Created:** 2026-10-16 10:20 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** a target (module id, `st`) and optionally a spec / wave of its `automation-plan.md`; the test files under
`automation/<pack>/`; the TCs they name. **Out:** `3-test-cases/automation-review.md` (overwrite); fixes only on the
user's OK. **Rules:** [standards/review-protocol.md](../../../standards/review-protocol.md) P1–P7; core R2, R9; pack
rules. **Next:** `auto-write` (test defects) or `design-cases` (TC defects), then `run-tests`.
**Stop if** there are no automated tests for the target → `auto-write`; no automation plan → `auto-decide`.

## Steps

1. **Lessons first** (P1.5): `project/lessons.md` and the L-T rows naming `auto-write` or `check-automation`.
2. **Binding scan:** `python3 scripts/run_tests.py <target> --plan` — copy the numbers (bound / unbound Auto TCs)
   into the header; every unbound Ready row is a finding.
3. **Checklist:** [references/automation.md](references/automation.md) — twelve checks (12 = SQL verifications); strength (check 2) for
   every test, the others where they apply.
4. **Spot-check** ≥ 10 tests, all P1 first: open the TC (`slice.py tc <target> --ids …`) next to the test and write
   the smallest wrong build that would still pass it.
5. **Write** the review file in the format of [check-design](../check-design/SKILL.md#output-format) with the
   coverage line `tests a/b bound · Strong a · Weak b · Fake c`.
6. **Report and offer fixes** (P5): a test defect goes to `auto-write` (SQL verifications: `sql-verify`); a TC that is itself vague or wrong goes to
   `design-cases` as **Fix upstream**. Re-run `run_tests.py <target> --grep <ids>` after fixes.
7. `project/status.md` board row + `project/log.md`; commit `<id> automation review: <verdict>`.

## Rules

- Green is not evidence: a test that cannot fail for a product reason is **Fake**, whatever its run history.
- Judge against the TC and its source, never against today's build output.
- Review only; the writer applies the fixes (writer ≠ reviewer).

## Done when

- [ ] Binding numbers in the header; every test classified Strong / Weak / Fake.
- [ ] ≥ 10 tests spot-checked (P1 first), each with its smallest wrong build.
- [ ] Every finding has evidence, severity and a fix aimed at `auto-write` or `design-cases`.
