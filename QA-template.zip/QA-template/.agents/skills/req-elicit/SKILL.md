---
name: req-elicit
description: Requirements: ask why before anything is written down (a vague request, a change request, "test the new X" with no document, a stakeholder's "we need …"). Run an ask-why elicitation loop from the QA side - classify the request (feature, complaint, workaround, KPI, solution bias, compliance…), show the five requirement layers (business, stakeholder, functional, non-functional, transition) as clear / partial / empty, list known vs unknown, ask 3-5 contextual questions per turn, paraphrase each answer and classify it (symptom, root cause, rule, constraint), scan the failure modes nobody mentioned, stop when goals and risks are clear - then write plans/discovery/<date>-<slug>.md with open questions and assumptions. Use for "we got a new request", "the client wants …, what should we ask", "clarify this CR", "discovery", "elicit requirements", "ask why", "phân tích yêu cầu", "khách hàng yêu cầu", "làm rõ yêu cầu". Reviewing a written document → req-review; writing stories → req-write.
metadata:
  group: req
  order: "-"
---

# Requirements: elicit (ask why before testing what)

> **Created:** 2026-10-16 09:48 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** the request as the user gives it (chat, email text, a meeting note, a ticket), any related sources and
`project/system-map.md`, `project/questions.md`. **Out:** a conversation of short turns, then
`plans/discovery/<YYYY-MM-DD>-<slug>.md`; open questions into `project/questions.md` on the user's OK. **Rules:** core
R1 (no invention); [standards/methods/requirement-quality.md](../../../standards/methods/requirement-quality.md) §2 (gap
kinds), §6 (closable questions), §7 (layers). **Next:** the BA / client answers; then `req-write` or
`req-write` (if QA must draft the requirement), or `req-review` / `plan-changes` when a document
arrives.

QA's reason to do this: a request accepted at face value gives tests for the wrong thing. The output is questions and
findings for the people who decide — never a requirement QA made up.

## The loop (one or two stages per turn; never all at once)

1. **Classify the request.**

   | Kind | Signal | First move |
   |---|---|---|
   | Feature request | "add", "we need to build" | ask for the problem and who has it, before any feature detail |
   | Complaint / defect | "broken", "too slow", "users complain" | frequency, impact, where; symptom vs cause |
   | Operational pain / workaround | "we export to Excel", "ops does it by hand" | why the workaround exists; what breaks without it |
   | KPI / objective | "reduce", "increase … by" | which behaviour drives it; baseline and target |
   | **Solution bias** | a tool or technology named as the requirement | treat it as a hypothesis; find the problem first |
   | Process / reporting / compliance | approvals, reports, "regulation requires" | owner, rule source, evidence the auditor needs |

2. **Layer status** — show the table every turn (✅ clear · 🟡 partial · ⛔ empty): business, stakeholder,
   functional, non-functional, transition (§7 of the reference). A request that jumps to functions without a business
   reason is incomplete.
3. **Known / unknown** — objective and measure, stakeholders and roles, volume and frequency, current process, rules
   and eligibility, exceptions, constraints (regulation, budget, systems), risks, success measure, NFRs, migration /
   cutover.
4. **Ask 3–5 questions**, specific to this request and its gaps, in this priority: business impact → root cause →
   who → current process → risk → edge cases → how success is measured. Never a generic questionnaire.
5. **After each answer:** paraphrase it in one or two sentences, classify it (symptom · root cause · rule ·
   constraint · requirement · assumption), update the findings, then ask the next batch.
6. **Failure scan** (at least once): duplicates, timeouts, retries, rollback, partial failure, fraud / abuse,
   permissions, audit trail, data inconsistency, regulatory cases (personal data, KYC / AML where relevant).
7. **Stop** when the goal is measurable, causes (not only symptoms) are known, behaviour is concrete enough to test,
   the main risks are named, and new questions add little. Say so and ask the user for corrections before writing.

## Findings file (`plans/discovery/<date>-<slug>.md`)

Header (request, who asked, date, status Draft) · business problem and measurable goal · stakeholders · pain points
and root causes · candidate functional and non-functional requirements (marked **candidate**, each citing who said
it) · business rules heard · transition needs · edge cases · layer status table · **assumptions** · **open
questions** (`Topic | Question | Owner | Blocks`) · test impact (what QA can and cannot plan yet; suggested next skill).

## Rules

- Max 3–5 questions per turn; no BRD / SRS / stories in the first answer.
- Every finding cites its speaker or source; inferences are labelled assumptions.
- The findings are input for the BA / client; nothing here becomes a test basis until confirmed in a source document.

## Done when

- [ ] Layer table, known / unknown and the failure scan done; stop condition stated.
- [ ] Findings file with assumptions and open questions (owners); questions copied to `project/questions.md` on OK.
