---
name: sql-explain
description: SQL (any time): explain a query, stored procedure, execution plan or database error so the reader understands what it really does - in logical evaluation order (FROM / JOIN → WHERE → GROUP BY → HAVING → SELECT → ORDER BY), what each join keeps or drops, how NULLs, duplicates and implicit conversions change the result, what a procedure reads, decides and writes, what a plan step costs and why - at the depth of the named audience (tester, BA, developer, PM, beginner / ELI5), with a tiny worked example on made-up rows. Use for "explain this query", "what does this SQL do", "why does this return duplicates", "explain this execution plan", "what does error 547 / ORA-01403 mean", "giải thích câu SQL", "giải thích store procedure". Not for: mapping many objects → sql-study; fixing a failing or slow query → sql-debug; explaining a QA artifact (report, defect) → learn-explain.
metadata:
  group: sql
  order: "-"
---

# SQL: explain

> **Created:** 2026-10-16 11:30 · **Updated:** 2026-10-16 12:05 (UTC+7)

**In:** the SQL text, procedure name (its source or `sql-study` card), plan output or error text; the dialect
(`project.json › sql.dialect`, else ask or infer from syntax and say so); the audience (default: a tester).
**Out:** chat; on request a note in `<folder>/sql-study/explain-<slug>.md`. **Rules:** facts only from the given
code / plan / docs; [packs/sql/dialects.md](../../../packs/sql/dialects.md) for dialect behaviour; audience shapes as
in [learn-explain](../learn-explain/SKILL.md). **Next:** none, or `sql-debug` if the explanation shows a defect.

## Modes

| Mode | Input | Shape |
|---|---|---|
| **query** | a SELECT / DML statement | one-line purpose → logical order walk-through → result shape (grain: one row per …) → traps |
| **procedure** | a procedure / function / trigger | purpose → inputs → flow (validate → read → decide → write → return) → effects → error paths |
| **plan** | an execution plan / EXPLAIN output | the costliest steps first: what each does, rows estimated vs actual, why the optimiser chose it |
| **error** | an error message / code | what the engine refused, the usual causes, how to confirm which one applies |

## Steps

1. **One-sentence answer first:** what the code returns or changes, in business words.
2. **Walk it** in the mode's shape. For queries, state the **grain** (one row per …) after each join; a join that
   multiplies rows is called out.
3. **Worked example:** 3–5 made-up rows per table, the intermediate result after the step that matters, the final
   rows. Mark them as illustrative, never as project data.
4. **Traps** that apply here only: NULL in `=` / `NOT IN` / aggregates, `LEFT JOIN` turned inner by a `WHERE` on
   the right table, missing `ORDER BY`, `DISTINCT` hiding a join problem, integer division, implicit conversion,
   time zone / `DATE` with time, Oracle `'' = NULL`.
5. **Audience close:** for testers, the cases worth a test (checklist IDs from
   [packs/sql/checklist.md](../../../packs/sql/checklist.md)); for a PM / BA, what it means for the business; for
   ELI5, one analogy and no jargon.

## Rules

- Explain what the code does; when it seems to contradict the spec, say so and cite both — don't decide which is
  right (→ `Q-xxx` or `sql-debug`).
- No guessing table meanings: unknown columns are "not documented".
- Keep it as short as the audience needs; a 5-line query does not get a 2-page answer.

## Done when

- [ ] Opening sentence, walk-through in the mode's shape, a worked example where rows matter.
- [ ] Traps listed only where they apply; dialect stated (given or inferred).
