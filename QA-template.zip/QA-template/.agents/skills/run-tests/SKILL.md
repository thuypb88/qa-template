---
name: run-tests
description: Run: execute the tests (both levels, every pack). Run the automated tests of one folder, several, all IT, ST or everything with scripts/run_tests.py; summarise passed / failed / skipped / no result / manual residue in runs/run-summary.md; triage every failure (product, automation, test case, environment); hand over the manual checklist; and, when the user names a cycle, record it into test-cases.json + Excel. Use for "run the tests", "execute E4", "run all IT / ST", "full regression", "rerun TC-E6-039", "record cycle C1". Writing tests → auto-write; what to automate → auto-decide.
metadata:
  group: run
  order: "E"
---

# Run: execute the tests

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:43 (UTC+7)

**In:** targets (`E4`, several, `it`, `st`, `all`); options: `--grep <TC id or prefix>`, `--pack`, a cycle name.
**Tool:** `scripts/run_tests.py` (runners per pack from `project.json › runners`). **Out:** `runs/run-summary.{md,json}`,
`runs/<key>/results.csv`, JUnit files, `manual-checklist.csv`; with a cycle: result fields in `test-cases.json` +
Excel. `runs/` is not in git: a run is kept only when recorded. **Rules:** R2 (judge at the surface), R9 (the right
environment per level). **Next:** defects → DEV; test fixes → `auto-write` / the writers.

## Steps

1. **State:** `python3 scripts/pipeline_status.py <target>`. Warn, don't stop, on unaccepted source changes,
   unreviewed / stale / Rework TCs, a plan older than the TCs; say so in the report.
2. **Plan:** `python3 scripts/run_tests.py <targets> --plan`. Show what will and won't run and why. Nothing can run →
   stop and name the fix (runner, install, env variable). **A production-looking or wrong-level URL / DSN (ST at IT, IT
   at UAT) → stop and ask.**
3. **Run:** `python3 scripts/run_tests.py <targets> [--grep …] [--pack …]` (long runs in the background). Exit 1 =
   failures, 2 = set-up error.
4. **Summary:** `runs/run-summary.md` — Auto TCs, Passed / Failed / Skipped, **No result** (an Auto TC no test
   reported: never "passed"), manual residue; then the conclusion per
   [standards/methods/defect-report.md](../../../standards/methods/defect-report.md) §3: tested / not tested, failed P1 / P2 by ID before
   any pass rate, the test plan's exit criteria as Met / Not met / Blocked / Unknown, a release *recommendation*.
5. **Triage every failure** (`runs/<key>/results.csv` reason, then the TC with `slice.py tc <target> --ids …`).
   More than 20: group by reason, analyse one per group. Classes:
   - **Product defect** → for DEV: TC, build, steps, expected vs actual, evidence path (`defect_id` only when the user
     gives one).
   - **Automation defect** (locator, binding, timing, data) → fix in `automation/` with the user's OK.
   - **TC defect** (expected contradicts the source) → the writer, with evidence.
   - **Environment** (down, mock / hook missing) → rerun once with `--grep`, then report.
   - **Flaky** (fails, then passes on an unchanged rerun) → report "passed 1 of 2", find the cause (shared data,
     order, a time-based wait, the clock); quarantine only with the user's OK, an owner and an exit condition.
   Never change an expected result or assertion, add retries or stretch timeouts to go green.
   Product defects are written per [standards/methods/defect-report.md](../../../standards/methods/defect-report.md) §1 (one report per
   symptom, listing every TC it fails).
6. **Record a cycle** only when the user names one: `python3 scripts/run_tests.py <targets> --record <cycle>` (bumps the
   suite version, re-exports); commit `<id> cycle <name>: <passed>/<auto> passed`.
7. **Manual residue:** hand over `runs/<key>/manual-checklist.csv` (Manual, Auto + Manual and untagged TCs). When
   the testers return it filled (result, tester, notes, defect_id), record it:
   `python3 scripts/record_manual.py <target> <csv> --cycle <cycle>` (`--dry-run` first). Product defects →
   `run-defects`; a cycle or release report → `run-report`.
8. `project/status.md` + `project/log.md`; a defect pattern worth remembering → `learn-retro`.

## Done when

- [ ] Plan shown; run done or the blocker named; summary written; every non-skipped failure triaged.
- [ ] Report the table, the defects for DEV, the manual residue count, and the cycle if recorded.
- [ ] Nothing that did not run is reported as passed; flaky tests named; quarantines have an owner and exit condition.
