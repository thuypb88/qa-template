# Skills catalog

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:54 (UTC+7)

Thirty-two skills in **eight groups by objective** plus the **domain group `sql-`**. Each name is `<group>-<objective>`, so the groups stay together in
every skill picker (Claude Code `/`, Codex, Copilot), which all sort by name and only find `skills/<name>/SKILL.md`, one
level deep. The level comes from the target (a module id → IT, `st` → ST); the pack from `project.json`. This README is
the catalog, not a skill. Design rules: [standards/skill-architecture.md](../../standards/skill-architecture.md); the v1.4 → v1.5 rename map:
`template-manifest.json › renamed_skills`. After changing a skill, run
`python3 scripts/workspace/sync_agents.py` (Codex copy in `.agents/skills/`, Copilot copy in `.github/skills/`).

**Not sure which skill?** `/flow-next` names one, with its reason.

```mermaid
flowchart LR
    FN{{flow-next}} -.routes.-> plan & req & design & check & auto & run & learn
    FC[[flow-cadence: day · sprint · release]] -.gates.-> run
    subgraph plan[plan- · what to test]
        PS[setup] --> PT[strategy] --> PC[changes] --> PSc[scope]
    end
    subgraph req[req- · is it testable]
        RE[elicit] --> RR[review]
        RW[write]
    end
    subgraph design[design- · what exactly]
        DA[analysis] --> DS[scenarios] --> DC[cases] --> DD[data]
        DN[nfr]
    end
    subgraph check[check- · is our work right]
        CD[design]
        CA[automation]
        CS[skill]
    end
    subgraph auto[auto- · automate]
        AD[decide] --> AW[write]
    end
    subgraph run[run- · does the build work]
        RS[select] --> RT[tests] --> RD[defects] --> RP[report]
        RX[explore]
    end
    subgraph learn[learn- · learn and share]
        LR[retro]
        LE[explain]
    end
    plan --> req --> design --> auto --> run --> learn
    DA & DS & DC -. reviewed by .-> CD
    AW -. reviewed by .-> CA
```

## flow- · Where are we, and what next?

Orchestrators: they name the next skill and keep the gates; they never do the work.

| Skill | Objective | Writes |
|---|---|---|
| `flow-next` | the one next skill for a folder or a plain request (router) | chat |
| `flow-cadence` | pace a **day** (start gate, queue, EOD), a **sprint** (six stages, DoD) or a **release** (freeze, RC, go / no-go, after go-live) | chat · `plans/sprints/` · `plans/releases/` |

## plan- · What do we test, how, and is our basis current?

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| -1 | `plan-setup` | set up a project from the template, once | `project.json`, `project/` (rules, memory), folders | `qa_config.py --validate`, `init_project.py` |
| -1 | `plan-strategy` | write or review the test strategy (project, sprint or release section) | `plans/test-strategy.md` | — |
| 0 | `plan-changes` | what changed in `sources/`, what it touches (affected TCs) | `project/change-impact/…`, baseline | `trace_changes.py` |
| 0 | `plan-scope` | one module's scope boundary and readiness | `0-scope.md` MANUAL block | `init_project.py` |

## req- · Is the requirement good enough to test?

QA's side of the requirements. Proposals stay **Proposed** until the BA / client confirms them and the user puts the
confirmed text in `sources/` (then `plan-changes` → `design-analysis`).

| Skill | Objective | Writes |
|---|---|---|
| `req-elicit` | ask why before anything is written: layers, known / unknown, 3–5 questions per turn | `plans/discovery/…` |
| `req-review` | findings and questions on a written document (SRS, stories, use cases, API spec, mapping) | `plans/requirement-reviews/…`, `project/questions.md` |
| `req-write` | draft or fix requirement text — form **story** (INVEST, Given-When-Then) or **use-case** (13 fields, 20-point check, test seeds) | `plans/stories/…`, `plans/use-cases/…` (Proposed) |

## design- · What exactly do we test, with which data?

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| 1 | `design-analysis` | analysis of a module (IT) or the system (ST) | `1-analysis.md` | — |
| 3 | `design-scenarios` | test scenarios (mindmap + table) | `2-mindmap.md` | `check_scenarios.py` |
| 5 | `design-cases` | test cases, pack checklist pass, Excel | `test-cases.json`, `checklist-pass.md`, Excel | `export_testcases.py --check` |
| 5+ | `design-data` | data plan, sets and fixtures | `3-test-cases/test-data.md`, `automation/<pack>/fixtures/` | — |
| ST | `design-nfr` | performance, security, accessibility, compatibility plan | `test-design/st/nfr-plan.md` | `check_scenarios.py st` |

## check- · Is our own work right?

Independent reviewers: findings with evidence and fixes; the writer applies them (writer ≠ reviewer).

| Order | Skill | Reviews | Writes | Check |
|---|---|---|---|---|
| 2 · 4 · 6 | `check-design` | analysis, scenarios, test cases | `*-review.md` | the step's script |
| A3 | `check-automation` | automated tests: would each fail on a wrong build? | `3-test-cases/automation-review.md` | `run_tests.py --plan` |
| — | `check-skill` | a skill as a contract; its behaviour evals; new skills | the skill (on OK), sync | `template-dev/tests/selftest.py` |

## auto- · What do we automate, and build it

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| A1 | `auto-decide` | what and how to automate, per TC | `automation` fields, `automation-plan.md` | `export_testcases.py --check` |
| A2 | `auto-write` | write the tests for a spec or wave | `automation/<pack>/…` | `run_tests.py --plan` |

## run- · Does the build work, and what do we tell people?

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| E0 | `run-select` | the regression set for a build / fix / release (sole owner) | `plans/regression/…` | — |
| E | `run-tests` | run, triage, record cycles and manual results | `runs/`, cycle results | `run_tests.py`, `record_manual.py` |
| E | `run-explore` | exploratory charters, sessions, debriefs | `<folder>/exploratory/ET-NNN-…` | — |
| E | `run-defects` | report, register, retest, close defects | `project/defects.md` | — |
| E+ | `run-report` | test summary / exit report | `test-reports/…` | — |

## learn- · What did we learn, and can others follow it?

| Skill | Objective | Writes |
|---|---|---|
| `learn-retro` | lessons, decisions, lasting fixes | `project/` |
| `learn-explain` | explain an artifact or a point to a named audience (client, PM, BA, dev, new tester, ELI5) | chat |

## sql- · Database code: understand it, test it, verify it (domain group)

For stored procedures, functions, views, triggers, jobs and queries — engine-neutral, with SQL Server / Oracle /
PostgreSQL / MySQL notes in [packs/sql/dialects.md](../../packs/sql/dialects.md). A module with `"pack": "sql"` runs the
normal chain with `sql-cases` at step 5 and `sql-verify` at A2; study, explain and debug work on any SQL, in any
project. Why a domain group: [skill-architecture.md §3a](../../standards/skill-architecture.md).

| Order | Skill | Objective | Writes | Check |
|---|---|---|---|---|
| 1- | `sql-study` | study database code: one card per object (interface, data touched, rules with `file:line`, errors, transactions, risks) | `<folder>/sql-study/` | — |
| — | `sql-explain` | explain a query, procedure, plan or DB error to a named audience | chat | — |
| E | `sql-debug` | reproduce, shrink, test hypotheses, root cause; defect or script fix | `<folder>/sql-debug/` | — |
| 5+ | `sql-data` | idempotent data + cleanup scripts per data set | `3-test-cases/sql/data/` | run twice + cleanup |
| 5 | `sql-cases` | test cases with the `sql` block, SQL checklist pass | `test-cases.json`, `checklist-pass.md`, Excel | `export_testcases.py --check` |
| A2 | `sql-verify` | verification procedures / scripts returning `tc_id, result, detail` | `automation/sql/verify/`, `test_<id>_sql.py` | `run_tests.py <id> --pack sql` |

```mermaid
flowchart LR
    SS[sql-study] --> DA[design-analysis] --> DS[design-scenarios] --> SC[sql-cases] --> SD[sql-data]
    SC --> AD[auto-decide] --> SV[sql-verify] --> RT[run-tests]
    RT -. failure .-> DB[sql-debug]
    SX[sql-explain]
```

## Order across levels

`plan-setup` (+ `plan-strategy` when the client has no usable plan; `req-elicit` for a vague request) →
(`design-analysis st` → `check-design st analysis`, when the test plan has a system level) → each module in
`project.json` order through steps 1–6 (`req-review` first for a raw document) → `design-analysis st` again (picks up
every "Moved to ST") → the rest of the ST chain (+ `design-nfr`) → `auto-decide` → `auto-write` (→ `check-automation`)
→ `run-select` → `run-tests` / `run-explore` / `run-defects` → `run-report` → `learn-retro`.

## Shared methods (read on demand, never copied into a skill)

| File | What | Read by |
|---|---|---|
| [requirement-quality.md](../../standards/methods/requirement-quality.md) | atomic rules, gap kinds, ambiguity, conflicts, testability, closable questions, layers, stories, use cases | `req-*`, `design-analysis`, `plan-strategy` |
| [test-techniques.md](../../standards/methods/test-techniques.md) | EP, BVA, decision table, state transition, pairwise, failure paths, edge dimensions, use-case flows | `design-scenarios`, `design-data`, `plan-strategy` |
| [defect-report.md](../../standards/methods/defect-report.md) | defect report, flaky tests, run summary conclusion | `run-tests`, `run-defects`, `run-report` |

A skill's own `references/` hold only its own modes and checklists (`check-design/references/`,
`flow-cadence/references/`, `req-write/references/`, `check-automation/references/`).

## Rules for skills

- **Add a skill** only when its input, primary output and triggers are bounded apart from every other skill;
  otherwise add a mode (a `references/<mode>.md`), a pack file (`packs/<pack>/…`) or a shared method.
- **Write one:** copy [SKILL_TEMPLATE.md](SKILL_TEMPLATE.md), pick the group, add a row above, then `check-skill`
  it and add `template-dev/tests/skill-evals/<name>.json`.
- `python3 template-dev/tests/selftest.py` checks: name = folder = `<group>-<objective>` (groups incl. `sql`); `metadata.group` = the prefix and an
  `order`; description ≤ 1024 chars; a `## Done when` list; every relative link (skills and `standards/methods/`);
  no link into another skill's `references/`; no retired v1.4 name anywhere; the eval files' shape.

**Sources studied:** awesome-qa-skills (PolyForm Noncommercial; v1.2–1.3, and the grouping by objective in v1.5),
BA Zone's user-story / use-case / product-discovery skills by Phúc NT and the ELI5 skill (MIT; v1.4). Ideas were
rewritten for this pipeline; no text was copied.
