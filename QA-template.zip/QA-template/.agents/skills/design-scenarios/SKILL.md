---
name: design-scenarios
description: Design step 3 (writer, IT or ST): the test scenarios. Build the test scenario mindmap of a module (or the system) from 1-analysis.md into 2-mindmap.md - Mermaid blocks plus the scenario table, laid out by the pack layout (UI form / flow, API resource / flow, ETL table / job; ST groups smoke, E2E, UC, integrations, RBAC, errors, NFR). Use for "design the E4 scenarios", "build the mindmap", "design the system / E2E scenarios", or to rebuild a mindmap in the current layout. Reviewing it → check-design.
metadata:
  group: design
  order: "3"
---

# Design: test scenarios (mindmap)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** `1-analysis.md` (+ `1-analysis-review.md`: apply its open findings; header says "unreviewed" if absent); its
inventory gives level 1. ST: also the module mindmaps' E2E branches. **Out:** `2-mindmap.md` (overwrite; title
exactly `# <name>: test mindmap`). **Rules:** core R1, R2, R5, R7, R10; `packs/<pack>/scenarios.md` (layout, prefixes,
easy-to-miss list). **Next:** `check-design`.
With `3-test-cases/test-cases.json` present you are **rebuilding**: write a TS mapping. For a few new scenarios,
**append** instead.

Read lean: one inventory item at a time (`slice.py section 1-analysis.md "<item>"`, `slice.py rows … TCOND-…`); write
its block before reading the next.

## 1. Layout

- **IT:** the pack layout of the module (`project.json › modules[].layout`): level 1 = inventory items in inventory
  order, level 2 = the layout's areas in their order; cross-cutting branches last (pack `cross_cutting_areas`).
  Never by requirement ID.
- **ST:** level 1 = groups: Smoke → E2E flows (one per chain) → UC walkthroughs → Integrations (one per INT row) →
  RBAC → Error handling → Non-functional. Area = the group's step (e.g. `Main flow`, `Exception`) — use the areas of
  the packs involved.

## 2. Scenario rules

1. **One level-1 item × one behaviour** per scenario. Not "mandatory checks per form", not "all endpoints".
2. **Observable at the surface** (R2); invisible checks → **Out of black-box scope**.
3. **Every AC** maps to a scenario (R1); cite client-document layouts / wording.
4. **Security** per the module's `security` value and the pack's techniques.
5. **Level fit** (R9): IT moved-to-ST items go in that table; ST does not repeat IT field checks.
6. **R10** once per variant: valid + invalid each. **R6.3** one Localization scenario per language per input.
7. **Open questions** in the text (`Q-xxx`).
8. **Priority by risk:** P1 / P2 money, state, security, data loss, hand-offs; P3 / P4 cosmetic.
9. Walk the pack's **easy-to-miss** list per level-1 item by hand (L-T13).
10. **Apply the technique, don't just name it** ([standards/methods/test-techniques.md](../../../standards/methods/test-techniques.md)): pick it from
    the rule's shape (field → partitions + boundaries; condition combinations → decision table; status / lifecycle →
    state transition; many factors → pairwise; writes / dependencies → failure paths), do its steps, and put what it
    found (a gap, an overlap, an unreachable state) in §9 of the analysis via a `Q-xxx`.
11. **A refusal scenario names the absence of a side effect** where the source says nothing may change (no record,
    no state change, no partial load), not only the message.
12. **No duplicates:** two scenarios with the same trigger, action and observable outcome are one; split only when
    the trigger, the way it is run or the expected outcome differs.

## 3. Mermaid

One overview block (root = module, level 1, level 2, no leaves), then one block per level-1 item under
`### <item>`:

```mermaid
mindmap
  root((Orders - POST /v1/orders))
    Request validation
      v1["[N] Missing currency is rejected"]
      v2["[B] Amount 0.01 accepted"]
    Auth
      a1["[S] Other buyer's cart refused"]
```

Leaves always quoted `id["[X] text"]`, unique ids per block, ≤ 8 words; prefixes from the pack's `scenarios.md`.

## 4. Scenario table (fixed columns; the scripts read them)

| Scenario ID | <Level-1 header of the layout> | Area | Requirement | Refs | Scenario | Type | Priority | Technique |
|---|---|---|---|---|---|---|---|---|
| TS-001 | POST /v1/orders | Request validation | FR-003 | TCOND-021, AC-02 | Order without currency is rejected with 400 and error code CURRENCY_REQUIRED | Negative | P2 - High | equivalence partitioning |

- Rows follow the mindmap, item by item, area by area; `TS-001…` in that order; leaves ↔ rows 1:1.
- **Type**: `project.json › values.test_types` + the pack's extra types. **Priority**: `values.priorities`.
- **Adding later:** next free TS IDs, each row inside its item and area (the "split into runs" warning is expected;
  merges at the next rebuild).

## 5. Other sections

- **Out of black-box scope** · **Moved to ST** (IT) · **Coverage check** (every requirement / TCOND / AC reaches a
  scenario, or the reason; an items × areas matrix; the security techniques covered; blocking `Q-xxx`).
- **TS mapping** (rebuild with TCs present): old TS → new TS; `design-cases` must then rewrite the TCs.

## 6. Check

`python3 scripts/check_scenarios.py <target>`: fix every Error; fix or justify each Warning.

## Pitfalls

L-T03, L-T10, L-T13 ([standards/template-lessons.md](../../../standards/template-lessons.md)), plus:
- **By-requirement tree** in a form / resource / table module = Rework.
- **Renumbering with TCs present.** Append, except a full rebuild with a TS mapping.
- **Citing an ID the analysis lacks.** Write "TCOND pending"; raise it upstream.
- **Integer boundaries on everything.** Amounts, decimals, byte-limited text and date-times have their own step
  (techniques §3).
- **Only the happy transition.** Each state needs its refused events too (techniques §5).

## Done when

- [ ] Layout per pack; cross-cutting last; leaves ↔ rows 1:1; TS in order.
- [ ] Easy-to-miss list walked per item; R10 and R6.3 complete; every Technique value applied per its section.
- [ ] Out of scope, Moved to ST, Coverage check (+ TS mapping) present; script 0 Error.
- [ ] Report counts per item / type / priority, uncovered items; suggest `check-design`.
