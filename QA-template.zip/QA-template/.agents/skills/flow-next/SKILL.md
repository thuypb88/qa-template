---
name: flow-next
description: Flow: which skill runs next, and why (router; before any other skill). Say which skill runs next and why, from scripts/pipeline_status.py (deliverables, review verdicts, stale reviews, automation plan, unaccepted source changes) or by matching a plain request to one skill. Use for "what's next", "where are we", "status of E4 / all modules", "which skill do I use for …", "the client sent a new file, what now?", or a request that names no skill and mixes phases. Never does the work itself.
metadata:
  group: flow
  order: "-"
---

# Flow: which skill runs next

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** a target (module id, folder, `st`) or none, and/or a plain request. **Out:** a chat answer; no files.
**Tool:** `python3 scripts/pipeline_status.py [target] [--json]` (read-only). **Next:** the named skill, only on the
user's go-ahead.

## Steps

1. **Project set up?** `project.json` missing, or `project.code` is `CHANGE-ME`, or no modules → `plan-setup`.
2. **Status:** `python3 scripts/pipeline_status.py <target>`. Read `project/index.md` › Now and `project/status.md` for
   what the script can't know (waiting on DEV, decisions pending).
3. **Sources first.** Files differ from the accepted baseline → `plan-changes` before everything, unless the latest
   `project/change-impact/` record covers exactly those files and only its follow-ups remain.
4. **Match a work request** — first the group (the question the user is asking), then the skill:

   | Group — question | Request | Skill |
   |---|---|---|
   | **flow** — what next, in what rhythm | plan my day, EOD · sprint testing, sprint exit · release, go / no-go, hotfix | `flow-cadence` (mode day · sprint · release) |
   | **plan** — what to test, is the basis current | new project, documents arrived, project.json skeleton | `plan-setup` |
   | | test plan / strategy, entry / exit criteria, review the client's test plan | `plan-strategy` |
   | | new / changed source file, impact | `plan-changes` |
   | | a module's scope, readiness per requirement, new module | `plan-scope` |
   | **req** — is the requirement testable | a vague request / CR, "the client wants …", what should we ask | `req-elicit` |
   | | check a written requirement document / story / use case, questions for the BA | `req-review` |
   | | write / refine stories and criteria, write / split use cases (as proposals) | `req-write` |
   | **design** — what exactly, with which data | analysis (module or system) | `design-analysis` |
   | | scenarios / mindmap | `design-scenarios` |
   | | test cases, Excel, checklist pass (pack sql → `sql-cases`) | `design-cases` |
   | | test data, fixtures, pairwise data sets | `design-data` |
   | | performance, security, accessibility, compatibility testing | `design-nfr` |
   | **check** — is our own work right | review an analysis, mindmap or test cases | `check-design` |
   | | review the automated tests, "is this test any good" | `check-automation` |
   | | review / write a skill, "why didn't the skill trigger" | `check-skill` |
   | **auto** — what to automate, build it | what to automate, re-tag, feasibility | `auto-decide` |
   | | write the automated tests | `auto-write` |
   | **run** — does the build work, what do we report | what to rerun for a build / fix / release | `run-select` |
   | | run tests, record a cycle, flaky test, manual results | `run-tests` |
   | | exploratory session, charters | `run-explore` |
   | | log / retest / close a defect, defect status | `run-defects` |
   | | test summary / exit / status report | `run-report` |
   | **sql** — database code (modules with pack sql, or any SQL question) | study / map a procedure, package or schema | `sql-study` |
   | | explain a query, procedure, plan or DB error | `sql-explain` |
   | | wrong rows, DB error, slow query, deadlock, failed SQL TC | `sql-debug` |
   | | test data / seed / insert scripts | `sql-data` |
   | | test cases for a procedure / function / view (pack sql) | `sql-cases` |
   | | stored procedures / scripts that verify the SQL test cases | `sql-verify` |
   | **learn** — what did we learn, can others follow | lessons, "why does this keep happening", after a review | `learn-retro` |
   | | explain something to the client / PM / BA / a new tester, ELI5 | `learn-explain` |

   If the target's upstream step is missing or stale, that step is primary.
5. **Confirm the decisive gap** in the file the script names: a review "stale" whose fixes were applied after it
   (Revision log) is not stale; **Rework** → the writer again with the findings.
6. **Answer and stop:**

   ```markdown
   **Next:** `/<skill> <target>`. <one-line reason, with the file and evidence>
   **Then:** `<following skill>`
   **Also open:** <warnings that matter, one line each, or "none">
   ```

   For all folders: the status table (folder · next · why), then the order: change control → ST analysis (when the
   test plan has ST) → modules in `project.json` order → the rest of the ST chain.

## Rules

- **One answer.** One primary skill, at most one helper.
- **Evidence only.** Every claim from the script or a file you opened, else "unknown".
- **Chain order wins.** Unreviewed steps come before automation.

## Done when

- [ ] One **Next** skill with its target and the evidence behind it; at most one helper.
- [ ] Nothing was written or run besides the read-only status script.
