---
name: learn-retro
description: Learn: keep the project learning (after a review, a run or a user correction). Harvest what went wrong or was learned - review findings, triaged failures, corrections the user made, decisions - into the project memory (project/) - lessons (L-NNN, with evidence and a count), decisions (ADR-NNN), questions, status and log - and turn repeated lessons into lasting fixes - a skill pitfall, a rule, a script / guard check - or a candidate for the template lessons (standards/template-lessons.md). Use for "retro", "what did we learn", "why does this keep happening", "remember this for next time", "update the project memory", "update the brain", after a Rework verdict, or when the same finding appears twice.
metadata:
  group: learn
  order: "-"
---

# Learn: retro

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** the latest review files, run summaries, `project/log.md`, the conversation (user corrections, decisions).
**Out:** `project/lessons.md`, `project/decisions/ADR-NNN-<slug>.md`, `project/questions.md`, `project/status.md`,
`project/log.md`, `project/index.md` › Now; on the user's OK, the lasting fix (skill / rule / script). **Rules:**
[standards/conventions.md](../../../standards/conventions.md) §3 IDs. **Next:** whatever `flow-next` says.

## Steps

1. **Collect** since the last retro (`project/log.md`): findings with High / Med severity, Rework verdicts, failure
   classes from triage, things the user corrected or decided.
2. **Find the cause, not the last symptom.** For each High finding, Rework or escaped defect, separate the
   **trigger** (what showed it), the **root cause** (the step that produced it: a skill instruction missing, a rule
   unclear, a source misread, a script not checking) and **contributing factors** (time pressure, a stale upstream,
   a large file read in part). Name the **escape point**: the earliest skill, review checklist item or script that
   should have caught it and didn't. Unproven causes stay marked as a guess.
3. **Match** each against `project/lessons.md` and [standards/template-lessons.md](../../../standards/template-lessons.md):
   - known lesson → increment **Seen**, add the evidence;
   - new → `L-NNN · Where (skill / artifact) · Lesson (the mistake and the way to avoid it, one sentence each) ·
     Evidence (folder, artifact, finding ID, date) · Seen 1 · Action noted`.
   Lessons are about how the work goes wrong, not about the system under test (system facts go to
   `project/system-map.md`; open points to `project/questions.md`).
4. **Decisions.** A choice a person made (scope, environment, interpretation) → `ADR-NNN` (copy
   `decisions/ADR-000-template.md`), and a project rule `PR-n` if it applies to every artifact.
5. **Lasting fixes** (aimed at the escape point) — propose, then apply on the user's OK:

   | When | Fix |
   |---|---|
   | Seen ≥ 2 in one skill's output | add it to that skill's **Pitfalls** (a project skill override: say it belongs in the template) |
   | a check a script could make | a check in `check_scenarios.py` / `export_testcases.py` / `guard.py` (template change) |
   | a rule that all artifacts must follow | `PR-n` in `project/rules.md` |
   | general beyond this project | **Promote to template** row (the template maintainer copies it as L-Tnn) |

   Mark **Action** accordingly (`→ skill design-cases`, `→ rule PR-3`, `→ script`, `promote`).
6. **Housekeeping:** close done follow-ups (`project/status.md` §2 → §3); refresh the board; rewrite `project/index.md` ›
   Now (3–6 lines); one `project/log.md` line. Keep `index.md` under 5 KB.
7. Commit `project: retro <date> (<n> lessons, <m> ADRs)`.

## Rules

- Evidence or it didn't happen: every lesson cites a finding ID, a run, or the user's words with the date.
- Never delete a lesson; supersede it (`Action superseded by L-NNN`).
- Personal agent memory may store a pointer ("project memory in project/index.md"), never the lesson itself — project/ is
  shared by every agent and person on the project.

## Done when

- [ ] Every High finding / Rework / escaped defect since the last retro has a cause, an escape point and a lesson row.
- [ ] Repeated lessons have a proposed lasting fix; decisions recorded as ADRs; `project/index.md` › Now refreshed.
