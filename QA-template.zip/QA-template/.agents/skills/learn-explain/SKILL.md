---
name: learn-explain
description: Learn: explain for an audience (any time). Explain a QA artifact or a technical point to a named audience at the right level - a defect or failed test to a PM or the client, a test report or go / no-go to a director, a business rule or test approach to a developer, the workspace and pipeline to a new tester, a mock or a reconciliation to a BA, an automation result to a manager, or ELI5 for anyone - starting with the what, one analogy from the audience's world, only the details they need, and the so-what (impact, decision, next step), from the project's own files and never beyond them. Use for "explain this to my manager", "how do I tell the client", "ELI5", "explain like I'm 5", "simplify this for the BA", "onboard a new tester", "giải thích cho …", "giải thích đơn giản". Writing the report itself → run-report; a defect report → run-defects; a query, procedure, plan or database error → sql-explain.
metadata:
  group: learn
  order: "-"
---

# Learn: explain for an audience

> **Created:** 2026-10-16 09:48 · **Updated:** 2026-10-16 12:05 (UTC+7)

**In:** the thing to explain (a file, a TC, a defect, a run summary, a rule, a concept) and the audience the user
names; the project files it depends on (read them first — never explain from memory). **Out:** the explanation in chat
(or a file when the user asks, e.g. `plans/onboarding.md`). **Next:** none.

## 1. Who is it for

| Audience | Cares about | Frame it as |
|---|---|---|
| Client / business owner | does it work, risk to their business, what they must decide | outcomes, risk, the decision and its deadline |
| Director / sponsor | go / no-go, cost of delay, confidence | one-line status, the 2–3 risks, the recommendation |
| PM / delivery lead | schedule, blockers, who does what | impact on dates, owners, options with effort |
| BA / PO | which rule, which requirement, what is unclear | the requirement ID, the question, the readings |
| Developer | how to reproduce, where it differs from the spec | steps, expected vs actual, the cited rule, evidence |
| New tester | how the workspace and pipeline work | the pipeline in order, where files are, the rules that matter most |
| Non-technical / ELI5 (default) | the idea | everyday analogy, short sentences, no jargon |

No audience named → ask, or default to plain language (ELI5).

## 2. Shape

1. **What** — one sentence with the essence.
2. **Analogy** — one, from the audience's world (a bank teller for a mock, a till roll for reconciliation, a
   checklist for a test case). Skip it for developers who want the facts.
3. **Details** — only the layers the audience needs; numbers from the files (counts, IDs, dates).
4. **So what** — what it means for *them*: impact, the decision needed, the next step and who takes it.

## 3. Language

- Plain audiences: no jargon (or define it at once), one idea per sentence, concrete over abstract, "you".
- Technical audiences: proper terms, the interesting part (the trade-off, the edge case), short.
- Business audiences: impact first, quantify from the evidence, options and a recommendation.
- In `project.json › project.document_language` unless the user asks for another language (e.g. Vietnamese for the
  client while the artifacts are in English).

## Rules

- Simplify, never distort: an 80 % picture is fine, a wrong one is not. Uncertain or unverified facts stay marked as
  such (a defect is "not reproduced yet", a run is "not executed").
- Never talk down; never hide a failure or a risk to make the message nicer.
- Explain the purpose before the mechanism.

## Done when

- [ ] Audience named; what → analogy → details → so what; every fact traceable to a project file.
