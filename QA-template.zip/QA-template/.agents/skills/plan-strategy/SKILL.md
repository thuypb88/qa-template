---
name: plan-strategy
description: Plan: the test strategy (project, sprint or release). Write or review the QA test strategy in plans/test-strategy.md - objectives, scope in / out, risk-ordered areas, levels (IT with mocks, ST with real systems) and packs, techniques and depth per risk, environments and data, entry / exit criteria, automation direction, defect and reporting flow, roles, schedule dependencies, open risks - from the client's test plan and documents; or review the client's test plan against them and list the gaps. Use for "write the test strategy", "we have no test plan", "review the test plan", "what are the entry / exit criteria", "test approach for release X". project.json set-up → plan-setup; one module's scope → plan-scope.
metadata:
  group: plan
  order: "-1"
---

# Plan: test strategy

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** `sources/testing/` (the client's test plan, if any), the requirement documents (`slice.py toc` → `section`),
`project.json` (levels, modules, externals, runners), `project/system-map.md`, `project/questions.md`. **Out:**
`plans/test-strategy.md` (project-owned; or `plans/test-strategy-review.md` in review mode); new `Q-INIT-NNN` /
`Q-ST-NNN` in `project/questions.md`; a decision → ADR. **Rules:** core R1, R2, R9. **Next:** `plan-setup` (if
`project.json` is still the skeleton) or the first `design-analysis`.

**Modes:** *write* (no client plan, or the user asks for our own); *review* (a client plan exists: check it against
the sections below, write gaps as questions — never rewrite the client's plan); *section* (add a sprint or release
section to an existing strategy, for `flow-cadence` / `flow-cadence`).

## Required sections

1. **Objectives and scope.** What quality outcome matters (from the documents); in scope / out of scope per module,
   interface and non-functional area, each citing its source; what is deliberately shallow.
2. **Risk-based priorities.** `Area | Risk (impact × likelihood × detectability, qualitative) | Why (source) |
   Depth | Level`. Money, state, security, data loss, hand-offs, legal text first. No numeric score unless the project
   has a risk model.
3. **Levels and environments.** Per level from `project.json › levels`: environment (exact name), externals (mock /
   real), entry and exit. IT = per module with mocks; ST = whole system with the real systems (R9).
4. **Approach per pack.** UI / API / ETL / SQL: surface (R2), techniques by rule shape (techniques reference of
   `design-scenarios`), checklists, what is automated by default and what stays manual.
5. **Test data.** Synthetic or masked only; who provides fixtures and mocks; reset / cleanup; personal data rules
   (→ `design-data`).
6. **Entry / exit criteria.** From the client plan when it has them (cite); else proposed and marked `Q-xxx: proposed
   …` for the QA lead. Each one checkable (e.g. "all P1 TCs executed, none failed without an accepted defect"), with
   its evidence source. Never invent a pass-rate threshold.
7. **Defects and reporting.** Severity scale, the tracker, retest and regression rules (→ `run-defects`),
   report cadence and audience (→ `run-report`).
8. **Automation direction.** Runner per pack, what goes into smoke and regression, hooks the DEV team must provide
   (from `auto-decide` when it has run).
9. **Transition.** When the release changes an existing system: data migration (counts, reconciliation, rejected
   rows), parallel run, cutover and rollback rehearsal, users / roles to migrate, training material checks — or a line
   saying none applies (requirement-quality reference §7 of `design-analysis`).
10. **Roles, schedule, dependencies.** Who does what (roles, not names unless given), milestones, the dependencies
   that block testing (builds, mocks, data, access).
11. **Risks, assumptions, open questions.** Each with an owner and what it blocks.

## Review mode

Walk the eleven sections against the client plan: `Section | Present / Partly / Missing | Evidence (§, page) | Gap |
Question (owner)`. Contradictions with the requirement documents or `project.json` → questions citing both. A gap the
team can live with is noted, not inflated.

## Rules

- Tailored or nothing: every line traces to this project's documents, `project.json` or a user answer; no textbook
  filler ("ensure quality", "test thoroughly").
- Proposals are labelled as proposals until the QA lead / client accepts them (then an ADR).
- Keep it short enough to be read: tables, one screen per section.

## Done when

- [ ] Eleven sections (or the review table) with citations; exit criteria checkable with an evidence source.
- [ ] Questions in `project/questions.md` with owners; `project/log.md` line; commit `test strategy v<n>`.
