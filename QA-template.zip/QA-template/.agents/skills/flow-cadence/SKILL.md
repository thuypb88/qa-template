---
name: flow-cadence
description: Flow: pace QA work through a day, a sprint or a release with checkable gates, and hand each item to exactly one skill (never does the work). Mode day - start gate (build, environment, mocks, smoke), a risk-ordered queue, midday check, end-of-day note. Mode sprint - planning, ready-for-test, execution, regression, stabilisation, review, the testing part of the Definition of Done; record plans/sprints/<sprint>.md. Mode release - planning, freeze, regression on the release candidate, non-functional checks, go / no-go evidence pack, post-release smoke and watch list; record plans/releases/<release>.md. Use for "plan my day", "EOD note", "stand-up update", "plan testing for sprint 5", "are we done for the sprint", "prepare the release", "go / no-go", "hotfix release", "after go-live checks". Not for: the single next step of the pipeline → flow-next; the strategy document → plan-strategy; the report itself → run-report.
metadata:
  group: flow
  order: "-"
---

# Flow: cadence (day · sprint · release)

> **Created:** 2026-10-16 10:20 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** `python3 scripts/pipeline_status.py`, `project/index.md` › Now, `project/status.md`, `project/defects.md`,
`project/questions.md`, `plans/test-strategy.md` (exit criteria), what the user says about the day / sprint / release.
**Out:** per mode below; always one `project/log.md` line. **Next:** the skill the current stage names — one.

## Modes — read only the one you run

| Mode | When | Reference | Record |
|---|---|---|---|
| **day** | "today", morning plan, EOD, stand-up | [references/day.md](references/day.md) | chat; `project/index.md` › Now at EOD |
| **sprint** | a sprint, iteration or test phase | [references/sprint.md](references/sprint.md) | `plans/sprints/<sprint>.md` |
| **release** | release window, RC, go / no-go, hotfix, go-live | [references/release.md](references/release.md) | `plans/releases/<release>.md` |

Infer the mode from the request and say which one you use. A request that spans two (a sprint that ends in a
release) runs the longer one and names the other's gates inside it.

## Steps

1. **Pick the mode**, open its reference, find the current stage / window from the record (or create the record).
2. **Check the gate** of the current stage against evidence: a run summary, a review verdict, the defect register,
   `pipeline_status.py`. No evidence → the gate is *Unknown* / AMBER "not checked", never Met.
3. **Queue the work** of the stage: one line per item — `P<n> · item · skill · done when <condition>`.
4. **Hand off:** answer with the record / plan and **Next:** `/<skill> <target>`. Do not do the items here.

## Rules

- Gates are compressed when time is short, never dropped; a dropped gate is stated as an accepted risk with its owner.
- Evidence only: "we tested a lot" is not a gate result; a plan is not a pass.
- One primary skill per hand-off; never a menu of five skills.
- Recommendations (sprint exit, go / no-go) go to the people the plan names; the decision is theirs and is recorded
  as "pending decision" until made.

## Done when

- [ ] Mode named; current stage / window and its gate status stated with evidence.
- [ ] Queue risk-ordered, each line with one skill and a done condition; **Next:** one skill.
- [ ] The mode's own Done-when list (in its reference) is met; `project/log.md` line.
