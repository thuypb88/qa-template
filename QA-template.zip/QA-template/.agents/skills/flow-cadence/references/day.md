# flow-cadence mode: day

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:43 (UTC+7)

**In:** `python3 scripts/pipeline_status.py`, `project/index.md` › Now, `project/status.md` (follow-ups),
`project/defects.md` (fixed → retest), `project/questions.md` (answered → unblock), the latest `runs/run-summary.md`,
what the user says about today (build, meetings, capacity). **Out:** the day plan or the EOD note in chat; one line in
`project/log.md`; `project/index.md` › Now refreshed at EOD. **Next:** the first skill in the queue.

## Stages and gates

| Stage | Goal | Exit (checkable) |
|---|---|---|
| A. Start gate | Can we test today? | Build / version known; environment of the level (`project.json › levels`) up; IT mocks / fixtures up; smoke (`run_tests.py <target> --grep <smoke ids>`) green — or the blocker named with an owner |
| B. Queue | Risk-ordered list for today | P1 → P3 items, each with one skill and a done condition; an explicit "not today" list |
| C. Midday check | Is the P1 work moving? | Every P1 item started; if not, re-plan and drop P3 |
| D. EOD | Tomorrow starts clean | Every P1 failure has a defect or an escalation; EOD note written |

**Start gate red** (environment down, build not deployed, smoke failing): no execution today. Re-plan to work that
needs no environment — analysis, scenarios, test cases, reviews, test data — and keep the gate red until smoke is
green on the current build. Naming who fixes it does not turn it green.

## Building the queue (stage B), in this order

1. **Retests** of defects marked fixed in `project/defects.md` (P1 / P2 first) → `run-defects`.
2. **Unblocked work**: questions answered in `project/questions.md`, follow-ups `FU-NNN` due → the writer the
   follow-up names.
3. **Source changes** not yet traced (`pipeline_status.py` says so) → `plan-changes`.
4. **The pipeline's next step** per folder (`flow-next` logic: the earliest missing or stale step first; a Rework
   before anything new).
5. **Runs** due (a new build → `run-select` then `run-tests`; manual residue → testers /
   `run-explore`).
6. **Reporting** owed today → `run-report`.

Each line: `P<n> · <folder / item> · <skill> · done when <condition>`. One skill per line; no line without a done
condition.

## Output

```markdown
**Day plan <date>** · Build <version or unknown> · Start gate: GREEN | AMBER | RED (<why>)
| P | Item | Skill | Done when |
|---|---|---|---|
**Not today:** … · **Blockers:** <blocker → owner, since> · **Next:** `/<skill> <target>`
```

EOD:

```markdown
**EOD <date>** · Done: … · Carried over: … (why) · New defects: DEF-… · Blockers: … · Tomorrow top 3: 1. … 2. … 3. …
```

## Rules

- Nothing executed on a red environment is a result; it stays Not Run / Blocked.

## Done when

- [ ] Start gate stated with evidence; queue risk-ordered with skills and done conditions; "not today" listed.
- [ ] EOD: every P1 failure has a DEF / escalation; carried-over items have a reason; `project/log.md` line; Now refreshed.
