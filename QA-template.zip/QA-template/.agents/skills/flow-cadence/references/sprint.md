# flow-cadence mode: sprint (or test phase)

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:29 (UTC+7)

**In:** the sprint goal and its stories / modules / change requests (from the user or the plan), `project.json`
(modules, levels), `plans/test-strategy.md` (if any), `pipeline_status.py`, `project/defects.md`, the previous sprint
record. **Out:** `plans/sprints/<sprint>.md` (create, then update per stage); `project/status.md` follow-ups;
`project/log.md`. **Next:** the skill the current stage names.

## Stages and gates

Day numbers don't matter; the gates do. A shorter sprint merges stages, never drops a gate.

| Stage | Goal | Primary skill | Exit gate (checkable) |
|---|---|---|---|
| 1. Planning | What, how deep, who | `plan-strategy` (sprint section) · `req-review` for new stories | Scope in / out per story or module; risk order; an owner per P1 area |
| 2. Ready for test | Designed and runnable | `design-analysis` → `check-design` → `design-scenarios` → `check-design` → `design-cases` → `check-design`, `design-data` | Every in-scope item has reviewed TCs (or the gap named); build deployed; smoke green |
| 3. Execution | Risk-ordered testing | `run-tests`, `run-explore`, `run-defects` | Every P1 / P2 TC has a result; defects raised with evidence |
| 4. Regression | Protect what worked | `run-select` → `run-tests` | Regression set run on the final build; failures triaged |
| 5. Stabilisation | Clear the blockers | `run-defects` (retests) | No open Critical / Major defect without a written acceptance by the person the plan names |
| 6. Review | Report and learn | `run-report`, `learn-retro` | Sprint report; carry-over listed with owners; lessons recorded |

**Definition of Done (testing part)**, stated in the record and checked at stage 6 — keep the team's own if it has
one: in-scope P1 / P2 TCs passed or their defects accepted; no open Critical defect; regression run on the release
build; residual risks written down.

## The sprint record (`plans/sprints/<sprint>.md`)

```markdown
# Sprint <name>: test record

> **Created:** … · **Updated:** … (<tz>)

**Goal:** … · **Dates:** … · **Build(s):** …
## Scope
| Story / CR / module | In / out | Risk (P) | Folder(s) | Owner |
## Gate board
| Gate | Status (Met / Not met / Blocked / Unknown) | Evidence | Date |
## Carry-over and accepted risks
| Item | Why | Owner | Next sprint? |
```

Update the gate board at each stage; scope added mid-sprint → re-rank and say which gate it moves.

## Rules

- A story is not done while its agreed evidence is missing; it carries over with its open defects.
- At stage 6 the exit verdict is a recommendation to the people the plan names.

## Done when

- [ ] Record exists with scope, owners and gate board; current stage named; **Next:** one skill.
- [ ] At exit: DoD checked item by item; carry-over and accepted risks listed with owners; `run-report` and `learn-retro` run.
