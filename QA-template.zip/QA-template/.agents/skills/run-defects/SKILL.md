---
name: run-defects
description: Run: the defect life cycle (both levels). Run the defect life cycle for the project - write a defect report from a failed TC, an exploratory note or a user's description (symptom title, environment and build, steps, expected with its source vs actual, reproducibility, impact, proposed severity / priority, evidence); keep the register project/defects.md (DEF-NNN or the tracker ID, status, TCs); retest fixed defects on the named build with the regression around them; set defect_id on the TCs; and summarise open defects by severity and age. Use for "log a bug", "write a defect for TC-E4-012", "retest DEF-007", "which defects are fixed / open", "defect status", "close the bug". Running suites → run-tests; choosing the regression around fixes → run-select.
metadata:
  group: run
  order: "E"
---

# Run: defects

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:43 (UTC+7)

**In:** a failure (`runs/<key>/results.csv`, the TC via `slice.py tc <target> --ids …`), an exploratory log, or
the user's description; `project/defects.md`; the tracker IDs the user gives. **Out:** `project/defects.md` rows; the report
text (chat, and `runs/<key>/defects.md` for a run); `defect_id` on TCs (through `record_manual.py` or a JSON edit
with a `version` bump + export); `project/log.md`. **Rules:** R2 (symptom at the surface), R9. Report format:
[standards/methods/defect-report.md](../../../standards/methods/defect-report.md) §1. **Next:**
`run-select` (retest set) or `run-report`.

## 1. Report a defect

1. **Is it a product defect?** Rule out first: automation defect, TC defect (expected contradicts the source),
   environment / mock / data, a duplicate of an open DEF (same symptom → add the TC to that row).
2. **Reproduce** on the stated build: `run_tests.py <target> --grep <TC>` or by hand; record `n of m`. Not reproduced →
   report as intermittent with the evidence, never as fixed.
3. **Write it** per the format: symptom title; environment and build; preconditions with fixture names; steps with the
   data used; expected (TC + source citation) vs actual (exact text / status / values); reproducibility; impact (what
   it blocks); proposed severity and priority with one line why; evidence paths. Guesses about the cause go to Notes.
4. **Register** in `project/defects.md`: next free `DEF-NNN` (or the tracker ID in **Tracker** when the user gives one).

## 2. Severity (proposed; the tracker owner decides)

| Severity | When |
|---|---|
| Critical | data loss or corruption, money wrong, security hole, P1 journey blocked with no workaround, crash |
| Major | a P1 / P2 behaviour wrong with a workaround, an integration hand-off wrong, a wrong legal text |
| Minor | a P3 behaviour wrong, a message unclear, a layout issue that hinders use |
| Trivial | cosmetic, no effect on use |

Priority = how soon it must be fixed (release, sprint, later), from impact and the schedule.

## 3. Life cycle

`New → Open → Fixed → Retest → Closed`, or `Reopened` (fails retest), `Rejected` / `Duplicate` / `Deferred` (by the
owner, with the reason and who decided). Status changes come from the tracker or the user; record the date.

## 4. Retest a fix

1. On the build that claims the fix (version in the row); fixed in a later build → that build.
2. Rerun the TC(s) of the defect, then the surrounding set (`run-select`, layer `retest`): the twins of the TC
   (same item and area) and any hand-off it touches.
3. Passes `n of n` → Closed (date, build); fails → Reopened with the new evidence; a new symptom → a new DEF.
4. Record the retest result on the TC in the current cycle (`record_manual.py` for manual retests).

## Register layout (`project/defects.md`)

`| DEF ID | Tracker | Title | Severity | Priority | Status | Folder | TCs | Found (build, date) | Fixed in | Retest
(build, date, result) | Notes |` — newest first; closed rows stay (history).

## Rules

- One defect per symptom; never a severity by feeling; never "Closed" without a retest on a named build.
- Never edit an expected result to make a defect disappear; a wrong TC goes to the writer.

## Done when

- [ ] Report complete per the format; register row added / updated; TCs carry the `defect_id` once known.
- [ ] Retests name the build and the surrounding set; status changes dated; summary by severity / status / age if asked.
