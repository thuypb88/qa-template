---
name: design-nfr
description: Design: the non-functional test plan (ST, before or alongside the ST mindmap). Plan the non-functional testing in test-design/st/nfr-plan.md - performance (workload model from sourced volumes - transaction mix, arrival rate vs concurrency, peaks, think time - load / stress / soak profiles, response-time targets from the documents), security (assets, roles, auth / session / authorization / input / data exposure / configuration checks, safe and authorised only), accessibility (the project's WCAG target, automated scan vs keyboard vs screen-reader evidence) and compatibility (browsers, devices, resolutions) - then add the NFR scenarios to the ST mindmap and TCs through the normal writers. Use for "plan performance / load testing", "security testing plan", "accessibility testing", "NFR tests", "browser compatibility matrix". Functional ST → design-scenarios st; running → run-tests.
metadata:
  group: design
  order: "ST"
---

# Design: non-functional testing (ST)

> **Created:** 2026-10-16 09:30 · **Updated:** 2026-10-16 10:34 (UTC+7)

**In:** the NFR requirements and the test plan's NFR scope (`slice.py rows` on their IDs), `test-design/st/1-analysis.md`
§7 (non-functional) and its RBAC matrix, `project/system-map.md`, `plans/test-strategy.md`, the packs' `X` checklist
rows (moved to ST). **Out:** `test-design/st/nfr-plan.md` (`NFR-NNN` items); then scenarios appended to
`test-design/st/2-mindmap.md` (`design-scenarios st`, Non-functional group) and TCs (`design-cases st`). **Rules:**
core R1, R9 (real environment, UAT names as in `project.json`); [standards/review-protocol.md](../../../standards/review-protocol.md)
for its review. **Next:** `design-scenarios st` (append), then `check-design`.

## 1. Performance

- **Targets** only from the documents (response time, throughput, batch window, concurrency). None stated → `Q-ST-xxx:
  proposed …` for the client; never a "usual 2 seconds".
- **Workload model** per sourced input, with unit and source: transaction mix (% per journey / endpoint), arrival rate
  at peak (daily volume alone gives only an average; a peak needs the peak share and window), concurrency (online
  users are not concurrent users), think time, data volume and distribution. Missing numbers → ranges with the formula
  and a question.
- **Profiles:** load (expected peak), stress (to the breaking point, to learn the limit), soak (expected load for
  hours), spike — only those the plan asks for.
- **Pass / fail per profile:** the sourced percentile targets, error rate, and no functional error under load.
- Tool from `project.json › runners` (k6 / JMeter); environment sized like production or the difference stated.

## 2. Security (authorised, defensive)

- **Scope:** assets (data, money, admin functions), roles from the RBAC matrix, entry points (screens, APIs, files,
  batch inputs) — only what the test plan authorises in which environment.
- **Checks:** authentication (lockout, password / token rules, MFA as specified), session (timeout, fixation, logout,
  revoked tokens), authorization (every role × function, other owner's object, URL / ID tampering), input handling
  (injection, file upload, oversized input), data exposure (responses, logs shown to users, exports, error pages),
  configuration (transport, headers, default accounts) as the plan lists.
- **A denial is two checks:** the refusal and no data / no change. A clean scanner run covers only what it scanned.
- Exploitation beyond proving the control fails, production targets and third-party systems: only with explicit
  written scope. Specialist penetration testing is named as such, not replaced by this plan.

## 3. Accessibility

- Target from the documents (e.g. WCAG 2.1 AA); none → `Q-ST-xxx`, never assumed.
- Per key journey: automated scan (axe-core), keyboard-only walk (order, focus visible, no trap, focus returns after a
  dialog), screen reader names / roles / states and announcements, zoom / contrast. Keep evidence per method apart;
  a clean scan is not conformance.

## 4. Compatibility

Matrix from the documents (browsers + versions, OS, devices, resolutions); pairwise over the factors when large, the
primary combination fully, the others by the smoke + P1 set.

## `nfr-plan.md` layout

Header · scope and sources · `NFR-NNN | Area | Requirement / source | Target (sourced or Q) | Method / tool | Data /
environment | Evidence | Pass / fail rule | Blocker` · workload model · security scope and authorisation · a11y and
compatibility matrices · open questions.

## Done when

- [ ] Every NFR requirement and every pack `X` row has an `NFR-NNN` or a reason; targets sourced or questioned.
- [ ] Workload model with units and sources; security scope authorised; a11y target stated.
- [ ] NFR scenarios appended to the ST mindmap (Non-functional group); suggest `check-design` then `design-cases st`.
