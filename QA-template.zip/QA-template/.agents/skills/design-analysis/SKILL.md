---
name: design-analysis
description: Design step 1 (writer, IT or ST): the analysis. Analyze one module (IT, any pack - ui / api / etl / sql) or the whole system (ST) from its sources, the client documents and the test plan, and write 1-analysis.md - citation keys, requirement breakdown, acceptance criteria, the pack inventory (screens / endpoints / target tables and jobs), flows, data and field rules, integrations, testable conditions (TCONDs) observable at the pack surface, questions, traceability, level scope and fixtures. Use for "analyze E4", "analyze the system / ST", or to redo an analysis after the sources change. Reviewing it → check-design.
metadata:
  group: design
  order: "1"
---

# Design: analysis of a module (IT) or the system (ST)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:34 (UTC+7)

**In:** a target (module id → IT; `st` → ST). IT: `0-scope.md`, `sources.json`, the sources it lists, the system
analysis if present. ST: the test plan, every module's analysis §11 "Moved to ST", `project/system-map.md`.
**Out:** `<folder>/1-analysis.md` (overwrite; title exactly `# <name>: analysis`). ST also writes
`test-design/st/0-scope.md` (hand-written). **Rules:** core R1, R2, R6.3, R9, R10; the pack's `rules.md` and
`analysis.md` (`packs/<pack>/`, the pack named in `project.json`; ST reads every pack in use); project rules. **Next:** `check-design`.
**Stop if** (IT) `0-scope.md` is missing or older than `project.json` / the sources → `plan-scope` first.

Read lean: `slice.py toc` → `section`; open a source at the cited line, never a whole big file. Read
`project/lessons.md` and the L-T rows for `design-analysis` in [standards/template-lessons.md](../../../standards/template-lessons.md).
While writing §2, §8 and §9, follow [standards/methods/requirement-quality.md](../../../standards/methods/requirement-quality.md) (atomic
rules, gap kinds, the seven ambiguity checks, conflicts, testability, closable questions).

## Steps

1. **Scope** (IT): `0-scope.md` (incl. MANUAL block) + `sources.json`. (ST): the test plan's system levels, INT
   rows, entry / exit criteria.
2. **Neighbours:** the system analysis (`slice.py rows test-design/st/1-analysis.md <id> <refs>`) and the analyses of
   `depends_on` modules: hand-offs, `Q-ST-xxx`. Cite, don't repeat.
3. **Test plan, this level:** the scope row per UC / module, mocking / fixture tables, what is moved to ST.
4. **All sources, images included.** Parsed copies under `sources/parsed/`; pack inventories
   (`sources/parsed/api/…-inventory.md`, `sources/parsed/etl/…-inventory.md`).
5. **Client documents** (R1): acceptance criteria; layouts, wording, sample data.
6. **Write** with a **citation-key table** first (`Key | File`) and a source-precedence note
   (`project.json › sources.precedence`). Every statement cites `[KEY:line](path#Lnn)`, `(FR-xxx)` or
   `Source: <doc> §x p.n`; links relative to the folder.

## Required sections

1. **Overview.** Purpose, actors, in / out of scope, assumptions, neighbouring modules (in / out).
2. **Requirement breakdown.** Per requirement: summary, priority, client ref, UC, atomic rules `BR-<req>-n` (one
   trigger, one outcome each; actor, preconditions, constraint, exception or `missing`). Then **Acceptance criteria**
   `AC ID | Criterion | Source | Requirements`; a criterion with no observable outcome is also a §9 `untestable`.
3. **Inventory** — the pack's §3 (screens / endpoints / tables + jobs). These names become mindmap level 1 and the
   TC title prefixes. Flows handling a variant set add the **Variants handled** table (R10).
4. **Functional flow.** Main / alternate / exception, each step with what is observable at the surface. Sources in
   use-case form map course by course (normal → main, `AC.n` → alternate, `EX.n` → exception, postconditions →
   observable results); Given-When-Then criteria give one TCOND per *Then* / *And* (reference §8–§9).
5. **Data & field rules** — the pack's §5 tables; state / transition tables.
6. **Integrations** — the pack's §6: each external system, its IT stand-in and ST counterpart.
7. **Non-functional.** Languages, compatibility, security (the module's techniques), audit, performance, volume.
8. **Testable conditions** `| ID | Condition | Requirement | Type | <Level-1 item> | Observable in |` (first four
   columns fixed; scripts read them).
   - Type: positive / negative / boundary / ui / localization / compatibility / security / accessibility /
     contract / data-quality / reconciliation / performance / e2e.
   - Per validated field / parameter / column: mandatory + invalid + boundary. Per state machine: allowed + refused.
   - R6.3: one localization TCOND per language per free-text input. R10: valid + invalid TCOND per variant per
     flow step.
   - Not observable at the surface → sub-table **Out of black-box scope** (covering layer; no TCOND ID).
9. **Gaps, conflicts & open questions** `ID | Kind | Topic | Evidence A | Evidence B | Proposed assumption | Owner |
   Blocks` (`Q-001…`, ST `Q-ST-001…`). Kind: missing rule / missing material / ambiguous / conflict / untestable /
   stale; an ambiguous row gives ≥ 2 readings; Blocks = the TCONDs / requirements waiting on it; ordered by what it
   blocks. Copy relevant `Q-ST` with their IDs; source conflicts (R1.4); unconfirmed values.
10. **Traceability** `Requirement / AC | BR rules | TCONDs | Q refs` — every requirement and AC.
11. **Level scope & fixtures.**
    - IT: per UC `UC | IT scope (In / Partly / Out) | Fixtures | Moved to ST | Source`; the **fixture list** with
      short names the TCs use (pack §11); **baseline preconditions** (R3.3: one line each, e.g. "<Project> <env> is
      running normally", "… connected to <system> (mock data)"); **Moved to ST** (no TCOND).
    - ST: the E2E chains, INT rows with the real systems, RBAC matrix, smoke set, NFRs, every item the modules moved
      to ST (none dropped), the environment and data per wave.

## Rules

- **No invention.** Unstated → §9. Exact source values; labels in their language.
- **Completeness.** Every requirement and AC in §2 and §10; every field / parameter / column of the sources in §5.
- **Downstream.** If a mindmap or TCs exist, say in the header they need re-checking; don't edit them.
- **IDs on rewrite.** Keep live TCOND / Q IDs; mark removed TCONDs *retired*; never reuse IDs.
- Update `project/questions.md` with the new open questions and a line in `project/log.md`.

## Pitfalls

L-T01 (claiming a gap unread), L-T02 (neighbour conflicts), L-T03 (any-variant conditions), L-T07 (invented
fixtures), L-T16 (literal test-plan wording) in [standards/template-lessons.md](../../../standards/template-lessons.md), plus:
- **Text only.** Figures, slides and screen mock-ups hold rules the text lacks.
- **Inventory by internal names** (table / route / component names) instead of what the surface shows.
- **Vague words accepted as rules** ("fast", "appropriate", "as needed"): no criterion → `untestable` question, not a
  TCOND with an invented threshold.
- **Questions nobody can close** ("please clarify the field"): ask the smallest deciding question, name the owner.

## Done when

- [ ] 11 sections; exact title; every requirement / AC in §2 + §10; every source field in §5.
- [ ] R6.3, R10 TCONDs complete; **Observable in** everywhere; internal-only checks in the sub-table.
- [ ] §11 baseline preconditions + fixtures (IT) / chains + INT + moved items (ST).
- [ ] Every unknown is a `Q-xxx` with kind, owner and Blocks; report counts (BR rules, ACs, fields, TCONDs by type, out of scope, fixtures,
  moved to ST, questions); suggest `check-design`.
