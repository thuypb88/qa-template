<!-- Generated from CLAUDE.md by scripts/workspace/sync_agents.py — do not edit; edit CLAUDE.md and re-run. -->

> **Gemini CLI — read this first.** These are the same rules and skills the other agents on this project use.
> - **Skills** are in `.gemini/skills/<name>/SKILL.md` (the table under "The pipeline" names them; `/skills list`).
>   Activate the one whose description matches the task; the user may also ask for one by name ("use the
>   design-analysis skill for E4").
> - **No Claude Code hooks run for you** (`.claude/settings.json`). So: never edit a file the guard lists as generated
>   (`sources/`, every `.xlsx` under the level folders, `test-design/it/INDEX.md`, `*/sources.json`, `0-scope.md` outside its
>   MANUAL block, `GEMINI.md`, `.gemini/skills/`, `AGENTS.md`, `.agents/`, `.github/skills/`,
>   `.github/copilot-instructions.md`) or template-owned (`template-manifest.json`); and **before you finish any change
>   run `python3 scripts/workspace/guard.py check`** and fix what it reports. The git pre-commit hook runs the same checks.
> - Wherever the text below says "Claude", read "the agent". Project facts are in `project.json` and `project/`.

# CLAUDE.md

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 14:18 (UTC+7)

A QA workspace built from **QA-template**. It turns a client's documents (requirements, API contracts, data mappings,
test plan) into analysis → test scenarios → test cases (JSON + Excel) → automated tests → execution results, per
module (IT) and for the whole system (ST), for UI, API, ETL and SQL (database code) testing.

**Start every session here:** read [project.json](project.json) (what this project is) and
[project/index.md](project/index.md) (where it stands). Not sure what to do next → `/flow-next`. A fresh copy (no modules
in `project.json`) → `/plan-setup`.

## Where things are

| Need | File |
|---|---|
| Project facts: modules, packs, levels, environments, systems, variants, languages, IDs, runners | [project.json](project.json) |
| Rules for every artifact (R1–R10) | [standards/core-rules.md](standards/core-rules.md) |
| Rules per test type (R-UI, R-API, R-ETL, R-SQL), checklists, analysis / scenario / TC shapes | `packs/<ui\|api\|etl\|sql>/` |
| Rules for this project only (PR-n) | [project/rules.md](project/rules.md) |
| Review severity, verdict, evidence, fixes (P1–P7) | [standards/review-protocol.md](standards/review-protocol.md) |
| Folders, file names, IDs, fields, stamps, commits — the design system | [standards/conventions.md](standards/conventions.md) |
| Shared memory: status, questions, decisions, lessons, log | [project/](project/index.md) · cross-project lessons [standards/template-lessons.md](standards/template-lessons.md) |
| Skills catalog: eight groups by objective (flow · plan · req · design · check · auto · run · learn) + domain group sql, and order | [.gemini/skills/README.md](.gemini/skills/README.md) |
| Our plans (strategy, requirement reviews, regression sets, sprint / release records) · test summary reports · defects | [plans/](plans/README.md) · [test-reports/](test-reports/README.md) · [project/defects.md](project/defects.md) |
| Other agents' copies (generated): Codex `AGENTS.md` + `.agents/skills/`; GitHub Copilot `.github/copilot-instructions.md` + `.github/skills/`, plus path rules in `.github/instructions/`; Gemini CLI `GEMINI.md` + `.gemini/skills/` | `python3 scripts/workspace/sync_agents.py` |

Precedence: core rules → pack rules → project rules (a project rule may tighten, never loosen).

## The pipeline

| Step | Skill | Output (in the level folder) | Check |
|---|---|---|---|
| set-up | `plan-setup` | `project.json`, `project/` (rules, memory), folders | `python3 scripts/qa_config.py --validate` |
| 0 | `plan-changes` · `plan-scope` | `project/change-impact/…` · `0-scope.md` MANUAL block | `python3 scripts/trace_changes.py` |
| 1 → 2 | `design-analysis` → `check-design` | `1-analysis.md`, `1-analysis-review.md` | — |
| 3 → 4 | `design-scenarios` → `check-design` | `2-mindmap.md`, `2-mindmap-review.md` | `python3 scripts/check_scenarios.py <target>` |
| 5 → 6 | `design-cases` → `check-design` | `3-test-cases/test-cases.json` + Excel, `checklist-pass.md`, `test-cases-review.md` | `python3 scripts/export_testcases.py <target> --check` |
| A1 → A2 | `auto-decide` → `auto-write` (→ `check-automation`, optional) | `automation-plan.md`, `automation/<pack>/`, `automation-review.md` | `python3 scripts/run_tests.py <target> --plan` |
| E | `run-tests` | `runs/` (raw output, not in git), recorded cycles | `python3 scripts/run_tests.py <target>` |
| B | `learn-retro` | `project/` lessons, decisions, status | — |

Skill names are `<group>-<objective>`; the group is the question it answers: `flow-` (what next, in what rhythm) ·
`plan-` (what to test, is the basis current) · `req-` (is the requirement testable; proposals enter the test basis
only through `sources/`) · `design-` (what exactly, with which data) · `check-` (is our own work right) · `auto-` ·
`run-` (does the build work, what do we report) · `learn-`; plus the domain group `sql-` (study, explain, debug,
data scripts, test cases and verification procedures for database code; pack `sql`). Catalog: [.gemini/skills/README.md](.gemini/skills/README.md);
design rules: [standards/skill-architecture.md](standards/skill-architecture.md). Manual results go back into the JSON
with `python3 scripts/record_manual.py`.

Targets: a module id from `project.json` (`E4`), its folder, `st`, `it` or `all`. Writer → reviewer at every step;
apply the review's fixes before the next step.

## Rules that never change

- **Observable at the pack surface (R2).** UI: what the tester sees. API: the HTTP response. ETL: query results. SQL: what a caller of the DB object gets back. A check
  below the surface is "Out of black-box scope", never a test case that peeks.
- **No invention.** Every statement cites a source line, a requirement ID or a client document; every unknown is a
  `Q-xxx: assumed <value>`. Never pick a side of a conflict silently.
- **Structure follows how the test is run** (the pack layout), never the requirement list. TC titles start with
  `[<Level-1 item>]`.
- **Steps ↔ expected results 1:1**, one behaviour per TC, one baseline precondition plus only this TC's specials.
- **Each variant (R10) and each language (R6.3)** gets its own scenario and TC.
- **IDs are never renumbered or reused;** append with the next free number.
- **The Excel is generated from the JSON** (`export_testcases.py`); bump `version` on every change.
- **IT uses mocks / fixtures; ST uses the real systems** (R9). Name environments exactly as `project.json` does.

## Reading large artifacts (token budget)

Never read a file over ~40 KB whole: map it, then read the part the step needs. Tool: `scripts/slice.py`.

| To get | Run |
|---|---|
| A Markdown outline with line ranges and sizes | `python3 scripts/slice.py toc <file.md>` |
| One section | `python3 scripts/slice.py section <file.md> "5.2"` |
| Every line citing some IDs | `python3 scripts/slice.py rows <file.md> TCOND-031 FR-004 Q-010` |
| A suite's shape / one line per TC | `python3 scripts/slice.py tc <target> --stats` / `--list` |
| Some TCs in full | `python3 scripts/slice.py tc <target> --ids … / --scenario TS-012 / --form "<item>" / --priority P1` |
| Templated bodies across a suite | `python3 scripts/slice.py tc <target> --patterns` |
| One sheet of a workbook | `python3 scripts/extract_text.py <file.xlsx> --sheet "<name>"` |

Trust the check scripts for what they check (counts, IDs, formats); spend the reading on what they can't judge.

## Guardrails

[scripts/workspace/guard.py](scripts/workspace/guard.py) enforces the rules in code: before every Edit / Write it blocks generated files
(`sources/`, `INDEX.md`, `sources.json`, `0-scope.md` outside MANUAL, every `.xlsx`, `AGENTS.md`, `.agents/`,
`.github/copilot-instructions.md`, `.github/skills/`, `GEMINI.md`, `.gemini/skills/`), the
template-owned files and `project.json › protected_paths`; after an edit of `test-cases.json` / `2-mindmap.md` it
reports new checker Errors; when a turn ends and at every commit it checks version bumps, exported Excel, Updated
stamps, the agents sync and the git remote. Agents without these hooks (Codex, GitHub Copilot, Gemini CLI) run
`python3 scripts/workspace/guard.py check` before they finish; the git pre-commit hook catches the rest. Errors that already exist are ratcheted in `.harness/check-baseline.json`
(`python3 scripts/workspace/guard.py baseline`). Bypass a commit check only knowingly (`git commit --no-verify`, reason in the
message).

## Conventions

- **Before adding a folder or file,** read [standards/conventions.md](standards/conventions.md) §1–2 and put it where
  files of its kind live; generated output stays in its generated place.
- **Template-owned files** (rules, packs, scripts, skills; see `template-manifest.json`) are changed in the template
  repo and pulled with `python3 scripts/workspace/template_sync.py --from <template>`. Project-specific needs go into
  `project.json`, `project/rules.md` or `project/`.
- **Docs header:** `> **Created:** … · **Updated:** YYYY-MM-DD HH:MM (<timezone>)`; set Updated on every content change.
- **Python** uses the standard library (openpyxl for Excel, PyYAML optional for YAML specs; test frameworks only under
  `automation/`). A missing package or tool (`No module named openpyxl / pytest`, `pdftotext not found`, Playwright):
  run `python3 scripts/workspace/setup_workspace.py --check` and tell the user what it reports; don't pip-install ad hoc.
- **Language:** docs and TCs in `project.document_language`; UI labels exactly as shown.
- **Memory:** project facts belong in `project.json` and `project/` (shared by every agent and person), not only in an
  agent's personal memory. After a review with repeated findings, run `learn-retro`.
- **Other agents:** after changing this file or a skill, run `python3 scripts/workspace/sync_agents.py` (mirrors in
  `project.json › agents.mirrors`: `codex`, `copilot`, `gemini`).

## Version history and backup

Local git repository (branch `main`). When `project.json › git.local_only` is true: no remote, no push, no hosted repo
until the user says so. Commit after each change set, naming the folder, artifact and version
(`E4 test cases v0.3: review fixes TR-001…007`). The post-commit hook runs `scripts/workspace/backup.py`: suite version tags
(`tc/<folder>/v<version>`), a local mirror and a daily bundle in `../<CODE>-backups/`. After a fresh clone:
`git config core.hooksPath scripts/workspace/git-hooks`. Restore: `git clone ../<CODE>-backups/<CODE>.git <dir>`, or
`git show tc/<folder>/v<version>:<path>`.
