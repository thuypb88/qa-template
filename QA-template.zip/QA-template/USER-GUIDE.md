# QA-template — user guide

> **Created:** 2026-10-19 08:53 · **Updated:** 2026-10-19 08:53 (UTC+7)

How to run a QA project with this template, from an empty folder to a recorded test cycle. For QA engineers and QA
leads who will work in a project made from the template. The [README](README.md) is the reference (every switch, every
folder); this guide is the walkthrough. You only need Claude Code (or Codex / Copilot / Gemini CLI), Python and git.

**Contents:** [1. Ideas](#1-the-ideas-in-five-minutes) · [2. Create a project](#2-create-a-project) ·
[3. Add the documents](#3-add-the-client-documents) · [4. Set up](#4-set-up-the-project-plan-setup) ·
[5. Design a module](#5-design-one-module-it) · [6. System test](#6-design-the-system-test-st) ·
[7. Automate](#7-automate) · [8. Run and report](#8-run-record-and-report) · [9. Day to day](#9-day-to-day-work) ·
[10. Guardrails](#10-working-with-the-guardrails) · [11. Other agents](#11-other-agents) ·
[12. Upgrade](#12-upgrade-to-a-new-template-version) · [13. Recipes](#13-recipes) · [14. Cheat sheet](#14-cheat-sheet)

---

## 1. The ideas in five minutes

| Idea | What it means for you |
|---|---|
| **You drive with skills** | Type `/<skill> <target>` in Claude Code, e.g. `/design-analysis E4`. Each skill does one step, writes one file and tells you the next skill. Lost? `/flow-next`. |
| **Target** | A module id from `project.json` (`E4`), `st` (the whole system), `it` (all modules) or `all`. |
| **Two levels** | **IT** = one module at a time, external systems mocked, in `test-design/it/MOD-<id>-<slug>/`. **ST** = the whole system with the real systems, in `test-design/st/`. Environment names come from `project.json › levels`. |
| **Four packs** | Each module has a test type: `ui` (screens), `api` (HTTP), `etl` (data loads), `sql` (procedures, functions, views). The pack decides the layout, checklist, test case fields and automation framework. |
| **One chain** | `0-scope` → `1-analysis` → `2-mindmap` (scenarios) → `3-test-cases/test-cases.json` (+ Excel) → automation → results. |
| **Writer → reviewer** | Every design step is followed by `check-design`, which writes a review with a verdict: **Pass**, **Pass with fixes** or **Rework**. Apply the fixes before the next step. |
| **No invention** | Every statement cites a source line or requirement ID. Anything unknown becomes `Q-nnn: assumed <value>` in a questions list for the BA / client. |
| **JSON is the truth** | Test cases live in `test-cases.json`. The Excel is generated from it; never edit the Excel. |
| **Project memory** | `project/` holds what every person and agent must know: rules, questions, decisions, lessons, defects, status, log. Start reading at [project/index.md](project/index.md). |
| **Guardrails** | A guard blocks edits to generated and template-owned files and checks every commit. When it blocks you, it names the script to run instead. |

The full chain:

```mermaid
flowchart LR
    SU[plan-setup] --> CH[plan-changes] --> SC[plan-scope] --> AN[design-analysis] --> R1{{check-design}}
    R1 --> SN[design-scenarios] --> R2{{check-design}} --> TC[design-cases] --> R3{{check-design}}
    R3 --> AD[auto-decide] --> AW[auto-write] --> RT[run-tests] --> RP[run-report]
    R1 & R2 & R3 & RT -.-> LR[learn-retro]
```

---

## 2. Create a project

**Prerequisites:** Python ≥ 3.10 and git. Optional: Node LTS (UI pack, Playwright), `pdftotext` / poppler (PDF
sources), a DB driver (SQL / ETL packs; the setup installs it into the venv).

Run from the template folder. Pick one:

```powershell
# Windows (PowerShell); also works with pwsh on Linux / macOS
cd QA-template
.\setup.ps1 -New ..\ACME-QA -InstallPrereqs -Packs all
```

```bash
# Linux / macOS without PowerShell
cd QA-template
python3 scripts/workspace/setup_workspace.py --new ../ACME-QA --packs all
```

This copies the template to `../ACME-QA`, runs `git init`, installs the git hooks, creates `.venv/` with the Python
packages and checks everything. Add `-ScaffoldUi` / `--scaffold-ui` if you will automate UI tests (creates the
Playwright project and installs Chromium).

Then:

1. Read the summary. `0 error(s)` = done. Each `!` line says what is missing and how to install it; fix it and run
   the same command again (it only does what is still missing).
2. Restart Claude Code (VS Code: *Developer: Reload Window*) so it picks up the venv.
3. Work in the **project** folder from now on, not in `QA-template/`.

Use `--check` / `-Check` at any time to see what is missing without changing anything.

---

## 3. Add the client documents

Copy the documents into `sources/` yourself (agents may read `sources/` but never write to it):

| Folder | Put here |
|---|---|
| `sources/client/` | The client's originals as received: BRD, paper forms, decks, data classification |
| `sources/requirements/` | SRS, functional spec, user stories, UI spec |
| `sources/api/` | OpenAPI / Swagger / Postman collections, interface specs |
| `sources/etl/` | Source-to-target mappings (STTM), DDL, job designs, data dictionaries |
| `sources/sql/` | Stored procedures, functions, views, DDL, database specs |
| `sources/testing/` | Test plan, the client's test case template, test strategy |

`sources/parsed/` (Markdown copies with line numbers, for citations) and `sources/trace/` (the change baseline) are
generated; leave them alone.

You need at least one requirement document (SRS, stories, API spec or mapping). Include the test plan if there is one:
it defines the levels, environments and scope.

---

## 4. Set up the project (`/plan-setup`)

In the project folder start Claude Code (`claude`) and run:

```text
/plan-setup
```

What happens:

1. It inventories and extracts every document in `sources/`.
2. It drafts `project.json` (the project's profile; see below), `project/rules.md`, `project/system-map.md` and
   any decisions.
3. It lists everything it had to assume as `Q-INIT-nnn` questions.
4. **It stops and shows you** the module table, levels, external systems, project rules and the Q-INIT list.

**Your job at this point:** check the module list carefully. Modules should follow how a tester runs the tests (a
form, an API, a data load), not the chapters of the SRS. One system tested both through its screens and its API is
**two** modules (one `ui`, one `api`). Correct anything wrong, answer the Q-INIT questions you can, then say
"confirmed". Only then does it build the module folders and commit.

### What is in `project.json`

The only project-specific configuration file. You can edit it by hand later (then run `python3 scripts/qa_config.py
--validate` and `python3 scripts/init_project.py`).

| Key | Holds |
|---|---|
| `project` | code (short, e.g. `ACME`), name, client, timezone, `document_language` |
| `levels` | IT and ST: environment name (exactly as the test plan writes it), mocks vs real systems |
| `external_systems` | each system, what it exchanges, its IT stand-in (mock / stub / fixture) and ST form (real / sandbox) |
| `modules` | per module: `id`, `slug`, `name`, `pack`, `layout`, `security`, `refs` (requirement IDs), `sources` (globs), `variants`, `depends_on`, `externals` |
| `variant_sets` | things that behave differently and each need their own coverage: form types, customer types, channels |
| `languages` | UI languages; each one gets its own scenario and test case |
| `ids`, `values` | ID formats and allowed values (test types, priorities, statuses), e.g. from the client's TC template |
| `sql` | dialect (`sqlserver`, `oracle`, `postgres`, `mysql`) and version, for SQL-pack modules |
| `runners` | how each pack's automated tests are run (pre-filled; normally left as is) |
| `agents` | who writes / reviews (`claude`, `codex`, `copilot`, `gemini`) and which mirrors to generate |
| `git` | `local_only: true` = no remote, no push |

Two worked examples: [template-dev/examples/alpha.project.json](template-dev/examples/alpha.project.json) (UI only) and
[template-dev/examples/shop-demo/](template-dev/examples/shop-demo/README.md) (all four packs). Both are in the template
repo only.

---

## 5. Design one module (IT)

Run these in order for each module (`E4` here). Each writer is followed by its review. You can always ask
`/flow-next E4` instead of remembering the order.

| # | Run | Produces (in `test-design/it/MOD-E4-…/`) | What you check as a human |
|---|---|---|---|
| 0 | `/plan-scope E4` | `0-scope.md` MANUAL block: in / out of scope, dependencies, readiness per requirement, first questions | Scope boundary matches the test plan; blocking questions raised |
| 1 | `/design-analysis E4` | `1-analysis.md`: inventory (forms / endpoints / tables / objects), business rules, test conditions `TCOND-nnn`, questions | Nothing invented; every rule cited; conflicts raised as questions, not resolved silently |
| 2 | `/check-design E4 analysis` | `1-analysis-review.md` with a verdict | Read the High findings; say "apply the fixes" |
| 3 | `/design-scenarios E4` | `2-mindmap.md`: Mermaid mindmap + scenario table `TS-nnn`, laid out by the pack's layout | Every TCOND covered; each variant and language has its own scenario |
| 4 | `/check-design E4 scenarios` | `2-mindmap-review.md` | Same: fixes applied before step 5 |
| 5 | `/design-cases E4` (SQL pack: `/sql-cases E4`) | `3-test-cases/test-cases.json`, `checklist-pass.md`, the Excel `<folder>_Test_Cases_v<version>.xlsx` | Steps and expected results match 1:1; one behaviour per TC; titles start with `[<item>]` |
| 6 | `/check-design E4 test-cases` | `3-test-cases/test-cases-review.md` | Verdict **Pass** or **Pass with fixes** (fixes applied) before automating |
| 5+ | `/design-data E4` (optional) | `3-test-cases/test-data.md`, fixtures | Data sets cover the pairs / boundaries the TCs need |

**Reading a verdict:** **Rework** (5+ High findings or the wrong structure) sends the step back to its writer with the
findings. **Pass with fixes**: the reviewer offers to apply them; accept, and the downstream step can start.

**Checks you can run yourself:**

```bash
python3 scripts/check_scenarios.py E4            # mindmap ↔ analysis consistency
python3 scripts/export_testcases.py E4 --check   # test case Errors / Warnings, no Excel written
python3 scripts/export_testcases.py E4           # check, then regenerate the Excel
python3 scripts/pipeline_status.py E4            # where the module stands, and the next skill
```

**Order across modules:** the modules in `project.json` order. If the test plan has a system level, run
`/design-analysis st` once before the modules too (so module analyses can hand items over to ST).

---

## 6. Design the system test (ST)

After the modules, run the same chain with the target `st`:

```text
/design-analysis st   →  /check-design st analysis
/design-scenarios st  →  /check-design st scenarios
/design-cases st      →  /check-design st test-cases
/design-nfr           (performance, security, accessibility, compatibility → test-design/st/nfr-plan.md)
```

The ST analysis collects every "Moved to ST" item from the module analyses, the end-to-end flows, integrations with
the real external systems, roles / permissions and smoke tests. ST test cases are `TC-ST-nnn`.

---

## 7. Automate

| Step | Run | Result |
|---|---|---|
| A1 | `/auto-decide E4` | Every TC tagged `Auto`, `Manual` or `Auto + Manual` with a reason; `3-test-cases/automation-plan.md` (waves, blockers, what DEV must provide) |
| A2 | `/auto-write E4` (SQL pack: `/sql-verify E4`) | Tests in `automation/<pack>/`, each carrying its TC ID in its name |
| A3 | `/check-automation E4` (optional) | `automation-review.md`: would each test actually fail on a wrong build? |

Frameworks per pack: Playwright (UI), pytest + `api_client.py` (API), pytest + `reconcile.py` (ETL), pytest +
`sql_verify.py` (SQL). API, ETL and SQL tests are **data-driven**: one test file per module reads the `api` / `etl` /
`sql` block of each TC, so most TCs need no code of their own. See [automation/README.md](automation/README.md).

Check what would run without running it:

```bash
python3 scripts/run_tests.py E4 --plan
```

---

## 8. Run, record and report

### Set the environment first

The runners read the target system from environment variables. Set the ones `--plan` lists in your shell or CI
secrets; **never commit them**:

| Pack | Variables |
|---|---|
| ui | `UI_BASE_URL` |
| api | `API_BASE_URL`, `API_TOKEN_<ROLE>` |
| etl | `ETL_SOURCE_DSN`, `ETL_TARGET_DSN` (+ `ETL_DRIVER`, `ETL_RUN_JOB`) |
| sql | `SQL_DSN` (+ `SQL_DRIVER`, `SQL_DIALECT`) |

Point IT runs at the IT environment and ST runs at the ST environment. The skill stops and asks if a URL looks like
production or the wrong level.

### Run

```text
/run-tests E4                 # or: it · st · all · several ids; "rerun TC-E4-012"
```

or by hand:

```bash
python3 scripts/run_tests.py E4                      # all automated TCs of E4
python3 scripts/run_tests.py E4 --grep TC-E4-012     # one TC
python3 scripts/run_tests.py it --pack api           # all IT modules, API tests only
```

Output goes to `runs/` (not in git): `run-summary.md`, `<key>/results.csv`, JUnit files, and
`<key>/manual-checklist.csv`. Exit code 0 = all passed, 1 = failures, 2 = set-up error. An Auto TC that no test
reported is **No result**, never "passed".

The skill triages every failure as a product defect, automation defect, TC defect, environment problem or flaky test.
It never changes an expected result, adds retries or stretches timeouts to make a test pass.

### Record a cycle

A run is kept only when you record it under a cycle name:

```bash
python3 scripts/run_tests.py E4 --record C1          # writes results into test-cases.json, bumps version, re-exports Excel
```

### Manual results

1. Give the testers `runs/<key>/manual-checklist.csv` (Manual, Auto + Manual and untagged TCs).
2. They fill `result` (Passed / Failed / Blocked / Not Run), `tester`, `notes`, `defect_id`.
3. Record it:

   ```bash
   python3 scripts/record_manual.py E4 filled-checklist.csv --cycle C1 --dry-run   # preview
   python3 scripts/record_manual.py E4 filled-checklist.csv --cycle C1
   ```

### Defects and reports

| Need | Run | Writes |
|---|---|---|
| Log, retest, close a defect | `/run-defects` | `project/defects.md` (`DEF-nnn`) |
| What to rerun for a new build / fix / release | `/run-select` | `plans/regression/…` |
| Exploratory session | `/run-explore E4` | `<folder>/exploratory/ET-nnn-…` |
| Test summary / exit report | `/run-report` | `test-reports/…` |
| Lessons after a review or run | `/learn-retro` | `project/lessons.md`, decisions, status |

---

## 9. Day-to-day work

### "What do I do next?"

```text
/flow-next            # all folders: a status table and the order
/flow-next E4         # one module: Next / Then / Also open
```

It reads `scripts/pipeline_status.py` (deliverables, verdicts, stale reviews, unaccepted source changes) and names
one skill with its reason. It does not do the work; you run the skill it names.

### A day, a sprint, a release

```text
/flow-cadence plan my day          # start gate (build, env, mocks, smoke), risk-ordered queue, EOD note
/flow-cadence sprint 5             # six stages and the testing Definition of Done → plans/sprints/
/flow-cadence release 2.0          # freeze, RC regression, go / no-go evidence → plans/releases/
```

### The client sent a new or changed document

1. Put the file in `sources/` (replace the old one; git keeps the history).
2. Run `python3 scripts/extract_text.py`.
3. Run `/plan-changes`. It diffs old and new content, traces each change to requirements, modules and test cases,
   decides per folder (none / refresh scope / patch / re-run from step N) and writes
   `project/change-impact/<date>-<slug>.md`.
4. Agree to accept the new baseline when it asks. Then run the skills the record names, then `/run-select` for the
   regression set.

`/flow-next` puts this before everything else whenever `sources/` differs from the accepted baseline.

### Requirements are vague or of poor quality

| Situation | Run |
|---|---|
| A vague request or CR: "the client wants …" | `/req-elicit`: layered questions, 3–5 per turn → `plans/discovery/` |
| A written document to check before testing | `/req-review`: findings + questions for the BA → `plans/requirement-reviews/`, `project/questions.md` |
| Draft user stories or use cases | `/req-write` → `plans/stories/` or `plans/use-cases/`, marked **Proposed** |

Proposals don't become test basis by themselves. Once the BA / client confirms them, put the confirmed text in
`sources/` and run `/plan-changes`.

### Database code (SQL pack, or any SQL question)

| Need | Run |
|---|---|
| Understand a procedure / package / schema | `/sql-study` → one card per object |
| Explain a query, plan or DB error to someone | `/sql-explain` |
| Wrong rows, a DB error, a slow query, a failed SQL TC | `/sql-debug` |
| Idempotent test data + cleanup scripts | `/sql-data E4` |

### Explaining work to others

`/learn-explain` explains an artifact to a named audience: client, PM, BA, developer, new tester, or "explain like
I'm five".

### Large files

Don't open a big analysis or test case file whole. Use the slicer:

```bash
python3 scripts/slice.py toc test-design/it/MOD-E4-x/1-analysis.md          # outline with line ranges
python3 scripts/slice.py section test-design/it/MOD-E4-x/1-analysis.md "5.2"
python3 scripts/slice.py tc E4 --stats                                       # suite shape
python3 scripts/slice.py tc E4 --ids TC-E4-012 TC-E4-013                     # some TCs in full
```

---

## 10. Working with the guardrails

The guard runs before each edit, at the end of each Claude turn and at every commit. When it blocks something, do what
the right-hand column says:

| Blocked | Why | Do instead |
|---|---|---|
| Anything in `sources/` | Client inputs stay as received | Replace the file yourself, then `extract_text.py` + `/plan-changes` |
| Any `.xlsx` under `test-design/` | Generated from the JSON | Edit `test-cases.json`, bump `version`, `export_testcases.py <target>` |
| `0-scope.md` outside the MANUAL block, `sources.json`, `INDEX.md` | Generated from `project.json` | Change `project.json`, run `init_project.py` |
| `AGENTS.md`, `GEMINI.md`, `.agents/`, `.github/skills/`, `.gemini/` | Mirrors of `CLAUDE.md` + skills | `python3 scripts/workspace/sync_agents.py` |
| Template-owned files (standards, packs, scripts, skills, `CLAUDE.md`, this guide) | Same in every project | Change them in the template, then `template_sync` (section 12); project-specific rules go in `project/rules.md` |

**Commit checks:** a changed `test-cases.json` must have its `version` bumped and its Excel exported; no new checker
Errors; the **Updated** stamp of a hand-written doc changes with its content; agent mirrors in sync; no git remote while
`git.local_only` is true. Run the same checks yourself:

```bash
python3 scripts/workspace/guard.py check
```

Commit after each change set, naming the folder, artifact and version, e.g. `E4 test cases v0.3: review fixes
TR-001…007`. Skip a check only on purpose (`git commit --no-verify`, with the reason in the message).

**Backups:** each commit also updates a local mirror and a daily bundle in `../<CODE>-backups/` and tags each suite
version (`tc/<folder>/v<version>`). To get an old suite back: `git show tc/<folder>/v0.2:<path>`.

---

## 11. Other agents

Claude Code is the source. The same instructions and skills are mirrored for:

| Agent | Reads |
|---|---|
| Codex | `AGENTS.md`, `.agents/skills/` |
| GitHub Copilot | `.github/copilot-instructions.md`, `.github/skills/`, `.github/instructions/` |
| Gemini CLI | `GEMINI.md`, `.gemini/skills/` |

Pick them in `project.json › agents.mirrors` and run `python3 scripts/workspace/sync_agents.py`. These agents don't run
Claude Code's hooks; they are told to run `guard.py check` before finishing, and the git pre-commit hook catches the
rest.

**Second-agent review:** set `project.json › agents.reviewer` to `codex`, `copilot` or `gemini` so another agent reviews
what Claude wrote. The reviewer records itself in the review and surfaces disagreements.

---

## 12. Upgrade to a new template version

```bash
cd ../ACME-QA
python3 scripts/workspace/template_sync.py --from ../QA-template           # dry run: what would change
python3 scripts/workspace/template_sync.py --from ../QA-template --apply
python3 scripts/workspace/sync_agents.py
python3 scripts/init_project.py
```

Then read the [CHANGELOG](CHANGELOG.md) entries between your old and new version for manual migration steps, and commit
`template v<version>`. Only template-owned files are overwritten. Your `project.json`, `project/`, `plans/`,
`test-design/`, `test-reports/`, sources and automated tests are left alone.

A project older than 1.10.0: run the template's copy of the script instead
(`python3 ../QA-template/scripts/workspace/template_sync.py --from ../QA-template --apply`).

---

## 13. Recipes

| I want to … | Do this |
|---|---|
| Add a module later | Add it to `project.json › modules`, then `/plan-scope <id>` (validates, builds the folder, fills the scope) |
| Fix one test case | Ask the agent to edit `test-cases.json` (or edit it yourself), bump `version`, `export_testcases.py <id>` |
| Add test cases for new scenarios | `/design-cases <id>`: it appends with the next free IDs (IDs are never renumbered or reused) |
| Find out why a review said Rework | Open the review file; the High findings say what to redo. Re-run the writer: `/design-analysis <id>` etc. |
| Answer an open question | Update the row in `project/questions.md` (or the analysis); if it changes a requirement, the confirmed text goes to `sources/` → `/plan-changes` |
| Record a decision by the QA lead | `/learn-retro` or copy `project/decisions/ADR-000-template.md` to the next `ADR-nnn` |
| Stop the same mistake from recurring | `/learn-retro`: a lesson with evidence; when it repeats, a skill pitfall, project rule or script check |
| Find which TCs a requirement has | The Excel's **RTM** sheet, or `python3 scripts/slice.py rows <analysis> FR-004` |
| Something is missing (`No module named openpyxl`, `pdftotext not found`) | `python3 scripts/workspace/setup_workspace.py --check` and follow what it says; don't `pip install` ad hoc |
| See the whole chain on sample data | In the template repo: `python3 template-dev/tests/selftest.py`, then read `template-dev/examples/shop-demo/` |

---

## 14. Cheat sheet

### Skills by question

| Question | Skills |
|---|---|
| What next, in what rhythm? | `flow-next` · `flow-cadence` |
| What do we test, is the basis current? | `plan-setup` · `plan-strategy` · `plan-changes` · `plan-scope` |
| Is the requirement testable? | `req-elicit` · `req-review` · `req-write` |
| What exactly, with which data? | `design-analysis` · `design-scenarios` · `design-cases` · `design-data` · `design-nfr` |
| Is our own work right? | `check-design` · `check-automation` · `check-skill` |
| What to automate, and build it | `auto-decide` · `auto-write` |
| Does the build work, what do we report? | `run-select` · `run-tests` · `run-explore` · `run-defects` · `run-report` |
| What did we learn? | `learn-retro` · `learn-explain` |
| Database code | `sql-study` · `sql-explain` · `sql-debug` · `sql-data` · `sql-cases` · `sql-verify` |

Full catalog: [.claude/skills/README.md](.claude/skills/README.md).

### Scripts

| Script | Use |
|---|---|
| `scripts/pipeline_status.py [target]` | Where each folder stands and the next skill (read-only) |
| `scripts/qa_config.py --validate` | Validate `project.json` |
| `scripts/init_project.py [--check]` | Build / refresh module folders from `project.json` |
| `scripts/extract_text.py [files]` | Parse sources into `sources/parsed/` |
| `scripts/trace_changes.py [--accept --note …]` | What changed in `sources/` since the baseline |
| `scripts/check_scenarios.py <target>` | Check a mindmap |
| `scripts/export_testcases.py <target> [--check]` | Check test cases; write the Excel |
| `scripts/slice.py toc / section / rows / tc` | Read large artifacts in parts |
| `scripts/run_tests.py <targets> [--plan] [--grep] [--pack] [--record C1]` | Run automated tests |
| `scripts/record_manual.py <target> <csv> --cycle C1 [--dry-run]` | Record manual results |
| `scripts/workspace/guard.py check` | Run the guard's checks by hand |
| `scripts/workspace/sync_agents.py` | Regenerate the Codex / Copilot / Gemini mirrors |
| `scripts/workspace/template_sync.py --from <template> [--apply]` | Upgrade to a newer template |
| `scripts/workspace/setup_workspace.py [--check]` | Set up or check the machine |

### Where to look

| For | Open |
|---|---|
| Where the project stands | [project/index.md](project/index.md) › Now, [project/status.md](project/status.md) |
| Open questions for the BA / client | [project/questions.md](project/questions.md) |
| The rules every artifact follows | [standards/core-rules.md](standards/core-rules.md), `packs/<pack>/rules.md`, [project/rules.md](project/rules.md) |
| Folder, file and ID conventions | [standards/conventions.md](standards/conventions.md) |
| How reviews judge | [standards/review-protocol.md](standards/review-protocol.md) |
