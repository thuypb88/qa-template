# Changelog

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 11:05 (UTC+7)

Template versions. Each entry: what changed, what a project must do after `template_sync.py --apply` (migration),
and the self-test result.

## 1.11.0 — 2026-10-16

One setup command for a machine: `scripts/workspace/setup_workspace.py`.

- **New `scripts/workspace/setup_workspace.py`** (standard library, template-owned): prerequisites (Python ≥ 3.10,
  git; pdftotext and Node reported with the install command), `.venv/` with openpyxl + PyYAML + pytest and the DB
  driver of `sql.dialect` (or `--driver`), Playwright for the UI pack (`npm install`, Chromium; `--scaffold-ui`),
  git init + hooks path, `init_project.py` (project with modules) or `sync_agents.py`, and a final verify
  (`project.json`, `guard.py check`, unset runner variables). `--check` reports only; `--packs ui,api|all`;
  `--no-venv` for CI; `--new <dir>` (template only) = `template_sync.py --new` + setup; `--selftest` (template only).
- **Claude Code uses the venv**: the script writes `.claude/settings.local.json › env` (`VIRTUAL_ENV`, `PATH` with
  `.venv/bin` first). Without it, Claude Code started from VS Code ran the system `python3`, which has no openpyxl /
  pytest on a PEP 668 system, so the Excel export and the API / ETL / SQL runs failed. `.gitignore` ignores the file.
- **Self-test fixes**: the skill scan skips `.venv/` (a venv in the template made it fail on site-packages text);
  `--python .venv/bin/python` is made absolute (it was read from inside the built project); new step
  `setup_workspace --check` (reports, writes nothing).
- **Migration:** `template_sync.py --apply` adds the script. Add `.claude/settings.local.json` to the project's
  `.gitignore` (the script does it on its first run), then run `python3 scripts/workspace/setup_workspace.py` and
  restart Claude Code. **Self-test 36/36.**

## 1.10.1 — 2026-10-16

Docs only: the READMEs caught up with 1.9.0 and 1.10.0.

- `README.md`: upgrade note for projects older than 1.10.0 (run the template's `template_sync.py`); what the project
  owns (`plans/`, `test-design/`, `test-reports/`); what the self-test covers (ETL + SQL runs with planted defects,
  manual results, layout upgrade, skill checks); the release steps for working on the template.
- `template-dev/examples/shop-demo/README.md`: four packs, not three (S1 SQL was missing); a module table, the
  folder tree and what each self-test run must pass and must fail.
- `.claude/skills/README.md`: the rename map is `template-manifest.json › renamed_skills`.
- `automation/README.md`: SQL data scripts under `test-design/it/MOD-<id>-<slug>/3-test-cases/sql/data/`; run output
  in `runs/`.
- **Migration:** none (`template_sync.py --apply` updates the template-owned READMEs; seeded ones such as
  `README.md` are kept: copy the changes by hand if you want them). **Self-test 35/35.**

## 1.10.0 — 2026-10-16

`scripts/` split by role, and the template-only folders under one parent:

| Old | New | Why |
|---|---|---|
| `scripts/guard.py`, `backup.py`, `sync_agents.py`, `template_sync.py`, `git-hooks/` | `scripts/workspace/` (same names) | plumbing that runs from hooks or on upgrade, apart from the QA tools you run by hand (`qa_config`, `init_project`, `extract_text`, `parsers/`, `check_scenarios`, `export_testcases`, `slice`, `pipeline_status`, `trace_changes`, `run_tests`, `record_manual`), which stay in `scripts/` |
| `tests/`, `examples/` | `template-dev/tests/`, `template-dev/examples/` | never copied into a project; one folder says so |

- `.claude/settings.json` hooks and permissions, the git hooks, `CLAUDE.md`, skills, standards and Copilot path
  rules use the new paths. `guard.py` now reports a `core.hooksPath` that points at a missing folder (commit checks
  and backups would be silently off). `template_sync.py`'s "still names a moved path" scan matches whole path
  segments (`reports/` no longer matches `test-reports/`).
- **Migration:** run the **template's** copy, since the project's own one moves during the upgrade:
  `python3 ../QA-template/scripts/workspace/template_sync.py --from ../QA-template --apply`. It `git mv`s the four
  scripts and `git-hooks/` into `scripts/workspace/` and sets `git config core.hooksPath scripts/workspace/git-hooks`.
  Check with `git config core.hooksPath`; fix any project note or alias that calls `scripts/guard.py` & co.
- **Self-test 35/35:** the layout-migration step also starts from flat `scripts/` with the old hooks path.

## 1.9.0 — 2026-10-16

Folder structure review: names that collided, a pack without a home for its inputs, migration data in `scripts/`,
and docs that lagged behind the SQL pack.

| Old | New | Why |
|---|---|---|
| `reports/` (raw run output, not in git) | `runs/` | `reports/` next to `test-reports/` (the reports we write, in git) read as the same thing; it is what `run_tests.py` writes |
| `artifacts/` (git-ignored) | removed | nothing wrote to it |
| — | `sources/sql/` | the SQL pack (1.6.0) had no source folder; `shop-demo` and the `sql-*` skill evals already used it. `template_sync.py --new` creates it |
| `scripts/skill_rename_map.json` | `template-manifest.json › renamed_skills` | migration data lives with `moved`, not among the tools |

- **Docs:** `README.md` folder layout grouped by role (inputs · rules · project work · tooling · generated) and now
  lists `plans/`, `test-reports/`, `.harness/`, `automation/sql/`, `sources/sql/` and the template-only `tests/` +
  `examples/`; the SQL pack is in the pack tables, `CLAUDE.md`, R2 and `standards/conventions.md` §1.
  `project.json › template_version` in the template repo matched `TEMPLATE_VERSION` again (it said 1.4.0).
- **Migration:** `template_sync.py --from ../QA-template --apply` moves `reports/` → `runs/` when present, and lists
  `scripts/skill_rename_map.json` as stale: delete it. Create `sources/sql/` if the project has a `sql` module. Any
  project-local note or script that reads `reports/…` → `runs/…`.
- **Self-test 35/35.**

## 1.8.0 — 2026-10-16

Level folders: `modules/` (named after the unit) and `system-test/` (named after the level) held the same kind of
work side by side at the root. They now sit under one parent, named after what they hold, with the level keys as
sub-folders:

| Old | New |
|---|---|
| `modules/` (`INDEX.md`, `test-cases-review-summary.md`, `MOD-<id>-<slug>/`) | `test-design/it/` (same content) |
| `system-test/` | `test-design/st/` |

- Defaults in `project.json`, `qa_config.py`, `guard.py`, `backup.py`, `init_project.py` and `template_sync.py --new`
  are `test-design/it` and `test-design/st`. Folders stay configurable (`levels.*.folder`);
  `examples/alpha.project.json` keeps `modules` / `system-test`.
- **Suite names:** a level folder named after its level key gets the upper-case key in Excel files and tags:
  `test-design/st` → `ST_Test_Cases_v<version>.xlsx`, tag `tc/ST/v<version>` (`qa_config.suite_name`). Module
  suites keep the module folder name. The target `system-test` still selects ST in every script.
- **Migration:** `template_sync.py --from ../QA-template --apply` moves `modules/` → `test-design/it/` and
  `system-test/` → `test-design/st/` with `git mv` and updates `project.json › levels.*.folder` when it named the old
  folder; then fix the listed references (`sed -i -E -e 's#(^|[^_a-z/])modules/#\1test-design/it/#g'
  -e 's#system-test/#test-design/st/#g'`). Re-export the ST suite (`python3 scripts/export_testcases.py st`) and move
  the old `system-test_Test_Cases_v*.xlsx` into `history/`; old `tc/system-test/v*` tags stay valid. To keep the old
  folder names, move them back and set `levels.*.folder`.
- **Self-test 35/35:** the layout-migration step also covers `modules/` + `system-test/`.

## 1.7.0 — 2026-10-16

Folder layout: `brain/` and `knowledge/` were two names for "things to know", with project-owned and template-owned
files mixed in `knowledge/` and a `lessons.md` in each. They are now split by **owner**:

| Old | New | Owner |
|---|---|---|
| `knowledge/core-rules.md`, `review-protocol.md`, `conventions.md`, `skill-architecture.md`, `methods/` | `standards/` (same names) | template |
| `knowledge/lessons.md` (`L-Tnn`) | `standards/template-lessons.md` | template |
| `knowledge/project-rules.md` (`PR-n`) | `project/rules.md` | project |
| `brain/` (index, system-map, status, questions, lessons, defects, log, decisions/, change-impact/) | `project/` (same names) | project |

- "Brain" is now "project memory" in the docs and skills; `learn-retro` commits as `project: retro …` and still
  answers to "update the brain". Content is unchanged apart from paths.
- **`template-manifest.json › moved`:** ordered old → new renames. `template_sync.py` shows them as `move` in a dry
  run and applies them with `git mv` before copying on `--apply`, then lists project files that still name an old path.
- **Self-test 35/35:** new step moves a project on the 1.6 layout and checks it ends up to date.
- **Migration:** `template_sync.py --from ../QA-template --apply` (moves `brain/` → `project/`, `knowledge/` →
  `standards/`), then fix the references it lists, e.g.
  `grep -rlE 'brain/|knowledge/' modules system-test plans test-reports project | xargs sed -i -E
  -e 's#knowledge/project-rules\.md#project/rules.md#g' -e 's#knowledge/lessons\.md#standards/template-lessons.md#g'
  -e 's#knowledge/#standards/#g' -e 's#brain/#project/#g'`; run `python3 scripts/sync_agents.py`, check
  `python3 scripts/guard.py check`, commit. Personal agent memory that points at `brain/index.md` → `project/index.md`.

## 1.6.0 — 2026-10-16

SQL skill set: a **`sql` pack** and a **`sql-` domain group** (26 → 32 skills), engine-neutral with SQL Server /
Oracle / PostgreSQL / MySQL notes. The domain group is the one recorded exception to grouping by objective
(`knowledge/skill-architecture.md` §3a, D5).

- **Pack `packs/sql/`:** `pack.json` (layouts `object` | `flow`, areas, `sql` TC block with `object`, `call`,
  `oracle`, `verify` required), `rules.md` (R-SQL1 surface and exact oracles, R-SQL2 the code is evidence not the
  oracle, R-SQL3 structure, R-SQL4 synthetic idempotent data and the `qa` schema, R-SQL5 the verification contract),
  `analysis.md`, `scenarios.md` (easy-to-miss coverage: NULL, zero / one / many, failure mid-way, side effects,
  re-run, concurrency, collation), `checklist.md` (SQL-V/R/E/C/X, 25 checks), `tc-fields.md`, `dialects.md` (quick
  reference per engine and a verification template each: T-SQL table variable over ROLLBACK, Oracle autonomous
  function returning a collection, PL/pgSQL sub-transaction per TC, MySQL MEMORY temp table; script form for any engine).
- **Skills:** `sql-study` (object cards with `file:line`, code-only rules as questions; catalog queries per engine),
  `sql-explain` (query / procedure / plan / error modes), `sql-debug` (reproduce, classify, shrink, hypotheses with
  check queries, root cause; never changes product objects), `sql-data` (idempotent data + cleanup scripts, proved by
  running twice), `sql-cases` (step 5 for pack-sql modules, object mode for a single object, SQL checklist pass),
  `sql-verify` (verification procedures / scripts returning `tc_id, result, detail`, deploy / drop scripts).
  Boundaries: `design-cases` → `sql-cases`, `auto-write` → `sql-verify`, `design-data` plans / `sql-data` scripts,
  `learn-explain` → `sql-explain`; `check-automation` check 12 reviews SQL verifications; `flow-next` routes the group;
  `pipeline_status.py` names `sql-cases` as the step-5 writer of a sql module. Evals for all six.
- **Runner `automation/sql/`:** `conftest.py` (`SQL_DSN`, `SQL_DRIVER`, `SQL_DIALECT`), `sql_verify.py` (dialect calls,
  script runner, verdict per TC — a TC without a row is NO RESULT), `test_example_sql.py` (data set once per session,
  cleanup at the end, one verification call per ref). `project.json › sql` (`dialect`, `version`, `verify_schema`) and
  `runners.sql`; `qa_config.py --validate` requires `sql.dialect` when a module uses the pack.
- **Self-test 34/34:** demo module S1 (SQLite view with a planted NULL-discount defect): checkers and export clean;
  a real run shows the defect and leaves no data behind. The four engines' verification templates are **not**
  executed by the self-test (no engines in it); try them on the first real project.
- **Migration:** `template_sync.py --from ../QA-template --apply` (new pack, skills, runner; `automation/sql/
  test_example_sql.py` is seeded), `python3 scripts/sync_agents.py`; add `runners.sql` and `sql` to `project.json`
  only if you add a sql module. Nothing else changes for ui / api / etl projects.

## 1.5.0 — 2026-10-16

Skills regrouped **by objective** and renamed `<group>-<objective>` (28 → 26), after a second study of the reference
set in `EIMS/sources/skills-refer/` (awesome-qa-skills: virtual domains, one router + one primary skill, thin entry
with on-demand references; BA Zone / ELI5 trigger style). Design and the full old → new table:
`knowledge/skill-architecture.md`; machine-readable map: `scripts/skill_rename_map.json`.

- **Eight groups, one question each:** `flow-` (what next, in what rhythm) · `plan-` (what to test, is the basis
  current) · `req-` (is the requirement testable) · `design-` (what exactly, with which data) · `check-` (is our own
  work right) · `auto-` · `run-` (does the build work, what do we report) · `learn-`. The prefix is the only grouping
  every agent's skill picker shows; `metadata.category` → `metadata.group` (= prefix) + `metadata.order`.
- **Renamed (21):** `discover` → `flow-next`, `qa-init` → `plan-setup`, `test-strategy` → `plan-strategy`, `scope` →
  `plan-scope`, `trace-changes` → `plan-changes`, `discovery` → `req-elicit`, `requirement-review` → `req-review`,
  `analyze` → `design-analysis`, `write-test-cases` → `design-cases`, `test-data` → `design-data`, `nfr-testing` →
  `design-nfr`, `review` → `check-design`, `skill-review` → `check-skill`, `automate-decide` → `auto-decide`,
  `automate-test` → `auto-write`, `regression-select` → `run-select`, `execute-test` → `run-tests`,
  `exploratory-testing` → `run-explore`, `defect-management` → `run-defects`, `test-report` → `run-report`, `retro` →
  `learn-retro`, `explain` → `learn-explain` (`design-scenarios` unchanged).
- **Merged:** `daily-workflow` + `sprint-workflow` + `release-workflow` → `flow-cadence` (modes day · sprint ·
  release in `references/`, shared gate rules once); `user-story-ac` + `use-case-spec` → `req-write` (forms story ·
  use-case). **Split:** `review automation` → `check-automation` (own input, checklist and AR- findings).
- **One owner per output:** `plan-changes` records the *Affected TCs*; `run-select` alone builds regression sets.
- **Shared methods** moved out of skill folders to `knowledge/methods/` (`requirement-quality.md`,
  `test-techniques.md` ← `techniques.md`, `defect-report.md`); skills no longer link into each other's `references/`.
- **Uniform skeleton:** description starts `<Group>[ order]: <objective>` and ends `Not for: … → skill`; H1
  `<Group>: <objective>`; every skill has `## Done when`; `flow-next` routes by group first. New `SKILL_TEMPLATE.md`
  and catalog README.
- **Self-test** (skills step): name prefix = `metadata.group`, `order` present, `## Done when` present, no link into
  another skill's `references/`, links in `knowledge/methods/` resolve, no retired skill name anywhere in the repo
  (outside this changelog, the map and the architecture doc). Evals: `req-write.json` merges the story and use-case
  cases (new near misses to `design-cases` / `req-review`); `discovery`, `requirement-review`, `explain` evals renamed.
- **Migration:** `template_sync.py --from ../QA-template --apply`, then delete the old skill folders it lists as
  **stale** (`.claude/skills/<old name>/`; the names are the keys of `scripts/skill_rename_map.json`), then
  `python3 scripts/sync_agents.py`. Project files that name old skills (`brain/`, `knowledge/project-rules.md`,
  `plans/`, project skills) → replace with the map; project skills: rename to `<group>-<objective>` and set
  `metadata.group` / `order`. Records in `brain/change-impact/` with a *Regression set* section stay valid; new ones
  write *Affected TCs*.

## 1.4.0 — 2026-10-16

Requirements category and four new skills (24 → 28), from BA Zone's user-story / use-case / product-discovery skills
(Phúc NT, MIT) and the ELI5 skill (MIT); ideas rewritten from the QA side, no text copied.

- **New category `requirements`** (seven in all): `discovery` (ask-why loop: request kind incl. solution bias, five
  requirement layers, known / unknown, 3–5 questions per turn, paraphrase + classify, failure scan, stop condition,
  `plans/discovery/`), `requirement-review` (moved from `plan`; now also checks the requirement layers, INVEST stories
  and use cases), `user-story-ac` (stories with a specific persona and distinct *so that*, INVEST table, split
  patterns, ≥ 3 Given-When-Then criteria; `plans/stories/`, status Proposed), `use-case-spec` (goal / event / CRUD
  discovery at user-goal level, the 13 fields, 20-point check, test seeds per course; `plans/use-cases/`, status
  Proposed). Proposals become a test basis only when the confirmed version is added to `sources/`.
- **New `explain`** (knowledge): an artifact or technical point for a named audience — client, director, PM, BA,
  developer, new tester, ELI5 — what → analogy → details → so what, facts only from the project files.
- **References:** `requirement-quality.md` §7 requirement layers, §8 stories and criteria, §9 use cases;
  `techniques.md` §10 use-case / scenario testing. `analyze` §4 maps use-case courses and Given-When-Then criteria;
  `test-strategy` gains a **Transition** section (migration, parallel run, cutover, rollback); `test-report` points
  to `explain` for other audiences.
- **Behaviour evals:** `tests/skill-evals/<skill>.json` (≥ 3 cases: success, incomplete input, near-miss routing;
  assertions per case) seeded for the five requirements / explain skills; `skill-review` check 11; the self-test
  validates their shape. New triggers in Vietnamese for the requirements skills and `explain`.
- **Migration:** `template_sync.py --from ../QA-template --apply`, then `python3 scripts/sync_agents.py`. A project
  skill with `category: plan` that reviews requirements may move to `requirements`.
- **Self-test:** 31/31 with pytest (skills step now also checks the requirements category and the evals shape).

## 1.3.0 — 2026-10-16

Twelve new skills (12 → 24) and skill categories, from the second pass over the awesome-qa-skills library (its
workflow layer and the test types the pipeline lacked; ideas rewritten, no text copied).

- **Categories:** every SKILL.md has `metadata: category:` — `workflow`, `plan`, `design`, `automation`,
  `execution`, `knowledge`. Folders stay flat (Claude Code, Codex and Copilot only discover `skills/<name>/SKILL.md`);
  the catalog `.claude/skills/README.md` is grouped by category; `SKILL_TEMPLATE.md` has the field.
- **Workflow:** `daily-workflow` (start gate, risk-ordered queue, EOD note), `sprint-workflow` (six stages, gate
  board, DoD, `plans/sprints/`), `release-workflow` (freeze → RC regression → NFR → go / no-go evidence pack →
  post-release, `plans/releases/`). They hand each stage to one skill; `discover` stays the router.
- **Plan:** `test-strategy` (write ours or review the client's test plan, `plans/test-strategy.md`),
  `requirement-review` (shift-left RQ-NNN questions, `plans/requirement-reviews/`).
- **Design:** `test-data` (`3-test-cases/test-data.md`: TDR groups, valid / invalid sets, pairwise, privacy,
  cleanup, generated fixtures), `nfr-testing` (`system-test/nfr-plan.md`: workload model, authorised security
  checks, WCAG evidence, compatibility matrix → ST scenarios).
- **Execution:** `regression-select` (layered selection with reason codes and runnable `--grep` commands,
  `plans/regression/`), `exploratory-testing` (charters, session logs, debriefs, `<folder>/exploratory/ET-NNN`),
  `defect-management` (reports, register `brain/defects.md` with `DEF-NNN`, retests on a named build),
  `test-report` (test summary / exit report from recorded results only, `test-reports/`).
- **Knowledge:** `skill-review` (a skill as a contract: trigger test, category, contract line, references, links,
  Done when; then sync + self-test).
- **New script `scripts/record_manual.py`:** writes the testers' filled `manual-checklist.csv` (result, tester,
  defect_id) into `test-cases.json` for a cycle, refuses unknown TCs / results, keeps an automated Failed, bumps the
  version and re-exports. `run_tests.py` adds a `defect_id` column to the manual checklist.
- **Seeded project files:** `plans/README.md`, `test-reports/README.md`, `brain/defects.md`; conventions list the new
  folders, files and IDs (`RQ-`, `TDR-`, `NFR-`, `ET-`, `DEF-`); `discover` routes to every new skill.
- **Migration:** `template_sync.py --from ../QA-template --apply` (brings the skills, the script and the seeded
  files), then `python3 scripts/sync_agents.py`. A project skill of its own needs `metadata.category` too, or the
  self-test reports it.
- **Self-test:** 31/31 with pytest (new: skill categories in the skills step; record_manual refuses bad rows and
  records results).

## 1.2.0 — 2026-10-16

Skills deepened with practices distilled from a study of the open awesome-qa-skills library (ideas rewritten for this
pipeline; no text copied). Still 12 skills: the additions are reference files and rules inside the existing steps.

- **New references (read on demand):** `analyze/references/requirement-quality.md` (atomic BR parts, six gap kinds,
  seven ambiguity checks, pair and multi-rule conflicts, testability, closable questions);
  `design-scenarios/references/techniques.md` (technique by rule shape; how to apply EP, BVA with unit / step /
  encoding, decision table gaps / overlaps / dead rules, state transition with refused events and guards, pairwise
  with constraints, failure-path classes, edge dimensions, risk priority without fake scores);
  `review/references/automation.md` (new optional **automation review**: would each test fail on a wrong build —
  Strong / Weak / Fake, surface, locators, waits, mock drift, data isolation); `execute-test/references/defect-report.md`
  (defect report fields, flaky tests and quarantine, run summary conclusion with exit criteria Met / Not met /
  Blocked / Unknown).
- **analyze:** BR rules atomic; §9 columns now `ID | Kind | Topic | Evidence A | Evidence B | Proposed assumption |
  Owner | Blocks`. **design-scenarios:** apply the named technique; refusals name the absent side effect; duplicate
  rule. **write-test-cases:** decidable expected results (no "as expected"), one violated constraint per negative TC,
  read-back on refusals. **review:** automation artifact (`AR-` / `SAR-`, `3-test-cases/automation-review.md`); every
  review ends with a **Fix order**; test-case checklist traces both directions (orphan TCs). **automate-test:**
  self-check per test (smallest escaping bug), scoped locators, state waits that never re-submit, per-run data,
  contract-shaped mocks. **execute-test:** Flaky triage class; no retries / longer timeouts to go green; honest
  summary. **trace-changes:** neighbours via `depends_on`, unknown ≠ no impact, removed rules keep their other
  protection, a **Regression set** section. **retro:** trigger / root cause / contributing factors and the escape
  point.
- **API pack:** new checks API-V06 payload size, API-V07 no side effect on refusal, API-A05 revoked access, API-P04
  cursor misuse, API-I05 idempotency key reuse, API-E04 error consistency; API-P02 covers equal sort keys; three more
  easy-to-miss items.
- **Self-test:** new step "skills: frontmatter + links" (name = folder, description ≤ 1024, every relative link in
  `.claude/skills/` resolves).
- **Migration:** `template_sync.py --from ../QA-template --apply`, then `python3 scripts/sync_agents.py`. Existing
  analyses keep their old §9 columns until next rewritten (no script reads them). Re-run the API checklist pass on
  API modules to pick up the new checks.
- **Self-test:** 30/30 with pytest (new step: skills frontmatter + links).

## 1.1.0 — 2026-10-16

- **GitHub Copilot support.** `sync_agents.py` now writes mirrors per `project.json › agents.mirrors` (default
  `codex`, `copilot`): `.github/copilot-instructions.md` (CLAUDE.md + Copilot preface, links rebased) and
  `.github/skills/` (identical SKILL.md copies). New template-owned path rules `.github/instructions/` for test cases,
  mindmaps, analyses, `sources/` and `automation/`. The guard treats the Copilot copies as generated; P7 allows
  `copilot` as reviewer.
- **Migration:** add `"mirrors": ["codex", "copilot"]` to `project.json › agents` (optional: it is the default), run
  `python3 scripts/sync_agents.py`, commit `.github/`.
- **Self-test:** 29/29 with pytest (new step: Copilot mirror in sync).

## 1.0.0 — 2026-10-16

First release, distilled from the ALPHA QA workspace (the pilot workspace and its harness clone, 2026-10-15).

- **Profile:** `project.json` holds every project-specific value; `scripts/qa_config.py` loads and validates it.
- **Skills 25 → 12:** the six `it-*` and six `st-*` skills merged into level-aware `analyze`, `design-scenarios`,
  `write-test-cases` and one `review` (checklists in `review/references/`); `it-write-ui-test-cases` became the pack
  checklist pass inside `write-test-cases`; new `qa-init`, `automate-test`, `retro`; `<project>-discover` → `discover`;
  `requirement-trace` → `trace-changes`; `it-update-scope` → `scope`. ALPHA-only skills (`pdf-form-data`,
  `e1-test-data`) stay in ALPHA.
- **Packs:** `ui` (from the ALPHA rules and GUI checklist), `api` and `etl` (new): rules, checklists, analysis sections,
  scenario layouts, TC blocks, Excel columns, forbidden-term checks.
- **Rules:** ALPHA R1–R10 generalised into core R1–R10 (R1.5 → source precedence, R6.3 → `languages`, R10 → `variant_sets`,
  R2 → "observable at the pack surface"); review protocol P1–P6 + P7 (cross-agent review).
- **Design system:** `knowledge/conventions.md` (ownership, layout, IDs, TC fields, Excel columns, headers, citations,
  commits).
- **Brain:** `brain/` (status, questions, ADRs, lessons, change impact, log) + template brain `knowledge/lessons.md`
  (L-T01…18 from ALPHA reviews).
- **Tools:** generic `extract_text.py` (docx / xlsx / pptx / pdf), `parsers/openapi_inventory.py`,
  `parsers/sttm_inventory.py`, `check_scenarios.py`, `export_testcases.py` (check + Excel + RTM + Summary),
  `pipeline_status.py`, `trace_changes.py`, `run_tests.py` (per-pack runners, JUnit → TC IDs, `--record`), `guard.py`
  (manifest + `protected_paths`), `backup.py`, `sync_agents.py`, `template_sync.py`, `slice.py`.
- **Automation:** `tc_binding.py`, data-driven API and ETL runners, `api_client.py`, `reconcile.py`.
- **Self-test:** `tests/selftest.py` — 28/28 passed (with pytest 8.4.2); 27/27 + set-up-error path without pytest.

Migration from the pilot workspace: not part of 1.0.0.
