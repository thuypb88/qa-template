"""Data-driven runner for ETL test cases: one pytest test per Auto TC of an ETL module, driven by its `etl` block.

Copy per module (test_<id>_etl.py) and set MODULE. Kinds other than count / sum / row_diff (history, rule, custom)
get their own hand-written test named test_TC_<id>_<nnn>_<what>, using the helpers in reconcile.py.
"""
import pytest

from reconcile import run_block
from tc_binding import tc_params

MODULE = None  # e.g. "D2"; None skips the file (the template ships no module)


@pytest.mark.parametrize("tc", tc_params(MODULE, pack="etl") if MODULE else [])
def test_etl_tc(tc, src, tgt, run_job, load_fixture):
    b = tc["etl"]
    if b.get("fixture"):
        load_fixture(src, b["fixture"])
    if b.get("job"):
        run_job(b["job"])
    if b["reconcile"] not in ("count", "sum", "row_diff"):
        pytest.skip(f"reconcile {b['reconcile']}: needs a dedicated test")
    r = run_block(src, tgt, b)
    assert r.ok, r.detail
