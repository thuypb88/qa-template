"""ETL pack: reconciliation checks over any DB-API 2.0 connection (sqlite3, psycopg, pyodbc, oracledb, …).

Each function returns a Result(ok, detail, numbers) so a test can assert `r.ok, r.detail`. Queries come from the
TC's `etl` block (source_sql / target_sql files) or inline strings. Standard library only.

    r = count(src_conn, tgt_conn, "select count(*) from customer", "select count(*) from dim_customer")
    r = row_diff(src, tgt, src_sql, tgt_sql, keys=["customer_no"])           # both directions
    r = sums(src, tgt, src_sql, tgt_sql, tolerance=0.01)                     # one row of measures each side
    r = null_check(tgt, "dim_customer", ["customer_no", "name"])
    r = duplicate_check(tgt, "dim_customer", ["customer_no"])
    r = ri_check(tgt, "fact_sales", "customer_sk", "dim_customer", "customer_sk")
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


@dataclass
class Result:
    ok: bool
    detail: str
    numbers: dict = field(default_factory=dict)


def sql_text(q: str) -> str:
    """A path to a .sql file (relative to the repo) or the SQL itself."""
    p = ROOT / q if not Path(q).is_absolute() else Path(q)
    return p.read_text(encoding="utf-8") if q.strip().lower().endswith(".sql") and p.is_file() else q


def rows(conn, q: str) -> tuple[list[str], list[tuple]]:
    cur = conn.cursor()
    cur.execute(sql_text(q))
    cols = [d[0].lower() for d in cur.description]
    return cols, [tuple(r) for r in cur.fetchall()]


def scalar(conn, q: str):
    return rows(conn, q)[1][0][0]


def norm(v):
    if isinstance(v, float):
        return round(Decimal(str(v)), 10)
    if isinstance(v, Decimal):
        return round(v, 10)
    if isinstance(v, str):
        return v.rstrip()
    return v


def count(src, tgt, src_sql: str, tgt_sql: str, expect_diff: int = 0) -> Result:
    s, t = scalar(src, src_sql), scalar(tgt, tgt_sql)
    return Result(s - t == expect_diff, f"source {s} · target {t} · diff {s - t} (expected {expect_diff})",
                  {"source": s, "target": t})


def sums(src, tgt, src_sql: str, tgt_sql: str, tolerance: float = 0) -> Result:
    sc, sr = rows(src, src_sql)
    tc, tr = rows(tgt, tgt_sql)
    bad = []
    for i, name in enumerate(sc):
        a, b = Decimal(str(sr[0][i] or 0)), Decimal(str(tr[0][i] or 0))
        if abs(a - b) > Decimal(str(tolerance)):
            bad.append(f"{name}: {a} vs {b}")
    return Result(not bad, "; ".join(bad) or f"{len(sc)} measure(s) equal within {tolerance}",
                  {"source": sr[0], "target": tr[0]})


def row_diff(src, tgt, src_sql: str, tgt_sql: str, keys: list[str] | None = None, limit: int = 20) -> Result:
    """Rows in source not in target and the reverse; with keys, also rows whose non-key values differ."""
    sc, sr = rows(src, src_sql)
    tc, tr = rows(tgt, tgt_sql)
    if sc != tc:
        return Result(False, f"columns differ: source {sc} vs target {tc}")
    sr = [tuple(norm(v) for v in r) for r in sr]
    tr = [tuple(norm(v) for v in r) for r in tr]
    if not keys:
        a, b = set(sr) - set(tr), set(tr) - set(sr)
        return Result(not a and not b, f"{len(a)} only in source, {len(b)} only in target"
                      + (f"; e.g. {sorted(a, key=str)[:3]} / {sorted(b, key=str)[:3]}" if a or b else ""),
                      {"only_source": len(a), "only_target": len(b), "diff_rows": len(a) + len(b)})
    ki = [sc.index(k.lower()) for k in keys]
    sk = {tuple(r[i] for i in ki): r for r in sr}
    tk = {tuple(r[i] for i in ki): r for r in tr}
    only_s, only_t = sorted(set(sk) - set(tk), key=str), sorted(set(tk) - set(sk), key=str)
    changed = [k for k in sk.keys() & tk.keys() if sk[k] != tk[k]]
    detail = [f"{len(only_s)} key(s) only in source", f"{len(only_t)} only in target", f"{len(changed)} changed"]
    for k in changed[:limit]:
        cols = [sc[i] for i in range(len(sc)) if sk[k][i] != tk[k][i]]
        detail.append(f"{k}: {', '.join(f'{c} {sk[k][sc.index(c)]!r}→{tk[k][sc.index(c)]!r}' for c in cols)}")
    n = len(only_s) + len(only_t) + len(changed)
    return Result(n == 0, "; ".join(detail), {"only_source": len(only_s), "only_target": len(only_t),
                                              "changed": len(changed), "diff_rows": n})


def null_check(conn, table: str, columns: list[str]) -> Result:
    bad = {c: scalar(conn, f"select count(*) from {table} where {c} is null") for c in columns}
    bad = {c: n for c, n in bad.items() if n}
    return Result(not bad, f"nulls: {bad}" if bad else f"no nulls in {', '.join(columns)}", bad)


def duplicate_check(conn, table: str, keys: list[str]) -> Result:
    k = ", ".join(keys)
    n = scalar(conn, f"select count(*) from (select {k} from {table} group by {k} having count(*) > 1) d")
    return Result(n == 0, f"{n} duplicate key(s) on ({k})", {"duplicates": n})


def ri_check(conn, child: str, fk: str, parent: str, pk: str) -> Result:
    n = scalar(conn, f"select count(*) from {child} c left join {parent} p on c.{fk} = p.{pk} "
                     f"where c.{fk} is not null and p.{pk} is null")
    return Result(n == 0, f"{n} orphan row(s) in {child}.{fk} → {parent}.{pk}", {"orphans": n})


def run_block(src, tgt, etl: dict) -> Result:
    """Run a TC's `etl` block for the generic reconcile kinds; others need a hand-written test."""
    kind, tol = etl["reconcile"], etl.get("tolerance", 0)
    if kind == "count":
        return count(src, tgt, etl["source_sql"], etl["target_sql"], etl.get("expect", {}).get("diff", 0))
    if kind == "sum":
        return sums(src, tgt, etl["source_sql"], etl["target_sql"], tol)
    if kind == "row_diff":
        r = row_diff(src, tgt, etl["source_sql"], etl["target_sql"], etl.get("keys"))
        want = etl.get("expect", {}).get("diff_rows", 0)
        return Result(r.numbers.get("diff_rows", -1) == want, r.detail, r.numbers)
    raise NotImplementedError(f"reconcile {kind!r}: write a dedicated test (test_TC_<id>_<nnn>_...)")
