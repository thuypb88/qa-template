"""ETL pack fixtures: source and target DB-API connections, a fixture-set loader and a job runner hook.

Environment (never commit values):
    ETL_SOURCE_DSN / ETL_TARGET_DSN   "sqlite:///path.db" works out of the box; any other DSN needs
                                      ETL_DRIVER=<module> (psycopg, pyodbc, oracledb, …) installed
    ETL_RUN_JOB                        a command that runs one job: "airflow tasks test {job}", "dbt run -s {job}",
                                       "./run_job.sh {job}" — {job} is the TC's etl.job
"""
from __future__ import annotations

import importlib
import os
import shlex
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))


def connect(dsn: str):
    if dsn.startswith("sqlite:///"):
        return sqlite3.connect(dsn[len("sqlite:///"):])
    driver = os.environ.get("ETL_DRIVER")
    if not driver:
        pytest.skip("ETL_DRIVER not set for a non-sqlite DSN")
    return importlib.import_module(driver).connect(dsn)


@pytest.fixture(scope="session")
def src():
    dsn = os.environ.get("ETL_SOURCE_DSN")
    if not dsn:
        pytest.skip("ETL_SOURCE_DSN not set")
    c = connect(dsn)
    yield c
    c.close()


@pytest.fixture(scope="session")
def tgt():
    dsn = os.environ.get("ETL_TARGET_DSN")
    if not dsn:
        pytest.skip("ETL_TARGET_DSN not set")
    c = connect(dsn)
    yield c
    c.close()


@pytest.fixture(scope="session")
def run_job():
    def run(job: str) -> None:
        cmd = os.environ.get("ETL_RUN_JOB")
        if not cmd:
            pytest.skip("ETL_RUN_JOB not set")
        r = subprocess.run(shlex.split(cmd.format(job=job)), capture_output=True, text=True)
        assert r.returncode == 0, f"job {job} failed: {r.stderr[-500:]}"
    return run


@pytest.fixture(scope="session")
def load_fixture():
    """load_fixture(conn, "ETL-FX-DIM_CUSTOMER-03") runs automation/etl/fixtures/<name>.sql against conn."""
    def load(conn, name: str) -> None:
        f = HERE / "fixtures" / f"{name}.sql"
        if not f.is_file():
            pytest.skip(f"fixture {f.relative_to(HERE.parent.parent)} missing")
        conn.executescript(f.read_text(encoding="utf-8")) if isinstance(conn, sqlite3.Connection) else \
            [conn.cursor().execute(s) for s in f.read_text(encoding="utf-8").split(";") if s.strip()]
        conn.commit()
    return load
