"""Bind automated tests to test case IDs, for every pack (pytest side; Playwright puts the ID in the test title).

A test reports its TC by carrying the ID in its name: `test_TC_E4_001_rejects_empty_amount`, or a parametrised id
`pytest.param(..., id="TC-E4-001")`. scripts/run_tests.py reads the JUnit file and maps results by that ID.

    from tc_binding import load_tcs, tc_params
    @pytest.mark.parametrize("tc", tc_params("E7", pack="api"))     # one test per Auto TC of the module
    def test_api_tc(tc, api): ...

Standard library only.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import qa_config as qc  # noqa: E402


def load_tcs(target: str) -> list[dict]:
    p = qc.load_project()
    t = qc.resolve(p, target)[0]
    f = t["folder"] / "3-test-cases/test-cases.json"
    return json.loads(f.read_text(encoding="utf-8")).get("test_cases", []) if f.is_file() else []


def tc_params(target: str, pack: str | None = None, automation=("Auto", "Auto + Manual")):
    """pytest params (id = tc_id) for the Auto TCs of a target, optionally one pack only."""
    import pytest  # noqa: PLC0415

    p = qc.load_project()
    t = qc.resolve(p, target)[0]
    out = []
    for tc in load_tcs(target):
        if tc.get("automation") not in automation:
            continue
        if pack and qc.tc_pack(tc, t, p) != pack:
            continue
        marks = [pytest.mark.skip(reason=tc.get("notes", "Blocked"))] if tc.get("status") == "Blocked" else []
        out.append(pytest.param(tc, id=tc["tc_id"].replace("-", "_"), marks=marks))
    return out
