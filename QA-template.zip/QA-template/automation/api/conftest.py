"""API pack fixtures: an HTTP client against the level's base URL, auth tokens per role, fixture files.

Environment (never commit values; put them in automation/.env, git-ignored, or the CI secrets):
    API_BASE_URL       the service under test (IT: the SIT service with mocked dependencies; ST: UAT)
    API_TOKEN_<ROLE>   a bearer token per role, e.g. API_TOKEN_BUYER (fixture name TOKEN-buyer in the TCs)
The client is api_client.py (urllib, no dependency needed to start).
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
from api_client import ApiClient  # noqa: E402

FIXTURES = HERE / "fixtures"


@pytest.fixture(scope="session")
def api() -> ApiClient:
    url = os.environ.get("API_BASE_URL")
    if not url:
        pytest.skip("API_BASE_URL not set")
    return ApiClient(url)


@pytest.fixture(scope="session")
def token():
    """token("TOKEN-buyer") → the value of API_TOKEN_BUYER; "none" → None."""
    def get(name: str | None):
        if not name or name == "none":
            return None
        env = "API_TOKEN_" + name.removeprefix("TOKEN-").upper().replace("-", "_")
        val = os.environ.get(env)
        if not val:
            pytest.skip(f"{env} not set")
        return val
    return get


@pytest.fixture(scope="session")
def fixture_body():
    """fixture_body("fixtures/api/order-valid.json") or an inline dict → the request body."""
    def get(ref):
        if ref is None or isinstance(ref, (dict, list)):
            return ref
        p = Path(ref)
        p = p if p.is_absolute() else (HERE.parent.parent / ref if (HERE.parent.parent / ref).is_file() else FIXTURES / p.name)
        return json.loads(p.read_text(encoding="utf-8"))
    return get
