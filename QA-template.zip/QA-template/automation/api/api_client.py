"""API pack: a small HTTP client and the `api.expect` assertions. urllib only (no dependency to start)."""
from __future__ import annotations

import json
import urllib.error
import urllib.request


class Response:
    def __init__(self, status: int, headers: dict, body: bytes):
        self.status_code, self.headers, self.content = status, headers, body

    def json(self):
        return json.loads(self.content or b"null")


class ApiClient:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    def request(self, method: str, path: str, token: str | None = None, body=None, headers: dict | None = None,
                timeout: float = 30) -> Response:
        h = {"Accept": "application/json", **(headers or {})}
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            h.setdefault("Content-Type", "application/json")
        if token:
            h["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request(self.base_url + path, data=data, method=method.upper(), headers=h)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 - test target URL from env
                return Response(r.status, dict(r.headers), r.read())
        except urllib.error.HTTPError as e:
            return Response(e.code, dict(e.headers), e.read())


def json_path(doc, path: str):
    """Tiny JSONPath: $.a.b[0].c"""
    cur = doc
    for part in path.lstrip("$").lstrip(".").replace("]", "").replace("[", ".").split("."):
        if part == "":
            continue
        cur = cur[int(part)] if isinstance(cur, list) else cur[part]
    return cur


def check_expect(resp: Response, expect: dict) -> None:
    """Assert an `api.expect` block: status, headers (exact), body (JSON path → exact value)."""
    assert resp.status_code == expect["status"], f"status {resp.status_code} ≠ {expect['status']}: {resp.content[:300]!r}"
    for k, v in (expect.get("headers") or {}).items():
        assert "{" in str(v) or resp.headers.get(k) == v, f"header {k} = {resp.headers.get(k)!r} ≠ {v!r}"
    if expect.get("body"):
        doc = resp.json()
        for path, v in expect["body"].items():
            assert json_path(doc, path) == v, f"{path} = {json_path(doc, path)!r} ≠ {v!r}"
