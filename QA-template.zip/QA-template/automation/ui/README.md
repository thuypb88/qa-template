# automation/ui — Playwright (UI pack)

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:50 (UTC+7)

Not scaffolded until the first UI spec is written (`auto-write`), so no Node install is needed for API / ETL-only
projects. To start:

```bash
cd automation/ui && npm init playwright@latest -- --quiet --lang=ts --no-examples
```

Conventions (so `scripts/run_tests.py` can bind results):
- One spec per level-1 item (screen / form / flow step): `tests/<module-id>/<screen>.spec.ts`.
- Every test title starts with its TC ID: `test('TC-E4-012 Reject with empty reason is refused', …)`. Data-driven
  rows (variants, languages, boundaries) keep one TC ID per row.
- Page objects in `pages/<Screen>Page.ts`; fixtures (mock login per role, seeded data) in `fixtures/`.
- JUnit reporter on: `reporter: [['junit', { outputFile: process.env.PLAYWRIGHT_JUNIT_OUTPUT_NAME || 'junit.xml' }], ['html']]`.
- Base URL from the environment (`UI_BASE_URL`), never hard-coded; IT and ST URLs differ (R9).

Runner entry in `project.json › runners.ui`:
`{"cmd": ["npx", "playwright", "test", "--grep", "{grep}"], "cwd": "automation/ui", "grep_style": "playwright",
"env": {"PLAYWRIGHT_JUNIT_OUTPUT_NAME": "{junit}", "UI_BASE_URL": "${UI_BASE_URL}"}}`
