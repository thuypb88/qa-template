# automation/

> **Created:** 2026-10-16 08:34 · **Updated:** 2026-10-16 10:54 (UTC+7)

One folder per pack. Every test carries its TC ID in its name, so `scripts/run_tests.py` binds results to the test
cases whatever the framework ([tc_binding.py](tc_binding.py)).

| Folder | Pack | Framework | Entry | Environment |
|---|---|---|---|---|
| `ui/` | UI | Playwright (TypeScript), created on the first spec | `npx playwright test` | `UI_BASE_URL` |
| `api/` | API | pytest + [api_client.py](api/api_client.py) (urllib; swap in httpx / requests if you like); optional schemathesis for contract fuzzing | `python3 -m pytest api` | `API_BASE_URL`, `API_TOKEN_<ROLE>` |
| `etl/` | ETL | pytest + [reconcile.py](etl/reconcile.py) over any DB-API connection; optional Great Expectations / dbt tests | `python3 -m pytest etl` | `ETL_SOURCE_DSN`, `ETL_TARGET_DSN`, `ETL_DRIVER`, `ETL_RUN_JOB` |
| `sql/` | SQL | pytest + [sql_verify.py](sql/sql_verify.py) calling verification procedures / scripts (rows `tc_id, result, detail`) over any DB-API connection; tSQLt / utPLSQL / pgTAP if the team has them | `python3 -m pytest sql` | `SQL_DSN`, `SQL_DRIVER`, `SQL_DIALECT` |

- **Data-driven first.** [api/test_example_api.py](api/test_example_api.py) and
  [etl/test_example_etl.py](etl/test_example_etl.py) and [sql/test_example_sql.py](sql/test_example_sql.py) run every Auto TC of a module straight from its `api` / `etl` / `sql`
  block. Copy one per module and set `MODULE`. Write a dedicated test only for TCs the block can't express.
- **Fixtures** live next to the tests: `api/fixtures/*.json`, `etl/fixtures/<ETL-FX-…>.sql`, `etl/sql/{src,tgt}/`, `sql/verify/*.sql` (verification scripts; verification procedures are kept as `sql/verify/<name>.<dialect>.sql` and deployed to schema `qa`); SQL data scripts live with the TCs in `test-design/it/MOD-<id>-<slug>/3-test-cases/sql/data/`. Raw run output goes to `runs/<key>/` (not in git).
- **Secrets** come from the environment or a git-ignored `.env`; never from the repo.
- **Runners** are declared in `project.json › runners.<pack>`; `python3 scripts/run_tests.py <target> --plan` shows
  what would run.
- **Oracle stays at the surface (R2).** A hook or mock may *set up* state; the assertion reads the screen, the
  response or the target data — never a log line.

`auto-decide` decides which TCs go here (per TC: `automation`, `automation_note`); `run-tests` runs them.
