"""SQL pack fixtures: one DB-API connection to the test database, the dialect, and a data-set loader.

Environment (never commit values):
    SQL_DSN       "sqlite:///path.db" works out of the box; any other DSN needs SQL_DRIVER=<module>
                  (pyodbc, oracledb, psycopg, pymysql, …) installed, and is passed to <module>.connect(SQL_DSN)
    SQL_DIALECT   sqlserver | oracle | postgres | mysql | sqlite (default: project.json › sql.dialect)
"""
from __future__ import annotations

import importlib
import os
import sqlite3
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from tc_binding import qc  # noqa: E402
from sql_verify import DIALECTS, run_script  # noqa: E402


def connect(dsn: str):
    if dsn.startswith("sqlite:///"):
        return sqlite3.connect(dsn[len("sqlite:///"):])
    driver = os.environ.get("SQL_DRIVER")
    if not driver:
        pytest.skip("SQL_DRIVER not set for a non-sqlite DSN")
    return importlib.import_module(driver).connect(dsn)


@pytest.fixture(scope="session")
def db():
    dsn = os.environ.get("SQL_DSN")
    if not dsn:
        pytest.skip("SQL_DSN not set")
    c = connect(dsn)
    yield c
    c.close()


@pytest.fixture(scope="session")
def dialect():
    d = os.environ.get("SQL_DIALECT") or qc.load_project().get("sql", {}).get("dialect")
    if d not in DIALECTS:
        pytest.skip(f"SQL dialect {d!r} not set or unknown (SQL_DIALECT or project.json › sql.dialect: {DIALECTS})")
    return d


@pytest.fixture(scope="session")
def load_data(db):
    """load_data(folder, "3-test-cases/sql/data/S1-DS-01.sql") runs a data script once per session; the matching
    *-cleanup.sql (if any) runs at the end of the session."""
    done: dict[Path, Path | None] = {}

    def load(folder: Path, rel: str, cleanup: str | None = None) -> None:
        f = folder / rel
        if f in done:
            return
        if not f.is_file():
            pytest.skip(f"data script {rel} missing in {folder.name}")
        run_script(db, f)
        c = folder / cleanup if cleanup else f.with_name(f.stem + "-cleanup.sql")
        done[f] = c if c.is_file() else None

    yield load
    for c in done.values():
        if c:
            run_script(db, c)
