"""SQL pack: run data scripts and verifications over any DB-API 2.0 connection, in the project's dialect.

Contract (packs/sql/tc-fields.md): a verification — stored procedure / function (`verify: proc`) or SQL script
(`verify: script`) — returns rows (tc_id, result, detail) with result PASS | FAIL. Calls per dialect
(packs/sql/dialects.md): sqlserver `EXEC qa.v`, mysql `CALL qa.v()`, postgres `SELECT … FROM qa.v()`, oracle
`SELECT … FROM TABLE(qa.v())`. Scripts: plain statements ending with `;` at the end of a line; the last one returns
the rows; run inside a transaction that is rolled back. Standard library only.
"""
from __future__ import annotations

import re
import sqlite3
from pathlib import Path

DIALECTS = ("sqlserver", "oracle", "postgres", "mysql", "sqlite")


def statements(text: str) -> list[str]:
    """Split a script on ';' at the end of a line; drop comment-only chunks. No procedural blocks (use a proc)."""
    out = []
    for chunk in re.split(r";[ \t]*(?:\r?\n|$)", text):
        body = "\n".join(line for line in chunk.splitlines() if not line.strip().startswith("--")).strip()
        if body:
            out.append(body)
    return out


def run_script(conn, path: Path, commit: bool = True) -> list[tuple]:
    """Execute every statement of a script; return the rows of the last one (empty if it returns none)."""
    cur, rows = conn.cursor(), []
    for s in statements(path.read_text(encoding="utf-8")):
        cur.execute(s)
        rows = cur.fetchall() if cur.description else []
    if commit:
        conn.commit()
    return [tuple(r) for r in rows]


def call_sql(dialect: str, name: str) -> str:
    if not re.fullmatch(r"[A-Za-z_][\w$#]*(\.[A-Za-z_][\w$#]*)?", name):
        raise ValueError(f"verification name {name!r} is not a plain [schema.]object name")
    return {"sqlserver": f"EXEC {name}",
            "mysql": f"CALL {name}()",
            "postgres": f"SELECT tc_id, result, detail FROM {name}()",
            "oracle": f"SELECT tc_id, result, detail FROM TABLE({name}())"}[dialect]


def call_verification(conn, dialect: str, name: str) -> list[tuple]:
    """Call a verification procedure / function; return its (tc_id, result, detail) rows."""
    if dialect == "sqlite":
        raise ValueError("sqlite has no stored procedures: use verify = script")
    cur = conn.cursor()
    cur.execute(call_sql(dialect, name))
    rows = cur.fetchall() if cur.description else []
    while not rows and getattr(cur, "nextset", None) and cur.nextset():   # T-SQL / MySQL: skip empty result sets
        rows = cur.fetchall() if cur.description else []
    conn.rollback()
    return [tuple(r) for r in rows]


def verify_script(conn, path: Path) -> list[tuple]:
    """Run a verification script and roll it back."""
    try:
        return run_script(conn, path, commit=False)
    finally:
        conn.rollback()


def verdict(rows: list[tuple], tc_id: str) -> tuple[str, str]:
    """('PASS' | 'FAIL' | 'NO RESULT', detail) for one TC from a verification's rows."""
    mine = [r for r in rows if str(r[0]).strip() == tc_id]
    if not mine:
        return "NO RESULT", f"no row for {tc_id} in the verification output ({len(rows)} row(s))"
    bad = [r for r in mine if str(r[1]).strip().upper() != "PASS"]
    return ("FAIL", "; ".join(str(r[2]) for r in bad)) if bad else ("PASS", str(mine[0][2] or ""))


def is_sqlite(conn) -> bool:
    return isinstance(conn, sqlite3.Connection)
