"""Data-driven runner for SQL test cases: one pytest test per Auto TC of a SQL module, driven by its `sql` block.

Copy per module (test_<id>_sql.py) and set MODULE. The data set loads once per session, each verification
(procedure or script) is called once and its (tc_id, result, detail) rows are mapped to the TCs; a TC with no row
fails as NO RESULT, never passes.
"""
from pathlib import Path

import pytest

from tc_binding import qc, tc_params
from sql_verify import call_verification, verdict, verify_script

MODULE = None  # e.g. "S1"; None skips the file (the template ships no module)
ROOT = Path(__file__).resolve().parents[2]
_cache: dict[str, list[tuple]] = {}


def _folder() -> Path:
    return qc.resolve(qc.load_project(), MODULE)[0]["folder"]


@pytest.mark.parametrize("tc", tc_params(MODULE, pack="sql") if MODULE else [])
def test_sql_tc(tc, db, dialect, load_data):
    b = tc["sql"]
    if b["verify"] == "manual":
        pytest.skip("verify: manual")
    if b.get("data_script"):
        load_data(_folder(), b["data_script"], b.get("cleanup_script"))
    ref = b.get("verify_ref")
    assert ref, f"{tc['tc_id']}: sql.verify_ref missing"
    if ref not in _cache:
        _cache[ref] = (verify_script(db, ROOT / ref) if b["verify"] == "script"
                       else call_verification(db, dialect, ref))
    result, detail = verdict(_cache[ref], tc["tc_id"])
    assert result == "PASS", f"{result}: {detail}"
