#!/usr/bin/env python3
"""Bring a project up to a newer template version, or start a new project from the template.

    python3 scripts/workspace/template_sync.py --from ../QA-template                 # show what would change (dry run)
    python3 scripts/workspace/template_sync.py --from ../QA-template --apply         # copy it
    python3 ../QA-template/scripts/workspace/template_sync.py --new ../ACME-QA       # new project folder from the template

template-manifest.json lists the files the template owns (overwritten on --apply) and the seeded files (copied only
when missing, then owned by the project), and the paths a template version renamed (`moved`, applied first with
git mv). Nothing else is touched: project.json, project/, test-design/, sources/, automation tests and data
stay the project's. After --apply: run
scripts/workspace/sync_agents.py and scripts/init_project.py, read CHANGELOG.md for migration notes, and commit
("template vX.Y.Z"). Standard library only.
"""
from __future__ import annotations

import argparse
import fnmatch
import filecmp
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parents[2]
HOOKS = "scripts/workspace/git-hooks"


def files_matching(root: Path, patterns: list[str]) -> list[Path]:
    out = set()
    for pat in patterns:
        if pat.endswith("/**"):
            base = root / pat[:-3]
            out |= {f for f in base.rglob("*") if f.is_file() and "__pycache__" not in f.parts} if base.is_dir() else set()
        else:
            out |= {f for f in root.glob(pat) if f.is_file()}
    return sorted(out)


def plan(tpl: Path, dst: Path) -> list[tuple[str, Path, Path]]:
    man = json.loads((tpl / "template-manifest.json").read_text(encoding="utf-8"))
    out = []
    for f in files_matching(tpl, man["template_owned"]):
        g = dst / f.relative_to(tpl)
        if not g.is_file():
            out.append(("add", f, g))
        elif not filecmp.cmp(f, g, shallow=False):
            out.append(("update", f, g))
    for f in files_matching(tpl, man["seeded"]):
        g = dst / f.relative_to(tpl)
        if not g.exists():
            out.append(("seed", f, g))
    owned_now = {f.relative_to(tpl).as_posix() for f in files_matching(tpl, man["template_owned"])}
    for g in files_matching(dst, [p for p in man["template_owned"] if p.endswith("/**")]):
        rel = g.relative_to(dst).as_posix()
        if rel not in owned_now and not fnmatch.fnmatch(rel, "*.pyc"):
            out.append(("stale", g, g))
    return out


def moves(tpl: Path, dst: Path) -> list[tuple[str, str]]:
    """The manifest's renamed paths to apply to the project, in order: old exists and new does not, counting the
    earlier moves in the list (a path moved away is gone, a path moved in is there)."""
    man = json.loads((tpl / "template-manifest.json").read_text(encoding="utf-8"))
    done: list[tuple[str, str]] = []

    def under(path: str, base: str) -> bool:
        return path == base or path.startswith(base + "/")

    def exists(path: str) -> bool:
        for old, new in reversed(done):
            if under(path, new):
                path = old + path[len(new):]
            elif under(path, old):
                return False
        return (dst / path).exists()

    for old, new in man.get("moved", []):
        if exists(old) and not exists(new):
            done.append((old, new))
    return done


def apply_moves(dst: Path, todo: list[tuple[str, str]]) -> None:
    in_git = (dst / ".git").exists()
    for old, new in todo:
        (dst / new).parent.mkdir(parents=True, exist_ok=True)
        if not in_git or subprocess.run(["git", "mv", old, new], cwd=dst, capture_output=True).returncode:
            shutil.move(str(dst / old), str(dst / new))


def old_path_refs(tpl: Path, dst: Path) -> list[str]:
    """Project-owned text files that still name a moved path."""
    man = json.loads((tpl / "template-manifest.json").read_text(encoding="utf-8"))
    olds = re.compile("|".join(r"(?<![\w.-])" + re.escape(o + ("/" if not Path(o).suffix else ""))
                               for o, _ in man.get("moved", [])))
    owned = {f.relative_to(tpl).as_posix() for f in files_matching(tpl, man["template_owned"])}
    hits = []
    for f in sorted(dst.rglob("*")):
        rel = f.relative_to(dst).as_posix()
        if (f.is_file() and f.suffix in (".md", ".json", ".py", ".txt") and rel not in owned
                and not rel.startswith((".git/", ".agents/", ".github/skills/", "sources/"))
                and rel != "template-manifest.json"):
            text = f.read_text(encoding="utf-8", errors="ignore")
            if olds.search(text):
                hits.append(rel)
    return hits


def version(root: Path) -> str:
    f = root / "TEMPLATE_VERSION"
    return f.read_text(encoding="utf-8").strip() if f.is_file() else "none"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--from", dest="tpl", type=Path, default=HERE, help="the template repo (default: this one)")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--new", type=Path, help="create a new project folder from the template")
    a = ap.parse_args()
    tpl = a.tpl.resolve()
    if a.new:
        dst = a.new.resolve()
        if dst.exists() and any(dst.iterdir()):
            sys.exit(f"{dst} exists and is not empty")
        dst.mkdir(parents=True, exist_ok=True)
        for kind, f, g in plan(tpl, dst):
            if kind != "stale":
                g.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, g)
        for d in ("sources/client", "sources/requirements", "sources/api", "sources/etl", "sources/sql", "sources/testing",
                  "sources/parsed", "test-design/it", "test-design/st", "project/change-impact"):
            (dst / d).mkdir(parents=True, exist_ok=True)
        pj = json.loads((dst / "project.json").read_text(encoding="utf-8"))
        pj.setdefault("guard", {})["template_dev"] = False
        pj.setdefault("git", {})["backup_dir"] = None  # the project's own ../<CODE>-backups
        pj["template_version"] = version(tpl)
        (dst / "project.json").write_text(json.dumps(pj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        subprocess.run(["git", "init", "-q", "-b", "main"], cwd=dst)
        subprocess.run(["git", "config", "core.hooksPath", HOOKS], cwd=dst)
        print(f"✓ new project at {dst} (template {version(tpl)}). Next: put the client documents in sources/, open "
              "Claude Code there and run /plan-setup.")
        return 0
    dst = Path.cwd().resolve() if (Path.cwd() / "project.json").is_file() else HERE
    if dst == tpl:
        sys.exit("Run this from the project folder, with --from <template>.")
    print(f"template {version(tpl)} → project {dst.name} (now {version(dst)})")
    todo = moves(tpl, dst)
    for old, new in todo:
        print(f"  move    {old} → {new}")
    if todo and a.apply:
        apply_moves(dst, todo)
    items = plan(tpl, dst)
    if todo and not a.apply:  # the plan is computed against the old layout until the moves run
        print("  (after the moves, files at the new paths are compared again on --apply)")
    for kind, f, g in items:
        print(f"  {kind:<7} {g.relative_to(dst)}" + ("  (not in the template any more: delete by hand if unused)"
                                                     if kind == "stale" else ""))
    if not items and not todo:
        print("  up to date")
        return 0
    if not a.apply:
        print("Dry run. Re-run with --apply to copy.")
        return 0
    for kind, f, g in items:
        if kind in ("add", "update", "seed"):
            g.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, g)
    pj_path = dst / "project.json"
    pj = json.loads(pj_path.read_text(encoding="utf-8"))
    pj["template_version"] = version(tpl)
    man = json.loads((tpl / "template-manifest.json").read_text(encoding="utf-8"))
    for old, new in man.get("moved", []):  # a level folder that moved (or was never made): use its new place
        for lv in (pj.get("levels") or {}).values():
            if lv.get("folder") == old and not (dst / old).exists():
                lv["folder"] = new
    pj_path.write_text(json.dumps(pj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if (dst / ".git").exists():  # hooks that moved with the template (1.10.0: scripts/git-hooks → scripts/workspace/)
        hooks = subprocess.run(["git", "config", "core.hooksPath"], cwd=dst, capture_output=True, text=True).stdout.strip()
        if hooks != HOOKS and (not hooks or not (dst / hooks).is_dir()):
            subprocess.run(["git", "config", "core.hooksPath", HOOKS], cwd=dst)
            print(f"  git     core.hooksPath → {HOOKS}")
    subprocess.run([sys.executable, str(dst / "scripts/workspace/sync_agents.py")], cwd=dst)
    refs = old_path_refs(tpl, dst)
    if refs:
        print("! these project files still name a moved path (see CHANGELOG.md migration notes):")
        for r in refs:
            print(f"    {r}")
    print(f"✓ applied. Read {tpl / 'CHANGELOG.md'} for migration notes, run python3 scripts/init_project.py, "
          f"then commit 'template v{version(tpl)}'.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
