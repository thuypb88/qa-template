#!/usr/bin/env python3
"""Back up the workspace's git history to a local folder. Nothing is sent off this machine.

Run by the post-commit hook (scripts/workspace/git-hooks/post-commit) after every commit, or by hand.
Each run:
  1. tags every test case suite version found in HEAD (tc/<folder>/v<version>, e.g.
     tc/MOD-E4-review-workflow/v0.3), so each version can be found and restored;
  2. updates a bare mirror repository <backup dir>/<CODE>.git with every branch and tag. A branch
     whose history was rewritten (amend, reset) keeps its old tip under refs/rewritten/, so no
     version is lost;
  3. writes a full single-file bundle <backup dir>/bundles/<CODE>_<stamp>_<sha>.bundle, once a day
     (or on every run with --bundle), and verifies it.
Backups are never deleted by this script. Each run is logged in <backup dir>/backup-log.txt.

<CODE> is project.json › project.code. The backup dir is project.json › git.backup_dir, else
../<CODE>-backups/ next to the project; $QA_BACKUP_DIR overrides both (e.g. another disk).

Usage:
    python3 scripts/workspace/backup.py             # tags + mirror + today's bundle if missing
    python3 scripts/workspace/backup.py --bundle    # also force a new bundle now
    python3 scripts/workspace/backup.py --list      # show the backups and version tags
    python3 scripts/workspace/backup.py --hook      # quiet; never fails (used by the post-commit hook)

Restore (examples):
    git clone ../<CODE>-backups/<CODE>.git <CODE>-restored          # from the mirror
    git clone ../<CODE>-backups/bundles/<CODE>_<stamp>_<sha>.bundle <CODE>-restored
    git show tc/<folder>/v0.3:test-design/it/<folder>/3-test-cases/test-cases.json
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _project() -> dict:
    try:
        return json.loads((ROOT / "project.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


_P = _project()
_CODE = (_P.get("project") or {}).get("code") or ""
CODE = re.sub(r"[^A-Za-z0-9_-]", "", ROOT.name if _CODE in ("", "CHANGE-ME") else _CODE) or "workspace"
LEVELS = tuple(f"{v.get('folder')}/" for v in (_P.get("levels") or {}).values() if v.get("folder")) or ("test-design/it/",
                                                                                                    "test-design/st/")
_DIR = os.environ.get("QA_BACKUP_DIR") or (_P.get("git") or {}).get("backup_dir") or f"../{CODE}-backups"
BACKUP_DIR = (Path(_DIR) if Path(_DIR).is_absolute() else ROOT / _DIR).expanduser().resolve()
MIRROR = BACKUP_DIR / f"{CODE}.git"
BUNDLES = BACKUP_DIR / "bundles"
LOG = BACKUP_DIR / "backup-log.txt"


def git(*args: str, cwd: Path = ROOT, check: bool = True) -> str:
    result = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True)
    if check and result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)}: {result.stderr.strip()}")
    return result.stdout.strip()


def tag_versions() -> list[str]:
    """Create tc/<folder>/v<version> for each suite version in HEAD that has no tag yet."""
    existing = set(git("tag", "--list", "tc/*").splitlines())
    created = []
    for path in git("ls-tree", "-r", "--name-only", "HEAD").splitlines():
        if not path.endswith("3-test-cases/test-cases.json") or not path.startswith(LEVELS):
            continue  # only real suites in the level folders (not template-dev/examples/ or fixtures)
        try:
            version = json.loads(git("show", f"HEAD:{path}")).get("version")
        except (json.JSONDecodeError, RuntimeError):
            continue
        parts = Path(path).parts
        folder = parts[-3]  # <level folder>/[<module>/]3-test-cases/test-cases.json → module folder or ST folder
        folder = folder.upper() if folder.lower() in ("it", "st") else folder  # = qa_config.suite_name
        name = f"tc/{folder}/v{version}"
        if version and name not in existing:
            git("tag", "-a", name, "-m", f"{folder} test cases v{version}")
            created.append(name)
    return created


def update_mirror() -> list[str]:
    """Push every branch and tag to the bare mirror; keep rewritten branch tips."""
    if not MIRROR.is_dir():
        MIRROR.parent.mkdir(parents=True, exist_ok=True)
        git("init", "--bare", "-q", str(MIRROR))
        git("config", "gc.pruneExpire", "never", cwd=MIRROR)
        git("config", "core.logAllRefUpdates", "always", cwd=MIRROR)
    kept = []
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    for line in git("for-each-ref", "--format=%(refname:short) %(objectname)", "refs/heads").splitlines():
        branch, new = line.split()
        old = git("rev-parse", "--verify", "-q", f"refs/heads/{branch}", cwd=MIRROR, check=False)
        # A fast-forward keeps the old tip in history; anything else (amend, reset) would drop it.
        fast_forward = subprocess.run(["git", "merge-base", "--is-ancestor", old, new], cwd=ROOT,
                                      capture_output=True).returncode == 0 if old else True
        if old and old != new and not fast_forward:
            ref = f"refs/rewritten/{branch}/{stamp}"
            git("update-ref", ref, old, cwd=MIRROR)
            kept.append(ref)
    git("push", "-q", "--force", str(MIRROR), "refs/heads/*:refs/heads/*")
    git("push", "-q", str(MIRROR), "refs/tags/*:refs/tags/*")
    return kept


def write_bundle(force: bool) -> Path | None:
    today = datetime.now().strftime("%Y%m%d")
    if not force and any(BUNDLES.glob(f"{CODE}_{today}-*.bundle")):
        return None
    BUNDLES.mkdir(parents=True, exist_ok=True)
    sha = git("rev-parse", "--short", "HEAD")
    path = BUNDLES / f"{CODE}_{datetime.now():%Y%m%d-%H%M}_{sha}.bundle"
    git("bundle", "create", "-q", str(path), "--all")
    git("bundle", "verify", "-q", str(path))
    return path


def list_backups() -> None:
    print(f"Backup dir: {BACKUP_DIR}")
    if MIRROR.is_dir():
        print(f"Mirror: {MIRROR} (HEAD of main: {git('rev-parse', '--short', 'main', cwd=MIRROR, check=False) or '-'})")
        rewritten = git("for-each-ref", "--format=%(refname)", "refs/rewritten", cwd=MIRROR, check=False)
        if rewritten:
            print("Rewritten branch tips kept:\n  " + rewritten.replace("\n", "\n  "))
    for b in sorted(BUNDLES.glob("*.bundle")) if BUNDLES.is_dir() else []:
        print(f"Bundle: {b.name}  {b.stat().st_size / 1e6:.1f} MB")
    tags = git("tag", "--list", "tc/*", "--sort=refname")
    print("Version tags:\n  " + (tags.replace("\n", "\n  ") if tags else "(none)"))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--bundle", action="store_true", help="write a new bundle even if one exists today")
    parser.add_argument("--list", action="store_true", help="list backups and version tags, then stop")
    parser.add_argument("--hook", action="store_true", help="quiet mode for the post-commit hook; never fails")
    args = parser.parse_args(argv)
    if args.list:
        list_backups()
        return 0
    try:
        if not args.hook and git("status", "--porcelain"):
            print("Warning: uncommitted changes are not in the backup. Commit them first.", file=sys.stderr)
        tags = tag_versions()
        kept = update_mirror()
        bundle = write_bundle(args.bundle)
    except Exception as exc:  # the hook must never block a commit
        print(f"backup: FAILED ({exc}). Run python3 scripts/workspace/backup.py by hand.", file=sys.stderr)
        return 0 if args.hook else 1
    head = git("log", "-1", "--format=%h %s")
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as log:
        log.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {head}  tags+{len(tags)}  "
                  f"rewritten-kept {len(kept)}  bundle {bundle.name if bundle else '-'}\n")
    lines = [f"backup: mirror updated ({MIRROR})"]
    lines += [f"backup: tagged {t}" for t in tags]
    lines += [f"backup: kept rewritten tip {r}" for r in kept]
    if bundle:
        lines.append(f"backup: bundle {bundle} ({bundle.stat().st_size / 1e6:.1f} MB)")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())
