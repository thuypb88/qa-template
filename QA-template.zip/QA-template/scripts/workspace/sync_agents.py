#!/usr/bin/env python3
"""Keep the other agents' copies in sync with the Claude Code source (CLAUDE.md, .claude/skills/).

    python3 scripts/workspace/sync_agents.py           # write every mirror listed in project.json › agents.mirrors
    python3 scripts/workspace/sync_agents.py --check   # exit 1 and list the differences; write nothing

| Mirror    | Instructions (from CLAUDE.md)       | Skills (from .claude/skills/<name>/) | Read by |
|-----------|-------------------------------------|--------------------------------------|---------|
| `codex`   | AGENTS.md                           | .agents/skills/<name>/               | Codex, any AGENTS.md agent |
| `copilot` | .github/copilot-instructions.md     | .github/skills/<name>/               | GitHub Copilot: cloud agent, CLI, VS Code and Visual Studio agent mode |

Default mirrors: ["codex", "copilot"]. Skill folders that exist only in a mirror (no Claude source) are kept. The
skills use the agentskills.io SKILL.md format (name = folder, description ≤ 1024 chars), which all three agents read,
so the copies are byte-identical; only the instruction files get an agent-specific preface. Path-specific Copilot
instructions (.github/instructions/*.instructions.md) are template-owned files, not generated.
Copilot also scans .claude/skills and .agents/skills: if it lists a skill twice, drop a mirror you don't need from
project.json › agents.mirrors. Standard library only.
"""
from __future__ import annotations

import filecmp
import json
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / ".claude/skills"

CODEX_NOTE = ("<!-- Generated from CLAUDE.md by scripts/workspace/sync_agents.py — do not edit; edit CLAUDE.md and re-run. "
              "Codex: read the skills in .agents/skills/<name>/SKILL.md when a task matches their description. -->\n\n")
COPILOT_NOTE = """<!-- Generated from CLAUDE.md by scripts/workspace/sync_agents.py — do not edit; edit CLAUDE.md and re-run. -->

> **GitHub Copilot — read this first.** These are the same rules and skills the other agents on this project use.
> - **Skills** are in `.github/skills/<name>/SKILL.md` (the table under "The pipeline" names them). Load the one whose
>   description matches the task; the user may also ask for one by name ("use the design-analysis skill for E4").
> - **No Claude Code hooks run for you** (`.claude/settings.json`). So: never edit a file the guard lists as generated
>   (`sources/`, every `.xlsx` under the level folders, `test-design/it/INDEX.md`, `*/sources.json`, `0-scope.md` outside its
>   MANUAL block, `AGENTS.md`, `.agents/`, `.github/skills/`, `.github/copilot-instructions.md`) or template-owned
>   (`template-manifest.json`); and **before you finish any change run `python3 scripts/workspace/guard.py check`** and fix what
>   it reports. The git pre-commit hook runs the same checks.
> - Wherever the text below says "Claude", read "the agent". Project facts are in `project.json` and `project/`.

"""


def rebase_links(text: str) -> str:
    """Relative Markdown links written for the repo root, rewritten for a file in .github/."""
    def fix(m):
        url = m.group(1)
        if re.match(r"^(https?:|mailto:|#|\.\./|/)", url):
            return m.group(0)
        url = "../" + url
        return "](" + (url[len("../.github/"):] if url.startswith("../.github/") else url) + ")"
    return re.sub(r"\]\(([^)\s]+)\)", fix, text)


def mirrors() -> list[str]:
    try:
        p = json.loads((ROOT / "project.json").read_text(encoding="utf-8"))
        return list((p.get("agents") or {}).get("mirrors", ["codex", "copilot"]))
    except (OSError, json.JSONDecodeError):
        return ["codex", "copilot"]


def targets() -> list[tuple[str, Path, Path, str]]:
    """(mirror, instruction file, skills dir, instruction text)."""
    claude = (ROOT / "CLAUDE.md").read_text(encoding="utf-8")
    out = []
    if "codex" in mirrors():
        out.append(("codex", ROOT / "AGENTS.md", ROOT / ".agents/skills",
                    CODEX_NOTE + claude.replace(".claude/skills/", ".agents/skills/")))
    if "copilot" in mirrors():
        out.append(("copilot", ROOT / ".github/copilot-instructions.md", ROOT / ".github/skills",
                    COPILOT_NOTE + rebase_links(claude.replace(".claude/skills/", ".github/skills/"))))
    return out


def skill_dirs() -> list[Path]:
    return sorted(p for p in SRC.iterdir() if p.is_dir()) if SRC.is_dir() else []


def stale_dirs(dst: Path) -> list[Path]:
    """Mirror skill folders whose source skill is gone (renamed or removed)."""
    names = {d.name for d in skill_dirs()}
    return sorted(p for p in dst.iterdir() if p.is_dir() and p.name not in names
                  and (p / "SKILL.md").is_file()) if dst.is_dir() else []


def diffs() -> list[str]:
    out = []
    for _, inst, dst, text in targets():
        out += [p.relative_to(ROOT).as_posix() + "/ (stale skill)" for p in stale_dirs(dst)]
        if not inst.is_file() or inst.read_text(encoding="utf-8") != text:
            out.append(inst.relative_to(ROOT).as_posix())
        if (SRC / "README.md").is_file() and not ((dst / "README.md").is_file()
                                                  and filecmp.cmp(SRC / "README.md", dst / "README.md", shallow=False)):
            out.append((dst / "README.md").relative_to(ROOT).as_posix())
        for d in skill_dirs():
            for f in sorted(x for x in d.rglob("*") if x.is_file()):
                g = dst / f.relative_to(SRC)
                if not g.is_file() or not filecmp.cmp(f, g, shallow=False):
                    out.append(g.relative_to(ROOT).as_posix())
            if (dst / d.name).is_dir():
                for g in (dst / d.name).rglob("*"):
                    if g.is_file() and not (SRC / g.relative_to(dst)).is_file():
                        out.append(g.relative_to(ROOT).as_posix() + " (extra)")
    return out


def main() -> int:
    if "--check" in sys.argv:
        d = diffs()
        for x in d:
            print(f"  differs: {x}")
        return 1 if d else 0
    for name, inst, dst, text in targets():
        inst.parent.mkdir(parents=True, exist_ok=True)
        inst.write_text(text, encoding="utf-8")
        for p in stale_dirs(dst):
            shutil.rmtree(p)
            print(f"sync_agents: {name}: removed stale {p.relative_to(ROOT)}/")
        for d in skill_dirs():
            target = dst / d.name
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(d, target, ignore=shutil.ignore_patterns("__pycache__"))
        if (SRC / "README.md").is_file():
            shutil.copy2(SRC / "README.md", dst / "README.md")
        print(f"sync_agents: {name}: {inst.relative_to(ROOT)} + {len(skill_dirs())} skill(s) → "
              f"{dst.relative_to(ROOT)}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
