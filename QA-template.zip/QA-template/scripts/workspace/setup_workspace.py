#!/usr/bin/env python3
"""Set up everything a QA workspace (the template or a project) needs on this machine, in one go. Safe to re-run.

    python3 scripts/workspace/setup_workspace.py                     # set up this workspace
    python3 scripts/workspace/setup_workspace.py --check             # report what is missing; change nothing
    python3 scripts/workspace/setup_workspace.py --packs all         # every pack, not only the ones in project.json
    python3 scripts/workspace/setup_workspace.py --new ../ACME-QA    # (template only) new project, then set it up
    python3 scripts/workspace/setup_workspace.py --selftest          # (template only) then run the self-test
    pwsh ./setup.ps1 [-InstallPrereqs] [-Check] …                    # Windows / PowerShell: the same, see setup.ps1

Steps:
  1. prerequisites   Python >= 3.10, git; optional poppler (pdftotext, for PDF sources) and Node (UI pack)
  2. Python env      .venv/ with openpyxl (Excel export, .xlsx sources), PyYAML (YAML OpenAPI specs), pytest (API /
                     ETL / SQL runs) and the DB driver of project.json › sql.dialect (or --driver)
  3. Playwright      UI pack only, when Node is installed: npm install (or the scaffold from automation/ui/README.md
                     with --scaffold-ui) and the Chromium browser
  4. workspace       git init + core.hooksPath; a project with modules: init_project.py (folders, agent mirrors,
                     source baseline); the template: sync_agents.py
  5. Claude Code     .claude/settings.local.json (per machine, not in git) puts .venv/bin first on PATH, so the hooks,
                     the tools and run_tests.py use the venv also when Claude Code is started from VS Code
  6. verify          imports in the venv, project.json valid, guard.py check, and the runner env vars still unset

Pack selection: --packs ui,api,… or all; default: the packs of project.json › modules, or api,etl,sql while there are
none yet (before /plan-setup). Nothing is installed system-wide: missing system tools are reported with the command
to install them. Standard library only.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HOOKS = "scripts/workspace/git-hooks"
PACKS = ("ui", "api", "etl", "sql")
BASE_PIP = {"openpyxl": "openpyxl", "yaml": "pyyaml"}  # import name → pip name
PYTEST_PIP = {"pytest": "pytest"}
DRIVERS = {  # project.json › sql.dialect → (import name, pip name, system note)
    "sqlserver": ("pyodbc", "pyodbc", "also needs unixODBC and the Microsoft ODBC Driver 18 (msodbcsql18)"),
    "oracle": ("oracledb", "oracledb", ""),
    "postgres": ("psycopg", "psycopg[binary]", ""),
    "mysql": ("pymysql", "pymysql", ""),
    "sqlite": ("sqlite3", "", ""),
}
RESULTS: list[tuple[str, str, str]] = []  # (mark, step, detail): ✓ done / ok, ! warning, ✗ error, - skipped


def note(mark: str, step: str, detail: str = "") -> None:
    RESULTS.append((mark, step, detail))
    print(f"  {mark} {step}" + (f" — {detail}" if detail else ""), flush=True)


def run(cmd: list[str], cwd: Path = ROOT, quiet: bool = True, env: dict | None = None) -> subprocess.CompletedProcess:
    return subprocess.run([str(c) for c in cmd], cwd=cwd, text=True, capture_output=quiet,
                          env={**os.environ, **(env or {})})


def tail(r: subprocess.CompletedProcess, n: int = 5) -> str:
    return " | ".join(((r.stdout or "") + (r.stderr or "")).strip().splitlines()[-n:])


def venv_python(venv: Path) -> Path:
    return venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def load_project() -> dict:
    try:
        return json.loads((ROOT / "project.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        sys.exit(f"✗ project.json: {e}")


def pick_packs(p: dict, arg: str | None) -> list[str]:
    if arg:
        packs = list(PACKS) if arg == "all" else [x.strip() for x in arg.split(",") if x.strip()]
        bad = [x for x in packs if x not in PACKS]
        if bad:
            sys.exit(f"✗ unknown pack(s) {', '.join(bad)}; choose from {', '.join(PACKS)} or all")
        return packs
    used = sorted({m.get("pack", "ui") for m in p.get("modules", [])}, key=PACKS.index)
    return used or ["api", "etl", "sql"]


def has_module(py: Path, name: str) -> bool:
    return run([py, "-c", f"import {name}"]).returncode == 0


# 1 ─ prerequisites ───────────────────────────────────────────────────────────────────────────────────────────────

def prerequisites(packs: list[str]) -> bool:
    print("1. prerequisites")
    ok = True
    if sys.version_info < (3, 10):
        note("✗", "Python", f"{sys.version.split()[0]} found, 3.10 or newer needed")
        ok = False
    else:
        note("✓", "Python", sys.version.split()[0])
    if shutil.which("git"):
        note("✓", "git", run(["git", "--version"]).stdout.strip().removeprefix("git version "))
    else:
        note("✗", "git", "not found: sudo apt install git (macOS: xcode-select --install)")
        ok = False
    if shutil.which("pdftotext"):
        note("✓", "pdftotext", "PDF sources can be extracted")
    else:
        note("!", "pdftotext", "PDF sources can't be extracted: sudo apt install poppler-utils (macOS: brew install poppler)")
    if "ui" in packs:
        if shutil.which("node") and shutil.which("npx"):
            note("✓", "Node", run(["node", "--version"]).stdout.strip())
        else:
            note("!", "Node", "UI pack needs Node 18+ for Playwright: install it (e.g. nvm install --lts), then re-run")
    return ok


# 2 ─ Python env ──────────────────────────────────────────────────────────────────────────────────────────────────

def wanted_pip(p: dict, packs: list[str], driver: str | None) -> tuple[dict[str, str], list[str]]:
    want = dict(BASE_PIP)
    notes = []
    if any(x in packs for x in ("api", "etl", "sql")):
        want.update(PYTEST_PIP)
    dialect = driver or ((p.get("sql") or {}).get("dialect") if "sql" in packs else "")
    if dialect:
        if dialect not in DRIVERS:
            sys.exit(f"✗ unknown driver / dialect {dialect!r}; choose from {', '.join(DRIVERS)}")
        imp, pip, sysnote = DRIVERS[dialect]
        if pip:
            want[imp] = pip
        if sysnote:
            notes.append(f"{pip}: {sysnote}")
    return want, notes


def python_env(p: dict, packs: list[str], args) -> Path:
    print("2. Python env")
    want, notes = wanted_pip(p, packs, args.driver)
    if args.no_venv:
        py = Path(sys.executable)
        note("-", "venv", f"--no-venv: installing into {py}")
    else:
        venv = (ROOT / args.venv).resolve()
        py = venv_python(venv)
        if py.is_file():
            note("✓", "venv", str(venv.relative_to(ROOT)) if venv.is_relative_to(ROOT) else str(venv))
        elif args.check:
            note("!", "venv", f"{args.venv} missing")
            return py
        else:
            r = run([sys.executable, "-m", "venv", venv])
            if r.returncode or not py.is_file():
                hint = f"sudo apt install python3.{sys.version_info.minor}-venv" if sys.platform == "linux" else ""
                note("✗", "venv", f"could not create {args.venv}: {tail(r, 2)} {hint}".strip())
                return py
            note("✓", "venv", f"created {args.venv}")
    if os.name == "nt" and not args.no_venv and py.is_file() and not (py.parent / "python3.exe").is_file() \
            and not args.check:  # the hooks and tools call python3; a Windows venv only has python.exe
        shutil.copy2(py, py.parent / "python3.exe")
        note("✓", "python3.exe", "added to the venv (hooks call python3)")
    missing = {imp: pip for imp, pip in want.items() if not has_module(py, imp)}
    if not missing:
        note("✓", "packages", ", ".join(want.values()))
    elif args.check:
        note("!", "packages", "missing: " + ", ".join(missing.values()))
    else:
        r = run([py, "-m", "pip", "install", "-q", "--disable-pip-version-check", *missing.values()])
        if r.returncode:
            note("✗", "packages", f"pip install {' '.join(missing.values())} failed: {tail(r)}")
        else:
            note("✓", "packages", "installed " + ", ".join(missing.values()))
    for n in notes:
        note("!", "driver", n)
    return py


# 3 ─ Playwright ──────────────────────────────────────────────────────────────────────────────────────────────────

def playwright(packs: list[str], args) -> None:
    print("3. Playwright (UI pack)")
    if "ui" not in packs:
        note("-", "Playwright", "no UI module (use --packs ui to set it up anyway)")
        return
    if not (shutil.which("node") and shutil.which("npx") and shutil.which("npm")):
        note("!", "Playwright", "skipped: Node is not installed (see step 1)")
        return
    ui = ROOT / "automation/ui"
    if not (ui / "package.json").is_file():
        if not args.scaffold_ui:
            note("-", "Playwright", "automation/ui not scaffolded yet (auto-write does it with the first spec; "
                                    "--scaffold-ui to do it now)")
            return
        if args.check:
            note("!", "Playwright", "would scaffold automation/ui")
            return
        r = run(["npm", "init", "playwright@latest", "--", "--quiet", "--lang=ts", "--no-examples"], cwd=ui, quiet=False)
        if r.returncode:
            note("✗", "Playwright", "npm init playwright failed (see above)")
            return
        note("✓", "Playwright", "scaffolded automation/ui (set the JUnit reporter: automation/ui/README.md)")
    elif not (ui / "node_modules").is_dir():
        if args.check:
            note("!", "Playwright", "npm packages not installed")
            return
        r = run(["npm", "ci" if (ui / "package-lock.json").is_file() else "install"], cwd=ui, quiet=False)
        if r.returncode:
            note("✗", "Playwright", "npm install failed (see above)")
            return
        note("✓", "Playwright", "npm packages installed")
    else:
        note("✓", "Playwright", "npm packages present")
    if args.check:
        return
    r = run(["npx", "playwright", "install", "chromium"], cwd=ui, quiet=False)
    if r.returncode:
        note("!", "browsers", "npx playwright install chromium failed; on Linux the system libraries may be missing: "
                              "sudo npx playwright install-deps chromium")
    else:
        note("✓", "browsers", "Chromium ready (others: npx playwright install)")


# 4 ─ workspace ───────────────────────────────────────────────────────────────────────────────────────────────────

def workspace(p: dict, py: Path, args) -> None:
    print("4. workspace")
    tool_py = py if py.is_file() else Path(sys.executable)
    if not (ROOT / ".git").exists():
        if args.check:
            note("!", "git", "not a git repository yet")
        else:
            run(["git", "init", "-q", "-b", "main"])
            note("✓", "git", "git init (branch main)")
    hooks = run(["git", "config", "core.hooksPath"]).stdout.strip()
    if hooks == HOOKS:
        note("✓", "git hooks", HOOKS)
    elif args.check:
        note("!", "git hooks", f"core.hooksPath is {hooks or 'unset'}, should be {HOOKS}")
    elif (ROOT / ".git").exists():
        run(["git", "config", "core.hooksPath", HOOKS])
        note("✓", "git hooks", f"core.hooksPath → {HOOKS} (guard before commit, backup after)")
    template = (p.get("guard") or {}).get("template_dev", False)
    if template or not p.get("modules"):
        script, why = "scripts/workspace/sync_agents.py", ("template repo" if template else "no modules yet: /plan-setup")
    else:
        script, why = "scripts/init_project.py", f"{len(p['modules'])} module(s)"
    if args.check:
        r = run([tool_py, script, "--check"])
        note("✓" if r.returncode == 0 else "!", Path(script).name, f"{why}: {tail(r, 1) or 'up to date'}")
        return
    r = run([tool_py, script])
    note("✓" if r.returncode == 0 else "✗", Path(script).name, f"{why}" + ("" if r.returncode == 0 else f": {tail(r)}"))


# 5 ─ Claude Code ─────────────────────────────────────────────────────────────────────────────────────────────────

def claude_env(py: Path, args) -> None:
    print("5. Claude Code")
    if args.no_venv or args.no_claude_env:
        note("-", "settings.local.json", "skipped (--no-venv / --no-claude-env)")
        return
    if not py.is_file():
        note("!", "settings.local.json", "no venv, nothing to point at")
        return
    path = ROOT / ".claude/settings.local.json"
    try:
        cur = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    except json.JSONDecodeError as e:
        note("✗", "settings.local.json", f"not valid JSON, left alone: {e}")
        return
    bindir = str(py.parent)
    rest = [d for d in dict.fromkeys(os.environ.get("PATH", "").split(os.pathsep))
            if d and Path(d).resolve() != py.parent.resolve()]
    want_env = {"VIRTUAL_ENV": str(py.parent.parent), "PATH": os.pathsep.join([bindir, *rest])}
    env = cur.get("env") or {}
    if env.get("VIRTUAL_ENV") == want_env["VIRTUAL_ENV"] and env.get("PATH", "").split(os.pathsep)[:1] == [bindir]:
        note("✓", "settings.local.json", "Claude Code already uses the venv")
    elif args.check:
        note("!", "settings.local.json", "Claude Code does not use the venv yet")
    else:
        cur["env"] = {**env, **want_env}
        path.parent.mkdir(exist_ok=True)
        path.write_text(json.dumps(cur, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        note("✓", "settings.local.json", "Claude Code runs python3 from the venv (restart the session to pick it up)")
    gi = ROOT / ".gitignore"
    text = gi.read_text(encoding="utf-8") if gi.is_file() else ""
    if ".claude/settings.local.json" not in text and not args.check:
        gi.write_text(text.rstrip("\n") + "\n# per machine (setup_workspace.py)\n.claude/settings.local.json\n",
                      encoding="utf-8")
        note("✓", ".gitignore", "+ .claude/settings.local.json")


# 6 ─ verify ──────────────────────────────────────────────────────────────────────────────────────────────────────

def verify(p: dict, py: Path, packs: list[str], args) -> None:
    print("6. verify")
    tool_py = py if py.is_file() else Path(sys.executable)
    r = run([tool_py, "scripts/qa_config.py", "--validate"])
    note("✓" if r.returncode == 0 else "✗", "project.json", "valid" if r.returncode == 0 else tail(r))
    r = run([tool_py, "scripts/workspace/guard.py", "check"])
    note("✓" if r.returncode == 0 else "!", "guard.py check", "clean" if r.returncode == 0 else tail(r, 3))
    unset = []
    for pack in packs:
        for k, v in ((p.get("runners") or {}).get(pack, {}).get("env") or {}).items():
            unset += [var for var in re.findall(r"\$\{(\w+)\}", v) if not os.environ.get(var)]
    if unset:
        note("!", "runner env", "set before run-tests (CI secrets or your shell; never commit them): "
                                + ", ".join(dict.fromkeys(unset)))
    else:
        note("✓", "runner env", "all set")


def summary(py: Path, args) -> int:
    errors = [r for r in RESULTS if r[0] == "✗"]
    warns = [r for r in RESULTS if r[0] == "!"]
    print(f"\nsetup_workspace{' --check' if args.check else ''}: {len(errors)} error(s), {len(warns)} warning(s)")
    if not args.no_venv and py.is_file():
        rel = py.parent.relative_to(ROOT) if py.is_relative_to(ROOT) else py.parent
        act = rf"{rel}\Activate.ps1" if os.name == "nt" else f"source {rel}/activate"
        print(f"In a terminal: {act}  (then python3 scripts/pipeline_status.py)")
    return 1 if errors else 0


def new_project(args) -> int:
    p = load_project()
    if not (p.get("guard") or {}).get("template_dev"):
        sys.exit("✗ --new runs from the template repo")
    dst = args.new.resolve()
    r = run([sys.executable, "scripts/workspace/template_sync.py", "--new", dst], quiet=False)
    if r.returncode:
        return r.returncode
    fwd = [a for a in sys.argv[1:] if a not in ("--selftest",)]
    i = fwd.index("--new")
    del fwd[i:i + 2]
    print(f"\nsetting up {dst}")
    return run([sys.executable, dst / "scripts/workspace/setup_workspace.py", *fwd], cwd=dst, quiet=False).returncode


def main() -> int:
    sys.stdout.reconfigure(line_buffering=True, errors="replace")  # ✓ / ✗ on a cp1252 console
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--check", action="store_true", help="report only; install and write nothing")
    ap.add_argument("--packs", help="ui,api,etl,sql or all (default: the packs in project.json)")
    ap.add_argument("--driver", help="DB driver for a dialect: " + ", ".join(DRIVERS) + " (default: sql.dialect)")
    ap.add_argument("--venv", default=".venv", help="venv folder, relative to the workspace (default .venv)")
    ap.add_argument("--no-venv", action="store_true", help="install into this interpreter instead (CI, containers)")
    ap.add_argument("--no-claude-env", action="store_true", help="leave .claude/settings.local.json alone")
    ap.add_argument("--scaffold-ui", action="store_true", help="scaffold Playwright in automation/ui now")
    ap.add_argument("--new", type=Path, help="(template only) create a new project there, then set it up")
    ap.add_argument("--selftest", action="store_true", help="(template only) run template-dev/tests/selftest.py after")
    args = ap.parse_args()
    if args.new:
        return new_project(args)
    p = load_project()
    packs = pick_packs(p, args.packs)
    kind = "template" if (p.get("guard") or {}).get("template_dev") else f"project {p.get('project', {}).get('code')}"
    print(f"setup_workspace: {ROOT} ({kind}) · packs {', '.join(packs)}" + (" · check only" if args.check else ""))
    if not prerequisites(packs):
        return summary(Path(), args)
    py = python_env(p, packs, args)
    playwright(packs, args)
    workspace(p, py, args)
    claude_env(py, args)
    verify(p, py, packs, args)
    rc = summary(py, args)
    if args.selftest and not args.check:
        if not (ROOT / "template-dev/tests/selftest.py").is_file():
            print("--selftest: no template-dev/ here (template repo only)")
            return rc
        print("\nself-test")
        rc = rc or run([py if py.is_file() else sys.executable, "template-dev/tests/selftest.py", "--python",
                        py if py.is_file() else sys.executable], quiet=False).returncode
    return rc


if __name__ == "__main__":
    sys.exit(main())
