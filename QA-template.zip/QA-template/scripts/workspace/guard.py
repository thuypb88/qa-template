#!/usr/bin/env python3
"""Harness guard: enforces the workspace rules in code, so they don't depend on an agent remembering them.

One rule set, three entry points: Claude Code hooks (.claude/settings.json), the git pre-commit hook (catches Codex
and hand edits too) and a manual check.

    python3 scripts/workspace/guard.py check [paths...]   # working tree (default: every changed / untracked file)
    python3 scripts/workspace/guard.py baseline           # accept today's checker Errors (the ratchet)
    python3 scripts/workspace/guard.py hook pre|post|stop # Claude Code hooks (stdin = hook payload)
    python3 scripts/workspace/guard.py commit             # git pre-commit

Blocked edits (`hook pre`; re-run the owning script instead):
  - sources/**                                 client documents + generated parsed/ and trace/
  - <IT folder>/INDEX.md, <IT folder>/*/sources.json        init_project.py
  - <IT folder>/*/0-scope.md outside the MANUAL block       init_project.py (MANUAL block: scope skill)
  - *.xlsx under the level folders            export_testcases.py
  - AGENTS.md, .agents/skills/**, .github/copilot-instructions.md, .github/skills/**,
    GEMINI.md, .gemini/skills/**                                                        sync_agents.py
  - template-owned files (template-manifest.json), unless project.json › guard.template_dev is true
  - project.json › protected_paths (globs)
Commit checks (changed files): test-cases.json `version` bumped and its Excel exported; no new export_testcases.py
--check / check_scenarios.py Error (vs .harness/check-baseline.json); the Updated stamp changed with the content of a
hand-written doc; the Codex / Copilot / Gemini copies in sync; no git remote when git.local_only.
Bypass a commit check only knowingly: git commit --no-verify, with the reason in the message.
"""
from __future__ import annotations

import fnmatch
import json
import os
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import qa_config as qc  # noqa: E402

ROOT = qc.ROOT
BASELINE = ROOT / ".harness/check-baseline.json"
HOOKS = "scripts/workspace/git-hooks"
PY = sys.executable or "python3"
MS, ME = "<!-- MANUAL:START -->", "<!-- MANUAL:END -->"
STAMP = re.compile(r"^> \*\*Created:\*\*.*\*\*Updated:\*\*", re.M)


def project() -> dict:
    try:
        return qc.load_project()
    except qc.ConfigError:  # no project.json yet (fresh copy): guard the generic paths only
        return {"project": {}, "levels": {"IT": {"folder": "test-design/it"}, "ST": {"folder": "test-design/st"}},
                "protected_paths": [], "git": {"local_only": True}, "modules": [], "values": qc.DEFAULT_VALUES,
                "ids": qc.DEFAULT_IDS}


def folders(p: dict) -> tuple[str, str]:
    return (re.escape(p["levels"].get("IT", {}).get("folder", "test-design/it")),
            re.escape(p["levels"].get("ST", {}).get("folder", "test-design/st")))


def patterns(p: dict):
    it, st = folders(p)
    level = rf"(?:{it}/[^/]+|{st})"
    tc_json = re.compile(rf"^({level})/3-test-cases/test-cases\.json$")
    mindmap = re.compile(rf"^({level})/2-mindmap\.md$")
    generated = [
        (re.compile(r"^sources/"), "sources/ holds the client documents (the user adds them) and generated parsed/ and "
         "trace/. Re-run scripts/extract_text.py or scripts/trace_changes.py; raise a finding for a source problem."),
        (re.compile(rf"^{it}/INDEX\.md$|^{it}/[^/]+/sources\.json$"), "generated; re-run scripts/init_project.py."),
        (re.compile(rf"^(?:{it}|{st})/.*\.xlsx$"), "Excel files are generated: python3 scripts/export_testcases.py "
         "<target>. Change test-cases.json instead."),
        (re.compile(r"^AGENTS\.md$|^\.agents/skills/|^\.github/copilot-instructions\.md$|^\.github/skills/"
                    r"|^GEMINI\.md$|^\.gemini/skills/"),
         "a generated copy for Codex / GitHub Copilot / Gemini. Edit CLAUDE.md / .claude/skills/, then run "
         "python3 scripts/workspace/sync_agents.py."),
    ]
    return tc_json, mindmap, generated, re.compile(rf"^{it}/[^/]+/0-scope\.md$")


def manifest_owned() -> list[str]:
    f = ROOT / "template-manifest.json"
    try:
        return json.loads(f.read_text(encoding="utf-8")).get("template_owned", [])
    except (OSError, json.JSONDecodeError):
        return []


def glob_match(rel: str, pat: str) -> bool:
    if pat.endswith("/**"):
        return rel.startswith(pat[:-3] + "/")
    return fnmatch.fnmatchcase(rel, pat)


BINARY = (".xlsx", ".xlsm", ".xls", ".docx", ".pptx", ".pdf", ".png", ".jpg", ".jpeg", ".gif", ".zip", ".db")


def git(*args):
    r = subprocess.run(["git", *args], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace")
    return r.stdout if r.returncode == 0 else None


def rel_path(file_path, cwd=None):
    path = Path(file_path)
    if not path.is_absolute():
        path = Path(cwd or os.getcwd()) / path
    try:
        return Path(os.path.normpath(path)).relative_to(ROOT).as_posix()
    except ValueError:
        return None


def outside_manual(text, missing_ok=False):
    i, j = text.find(MS), text.find(ME)
    if i < 0 and j < 0 and missing_ok:
        return text.strip()
    return None if i < 0 or j < i else (text[:i].rstrip() + "\n" + text[j + len(ME):].strip()).strip()


def new_content(tool, inp, current):
    if tool == "Write":
        return inp.get("content")
    edits = inp.get("edits") if tool == "MultiEdit" else [inp] if tool == "Edit" else None
    if edits is None or current is None:
        return None
    text = current
    for e in edits:
        old, new = e.get("old_string", ""), e.get("new_string", "")
        text = text.replace(old, new) if e.get("replace_all") else text.replace(old, new, 1)
    return text


def blocked_reason(p, rel, tool, inp):
    _, _, generated, scope_rx = patterns(p)
    for rx, reason in generated:
        if rx.search(rel):
            return f"{rel} is not hand-edited: {reason}"
    if not p.get("guard", {}).get("template_dev"):
        for pat in manifest_owned():
            if glob_match(rel, pat):
                return (f"{rel} is owned by the template (template-manifest.json). Change it in the template repo and "
                        "run python3 scripts/workspace/template_sync.py --from <template>; or record a project rule in "
                        "project/rules.md instead.")
    for pat in p.get("protected_paths", []):
        if glob_match(rel, pat):
            return f"{rel} matches project.json › protected_paths ({pat})."
    if scope_rx.match(rel):
        f = ROOT / rel
        current = f.read_text(encoding="utf-8") if f.exists() else None
        after = new_content(tool, inp, current)
        if current is not None and (after is None or outside_manual(after) is None
                                    or outside_manual(after) != outside_manual(current, missing_ok=True)):
            return (f"{rel} is generated except the {MS} … {ME} block. Change only that block (scope skill), or "
                    "project.json + scripts/init_project.py for the rest.")
    return None


def checker_errors(kind, folder):
    script = "export_testcases.py" if kind == "test-cases" else "check_scenarios.py"
    args = [PY, str(ROOT / "scripts" / script), folder] + (["--check"] if kind == "test-cases" else []) + ["--json"]
    r = subprocess.run(args, cwd=ROOT, capture_output=True, text=True)
    try:
        results = json.loads(r.stdout)
    except json.JSONDecodeError:
        return {f"crash|{script}|{(r.stderr or r.stdout).strip()[-300:]}"}
    return {f"{f['check']}|{f['ref']}|{f['message']}" for res in results for f in res.get("findings", [])
            if f.get("severity") == "Error"} | {f"error|-|{res['error']}" for res in results if res.get("error")}


def load_baseline():
    try:
        return json.loads(BASELINE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def new_errors(kind, folder):
    return sorted(checker_errors(kind, folder) - set(load_baseline().get(kind, {}).get(folder, [])))


def fmt_errors(kind, folder, errs, limit=15):
    script = "export_testcases.py --check" if kind == "test-cases" else "check_scenarios.py"
    out = [f"{folder}: {len(errs)} new {script} Error(s) (not in .harness/check-baseline.json):"]
    out += [f"  - {e.split('|', 1)[1].replace('|', ': ', 1)}" for e in errs[:limit]]
    if len(errs) > limit:
        out.append(f"  … {len(errs) - limit} more; run python3 scripts/{script} {folder}")
    return "\n".join(out)


def read_version(rel, where):
    if where == "work":
        f = ROOT / rel
        return f.read_text(encoding="utf-8", errors="replace") if f.is_file() else None
    return git("show", f"{where}:{rel}" if where == "HEAD" else f":{rel}")


def run_checks(p, files, staged):
    errors = []
    where = ":" if staged else "work"
    tc_json, mindmap, _, _ = patterns(p)
    if p.get("git", {}).get("local_only", True) and (git("remote") or "").strip():
        errors.append("git has a remote, but project.json › git.local_only is true. Remove it (or change the setting "
                      "on the user's say-so).")
    hooks = (git("config", "core.hooksPath") or "").strip()
    if hooks and not (ROOT / hooks).is_dir():
        errors.append(f"git core.hooksPath is {hooks!r}, which does not exist, so the commit checks and backups are "
                      f"off. Run: git config core.hooksPath {HOOKS}")
    checked = set()
    for rel in files:
        if rel.lower().endswith(BINARY):
            continue
        now, head = read_version(rel, where), read_version(rel, "HEAD")
        if now is None:
            continue
        m = tc_json.match(rel)
        if m:
            folder = m.group(1)
            try:
                data = json.loads(now)
            except json.JSONDecodeError as e:
                errors.append(f"{rel}: not valid JSON ({e}).")
                continue
            version = str(data.get("version", ""))
            try:
                old = json.loads(head) if head else None
            except json.JSONDecodeError:
                old = None
            if old is not None and str(old.get("version", "")) == version and old != data:
                errors.append(f"{rel}: test cases changed but `version` is still {version}. Bump it, then re-export.")
            xlsx = f"{folder}/3-test-cases/{qc.suite_name(folder)}_Test_Cases_v{version}.xlsx"
            exported = (git("cat-file", "-e", f":{xlsx}") is not None) if staged else (ROOT / xlsx).is_file()
            if old != data and not exported:
                errors.append(f"{xlsx} {'is not staged' if staged else 'is missing'}: run python3 scripts/"
                              f"export_testcases.py {folder}" + (" and git add it." if staged else "."))
            if ("test-cases", folder) not in checked:
                checked.add(("test-cases", folder))
                errs = new_errors("test-cases", folder)
                if errs:
                    errors.append(fmt_errors("test-cases", folder, errs))
            continue
        m = mindmap.match(rel)
        if m and ("mindmap", m.group(1)) not in checked:
            checked.add(("mindmap", m.group(1)))
            errs = new_errors("mindmap", m.group(1))
            if errs:
                errors.append(fmt_errors("mindmap", m.group(1), errs))
        if rel.endswith(".md") and head is not None and now != head:
            stamp = next((l for l in now.splitlines()[:15] if STAMP.match(l)), None)
            if stamp and stamp in head.splitlines()[:15]:
                errors.append(f"{rel}: content changed but the Updated stamp did not. Set it to {qc.now_stamp(p)}.")
    if any(f.startswith((".claude/skills/", ".agents/skills/", ".github/skills/", ".gemini/skills/"))
           or f in ("CLAUDE.md", "AGENTS.md", ".github/copilot-instructions.md", "GEMINI.md") for f in files):
        r = subprocess.run([PY, str(ROOT / "scripts/workspace/sync_agents.py"), "--check"], cwd=ROOT, capture_output=True,
                           text=True)
        if r.returncode:
            errors.append("The Codex / Copilot / Gemini copies differ from CLAUDE.md / .claude/skills: run python3 "
                          "scripts/workspace/sync_agents.py.\n" + r.stdout.strip())
    return errors


def changed_files(staged):
    if staged:
        return [l for l in (git("diff", "--cached", "--name-only", "--diff-filter=ACMR") or "").splitlines() if l]
    has_head = git("rev-parse", "--verify", "-q", "HEAD") is not None
    out = ((git("diff", "HEAD", "--name-only", "--diff-filter=ACMR") or "") if has_head else "") + \
        (git("ls-files", "--others", "--exclude-standard") or "")
    return sorted({l for l in out.splitlines() if l})


def hook(p, event):
    try:
        payload = json.load(sys.stdin)
    except json.JSONDecodeError:
        payload = {}
    tool, inp = payload.get("tool_name", ""), payload.get("tool_input") or {}
    if event in ("pre", "post"):
        fp = inp.get("file_path") or inp.get("notebook_path")
        rel = rel_path(fp, payload.get("cwd")) if fp else None
        if not rel:
            return 0
        if event == "pre":
            reason = blocked_reason(p, rel, tool, inp)
            if reason:
                print(f"Blocked by scripts/workspace/guard.py: {reason}", file=sys.stderr)
                return 2
            return 0
        tc_json, mindmap, _, _ = patterns(p)
        for kind, rx in (("test-cases", tc_json), ("mindmap", mindmap)):
            m = rx.match(rel)
            if m:
                errs = new_errors(kind, m.group(1))
                if errs:
                    print(fmt_errors(kind, m.group(1), errs) + "\nFix them before you go on.", file=sys.stderr)
                    return 2
        return 0
    if event == "stop":
        files = changed_files(staged=False)
        errors = run_checks(p, files, staged=False)
        if errors and not payload.get("stop_hook_active"):
            print(json.dumps({"decision": "block", "reason": "scripts/workspace/guard.py found rule breaks in the working tree; "
                              "fix them, or tell the user why not:\n- " + "\n- ".join(errors)}))
        elif files:
            print(json.dumps({"systemMessage": f"guard: {len(files)} uncommitted file(s). Commit each change set."}))
        return 0
    print(f"unknown hook event: {event}", file=sys.stderr)
    return 1


def report(errors, files, mode):
    if errors:
        print(f"guard: {len(errors)} problem(s) in {len(files)} {mode} file(s):\n")
        print("\n\n".join(f"✗ {e}" for e in errors))
        if mode == "staged":
            print("\nFix them and commit again (bypass once, knowingly: git commit --no-verify).")
        return 1
    print(f"guard: OK ({len(files)} {mode} file(s) checked)")
    return 0


def baseline(p):
    data = {"_note": "Checker Errors accepted when they were recorded. guard.py fails only on Errors not listed here. "
                     "Rebuild: python3 scripts/workspace/guard.py baseline",
            "generated": qc.now_stamp(p), "test-cases": {}, "mindmap": {}}
    for t in qc.targets(p):
        for kind, f in (("test-cases", "3-test-cases/test-cases.json"), ("mindmap", "2-mindmap.md")):
            if (t["folder"] / f).is_file():
                errs = sorted(checker_errors(kind, t["rel"]))
                if errs:
                    data[kind][t["rel"]] = errs
    BASELINE.parent.mkdir(exist_ok=True)
    BASELINE.write_text(json.dumps(data, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    n = sum(len(v) for k in ("test-cases", "mindmap") for v in data[k].values())
    print(f"Wrote {BASELINE.relative_to(ROOT)}: {n} accepted Error(s)")
    return 0


def main(argv):
    if not argv:
        print(__doc__)
        return 1
    try:
        p = project()
        if argv[0] == "hook" and len(argv) > 1:
            return hook(p, argv[1])
        if argv[0] == "commit":
            files = changed_files(staged=True)
            return report(run_checks(p, files, staged=True), files, "staged")
        if argv[0] == "check":
            files = [rel_path(x) for x in argv[1:]] if argv[1:] else changed_files(staged=False)
            files = [f for f in files if f]
            return report(run_checks(p, files, staged=False), files, "working-tree")
        if argv[0] == "baseline":
            return baseline(p)
    except Exception as e:  # noqa: BLE001 - a broken guard must never stop the work silently, nor block it
        print(f"guard.py internal error ({type(e).__name__}: {e}); nothing was checked.", file=sys.stderr)
        return 1
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
