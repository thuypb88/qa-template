#!/usr/bin/env python3
"""Change control: what changed under sources/ since the accepted baseline, and which level folders read it.

    python3 scripts/trace_changes.py                 # compare; write sources/trace/source-changes.{md,json}
    python3 scripts/trace_changes.py --json          # print the comparison only (used by pipeline_status.py)
    python3 scripts/trace_changes.py --accept --note "SRS v1.3 traced in project/change-impact/2026-10-20-srs-v13.md"

The baseline (sources/trace/source-baseline.json) is the hash of every file under sources/ (parsed/ and trace/
excluded) at the last --accept. A changed / added / removed file is mapped to the level folders that read it: listed
in a module's sources.json (globs in project.json › modules[].sources), or cited by path in a folder's 1-analysis.md
(the file, or its parsed copy). The `plan-changes` skill turns this into a decision per folder and a record in
project/change-impact/; accept only after that. Standard library only.
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import qa_config as qc  # noqa: E402

ROOT = qc.ROOT
SRC = ROOT / "sources"
TRACE = SRC / "trace"
BASELINE = TRACE / "source-baseline.json"


def snapshot() -> dict[str, str]:
    out = {}
    for f in sorted(SRC.rglob("*")):
        rel = f.relative_to(SRC)
        if f.is_file() and rel.parts[0] not in ("parsed", "trace") and not f.name.startswith(".") \
                and rel.as_posix() != "README.md":
            out[f.relative_to(ROOT).as_posix()] = hashlib.sha256(f.read_bytes()).hexdigest()[:16]
    return out


def readers(p: dict, path: str) -> list[str]:
    hits = []
    parsed = "sources/parsed/" + path[len("sources/"):] + ".md"
    for t in qc.targets(p):
        pats = (t["module"] or {}).get("sources", [])
        listed = any(fnmatch.fnmatch(path, pat) or path == pat for pat in pats)
        cited = False
        a = t["folder"] / "1-analysis.md"
        if a.is_file():
            text = a.read_text(encoding="utf-8")
            cited = path in text or parsed in text or Path(path).name in text
        if listed or cited:
            hits.append(f"{t['key']} ({'listed' if listed else ''}{'+' if listed and cited else ''}"
                        f"{'cited' if cited else ''})")
    return hits


def compare(p: dict) -> dict:
    base = json.loads(BASELINE.read_text(encoding="utf-8")) if BASELINE.is_file() else {"files": {}}
    old, new = base.get("files", {}), snapshot()
    changes = []
    for path in sorted(set(old) | set(new)):
        kind = "added" if path not in old else "removed" if path not in new else \
            "changed" if old[path] != new[path] else None
        if kind:
            changes.append({"path": path, "change": kind, "read_by": readers(p, path)})
    return {"baseline": base.get("accepted"), "baseline_note": base.get("note"), "has_baseline": BASELINE.is_file(),
            "changes": changes}


def write_report(p: dict, res: dict) -> None:
    TRACE.mkdir(parents=True, exist_ok=True)
    (TRACE / "source-changes.json").write_text(json.dumps(res, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = ["# Source changes", "", f"> Generated on {qc.now_stamp(p)} by scripts/trace_changes.py. Do not edit.", "",
             f"Baseline: {res['baseline'] or 'none'} ({res['baseline_note'] or '-'}) · "
             f"{len(res['changes'])} file(s) differ", "", "| File | Change | Read by |", "|---|---|---|"]
    lines += [f"| `{c['path']}` | {c['change']} | {', '.join(c['read_by']) or '— (no folder reads it yet)'} |"
              for c in res["changes"]]
    (TRACE / "source-changes.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--accept", action="store_true")
    ap.add_argument("--note", default="")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    p = qc.load_project()
    if a.accept:
        TRACE.mkdir(parents=True, exist_ok=True)
        snap = snapshot()
        BASELINE.write_text(json.dumps({"accepted": qc.now_stamp(p), "note": a.note, "files": snap}, indent=1,
                                       ensure_ascii=False) + "\n", encoding="utf-8")
        write_report(p, compare(p))
        print(f"✓ baseline accepted: {len(snap)} source file(s) ({a.note or 'no note'})")
        return 0
    res = compare(p)
    if a.json:
        print(json.dumps(res, indent=1, ensure_ascii=False))
        return 0
    write_report(p, res)
    print(f"baseline {res['baseline'] or 'none'} · {len(res['changes'])} file(s) differ")
    for c in res["changes"]:
        print(f"  {c['change']:<8} {c['path']}  → {', '.join(c['read_by']) or 'no reader'}")
    if res["changes"]:
        print("Next: the plan-changes skill (decision per folder), then --accept --note '<record>'")
    return 0


if __name__ == "__main__":
    sys.exit(main())
