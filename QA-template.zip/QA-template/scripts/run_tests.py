#!/usr/bin/env python3
"""Run the automated tests of one or more level folders, bind the results to TC IDs and summarise them.

    python3 scripts/run_tests.py E4 --plan            # what would run, with which runner; runs nothing
    python3 scripts/run_tests.py E4 [E5 …] | it | st | all [--grep TC-E4-012] [--pack api]
    python3 scripts/run_tests.py E4 --record C1       # also write cycle C1 results into test-cases.json (+ re-export)

Runners come from project.json › runners.<pack> (one per pack):
    {"cmd": ["{python}", "-m", "pytest", "api", "-k", "{grep}", "--junitxml={junit}"], "cwd": "automation",
     "grep_style": "pytest", "env": {"BASE_URL": "${IT_BASE_URL}"}}
{python} = this interpreter, {junit} = the JUnit file, {grep} = the TC filter; ${VAR} reads the environment.
A test binds to a TC by carrying its ID in the test name (TC-E4-001 or TC_E4_001); see automation/tc_binding.py.

Output: runs/<key>/results.csv (tc_id, title, automation, result, reason, test), runs/<key>/<pack>-junit.xml,
runs/run-summary.{md,json}. Result = Passed / Failed / Skipped / No result (an Auto TC that no test reported —
never counted as passed). Manual and Auto + Manual TCs go to runs/<key>/manual-checklist.csv; the testers fill
result / tester / notes / defect_id and scripts/record_manual.py writes them into test-cases.json.
Exit 0 all passed · 1 failures · 2 set-up error. Standard library only.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import qa_config as qc  # noqa: E402

ROOT = qc.ROOT
RUNS = ROOT / "runs"
TC_IN_NAME = re.compile(r"\bTC[-_]([A-Za-z0-9]+)[-_](\d{3,})\b")


def load_tcs(t: dict) -> tuple[dict, list[dict]]:
    f = t["folder"] / "3-test-cases/test-cases.json"
    if not f.is_file():
        return {}, []
    data = json.loads(f.read_text(encoding="utf-8"))
    return data, data.get("test_cases", [])


def expand(s: str, ctx: dict) -> str:
    """{python} {junit} {grep} {key} {folder} from ctx, then ${VAR} from the environment."""
    for k, v in ctx.items():
        s = s.replace("{" + k + "}", v)
    return re.sub(r"\$\{(\w+)\}", lambda m: os.environ.get(m.group(1), ""), s)


def runner_cmd(p: dict, pack: str, t: dict, grep: str, junit: Path) -> tuple[list[str], Path, dict, str | None]:
    r = p.get("runners", {}).get(pack)
    if not r:
        return [], ROOT, {}, f"no runner for pack {pack!r} in project.json › runners"
    ctx = {"python": sys.executable, "junit": str(junit), "grep": grep, "key": t["key"], "folder": t["rel"]}
    cmd = [c for c in (expand(c, ctx) for c in r["cmd"]) if c != ""]
    cwd = ROOT / r.get("cwd", ".")
    env = {k: expand(v, ctx) for k, v in r.get("env", {}).items()}
    if not cwd.is_dir():
        return cmd, cwd, env, f"runner folder {cwd.relative_to(ROOT)} not found"
    if not (shutil.which(cmd[0]) or Path(cmd[0]).is_file()):
        return cmd, cwd, env, f"{cmd[0]} not installed"
    if len(cmd) > 2 and cmd[1] == "-m" and Path(cmd[0]).name.startswith("python"):
        probe = subprocess.run([cmd[0], "-c", f"import {cmd[2]}"], capture_output=True)
        if probe.returncode:
            return cmd, cwd, env, f"{cmd[2]} not installed for {cmd[0]} (pip install {cmd[2]})"
    missing = [k for k, v in r.get("env", {}).items() if "${" in v and not env[k]]
    if missing:
        return cmd, cwd, env, "environment not set: " + ", ".join(re.findall(r"\$\{(\w+)\}", " ".join(
            r["env"][k] for k in missing)))
    return cmd, cwd, env, None


def grep_for(p: dict, pack: str, t: dict, user: str | None) -> str:
    style = p.get("runners", {}).get(pack, {}).get("grep_style", "pytest")
    base = user or ("TC-ST-" if t["level"] == "ST" else f"TC-{t['key']}-")
    return base.replace("-", "_") if style == "pytest" else base


def parse_junit(f: Path) -> dict[str, tuple[str, str, str]]:
    out = {}
    if not f.is_file():
        return out
    root = ET.parse(f).getroot()
    for tc in root.iter("testcase"):
        name = f"{tc.get('classname', '')}::{tc.get('name', '')}"
        if tc.find("failure") is not None or tc.find("error") is not None:
            el = tc.find("failure") if tc.find("failure") is not None else tc.find("error")
            res, reason = "Failed", (el.get("message") or el.text or "").strip().splitlines()[0][:300] if (
                el.get("message") or el.text) else "failed"
        elif tc.find("skipped") is not None:
            res, reason = "Skipped", (tc.find("skipped").get("message") or "").strip()[:300]
        else:
            res, reason = "Passed", ""
        for m in TC_IN_NAME.finditer(name):
            tid = f"TC-{m.group(1)}-{m.group(2)}"
            prev = out.get(tid)
            # several tests (data-driven rows) per TC: any failure wins, then skipped
            if not prev or {"Failed": 2, "Skipped": 1, "Passed": 0}[res] > {"Failed": 2, "Skipped": 1, "Passed": 0}[prev[0]]:
                out[tid] = (res, reason, name)
    return out


def bump(v: str) -> str:
    parts = str(v).split(".")
    parts[-1] = str(int(parts[-1]) + 1) if parts[-1].isdigit() else parts[-1] + ".1"
    return ".".join(parts)


def main() -> int:
    sys.stdout.reconfigure(line_buffering=True)  # keep our lines in order with the runners' output
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("targets", nargs="+")
    ap.add_argument("--plan", action="store_true")
    ap.add_argument("--grep")
    ap.add_argument("--pack")
    ap.add_argument("--record", metavar="CYCLE")
    a = ap.parse_args()
    p = qc.load_project()
    tgts = []
    for x in a.targets:
        for t in qc.resolve(p, x):
            if t not in tgts:
                tgts.append(t)
    summary, setup_error, any_fail = [], False, False
    for t in tgts:
        data, tcs = load_tcs(t)
        if not tcs:
            summary.append({"key": t["key"], "note": "no test-cases.json"})
            continue
        auto = [tc for tc in tcs if tc.get("automation") in ("Auto", "Auto + Manual")]
        by_pack: dict[str, list] = {}
        for tc in auto:
            by_pack.setdefault(qc.tc_pack(tc, t, p), []).append(tc)
        out_dir = RUNS / t["key"].lower()
        results: dict[str, tuple[str, str, str]] = {}
        notes = []
        for pack, items in sorted(by_pack.items()):
            if a.pack and pack != a.pack:
                continue
            junit = out_dir / f"{pack}-junit.xml"
            grep = grep_for(p, pack, t, a.grep)
            cmd, cwd, env, problem = runner_cmd(p, pack, t, grep, junit)
            line = f"{t['key']} · {pack}: {len(items)} Auto TC(s) · " + (f"BLOCKED: {problem}" if problem else
                                                                        f"`{' '.join(cmd)}` in {cwd.relative_to(ROOT)}")
            notes.append(line)
            if a.plan or problem:
                setup_error |= bool(problem) and not a.plan
                continue
            out_dir.mkdir(parents=True, exist_ok=True)
            if junit.exists():
                junit.unlink()
            r = subprocess.run(cmd, cwd=cwd, env={**os.environ, **env})
            if not junit.exists():  # the runner never got to the tests (crash, missing module, bad config)
                notes.append(f"{t['key']} · {pack}: runner exit {r.returncode}, no JUnit file — set-up error")
                setup_error = True
            results.update(parse_junit(junit))
        print("\n".join(notes) or f"{t['key']}: no Auto TCs")
        if a.plan:
            continue
        rows = []
        for tc in tcs:
            res = results.get(tc["tc_id"])
            if tc.get("automation") in ("Auto", "Auto + Manual"):
                rows.append([tc["tc_id"], tc.get("title", ""), tc.get("automation"), res[0] if res else "No result",
                             res[1] if res else "", res[2] if res else ""])
        out_dir.mkdir(parents=True, exist_ok=True)
        with (out_dir / "results.csv").open("w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows([["tc_id", "title", "automation", "result", "reason", "test"]] + rows)
        manual = [tc for tc in tcs if tc.get("automation") in ("Manual", "Auto + Manual", None, "")]
        with (out_dir / "manual-checklist.csv").open("w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows([["tc_id", "title", "automation", "priority", "result", "tester", "notes",
                                      "defect_id"]] +
                                    [[tc["tc_id"], tc.get("title"), tc.get("automation") or "untagged",
                                      tc.get("priority"), "", "", "", ""] for tc in manual])
        c = Counter(r[3] for r in rows)
        any_fail |= c.get("Failed", 0) > 0
        summary.append({"key": t["key"], "tcs": len(tcs), "auto": len(auto), "passed": c.get("Passed", 0),
                        "failed": c.get("Failed", 0), "skipped": c.get("Skipped", 0),
                        "no_result": c.get("No result", 0), "manual": len(manual)})
        if a.record:
            stamp = qc.now_stamp(p)
            for tc in tcs:
                if tc["tc_id"] in results:
                    tc.update({"cycle": a.record, "result": results[tc["tc_id"]][0], "executed_on": stamp})
            data["version"] = bump(data.get("version", "0.1"))
            (t["folder"] / "3-test-cases/test-cases.json").write_text(
                json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            subprocess.run([sys.executable, str(ROOT / "scripts/export_testcases.py"), t["key"]], cwd=ROOT)
            print(f"{t['key']}: cycle {a.record} recorded, version {data['version']}")
    if a.plan:
        return 0
    RUNS.mkdir(exist_ok=True)
    (RUNS / "run-summary.json").write_text(json.dumps(summary, indent=1) + "\n", encoding="utf-8")
    md = [f"# Run summary", "", f"> Generated on {qc.now_stamp(p)} by scripts/run_tests.py {' '.join(a.targets)}", "",
          "| Target | TCs | Auto | Passed | Failed | Skipped | No result | Manual residue |", "|---|---|---|---|---|---|---|---|"]
    md += [f"| {s['key']} | {s.get('tcs', '-')} | {s.get('auto', '-')} | {s.get('passed', '-')} | {s.get('failed', '-')} | "
           f"{s.get('skipped', '-')} | {s.get('no_result', '-')} | {s.get('manual', '-')} |" for s in summary]
    (RUNS / "run-summary.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print("\n".join(md[4:]))
    return 2 if setup_error else 1 if any_fail else 0


if __name__ == "__main__":
    sys.exit(main())
