#!/usr/bin/env python3
"""Where every level folder stands, and the one skill that runs next. Read-only.

    python3 scripts/pipeline_status.py             # all folders
    python3 scripts/pipeline_status.py E4          # one target (module id, folder, st, it)
    python3 scripts/pipeline_status.py --json

Per folder: each step's file (exists, Updated stamp / mtime), each review's verdict and whether it is older than its
artifact (stale), the test case version and count, check Errors, the automation plan, and execution results. Before
everything: unaccepted source changes (trace_changes.py). The "next" rule is the chain order:
    plan-changes → plan-scope → design-analysis → check-design(analysis) → design-scenarios → check-design(scenarios)
    → design-cases → check-design(test-cases) → auto-decide → run-tests
A review with verdict Rework sends the folder back to its writer. Standard library only.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import qa_config as qc  # noqa: E402

ROOT = qc.ROOT
STEPS = [("analysis", "1-analysis.md", "1-analysis-review.md", "design-analysis"),
         ("scenarios", "2-mindmap.md", "2-mindmap-review.md", "design-scenarios"),
         ("test-cases", "3-test-cases/test-cases.json", "3-test-cases/test-cases-review.md", "design-cases")]
PACK_WRITERS = {("sql", "design-cases"): "sql-cases"}  # a pack whose step has its own writer skill
STAMP = re.compile(r"\*\*Updated:\*\*\s*(\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?)")
VERDICT = re.compile(r"\*\*Verdict:\*\*\s*(Pass with fixes|Pass|Rework)")


def when(f: Path) -> float:
    """Last commit time of the file, else its mtime (a fresh clone resets mtimes)."""
    r = subprocess.run(["git", "log", "-1", "--format=%ct", "--", str(f)], cwd=ROOT, capture_output=True, text=True)
    dirty = subprocess.run(["git", "status", "--porcelain", "--", str(f)], cwd=ROOT, capture_output=True, text=True)
    if r.returncode == 0 and r.stdout.strip() and not dirty.stdout.strip():
        return float(r.stdout.strip())
    return f.stat().st_mtime


def folder_status(p: dict, t: dict) -> dict:
    st = {"key": t["key"], "folder": t["rel"], "level": t["level"], "pack": t["pack"], "steps": {}, "warnings": []}
    nxt = None
    if t["module"] and not (t["folder"] / "0-scope.md").is_file():
        nxt = ("plan-scope", "0-scope.md missing (run scripts/init_project.py)")
    for name, art, rev, writer in STEPS:
        writer = PACK_WRITERS.get((t["pack"], writer), writer)
        a, r = t["folder"] / art, t["folder"] / rev
        s = {"exists": a.is_file(), "review": None, "verdict": None, "stale_review": False}
        if a.is_file():
            if r.is_file():
                text = r.read_text(encoding="utf-8")
                m = VERDICT.search(text)
                s["review"], s["verdict"] = rev, m.group(1) if m else "?"
                applied = "## Revision log" in text
                s["stale_review"] = when(a) > when(r) + 60 and not applied
        st["steps"][name] = s
        if nxt:
            continue
        if not a.is_file():
            nxt = (writer, f"{art} missing")
        elif not r.is_file():
            nxt = ("check-design", f"{art} not reviewed")
        elif s["verdict"] == "Rework":
            nxt = (writer, f"{rev} verdict Rework: rebuild with the findings")
        elif s["stale_review"]:
            nxt = ("check-design", f"{art} changed after its review")
    tcj = t["folder"] / "3-test-cases/test-cases.json"
    if tcj.is_file():
        try:
            data = json.loads(tcj.read_text(encoding="utf-8"))
            tcs = data.get("test_cases", [])
            st["tc_version"], st["tc_count"] = data.get("version"), len(tcs)
            st["untagged"] = sum(1 for tc in tcs if not tc.get("automation"))
            st["results"] = sum(1 for tc in tcs if tc.get("result"))
        except json.JSONDecodeError:
            st["warnings"].append("test-cases.json is not valid JSON")
        plan = t["folder"] / "3-test-cases/automation-plan.md"
        st["automation_plan"] = plan.is_file()
        if not nxt and (not plan.is_file() or when(plan) < when(tcj) - 60):
            nxt = ("auto-decide", "no automation plan" if not plan.is_file() else "plan older than the TCs")
        if not nxt:
            nxt = ("run-tests", "chain complete; run or record a cycle")
        xl = list((t["folder"] / "3-test-cases").glob(f"*_v{st.get('tc_version')}.xlsx"))
        if not xl:
            st["warnings"].append(f"no Excel for v{st.get('tc_version')} (python3 scripts/export_testcases.py {t['key']})")
    st["next"], st["why"] = nxt or ("design-analysis", "")
    return st


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("target", nargs="?")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    p = qc.load_project()
    r = subprocess.run([sys.executable, str(ROOT / "scripts/trace_changes.py"), "--json"], cwd=ROOT,
                       capture_output=True, text=True)
    try:
        src = json.loads(r.stdout)
    except json.JSONDecodeError:
        src = {"changes": [], "has_baseline": False}
    rows = [folder_status(p, t) for t in qc.resolve(p, a.target)]
    out = {"project": p["project"].get("code"), "source_changes": len(src.get("changes", [])),
           "source_baseline": src.get("has_baseline"), "folders": rows}
    if a.json:
        print(json.dumps(out, indent=1, ensure_ascii=False))
        return 0
    if not src.get("has_baseline"):
        print("! No source baseline: run python3 scripts/init_project.py (or trace_changes.py --accept).")
    elif src.get("changes"):
        print(f"! {len(src['changes'])} source file(s) differ from the accepted baseline → run plan-changes first.")
    mark = {True: "✓", False: "·"}
    print(f"\n{'Folder':<38} {'Analysis':<12} {'Scenarios':<12} {'Test cases':<16} Next")
    for s in rows:
        cells = []
        for name, *_ in STEPS:
            x = s["steps"][name]
            v = (x["verdict"] or "unrev") if x["exists"] else ""
            v = v.replace("Pass with fixes", "PwF")
            cells.append(f"{mark[x['exists']]} {v}{' (stale)' if x['stale_review'] else ''}")
        if s.get("tc_version"):
            cells[2] += f" v{s['tc_version']}/{s['tc_count']}"
        print(f"{s['folder']:<38} {cells[0]:<12} {cells[1]:<12} {cells[2]:<16} {s['next']} — {s['why']}")
        for w in s["warnings"]:
            print(f"{'':<38} ! {w}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
