#!/usr/bin/env python3
"""Check a level folder's 3-test-cases/test-cases.json and export it to Excel.

    python3 scripts/export_testcases.py <target> --check   # check only (module id, folder, st, it, or --all)
    python3 scripts/export_testcases.py <target>           # check, then write the Excel when there is no Error
    python3 scripts/export_testcases.py --all --check --json

The Excel is <folder>_Test_Cases_v<version>.xlsx in 3-test-cases/ (older ones move to history/), with sheets
Test Cases, RTM and Summary (standards/conventions.md §5). The export needs openpyxl; the check does not.

Error   invalid JSON · missing module / version / test_cases · bad or duplicate tc_id · required field missing ·
        value not in project.json › values (+ pack extra types) · steps ≠ expected results (R4) · numbered list items
        (R3, R4) · title without [prefix] (R5) · scenario_id not in 2-mindmap.md · pack block missing / incomplete
Warning a TS with no TC · vague expected result (R4.5) · Q-xxx cited without "assumed" (R8) · forbidden terms for the
        pack (R2) · description repeats the title · checklist ID not defined in the pack checklist
Info    TC IDs not sequential · Blocked rows
Standard library only (openpyxl for the Excel).
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import qa_config as qc  # noqa: E402
from check_scenarios import parse_scenarios  # noqa: E402

REQUIRED = ["tc_id", "scenario_id", "test_type", "priority", "title", "steps", "expected_result", "status"]
NUMBERED = re.compile(r"^\s*(\d+[.)]|step \d+:)\s", re.I)
VAGUE = re.compile(r"\b(as expected|works? (fine|correctly|properly)|appropriate(ly)?|correctly handled|"
                   r"should work|or (rejected|rounded|accepted)|and/or|etc\.?)\b", re.I)
QREF = re.compile(r"\bQ-(?:[A-Z]+-)?\d{3,}\b")


def as_list(v):
    return [] if v in (None, "") else (v if isinstance(v, list) else [v])


def checklist_ids(pack: str) -> dict[str, str]:
    f = qc.PACKS_DIR / pack / "checklist.md"
    out = {}
    if f.is_file():
        for line in f.read_text(encoding="utf-8").splitlines():
            m = re.match(r"^\|\s*([A-Z]+-[A-Z]\d{2})\s*\|\s*([^|]+?)\s*\|", line)
            if m:
                out[m.group(1)] = m.group(2)
    return out


def check(p: dict, t: dict) -> tuple[dict, dict | None]:
    res = {"folder": t["rel"], "findings": [], "stats": {}}
    add = lambda sev, chk, ref, msg: res["findings"].append(  # noqa: E731
        {"severity": sev, "check": chk, "ref": ref, "message": msg})
    f = t["folder"] / "3-test-cases/test-cases.json"
    if not f.is_file():
        res["error"] = "3-test-cases/test-cases.json not found"
        return res, None
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        res["error"] = f"invalid JSON: {e}"
        return res, None
    for k in ("module", "version", "test_cases"):
        if k not in data:
            add("Error", "Structure", k, f"missing top-level {k!r}")
    if t["module"] and data.get("module") and data["module"] != t["module"]["name"]:
        add("Error", "Structure", "module", f"module {data['module']!r} ≠ project.json name {t['module']['name']!r}")
    tcs = data.get("test_cases") or []
    rx = qc.tc_pattern(p, t)
    scen_file = t["folder"] / "2-mindmap.md"
    scen_ids = {r.get("Scenario ID") for r in parse_scenarios(scen_file)[0]} if scen_file.is_file() else None
    vals = p["values"]
    seen, used_ts, nums = set(), set(), []
    for tc in tcs:
        tid = tc.get("tc_id", "?")
        for k in REQUIRED:
            if tc.get(k) in (None, "", []):
                add("Error", "Fields", tid, f"missing {k}")
        if not rx.match(tid):
            add("Error", "IDs", tid, f"tc_id does not match {rx.pattern}")
        else:
            nums.append(int(re.findall(r"\d+", tid)[-1]))
        if tid in seen:
            add("Error", "IDs", tid, "duplicate tc_id")
        seen.add(tid)
        pack = qc.tc_pack(tc, t, p)
        types = qc.test_types(p, [pack])
        for key, allowed in (("test_type", types), ("priority", vals["priorities"]), ("status", vals["statuses"])):
            if tc.get(key) and tc[key] not in allowed:
                add("Error", "R8", tid, f"{key} {tc[key]!r} not allowed")
        if tc.get("automation") and tc["automation"] not in vals["automation"]:
            add("Error", "R8", tid, f"automation {tc['automation']!r} not allowed")
        steps, exp, pre = as_list(tc.get("steps")), as_list(tc.get("expected_result")), as_list(tc.get("preconditions"))
        if len(steps) != len(exp):
            add("Error", "R4", tid, f"{len(steps)} steps vs {len(exp)} expected results")
        for name, items in (("steps", steps), ("expected_result", exp), ("preconditions", pre)):
            if any(NUMBERED.match(str(s)) for s in items):
                add("Error", "R3/R4", tid, f"{name} numbered by hand (the export numbers them)")
        if not re.match(r"^\[[^\]]+\]\s+\S", tc.get("title", "")):
            add("Error", "R5", tid, "title must start with [<Level-1 item>]")
        ts = tc.get("scenario_id")
        if ts:
            used_ts.add(ts)
            if scen_ids is not None and ts not in scen_ids:
                add("Error", "Coverage", tid, f"scenario {ts} not in 2-mindmap.md")
        for e in exp:
            if VAGUE.search(str(e)):
                add("Warning", "R4.5", tid, f"vague expected result: {str(e)[:80]!r}")
                break
        notes = str(tc.get("notes", ""))
        for q in set(QREF.findall(notes)):
            if not re.search(re.escape(q) + r"\s*:\s*(assumed|Blocked)", notes, re.I) and \
                    not re.search(r"Blocked:\s*" + re.escape(q), notes):
                add("Warning", "R8", tid, f"{q} cited without 'assumed <value>'")
        if tc.get("status") == "Blocked" and "Blocked" not in notes:
            add("Warning", "R8", tid, "status Blocked but notes give no 'Blocked: Q-xxx <reason>'")
        pk = qc.load_pack(pack)
        ft = pk.get("forbidden_terms")
        if ft:
            text = " ".join(str(x) for w in ft["where"] for x in as_list(tc.get(w)))
            hits = [pat for pat in ft["patterns"] if re.search(pat, text, re.I)]
            if hits:
                add(ft.get("severity", "Warning"), "R2", tid, f"{ft['rule']} (matched {hits[0]})")
        blk = pk.get("tc_block")
        if blk:
            b = tc.get(blk["key"])
            if not isinstance(b, dict):
                add("Error", "Pack", tid, f"{pack} TC needs an {blk['key']!r} block (packs/{pack}/tc-fields.md)")
            else:
                for k in blk["required"]:
                    if b.get(k) in (None, "", {}):
                        add("Error", "Pack", tid, f"{blk['key']}.{k} missing")
                for k, allowed in blk.get("enums", {}).items():
                    if b.get(k) and str(b[k]) not in allowed:
                        add("Error", "Pack", tid, f"{blk['key']}.{k} {b[k]!r} not in {allowed}")
                for k in blk.get("expect_required", []):
                    if not isinstance(b.get("expect"), dict) or k not in b["expect"]:
                        add("Error", "Pack", tid, f"{blk['key']}.expect.{k} missing")
        desc, title = str(tc.get("description", "")), re.sub(r"^\[[^\]]+\]\s*", "", tc.get("title", ""))
        if desc and title and desc.lower().replace("verify that ", "").startswith(title.lower()[:40]):
            add("Warning", "R8", tid, "description repeats the title; say why the row exists")
        ids = checklist_ids(pack)
        for cid in re.findall(r"\b(?:GUI|API|ETL|SQL)-[A-Z]\d{2}\b", notes):
            if ids and cid not in ids:
                add("Warning", "Checklist", tid, f"{cid} not defined in packs/{pack}/checklist.md")
    if scen_ids:
        missing = sorted(s for s in scen_ids - used_ts if s)
        if missing:
            add("Warning", "Coverage", "TS", f"{len(missing)} scenario(s) with no TC: " + ", ".join(missing[:30])
                + (" …" if len(missing) > 30 else ""))
    if nums and nums != list(range(min(nums), min(nums) + len(nums))):
        add("Info", "IDs", "tc_id", "TC numbers are not a gap-free sequence (fine after deletions; never renumber)")
    blocked = sum(1 for tc in tcs if tc.get("status") == "Blocked")
    if blocked:
        add("Info", "Status", "Blocked", f"{blocked} Blocked TC(s)")
    res["stats"] = {"version": data.get("version"), "tcs": len(tcs),
                    "scenarios": f"{len(used_ts & (scen_ids or set()))}/{len(scen_ids)}" if scen_ids else "-"}
    return res, data


# --- Excel ------------------------------------------------------------------------------------------------------

BASE_COLS = [("tc_id", "TC ID", 14), ("module", "Module", 18), ("scenario_id", "Scenario", 10),
             ("srs_ref", "Requirement", 14), ("use_case", "Use Case", 10), ("test_type", "Test Type", 13),
             ("priority", "Priority", 12), ("title", "Title", 45), ("description", "Description", 35),
             ("preconditions", "Preconditions", 40), ("steps", "Test Steps", 50), ("test_data", "Test Data", 30),
             ("expected_result", "Expected Result", 50), ("status", "Status", 12), ("automation", "Automation", 12),
             ("automation_note", "Automation Note", 25), ("_checklist", "Checklist", 18), ("notes", "Notes", 40)]
EXEC_COLS = [("cycle", "Cycle"), ("result", "Result"), ("executed_on", "Executed On"), ("defect_id", "Defect ID")]


def fmt(v, numbered=False) -> str:
    if isinstance(v, list):
        return "\n".join(f"{i}. {x}" if numbered else str(x) for i, x in enumerate(v, 1))
    if isinstance(v, dict):
        return "\n".join(f"{k}: {json.dumps(x, ensure_ascii=False) if isinstance(x, (dict, list)) else x}"
                         for k, x in v.items())
    return "" if v is None else str(v)


def dig(tc: dict, path: str):
    cur = tc
    for part in path.split("."):
        cur = cur.get(part) if isinstance(cur, dict) else None
    return cur


def export(p: dict, t: dict, data: dict) -> Path:
    try:
        from openpyxl import Workbook  # noqa: PLC0415
        from openpyxl.styles import Alignment, Font, PatternFill  # noqa: PLC0415
        from openpyxl.utils import get_column_letter  # noqa: PLC0415
        from openpyxl.worksheet.datavalidation import DataValidation  # noqa: PLC0415
    except ImportError:
        sys.exit("The export needs openpyxl: pip install openpyxl (the --check mode works without it)")
    tcs = data["test_cases"]
    packs = sorted({qc.tc_pack(tc, t, p) for tc in tcs})
    pack_cols = [c for pk in packs for c in qc.load_pack(pk).get("excel_columns", [])]
    has_exec = any(tc.get(k) for tc in tcs for k, _ in EXEC_COLS)
    cols = [(k, h, w) for k, h, w in BASE_COLS] + [(k, h, 25) for k, h in pack_cols] + \
           ([(k, h, 14) for k, h in EXEC_COLS] if has_exec else [])
    names = {pk: checklist_ids(pk) for pk in packs}
    wb = Workbook()
    ws = wb.active
    ws.title = "Test Cases"
    head_fill, head_font = PatternFill("solid", fgColor="1F4E78"), Font(bold=True, color="FFFFFF")
    for i, (_, h, w) in enumerate(cols, 1):
        c = ws.cell(row=1, column=i, value=h)
        c.fill, c.font, c.alignment = head_fill, head_font, Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(i)].width = w
    wrap = Alignment(wrap_text=True, vertical="top")
    for r, tc in enumerate(tcs, 2):
        pk = qc.tc_pack(tc, t, p)
        ids = re.findall(r"\b(?:GUI|API|ETL|SQL)-[A-Z]\d{2}\b", str(tc.get("notes", "")))
        for i, (k, _, _) in enumerate(cols, 1):
            if k == "module":
                v = data.get("module")
            elif k == "_checklist":
                v = "\n".join(f"{x} {names.get(pk, {}).get(x, '')}".strip() for x in dict.fromkeys(ids))
            elif "." in k:
                v = fmt(dig(tc, k))
            else:
                v = fmt(tc.get(k), numbered=k in ("preconditions", "steps", "expected_result"))
            ws.cell(row=r, column=i, value=v).alignment = wrap
    ws.freeze_panes = "B2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{max(len(tcs) + 1, 2)}"
    idx = {k: i for i, (k, _, _) in enumerate(cols, 1)}
    lists = {"test_type": qc.test_types(p, packs), "priority": p["values"]["priorities"],
             "status": p["values"]["statuses"], "automation": p["values"]["automation"]}
    for k, allowed in lists.items():
        if k in idx and len(",".join(allowed)) < 250:
            dv = DataValidation(type="list", formula1='"' + ",".join(allowed) + '"', allow_blank=True)
            letter = get_column_letter(idx[k])
            dv.add(f"{letter}2:{letter}{max(len(tcs) + 1, 2)}")
            ws.add_data_validation(dv)
    rtm = wb.create_sheet("RTM")
    rtm.append(["Requirement", "TC count", "TC IDs"])
    by_req = defaultdict(list)
    for tc in tcs:
        for ref in as_list(tc.get("srs_ref")) or ["(none)"]:
            by_req[str(ref)].append(tc["tc_id"])
    for ref in sorted(by_req):
        rtm.append([ref, len(by_req[ref]), ", ".join(by_req[ref])])
    summ = wb.create_sheet("Summary")
    summ.append([f"{data.get('module')} · version {data.get('version')} · {len(tcs)} TCs · exported "
                 f"{qc.now_stamp(p)}"])
    for key in ("test_type", "priority", "status", "automation"):
        summ.append([])
        summ.append([key, "count"])
        for v, n in Counter(tc.get(key) or "(empty)" for tc in tcs).most_common():
            summ.append([v, n])
    for sheet in (rtm, summ):
        for c in sheet[1]:
            c.font = Font(bold=True)
        sheet.column_dimensions["A"].width = 30
        sheet.column_dimensions["C"].width = 80
    out_dir = t["folder"] / "3-test-cases"
    out = out_dir / f"{qc.suite_name(t['folder'])}_Test_Cases_v{data.get('version')}.xlsx"
    hist = out_dir / "history"
    for old in out_dir.glob(f"{qc.suite_name(t['folder'])}_Test_Cases_v*.xlsx"):
        if old != out:
            hist.mkdir(exist_ok=True)
            shutil.move(str(old), hist / old.name)
    wb.save(out)
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("target", nargs="?")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    p = qc.load_project()
    tgts = qc.resolve(p, None if a.all else (a.target or "all"))
    results, failed = [], False
    for t in tgts:
        if not a.target and not (t["folder"] / "3-test-cases/test-cases.json").is_file():
            continue
        res, data = check(p, t)
        errors = [f for f in res["findings"] if f["severity"] == "Error"]
        failed |= bool(errors) or bool(res.get("error") and a.target)
        if not a.check and data and not errors:
            res["excel"] = export(p, t, data).relative_to(qc.ROOT).as_posix()
        elif not a.check and errors:
            res["excel"] = None
        results.append(res)
    if a.json:
        print(json.dumps(results, ensure_ascii=False, indent=1))
    else:
        for r in results:
            fs = r["findings"]
            counts = " · ".join(f"{sum(1 for f in fs if f['severity'] == s)} {s}" for s in ("Error", "Warning", "Info"))
            print(f"\n{r['folder']}: {r.get('error') or counts}  "
                  + " · ".join(f"{k} {v}" for k, v in r.get("stats", {}).items()))
            for f in fs:
                print(f"  {f['severity']:<7} {f['check']:<9} {f['ref']:<14} {f['message']}")
            if "excel" in r:
                print(f"  → {r['excel']}" if r["excel"] else "  → Excel NOT written: fix the Errors first")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
