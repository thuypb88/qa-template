#!/usr/bin/env python3
"""Record manual test results (the filled manual-checklist.csv) into a folder's test-cases.json.

    python3 scripts/record_manual.py E4 runs/e4/manual-checklist.csv --cycle C1 [--dry-run]

The CSV is the one run_tests.py writes (tc_id, title, automation, priority, result, tester, notes, defect_id), filled
by the testers. Rows with an empty result are skipped (the TC stays unexecuted). Result values: Passed, Failed,
Blocked, Not Run (case-insensitive). For each recorded TC: cycle, result, executed_on, and tester / defect_id when
given. An Auto + Manual TC that already Failed in the same cycle stays Failed (any failure wins). Then the suite
version is bumped and the Excel re-exported. Unknown TC IDs or result values → exit 2, nothing written.
Standard library only.
"""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import qa_config as qc  # noqa: E402
from run_tests import bump  # noqa: E402

RESULTS = {"passed": "Passed", "failed": "Failed", "blocked": "Blocked", "not run": "Not Run"}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("target")
    ap.add_argument("csv", type=Path)
    ap.add_argument("--cycle", required=True)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    p = qc.load_project()
    tgts = qc.resolve(p, a.target)
    if len(tgts) != 1:
        print(f"record_manual: '{a.target}' must name exactly one folder", file=sys.stderr)
        return 2
    t = tgts[0]
    jf = t["folder"] / "3-test-cases/test-cases.json"
    if not jf.is_file() or not a.csv.is_file():
        print(f"record_manual: missing {jf if not jf.is_file() else a.csv}", file=sys.stderr)
        return 2
    data = json.loads(jf.read_text(encoding="utf-8"))
    by_id = {tc["tc_id"]: tc for tc in data.get("test_cases", [])}
    with a.csv.open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    problems, updates = [], []
    for n, r in enumerate(rows, start=2):
        tid, res = (r.get("tc_id") or "").strip(), (r.get("result") or "").strip()
        if not res:
            continue
        if tid not in by_id:
            problems.append(f"line {n}: unknown TC {tid!r}")
        elif res.lower() not in RESULTS:
            problems.append(f"line {n}: {tid} result {res!r} not one of {', '.join(RESULTS.values())}")
        else:
            updates.append((tid, RESULTS[res.lower()], (r.get("tester") or "").strip(), (r.get("defect_id") or "").strip()))
    if problems:
        print("record_manual: nothing written\n  " + "\n  ".join(problems), file=sys.stderr)
        return 2
    stamp, kept = qc.now_stamp(p), []
    for tid, res, tester, defect in updates:
        tc = by_id[tid]
        if tc.get("cycle") == a.cycle and tc.get("result") == "Failed" and res != "Failed":
            kept.append(tid)
            res = "Failed"
        tc.update({"cycle": a.cycle, "result": res, "executed_on": stamp})
        if tester:
            tc["tester"] = tester
        if defect:
            tc["defect_id"] = defect
    counts = {v: sum(1 for u in updates if by_id[u[0]]["result"] == v) for v in RESULTS.values()}
    print(f"{t['key']}: {len(updates)} manual result(s) for cycle {a.cycle} · "
          + " · ".join(f"{k} {v}" for k, v in counts.items() if v)
          + (f" · kept Failed from the automated run: {', '.join(kept)}" if kept else "")
          + f" · {len(rows) - len(updates)} row(s) without a result")
    if a.dry_run or not updates:
        return 0
    data["version"] = bump(data.get("version", "0.1"))
    jf.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    subprocess.run([sys.executable, str(qc.ROOT / "scripts/export_testcases.py"), t["key"]], cwd=qc.ROOT)
    print(f"{t['key']}: version {data['version']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
