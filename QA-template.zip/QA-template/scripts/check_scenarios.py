#!/usr/bin/env python3
"""Check a level folder's 2-mindmap.md (test scenarios) against the pack layout and the analysis.

    python3 scripts/check_scenarios.py <target>        # module id (E4), folder, st, it, or --all
    python3 scripts/check_scenarios.py --all --json    # machine output (used by guard.py)

The scenario table is the one whose header starts with `Scenario ID`. Fixed columns, in this order:
    Scenario ID | <Level-1 item> | Area | Requirement | Refs | Scenario | Type | Priority | Technique
(the second header names the level 1 of the pack layout, e.g. Form / Screen, Resource / Endpoint, Target table).

Error   title line missing · no scenario table · bad / duplicate TS ID · Area not in the pack layout ·
        Type / Priority not allowed · empty scenario text
Warning TS IDs out of order · a level-1 item split into several runs · areas out of layout order inside an item ·
        mindmap leaves ≠ table rows · a cited TCOND missing from the analysis · analysis TCONDs / module
        requirements with no scenario · a variant (R10) never named · no Security scenario for security=full
Info    fewer Localization scenarios than project languages (R6.3)
Standard library only.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import qa_config as qc  # noqa: E402

TS_RX = re.compile(r"^TS-\d{3,}$")
TCOND_RX = re.compile(r"\bTCOND-\d{3,}\b")
LEAF_RX = re.compile(r'^\s+\w+\["\[[A-Z0-9]+\]')


def split_row(line: str) -> list[str]:
    cells = re.split(r"(?<!\\)\|", line.strip().strip("|"))
    return [c.strip() for c in cells]


def parse_scenarios(path: Path) -> tuple[list[dict], list[str], dict]:
    """Rows of the scenario table as dicts (with 'line'), the header, and extra info (title, leaves)."""
    lines = path.read_text(encoding="utf-8").splitlines()
    info = {"title": lines[0] if lines else "", "leaves": 0}
    rows, header, in_table, fence = [], [], False, False
    for n, line in enumerate(lines, 1):
        if line.lstrip().startswith("```"):
            fence = not fence
            continue
        if fence:
            if LEAF_RX.match(line):
                info["leaves"] += 1
            continue
        if line.startswith("|") and not in_table and split_row(line)[0].lower() == "scenario id":
            header, in_table = split_row(line), True
            continue
        if in_table:
            if not line.startswith("|"):
                in_table = False
                continue
            cells = split_row(line)
            if set("".join(cells)) <= set("-: "):
                continue
            row = {h: (cells[i] if i < len(cells) else "") for i, h in enumerate(header)}
            row["_item"] = cells[1] if len(cells) > 1 else ""
            row["line"] = n
            rows.append(row)
    return rows, header, info


def col(row: dict, *names: str) -> str:
    for k, v in row.items():
        if any(k.lower().startswith(n) for n in names):
            return v
    return ""


def check(p: dict, t: dict) -> dict:
    res = {"folder": t["rel"], "findings": [], "stats": {}}
    f = t["folder"] / "2-mindmap.md"
    add = lambda sev, chk, ref, msg: res["findings"].append(  # noqa: E731
        {"severity": sev, "check": chk, "ref": ref, "message": msg})
    if not f.is_file():
        res["error"] = "2-mindmap.md not found"
        return res
    rows, header, info = parse_scenarios(f)
    if not re.match(r"^# .+: test mindmap\s*$", info["title"]):
        add("Error", "R5", "title", "first line must be '# <module name>: test mindmap'")
    if not rows:
        add("Error", "R5", "table", "no scenario table (header must start with 'Scenario ID')")
        return res
    packs = [t["pack"]] if t["pack"] else qc.project_packs(p)
    layout = t["layout"]
    allowed_areas = []
    for pk in packs:
        allowed_areas += [a for a in qc.areas(pk, layout) if a not in allowed_areas]
    order = {a: i for i, a in enumerate(allowed_areas)}
    types = qc.test_types(p, packs)
    prios = p["values"]["priorities"]
    seen, last_num, runs, prev_item = set(), 0, {}, None
    area_pos: dict[str, int] = {}
    for r in rows:
        ts, ref = r.get("Scenario ID", ""), f"L{r['line']}"
        if not TS_RX.match(ts):
            add("Error", "IDs", ref, f"bad scenario ID {ts!r}")
            continue
        if ts in seen:
            add("Error", "IDs", ts, "duplicate scenario ID")
        seen.add(ts)
        num = int(ts[3:])
        if num < last_num:
            add("Warning", "IDs", ts, f"out of order after TS-{last_num:03d}")
        last_num = max(last_num, num)
        item, area = r["_item"], col(r, "area")
        if item != prev_item:
            runs[item] = runs.get(item, 0) + 1
            area_pos[item] = -1
            prev_item = item
        if area not in order:
            add("Error", "R5", ts, f"Area {area!r} not in the {'/'.join(packs)} layout ({', '.join(allowed_areas)})")
        else:
            if order[area] < area_pos.get(item, -1):
                add("Warning", "R5", ts, f"area {area!r} after a later area inside [{item}]")
            area_pos[item] = max(area_pos.get(item, -1), order[area])
        typ, pri = col(r, "type"), col(r, "priority")
        if typ not in types:
            add("Error", "R8", ts, f"Type {typ!r} not allowed")
        if pri not in prios:
            add("Error", "R8", ts, f"Priority {pri!r} not allowed")
        if not col(r, "scenario"):
            add("Error", "R4", ts, "empty scenario text")
    for item, n in runs.items():
        if n > 1:
            add("Warning", "R5", item, f"[{item}] split into {n} runs (keep each level-1 item together)")
    if info["leaves"] and info["leaves"] != len(rows):
        add("Warning", "Structure", "mermaid", f"{info['leaves']} mindmap leaves vs {len(rows)} table rows")
    analysis = t["folder"] / "1-analysis.md"
    cited = {m for r in rows for m in TCOND_RX.findall(col(r, "refs", "tcond") + " " + col(r, "scenario"))}
    if analysis.is_file():
        defined = set()
        for line in analysis.read_text(encoding="utf-8").splitlines():
            m = re.match(r"^\|\s*(TCOND-\d{3,})\s*\|", line)
            if m:
                defined.add(m.group(1))
        for c in sorted(cited - defined):
            add("Warning", "Coverage", c, "cited but not defined in 1-analysis.md (write 'TCOND pending' and raise it)")
        missing = sorted(defined - cited)
        if missing:
            add("Warning", "Coverage", "TCOND", f"{len(missing)} analysis TCOND(s) with no scenario: "
                + ", ".join(missing[:25]) + (" …" if len(missing) > 25 else ""))
        res["stats"]["tconds"] = f"{len(defined & cited)}/{len(defined)}"
    if t["module"]:
        m = t["module"]
        reqs = " ".join(col(r, "requirement", "fr", "req") for r in rows)
        miss = [x for x in m.get("refs", []) if x not in reqs]
        if miss:
            add("Warning", "Coverage", "refs", "module requirement(s) with no scenario: " + ", ".join(miss))
        text = " ".join(r["_item"] + " " + col(r, "scenario") for r in rows).lower()
        for vs in m.get("variants", []):
            for v in p["variant_sets"].get(vs, []):
                if v.lower() not in text:
                    add("Warning", "R10", vs, f"variant {v!r} of set {vs!r} is never named")
        if m.get("security", "full") == "full" and not any(col(r, "type") == "Security" for r in rows):
            add("Warning", "R7", "Security", "security=full but no Security scenario")
    langs = p.get("languages", [])
    loc = sum(1 for r in rows if col(r, "type") == "Localization")
    if len(langs) > 1 and loc < len(langs):
        add("Info", "R6.3", "Localization", f"{loc} Localization scenario(s) for {len(langs)} languages")
    res["stats"].update({"scenarios": len(rows), "items": len(runs), "leaves": info["leaves"]})
    return res


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("target", nargs="?")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    p = qc.load_project()
    tgts = qc.resolve(p, None if a.all else (a.target or "all"))
    results = [check(p, t) for t in tgts if a.target or (t["folder"] / "2-mindmap.md").is_file()]
    if a.json:
        print(json.dumps(results, ensure_ascii=False, indent=1))
    else:
        for r in results:
            fs = r["findings"]
            counts = {s: sum(1 for f in fs if f["severity"] == s) for s in ("Error", "Warning", "Info")}
            print(f"\n{r['folder']}: " + (r.get("error") or " · ".join(f"{v} {k}" for k, v in counts.items())
                                          + "  " + " · ".join(f"{k} {v}" for k, v in r.get("stats", {}).items())))
            for f in fs:
                print(f"  {f['severity']:<7} {f['check']:<9} {f['ref']:<14} {f['message']}")
    return 1 if any(f["severity"] == "Error" for r in results for f in r["findings"]) or any(
        r.get("error") for r in results if a.target) else 0


if __name__ == "__main__":
    sys.exit(main())
