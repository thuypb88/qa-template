#!/usr/bin/env python3
"""Extract client documents into Markdown under sources/parsed/, so analyses can cite stable line numbers.

    python3 scripts/extract_text.py                       # every new / changed file under sources/ (not parsed/, trace/)
    python3 scripts/extract_text.py sources/srs/SRS.docx  # one file (or several)
    python3 scripts/extract_text.py --all                 # re-extract everything
    python3 scripts/extract_text.py <file.xlsx> --sheet "<name>"   # print one sheet as a table (no file written)
    python3 scripts/extract_text.py <file.xlsx> --sheets            # list the sheets

Output: sources/parsed/<path under sources/>.md, e.g. sources/parsed/srs/SRS.docx.md, with a "Generated on" line
and the source hash; a file is skipped when its hash is unchanged. Formats: .docx (paragraphs, headings, tables),
.xlsx / .xlsm (every sheet as a table; needs openpyxl, else a plain-zip fallback), .pptx (slide text), .pdf (needs
poppler's pdftotext), .md / .txt / .csv / .json / .yaml (copied). Images are listed, not read: open them with the
Read tool when the analysis needs them. Standard library only (openpyxl optional).
"""
from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / "sources"
PARSED = SOURCES / "parsed"
SKIP_DIRS = {"parsed", "trace"}
TEXT_EXT = {".md", ".txt", ".csv", ".json", ".yaml", ".yml", ".sql", ".xml", ".html"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".svg", ".webp"}
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def cell(v) -> str:
    return "" if v is None else str(v).replace("|", "\\|").replace("\n", "<br>").strip()


def table_md(rows: list[list]) -> list[str]:
    rows = [r for r in rows if any(cell(c) for c in r)]
    if not rows:
        return []
    width = max(len(r) for r in rows)
    rows = [list(r) + [""] * (width - len(r)) for r in rows]
    out = ["| " + " | ".join(cell(c) or " " for c in rows[0]) + " |", "|" + "---|" * width]
    out += ["| " + " | ".join(cell(c) for c in r) + " |" for r in rows[1:]]
    return out


# --- formats ----------------------------------------------------------------------------------------------------

def docx(path: Path) -> list[str]:
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    out = []
    body = root.find(f"{W}body")
    for el in body:
        if el.tag == f"{W}p":
            text = "".join(t.text or "" for t in el.iter(f"{W}t")).strip()
            if not text:
                continue
            style = el.find(f"{W}pPr/{W}pStyle")
            sval = style.get(f"{W}val", "") if style is not None else ""
            m = re.search(r"(?:Heading|heading|Title)\s*(\d)?", sval)
            if m:
                out += ["", "#" * min(int(m.group(1) or 1) + 1, 6) + " " + text, ""]
            elif el.find(f"{W}pPr/{W}numPr") is not None:
                out.append("- " + text)
            else:
                out.append(text)
        elif el.tag == f"{W}tbl":
            rows = [["".join(t.text or "" for t in tc.iter(f"{W}t")) for tc in tr.iter(f"{W}tc")]
                    for tr in el.iter(f"{W}tr")]
            out += [""] + table_md(rows) + [""]
    return out


def xlsx_sheets(path: Path) -> dict[str, list[list]]:
    try:
        import openpyxl  # noqa: PLC0415
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        return {ws.title: [list(r) for r in ws.iter_rows(values_only=True)] for ws in wb.worksheets}
    except ImportError:
        pass
    with zipfile.ZipFile(path) as z:  # fallback: shared strings + inline values, no formatting
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            shared = ["".join(t.text or "" for t in si.iter(f"{S}t"))
                      for si in ET.fromstring(z.read("xl/sharedStrings.xml")).iter(f"{S}si")]
        wbx = ET.fromstring(z.read("xl/workbook.xml"))
        names = [s.get("name") for s in wbx.iter(f"{S}sheet")]
        out = {}
        for i, name in enumerate(names, 1):
            f = f"xl/worksheets/sheet{i}.xml"
            if f not in z.namelist():
                continue
            rows = []
            for row in ET.fromstring(z.read(f)).iter(f"{S}row"):
                vals = []
                for c in row.iter(f"{S}c"):
                    col = re.match(r"[A-Z]+", c.get("r", "A")).group(0)
                    idx = sum((ord(ch) - 64) * 26 ** k for k, ch in enumerate(reversed(col))) - 1
                    while len(vals) < idx:
                        vals.append("")
                    v = c.find(f"{S}v")
                    txt = "".join(t.text or "" for t in c.iter(f"{S}t")) if c.get("t") == "inlineStr" else (
                        shared[int(v.text)] if c.get("t") == "s" and v is not None else (v.text if v is not None else ""))
                    vals.append(txt)
                rows.append(vals)
            out[name] = rows
        return out


def xlsx(path: Path) -> list[str]:
    out = []
    for name, rows in xlsx_sheets(path).items():
        out += ["", f"## Sheet: {name}", ""]
        numbered = [["Row"] + list(rows[0])] + [[i + 2] + list(r) for i, r in enumerate(rows[1:])] if rows else []
        out += table_md(numbered)
    return out


def pptx(path: Path) -> list[str]:
    out = []
    with zipfile.ZipFile(path) as z:
        slides = sorted((n for n in z.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                        key=lambda n: int(re.search(r"(\d+)", n.rsplit("/", 1)[1]).group(1)))
        for n in slides:
            root = ET.fromstring(z.read(n))
            out += ["", f"## Slide {re.search(r'(\d+)', n.rsplit('/', 1)[1]).group(1)}", ""]
            for p in root.iter(f"{A}p"):
                t = "".join(r.text or "" for r in p.iter(f"{A}t")).strip()
                if t:
                    out.append(t)
    return out


def pdf(path: Path) -> list[str]:
    if not shutil.which("pdftotext"):
        raise RuntimeError("pdftotext not found (install poppler-utils)")
    r = subprocess.run(["pdftotext", "-layout", str(path), "-"], capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stderr.strip())
    out = []
    for i, page in enumerate(r.stdout.split("\f"), 1):
        if page.strip():
            out += ["", f"## Page {i}", ""] + [l.rstrip() for l in page.splitlines()]
    return out


def extract(path: Path) -> list[str] | None:
    ext = path.suffix.lower()
    if ext == ".docx":
        return docx(path)
    if ext in (".xlsx", ".xlsm"):
        return xlsx(path)
    if ext == ".pptx":
        return pptx(path)
    if ext == ".pdf":
        return pdf(path)
    if ext in TEXT_EXT:
        return path.read_text(encoding="utf-8", errors="replace").splitlines()
    return None


# --- driver -----------------------------------------------------------------------------------------------------

def out_path(src: Path) -> Path:
    return PARSED / (src.relative_to(SOURCES).as_posix() + ".md")


def candidates() -> list[Path]:
    return sorted(p for p in SOURCES.rglob("*") if p.is_file() and not p.name.startswith(".")
                  and p.relative_to(SOURCES).parts[0] not in SKIP_DIRS and p != SOURCES / "README.md")


def run(files: list[Path], force: bool) -> int:
    done = skipped = failed = 0
    images = []
    for src in files:
        if src.suffix.lower() in IMAGE_EXT:
            images.append(src)
            continue
        dst = out_path(src)
        h = sha(src)
        if not force and dst.is_file() and f"sha256:{h}" in dst.read_text(encoding="utf-8")[:600]:
            skipped += 1
            continue
        try:
            lines = extract(src)
        except Exception as e:  # noqa: BLE001
            print(f"✗ {src.relative_to(ROOT)}: {e}")
            failed += 1
            continue
        if lines is None:
            print(f"- {src.relative_to(ROOT)}: no extractor for {src.suffix}; read it directly")
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        head = [f"# {src.name}", "", f"> Generated on {datetime.now():%Y-%m-%d %H:%M} by scripts/extract_text.py from "
                f"`{src.relative_to(ROOT).as_posix()}` (sha256:{h}). Do not edit; re-run the script.", ""]
        dst.write_text("\n".join(head + lines) + "\n", encoding="utf-8")
        print(f"✓ {dst.relative_to(ROOT)} ({len(lines)} lines)")
        done += 1
    if images:
        print(f"{len(images)} image(s) not extracted (open them with Read when needed): "
              + ", ".join(i.relative_to(SOURCES).as_posix() for i in images[:10]) + (" …" if len(images) > 10 else ""))
    print(f"extract_text: {done} written · {skipped} unchanged · {failed} failed")
    return 1 if failed else 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="*", type=Path)
    ap.add_argument("--all", action="store_true", help="re-extract every file")
    ap.add_argument("--sheet", help="print one sheet of an .xlsx as a Markdown table")
    ap.add_argument("--sheets", action="store_true", help="list the sheets of an .xlsx")
    a = ap.parse_args()
    if a.sheet or a.sheets:
        if len(a.files) != 1:
            ap.error("--sheet / --sheets take exactly one .xlsx file")
        sheets = xlsx_sheets(a.files[0])
        if a.sheets:
            for n, rows in sheets.items():
                print(f"{n}  ({len(rows)} rows)")
            return 0
        if a.sheet not in sheets:
            sys.exit(f"No sheet {a.sheet!r}; sheets: {', '.join(sheets)}")
        rows = sheets[a.sheet]
        print("\n".join(table_md([["Row"] + list(rows[0])] + [[i + 2] + list(r) for i, r in enumerate(rows[1:])])))
        return 0
    files = [f.resolve() for f in a.files] if a.files else candidates()
    return run(files, force=a.all or bool(a.files))


if __name__ == "__main__":
    sys.exit(main())
