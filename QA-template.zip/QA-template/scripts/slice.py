#!/usr/bin/env python3
"""Read only the part of a large artifact you need, to keep agent context small.

A big module easily reaches a 1 MB test-cases.json and a 300 KB analysis: far more than a skill needs at once.
Read the map first, then the pieces.

Markdown (1-analysis.md, 2-mindmap.md, reviews, sources)
    python3 scripts/slice.py toc <file.md>                   headings with line range and size (KB)
    python3 scripts/slice.py section <file.md> "<heading>"   one section, sub-sections included; the heading is
                                                             matched as a case-insensitive substring ("5.2", "Data & field")
    python3 scripts/slice.py rows <file.md> <ID> [<ID> …]    the table rows / lines that cite these IDs (TCOND-031,
                                                             FR-004, TS-120, Q-010 …), with line numbers

Test cases (3-test-cases/test-cases.json; give a module id from project.json, the folder, st, or the JSON path)
    python3 scripts/slice.py tc <module> --list              one line per TC: id · scenario · type · priority · title
    python3 scripts/slice.py tc <module> --stats             counts by title prefix [Form / Screen], type, priority,
                                                             automation; first and last TC ID
    python3 scripts/slice.py tc <module> [filters] [--fields f1,f2]
                                                             full TCs, compact: steps paired with expected results
        filters (combined with AND): --ids TC-E4-001,TC-E4-007 · --scenario TS-012[,TS-013] · --form "<title prefix>"
                                     · --priority P1 · --type Negative · --grep <regex on the whole TC> · --limit N
    python3 scripts/slice.py tc <module> --patterns          scan the WHOLE suite for templated bodies: step text
                                                             repeated across many TCs, unfilled {…} placeholders,
                                                             "Adapted from", expected results that copy the title,
                                                             steps ≠ expected counts, near-duplicate bodies
Standard library only.
"""
import argparse
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HEADING = re.compile(r"^(#{1,6})\s+(.*)$")


# --- Markdown ---------------------------------------------------------------------------------------------------

def headings(lines):
    out, fence = [], False
    for i, line in enumerate(lines):
        if line.lstrip().startswith("```"):
            fence = not fence
        m = None if fence else HEADING.match(line)
        if m:
            out.append((i, len(m.group(1)), m.group(2).strip()))
    return out


def section_end(heads, k, n_lines):
    level = heads[k][1]
    return next((h[0] for h in heads[k + 1:] if h[1] <= level), n_lines)


def cmd_toc(path):
    lines = path.read_text(encoding="utf-8").splitlines()
    heads = headings(lines)
    print(f"{path} · {len(lines)} lines · {path.stat().st_size / 1024:.0f} KB")
    for k, (i, level, text) in enumerate(heads):
        end = section_end(heads, k, len(lines))
        size = sum(len(l) + 1 for l in lines[i:end]) / 1024
        print(f"{'  ' * (level - 1)}{text}  [L{i + 1}-{end}, {size:.1f} KB]")


def cmd_section(path, query):
    lines = path.read_text(encoding="utf-8").splitlines()
    heads = headings(lines)
    q = query.lower()
    hits = [k for k, h in enumerate(heads) if q in h[2].lower()]
    if not hits:
        sys.exit(f"No heading contains {query!r}. Run: python3 scripts/slice.py toc {path}")
    k = hits[0]
    end = section_end(heads, k, len(lines))
    if len(hits) > 1:
        others = ", ".join(f"{heads[h][2]!r} (L{heads[h][0] + 1})" for h in hits[1:6])
        print(f"<!-- {len(hits)} headings match; showing the first. Others: {others} -->")
    print(f"<!-- {path}:{heads[k][0] + 1}-{end} -->")
    print("\n".join(lines[heads[k][0]:end]))


def cmd_rows(path, ids):
    pattern = re.compile("|".join(rf"\b{re.escape(i)}\b" for i in ids))
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if pattern.search(line):
            print(f"{n}: {line}")


# --- test cases -------------------------------------------------------------------------------------------------

def find_json(target):
    p = Path(target)
    if p.suffix == ".json" and p.is_file():
        return p
    try:
        sys.path.insert(0, str(ROOT / "scripts"))
        import qa_config
        return qa_config.resolve(qa_config.load_project(), target)[0]["folder"] / "3-test-cases/test-cases.json"
    except Exception as e:  # noqa: BLE001 - fall back to a plain folder path
        if not p.is_absolute():
            p = ROOT / p if (ROOT / p).exists() else p
        if p.is_dir():
            return p / "3-test-cases/test-cases.json"
        sys.exit(f"No test-cases.json for {target!r} ({e})")


def as_list(v):
    if v is None or v == "":
        return []
    return v if isinstance(v, list) else [v]


def text_of(tc):
    return json.dumps(tc, ensure_ascii=False)


def prefix(title):
    m = re.match(r"\[([^\]]+)\]", title or "")
    return m.group(1) if m else "(no prefix)"


def render(tc, fields):
    out = [f"## {tc.get('tc_id')} · {tc.get('scenario_id', '')} · {tc.get('test_type', '')} · "
           f"{tc.get('priority', '')} · auto={tc.get('automation', '-')}", tc.get("title", "")]
    skip = {"tc_id", "scenario_id", "test_type", "priority", "title", "automation", "steps", "expected_result"}
    for key, val in tc.items():
        if key in skip or (fields and key not in fields) or val in (None, "", [], {}):
            continue
        if isinstance(val, dict):
            out.append(f"{key}: " + " · ".join(f"{k} = {v}" for k, v in val.items()))
        elif isinstance(val, list) and key == "preconditions":
            out.append(f"{key}:" + "".join(f"\n  - {v}" for v in val))
        else:
            out.append(f"{key}: {', '.join(map(str, val)) if isinstance(val, list) else val}")
    if not fields or "steps" in fields or "expected_result" in fields:
        steps, exp = as_list(tc.get("steps")), as_list(tc.get("expected_result"))
        for i in range(max(len(steps), len(exp))):
            s = steps[i] if i < len(steps) else "—"
            e = exp[i] if i < len(exp) else "—"
            out.append(f"  {i + 1}. {s}\n     → {e}")
    return "\n".join(out)


def patterns(tcs):
    n = len(tcs)
    steps = defaultdict(set)
    for tc in tcs:
        for s in as_list(tc.get("steps")):
            steps[str(s).strip().lower()].add(tc["tc_id"])
    common = sorted(((len(v), s) for s, v in steps.items() if len(v) >= max(5, n // 10)), reverse=True)
    print(f"# Templated-pattern scan · {n} TCs")
    print(f"\n## Step text repeated in ≥ {max(5, n // 10)} TCs (normal for set-up steps; suspicious for checks)")
    for c, s in common[:20]:
        print(f"- {c}× {s[:140]}")
    checks = {
        "unfilled placeholder {…}": lambda tc: re.search(r"\{[^{}\"]{1,40}\}", " ".join(
            map(str, as_list(tc.get("steps")) + as_list(tc.get("expected_result"))))),
        '"Adapted from"': lambda tc: "adapted from" in text_of(tc).lower(),
        "steps ≠ expected results count": lambda tc: len(as_list(tc.get("steps"))) != len(
            as_list(tc.get("expected_result"))),
        "expected result repeats the title": lambda tc: any(
            re.sub(r"^\[[^\]]+\]\s*", "", tc.get("title", "")).lower()[:40] in str(e).lower()
            for e in as_list(tc.get("expected_result"))) and len(tc.get("title", "")) > 20,
        "one step only": lambda tc: len(as_list(tc.get("steps"))) == 1,
    }
    for name, fn in checks.items():
        ids = [tc["tc_id"] for tc in tcs if fn(tc)]
        print(f"\n## {name}: {len(ids)}")
        if ids:
            print(", ".join(ids[:60]) + (f" … +{len(ids) - 60}" if len(ids) > 60 else ""))
    bodies = defaultdict(list)
    for tc in tcs:
        key = json.dumps([as_list(tc.get("steps")), as_list(tc.get("expected_result"))], ensure_ascii=False).lower()
        bodies[re.sub(r"\d+", "#", key)].append(tc["tc_id"])
    dupes = [v for v in bodies.values() if len(v) > 1]
    print(f"\n## Same steps + expected results (numbers ignored): {len(dupes)} group(s)")
    for v in sorted(dupes, key=len, reverse=True)[:20]:
        print("- " + ", ".join(v[:12]) + (f" … +{len(v) - 12}" if len(v) > 12 else ""))


def cmd_tc(a):
    path = find_json(a.target)
    data = json.loads(path.read_text(encoding="utf-8"))
    tcs = data.get("test_cases", [])
    if a.patterns:
        return patterns(tcs)
    if a.stats:
        print(f"{path.relative_to(ROOT) if path.is_relative_to(ROOT) else path} · version {data.get('version')} · "
              f"{len(tcs)} TCs · {tcs[0]['tc_id'] if tcs else '-'} … {tcs[-1]['tc_id'] if tcs else '-'}")
        for key, fn in (("Form / Screen (title prefix)", lambda t: prefix(t.get("title"))),
                        ("test_type", lambda t: t.get("test_type")), ("priority", lambda t: t.get("priority")),
                        ("automation", lambda t: t.get("automation")), ("status", lambda t: t.get("status"))):
            print(f"\n{key}: " + " · ".join(f"{k} {v}" for k, v in Counter(map(fn, tcs)).most_common()))
        return
    ids = {i.strip() for i in a.ids.split(",")} if a.ids else None
    scen = {s.strip() for s in a.scenario.split(",")} if a.scenario else None
    rx = re.compile(a.grep, re.I) if a.grep else None
    sel = [t for t in tcs
           if (not ids or t.get("tc_id") in ids)
           and (not scen or t.get("scenario_id") in scen)
           and (not a.form or a.form.lower() in prefix(t.get("title")).lower())
           and (not a.priority or str(t.get("priority", "")).startswith(a.priority))
           and (not a.type or t.get("test_type") == a.type)
           and (not rx or rx.search(text_of(t)))]
    if a.limit:
        sel = sel[:a.limit]
    if a.list:
        for t in sel:
            print(f"{t.get('tc_id')} · {t.get('scenario_id', '')} · {t.get('test_type', '')} · "
                  f"{str(t.get('priority', ''))[:2]} · {t.get('title', '')}")
    else:
        fields = set(a.fields.split(",")) if a.fields else None
        print("\n\n".join(render(t, fields) for t in sel))
    print(f"\n<!-- {len(sel)} of {len(tcs)} TCs · {path.name} v{data.get('version')} -->")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("toc"); s.add_argument("file", type=Path)
    s = sub.add_parser("section"); s.add_argument("file", type=Path); s.add_argument("heading")
    s = sub.add_parser("rows"); s.add_argument("file", type=Path); s.add_argument("ids", nargs="+")
    s = sub.add_parser("tc"); s.add_argument("target")
    for flag in ("--list", "--stats", "--patterns"):
        s.add_argument(flag, action="store_true")
    for opt in ("--ids", "--scenario", "--form", "--priority", "--type", "--grep", "--fields"):
        s.add_argument(opt)
    s.add_argument("--limit", type=int)
    a = ap.parse_args()
    if a.cmd == "toc":
        cmd_toc(a.file)
    elif a.cmd == "section":
        cmd_section(a.file, a.heading)
    elif a.cmd == "rows":
        cmd_rows(a.file, a.ids)
    else:
        cmd_tc(a)


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        pass
