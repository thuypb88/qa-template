#!/usr/bin/env python3
"""API pack: turn an OpenAPI 3 / Swagger 2 spec (or a Postman v2 collection) into an endpoint inventory.

    python3 scripts/parsers/openapi_inventory.py sources/api/orders-openapi.json
    python3 scripts/parsers/openapi_inventory.py sources/api/orders.yaml --out sources/parsed/api/orders-inventory.md

Writes sources/parsed/api/<name>-inventory.md (default): one row per METHOD path (endpoint, operationId, summary,
auth, parameters, request schema, response codes), then one field table per schema (JSON path, type, required,
format / enum / range). The analysis's §3 Endpoint inventory and §5 field tables cite its lines.
JSON needs only the standard library; YAML needs PyYAML (pip install pyyaml).
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
METHODS = ("get", "post", "put", "patch", "delete", "head", "options")


def load(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in (".yaml", ".yml"):
        try:
            import yaml  # noqa: PLC0415
        except ImportError:
            sys.exit("YAML spec: pip install pyyaml, or convert it to JSON first")
        return yaml.safe_load(text)
    return json.loads(text)


def ref_name(ref: str) -> str:
    return ref.rsplit("/", 1)[-1]


def resolve(spec: dict, node: dict | None) -> dict:
    seen = 0
    while isinstance(node, dict) and "$ref" in node and seen < 20:
        cur = spec
        for part in node["$ref"].lstrip("#/").split("/"):
            cur = cur.get(part, {})
        node, seen = cur, seen + 1
    return node or {}


def schema_label(spec: dict, s: dict | None) -> str:
    if not s:
        return "—"
    if "$ref" in s:
        return ref_name(s["$ref"])
    if s.get("type") == "array":
        return f"array of {schema_label(spec, s.get('items'))}"
    return s.get("type", "object")


def fields(spec: dict, s: dict, prefix: str = "$", depth: int = 0) -> list[list[str]]:
    s = resolve(spec, s)
    rows = []
    if depth > 6:
        return rows
    for k in ("allOf", "oneOf", "anyOf"):
        for sub in s.get(k, []):
            rows += fields(spec, sub, prefix, depth + 1)
    req = set(s.get("required", []))
    for name, prop in (s.get("properties") or {}).items():
        p = resolve(spec, prop)
        rules = []
        for key in ("format", "pattern", "minLength", "maxLength", "minimum", "maximum", "minItems", "maxItems",
                    "default"):
            if key in p:
                rules.append(f"{key}={p[key]}")
        if "enum" in p:
            rules.append("enum=" + "/".join(map(str, p["enum"])))
        path = f"{prefix}.{name}"
        rows.append([path, schema_label(spec, prop), "yes" if name in req else "no", ", ".join(rules) or "—",
                     "read-only" if p.get("readOnly") else ""])
        if p.get("type") == "object" or "properties" in p:
            rows += fields(spec, p, path, depth + 1)
        elif p.get("type") == "array":
            rows += fields(spec, p.get("items", {}), path + "[]", depth + 1)
    return rows


def openapi_rows(spec: dict) -> tuple[list[list[str]], set[str]]:
    rows, schemas = [], set()
    global_sec = spec.get("security")
    for path, item in (spec.get("paths") or {}).items():
        shared = item.get("parameters", [])
        for m in METHODS:
            op = item.get(m)
            if not op:
                continue
            params = [resolve(spec, p) for p in shared + op.get("parameters", [])]
            plist = ", ".join(f"{p.get('name')} ({p.get('in')}{', req' if p.get('required') else ''})" for p in params)
            body = "—"
            rb = resolve(spec, op.get("requestBody"))
            for media in (rb.get("content") or {}).values():
                body = schema_label(spec, media.get("schema"))
                if "$ref" in (media.get("schema") or {}):
                    schemas.add(ref_name(media["schema"]["$ref"]))
                break
            for p in params:  # swagger 2 body param
                if p.get("in") == "body":
                    body = schema_label(spec, p.get("schema"))
            codes = []
            for code, resp in (op.get("responses") or {}).items():
                resp = resolve(spec, resp)
                sch = next((c.get("schema") for c in (resp.get("content") or {}).values()), resp.get("schema"))
                if sch and "$ref" in sch:
                    schemas.add(ref_name(sch["$ref"]))
                codes.append(f"{code}{' ' + schema_label(spec, sch) if sch else ''}")
            sec = op.get("security", global_sec)
            auth = "none" if sec == [] else ", ".join(k for s in (sec or []) for k in s) or "—"
            rows.append([f"{m.upper()} {path}", op.get("operationId", ""), (op.get("summary") or "").strip(), auth,
                         plist or "—", body, "; ".join(codes) or "—"])
    return rows, schemas


def postman_rows(coll: dict) -> list[list[str]]:
    rows = []

    def walk(items, folder=""):
        for it in items:
            if "item" in it:
                walk(it["item"], f"{folder}{it.get('name', '')}/")
                continue
            req = it.get("request", {})
            url = req.get("url", {})
            raw = url.get("raw", url) if isinstance(url, dict) else url
            rows.append([f"{req.get('method', 'GET')} {raw}", folder + it.get("name", ""), "",
                         (req.get("auth") or {}).get("type", "—"), "—", (req.get("body") or {}).get("mode", "—"), "—"])
    walk(coll.get("item", []))
    return rows


def esc(v: str) -> str:
    return str(v).replace("|", "\\|").replace("\n", " ")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("spec", type=Path)
    ap.add_argument("--out", type=Path)
    a = ap.parse_args()
    spec = load(a.spec)
    out = a.out or ROOT / "sources/parsed/api" / f"{a.spec.stem}-inventory.md"
    lines = [f"# API inventory: {a.spec.name}", "",
             f"> Generated on {datetime.now():%Y-%m-%d %H:%M} by scripts/parsers/openapi_inventory.py from "
             f"`{a.spec.as_posix()}`. Do not edit; re-run the script.", ""]
    if "info" in spec and ("paths" in spec):
        info = spec["info"]
        lines += [f"**API:** {info.get('title', '')} · **version** {info.get('version', '')} · "
                  f"**spec** {spec.get('openapi') or spec.get('swagger')}", ""]
        rows, schemas = openapi_rows(spec)
    elif "item" in spec:
        rows, schemas = postman_rows(spec), set()
        lines += ["**Postman collection** (no schemas: add the OpenAPI spec for field tables).", ""]
    else:
        sys.exit("Not an OpenAPI / Swagger spec or a Postman collection")
    lines += ["## Endpoints", "", "| # | Endpoint | operationId | Summary | Auth | Parameters | Request body | Responses |",
              "|---|---|---|---|---|---|---|---|"]
    lines += [f"| {i} | " + " | ".join(esc(c) for c in r) + " |" for i, r in enumerate(rows, 1)]
    comps = (spec.get("components") or {}).get("schemas") or spec.get("definitions") or {}
    for name in sorted(schemas | set(comps)):
        if name not in comps:
            continue
        lines += ["", f"## Schema: {name}", "", "| JSON path | Type | Required | Rules | Note |", "|---|---|---|---|---|"]
        lines += ["| " + " | ".join(esc(c) for c in r) + " |" for r in fields(spec, comps[name])]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"✓ {out.relative_to(ROOT) if out.is_relative_to(ROOT) else out}: {len(rows)} endpoint(s), "
          f"{len([s for s in schemas | set(comps) if s in comps])} schema(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
