#!/usr/bin/env python3
"""ETL pack: turn a source-to-target mapping workbook (STTM) into a mapping inventory with stable rule IDs.

    python3 scripts/parsers/sttm_inventory.py sources/etl/Customer_STTM_v1.xlsx
    python3 scripts/parsers/sttm_inventory.py <file.xlsx|.csv> --sheet "Mapping" --out sources/parsed/etl/x.md

Finds the header row and columns by name (aliases below; override with --map "target_table=Tgt Table,..."), then
writes sources/parsed/etl/<name>-inventory.md:
  - a target-table summary (columns mapped, keys, source tables, rules);
  - one table per target table, one row per target column with rule ID MAP-<TABLE>-<nn> (numbered in workbook order,
    so IDs stay stable while rows are only appended), the source column(s), transformation, key / null / default,
    and the workbook row for citations.
IDs shift if rows are inserted in the middle: plan-changes reports it, and the analysis keeps its old IDs.
Needs openpyxl for .xlsx (CSV works with the standard library).
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from collections import OrderedDict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ALIASES = {
    "target_table": ["target table", "tgt table", "target entity", "target object", "to table"],
    "target_column": ["target column", "tgt column", "target field", "target attribute", "to column"],
    "source_table": ["source table", "src table", "source entity", "source object", "from table", "source file"],
    "source_column": ["source column", "src column", "source field", "source attribute", "from column"],
    "rule": ["transformation", "transformation rule", "business rule", "rule", "logic", "derivation", "mapping rule"],
    "type": ["target data type", "data type", "target type", "type"],
    "key": ["key", "pk", "primary key", "business key", "key type"],
    "nullable": ["nullable", "null", "mandatory", "not null"],
    "default": ["default", "default value", "unknown value"],
    "notes": ["comments", "comment", "notes", "remarks"],
}


def norm(s) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


def read_rows(path: Path, sheet: str | None) -> list[list]:
    if path.suffix.lower() == ".csv":
        with path.open(encoding="utf-8-sig", newline="") as f:
            return [r for r in csv.reader(f)]
    try:
        import openpyxl  # noqa: PLC0415
    except ImportError:
        sys.exit("pip install openpyxl (or export the sheet to CSV)")
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    if sheet:
        ws = wb[sheet]
    else:  # the sheet whose first 15 rows best match the aliases
        def score(ws):
            best = 0
            for r in ws.iter_rows(max_row=15, values_only=True):
                cells = {norm(c) for c in r}
                best = max(best, sum(any(a in cells for a in al) for al in ALIASES.values()))
            return best
        ws = max(wb.worksheets, key=score)
    print(f"sheet: {ws.title}")
    return [list(r) for r in ws.iter_rows(values_only=True)]


def find_header(rows: list[list], overrides: dict[str, str]) -> tuple[int, dict[str, int]]:
    for i, r in enumerate(rows[:30]):
        cells = [norm(c) for c in r]
        cols = {}
        for key, al in ALIASES.items():
            names = [norm(overrides[key])] if key in overrides else al
            for n in names:
                if n in cells:
                    cols[key] = cells.index(n)
                    break
        if "target_table" in cols and "target_column" in cols:
            return i, cols
    sys.exit("No header row with a target table and a target column. Use --map target_table=<header>,...")


def esc(v) -> str:
    return str(v if v is not None else "").replace("|", "\\|").replace("\n", "<br>").strip()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", type=Path)
    ap.add_argument("--sheet")
    ap.add_argument("--map", default="", help="key=Header,key=Header (keys: " + ", ".join(ALIASES) + ")")
    ap.add_argument("--out", type=Path)
    a = ap.parse_args()
    overrides = dict(kv.split("=", 1) for kv in a.map.split(",") if "=" in kv)
    rows = read_rows(a.file, a.sheet)
    h, cols = find_header(rows, overrides)
    get = lambda r, k: (r[cols[k]] if k in cols and cols[k] < len(r) else None)  # noqa: E731
    tables: "OrderedDict[str, list]" = OrderedDict()
    last_table = None
    for n, r in enumerate(rows[h + 1:], start=h + 2):
        tt = get(r, "target_table") or last_table  # merged cells: carry the table down
        tc = get(r, "target_column")
        if not tt or not tc:
            continue
        last_table = tt
        key = re.sub(r"[^A-Za-z0-9_]", "_", str(tt).strip()).upper()
        tables.setdefault(key, []).append((n, r))
    out = a.out or ROOT / "sources/parsed/etl" / f"{a.file.stem}-inventory.md"
    lines = [f"# Mapping inventory: {a.file.name}", "",
             f"> Generated on {datetime.now():%Y-%m-%d %H:%M} by scripts/parsers/sttm_inventory.py from "
             f"`{a.file.as_posix()}`. Do not edit; re-run the script. Columns found: "
             + ", ".join(f"{k}=col {v + 1}" for k, v in cols.items()), "",
             "## Target tables", "", "| Target table | Columns | Keys | Source tables | Rules |", "|---|---|---|---|---|"]
    for t, items in tables.items():
        keys = [esc(get(r, "target_column")) for _, r in items if norm(get(r, "key")) not in ("", "n", "no", "none")]
        srcs = sorted({esc(get(r, "source_table")) for _, r in items if get(r, "source_table")})
        rules = f"MAP-{t}-01 … MAP-{t}-{len(items):02d}" if len(items) > 1 else f"MAP-{t}-01"
        lines.append(f"| {t} | {len(items)} | {', '.join(keys) or '—'} | {', '.join(srcs) or '—'} | {rules} |")
    total = 0
    for t, items in tables.items():
        lines += ["", f"## {t}", "", "| Rule ID | Target column | Type | Key | Nullable | Source | Transformation | "
                  "Default | Notes | Row |", "|---|---|---|---|---|---|---|---|---|---|"]
        for i, (n, r) in enumerate(items, 1):
            src = ".".join(esc(x) for x in (get(r, "source_table"), get(r, "source_column")) if x)
            lines.append(f"| MAP-{t}-{i:02d} | {esc(get(r, 'target_column'))} | {esc(get(r, 'type'))} | "
                         f"{esc(get(r, 'key'))} | {esc(get(r, 'nullable'))} | {src or '—'} | {esc(get(r, 'rule')) or '—'} | "
                         f"{esc(get(r, 'default'))} | {esc(get(r, 'notes'))} | {n} |")
            total += 1
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"✓ {out.relative_to(ROOT) if out.is_relative_to(ROOT) else out}: {len(tables)} target table(s), {total} rule(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
