#!/usr/bin/env python3
"""Shared loader for project.json and the test-type packs. Every other script imports it.

project.json is the only project-specific file the scripts read. Packs (packs/<name>/pack.json) hold what differs
per test type (UI, API, ETL, SQL): layouts, areas, extra test types, the TC block and the forbidden-term check.

    python3 scripts/qa_config.py             # print the resolved targets (folder · level · pack)
    python3 scripts/qa_config.py --validate  # validate project.json and the packs; exit 1 on an error
Standard library only.
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROJECT_FILE = ROOT / "project.json"
PACKS_DIR = ROOT / "packs"

DEFAULT_VALUES = {
    "test_types": ["Functional", "Regression", "Boundary", "Negative", "E2E", "Smoke", "Sanity", "Exploratory",
                   "Security", "Performance", "Localization", "Accessibility"],
    "priorities": ["P1 - Critical", "P2 - High", "P3 - Medium", "P4 - Low"],
    "statuses": ["Not Started", "In Progress", "Passed", "Failed", "Blocked", "Skipped"],
    "automation": ["Auto", "Manual", "Auto + Manual"],
}
DEFAULT_IDS = {
    "module_folder": "MOD-{id}-{slug}",
    "tc": "TC-{id}-{n:03d}",
    "st_tc": "TC-ST-{n:03d}",
    "scenario": "TS-{n:03d}",
    "condition": "TCOND-{n:03d}",
    "question": "Q-{n:03d}",
    "st_question": "Q-ST-{n:03d}",
}
LAYOUTS = {"form", "flow", "resource", "table", "job"}


class ConfigError(Exception):
    pass


# --- loading ----------------------------------------------------------------------------------------------------

def load_project(path: Path = PROJECT_FILE) -> dict:
    if not path.is_file():
        raise ConfigError(f"{path.name} not found. Copy one of the template's template-dev/examples/*.project.json or run the plan-setup skill.")
    try:
        p = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ConfigError(f"{path.name}: invalid JSON ({e})") from e
    p.setdefault("values", {})
    for k, v in DEFAULT_VALUES.items():
        p["values"].setdefault(k, list(v))
    p["ids"] = {**DEFAULT_IDS, **p.get("ids", {})}
    p.setdefault("modules", [])
    p.setdefault("levels", {"IT": {"env": "SIT", "externals": "mock", "folder": "test-design/it"},
                            "ST": {"env": "UAT", "externals": "real", "folder": "test-design/st"}})
    p.setdefault("languages", ["EN"])
    p.setdefault("variant_sets", {})
    p.setdefault("protected_paths", [])
    p.setdefault("git", {"local_only": True})
    return p


_PACK_CACHE: dict[str, dict] = {}


def load_pack(name: str) -> dict:
    if name not in _PACK_CACHE:
        f = PACKS_DIR / name / "pack.json"
        if not f.is_file():
            raise ConfigError(f"pack {name!r} not found ({f.relative_to(ROOT)})")
        _PACK_CACHE[name] = json.loads(f.read_text(encoding="utf-8"))
    return _PACK_CACHE[name]


def project_packs(p: dict) -> list[str]:
    names = sorted({m.get("pack", "ui") for m in p["modules"]})
    return names or ["ui"]


# --- values -----------------------------------------------------------------------------------------------------

def test_types(p: dict, packs: list[str]) -> list[str]:
    out = list(p["values"]["test_types"])
    for name in packs:
        out += [t for t in load_pack(name).get("extra_test_types", []) if t not in out]
    return out


def areas(pack_name: str, layout: str | None = None) -> list[str]:
    pack = load_pack(pack_name)
    lays = pack["layouts"]
    names = [layout] if layout in lays else list(lays)
    out = []
    for n in names:
        out += [a for a in lays[n]["areas"] if a not in out]
    return out + [a for a in pack.get("cross_cutting_areas", []) if a not in out]


def id_regex(template: str, **fixed) -> re.Pattern:
    """TC-{id}-{n:03d} with id=E4 → ^TC\\-E4\\-\\d{3,}$ ; unknown fields match \\w+."""
    out, i = "", 0
    for m in re.finditer(r"\{(\w+)(?::0?(\d+)d)?\}", template):
        out += re.escape(template[i:m.start()])
        name, width = m.group(1), m.group(2)
        if name == "n":
            out += rf"\d{{{width or 1},}}"
        elif name in fixed:
            out += re.escape(str(fixed[name]))
        else:
            out += r"[\w.-]+"
        i = m.end()
    return re.compile("^" + out + re.escape(template[i:]) + "$")


def now_stamp(p: dict | None = None) -> str:
    tz = (p or {}).get("project", {}).get("timezone", "UTC+7")
    m = re.fullmatch(r"UTC([+-]\d{1,2})(?::?(\d{2}))?", tz)
    off = timedelta(hours=int(m.group(1)), minutes=int(m.group(2) or 0)) if m else timedelta(0)
    return datetime.now(timezone(off)).strftime("%Y-%m-%d %H:%M")


# --- targets ----------------------------------------------------------------------------------------------------

def module_folder(p: dict, m: dict) -> Path:
    base = p["levels"].get("IT", {}).get("folder", "test-design/it")
    return ROOT / base / p["ids"]["module_folder"].format(**m)


def st_folder(p: dict) -> Path:
    return ROOT / p["levels"].get("ST", {}).get("folder", "test-design/st")


def suite_name(folder: str | Path) -> str:
    """Name of a suite in Excel files and tags: the folder name, or the level key (IT / ST) when the folder is
    named after it (test-design/st → ST_Test_Cases_v0.1.xlsx, tag tc/ST/v0.1)."""
    name = Path(folder).name
    return name.upper() if name.lower() in ("it", "st") else name


def targets(p: dict) -> list[dict]:
    """Every level folder: IT modules first, then the ST folder."""
    out = []
    for m in p["modules"]:
        f = module_folder(p, m)
        out.append({"key": m["id"], "folder": f, "rel": f.relative_to(ROOT).as_posix(), "level": "IT",
                    "module": m, "pack": m.get("pack", "ui"), "layout": m.get("layout"),
                    "name": m.get("name", f"{m['id']} - {m.get('slug', '')}")})
    if "ST" in p["levels"]:
        f = st_folder(p)
        out.append({"key": "ST", "folder": f, "rel": f.relative_to(ROOT).as_posix(), "level": "ST", "module": None,
                    "pack": None, "layout": None, "name": p.get("project", {}).get("name", "System") + " - System Test"})
    return out


def resolve(p: dict, target: str | None) -> list[dict]:
    """'all' / None, 'it', 'st', a module id (E4), the folder name (MOD-E4-…), MOD-E4, or a path."""
    ts = targets(p)
    if target in (None, "", "all", "--all"):
        return ts
    t = target.strip().rstrip("/")
    if t.lower() == "it":
        return [x for x in ts if x["level"] == "IT"]
    if t.lower() in ("st", "system-test", "test-design/st"):
        return [x for x in ts if x["level"] == "ST"]
    for x in ts:
        names = {x["key"].lower(), x["folder"].name.lower(), x["rel"].lower(), str(x["folder"]).lower()}
        if x["module"]:
            names.add(f"mod-{x['key']}".lower())
        if t.lower() in names or (Path(t).resolve() == x["folder"].resolve()):
            return [x]
    raise ConfigError(f"unknown target {target!r}; known: " + ", ".join(x["key"] for x in ts))


def tc_pattern(p: dict, tgt: dict) -> re.Pattern:
    if tgt["level"] == "ST":
        return id_regex(p["ids"]["st_tc"])
    return id_regex(p["ids"]["tc"], **tgt["module"])


def tc_pack(tc: dict, tgt: dict, p: dict) -> str:
    """The pack a TC belongs to: its own `pack`, its api / etl block, the module pack, else the first project pack."""
    if tc.get("pack"):
        return tc["pack"]
    for name in ("api", "etl"):
        if isinstance(tc.get(name), dict):
            return name
    return tgt["pack"] or ("ui" if "ui" in project_packs(p) else project_packs(p)[0])


# --- validation -------------------------------------------------------------------------------------------------

def validate(p: dict) -> list[str]:
    errs = []
    for key in ("project", "modules"):
        if key not in p:
            errs.append(f"missing top-level key {key!r}")
    if not p.get("project", {}).get("code"):
        errs.append("project.code is required (short name used in backups, e.g. ALPHA)")
    seen = set()
    for i, m in enumerate(p.get("modules", [])):
        where = f"modules[{i}]"
        for k in ("id", "slug", "name", "pack", "layout"):
            if not m.get(k):
                errs.append(f"{where}: missing {k!r}")
        if m.get("id") in seen:
            errs.append(f"{where}: duplicate id {m.get('id')!r}")
        seen.add(m.get("id"))
        if m.get("slug") and not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", m["slug"]):
            errs.append(f"{where}: slug {m['slug']!r} must be kebab-case")
        try:
            pack = load_pack(m.get("pack", "ui"))
            if m.get("layout") and m["layout"] not in pack["layouts"]:
                errs.append(f"{where}: layout {m['layout']!r} not in pack {m['pack']!r} "
                            f"({', '.join(pack['layouts'])})")
        except ConfigError as e:
            errs.append(f"{where}: {e}")
        if m.get("security") not in (None, "full", "limited", "none"):
            errs.append(f"{where}: security must be full | limited | none")
    if any(m.get("pack") == "sql" for m in p.get("modules", [])):
        d = p.get("sql", {}).get("dialect")
        if d not in ("sqlserver", "oracle", "postgres", "mysql", "sqlite"):
            errs.append(f"sql.dialect {d!r}: a sql-pack module needs sqlserver | oracle | postgres | mysql "
                        "(sqlite: self-test only); see packs/sql/dialects.md")
    for name, vs in p.get("variant_sets", {}).items():
        if not isinstance(vs, list) or not vs:
            errs.append(f"variant_sets.{name}: must be a non-empty list")
    for k in p["values"]:
        if not isinstance(p["values"][k], list):
            errs.append(f"values.{k}: must be a list")
    return errs


def main(argv: list[str]) -> int:
    try:
        p = load_project()
    except ConfigError as e:
        print(f"✗ {e}")
        return 1
    if "--validate" in argv:
        errs = validate(p)
        for e in errs:
            print(f"✗ {e}")
        print(f"project.json: {'OK' if not errs else f'{len(errs)} error(s)'} · {len(p['modules'])} module(s) · "
              f"packs {', '.join(project_packs(p))}")
        return 1 if errs else 0
    for t in targets(p):
        print(f"{t['key']:<6} {t['level']}  {t['pack'] or '(mixed)':<5} {t['layout'] or '-':<9} {t['rel']}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
