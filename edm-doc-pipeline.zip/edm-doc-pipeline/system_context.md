Project: <name>
Flow: Source File (<vendor/format, e.g. Bloomberg .out>) -> ETL Pipeline (Markit EDM data porters / inspectors / constructors)
      -> EDM backend (<database>, master tables) -> EDM web app (<who uses it, what for>) -> Downstream (<consumers>)
Business domain: <e.g. security master, pricing, corporate actions>
Key stakeholders: <ops, data stewards, downstream teams>
Conventions: <naming, environments, anything the XML won't tell the model>
