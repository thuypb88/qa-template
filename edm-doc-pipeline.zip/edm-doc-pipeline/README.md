# EDM Documentation Prompt Pipeline

Generates BRD, FRD, SRS, PRD, Data Mapping, Use Cases, Mermaid diagrams and a traceability
matrix from Markit EDM definition XML. All of them come from one canonical model, so every
statement traces back to an XML path.

```
DB / solution export
   │  Stage 1  extract/extract_xml.py         (code)
   ▼
work/xml/*.xml  (one file per component)
   │  Stage 2a 01_parse_component.md          (1 call per component)
   ▼
work/components/*.json
   │  Stage 2b 02_merge_model.md
   ▼
work/canonical_model.json   ◄── single source of truth; review it before Stage 3
   │  Stage 3  03→10 prompts
   ▼
output/  BRD → FRD → SRS, PRD, Use_Cases → RTM   (+ Data_Mapping.csv, Diagrams.md)
   │  Stage 4  11_review.md                   (separate reviewer model)
   ▼
output/reviews/*_review.md
```

## Run

```bash
pip install anthropic pyodbc
export ANTHROPIC_API_KEY=...

# 1. fill in system_context.md (5 lines of context the XML can't give)
# 2. edit QUERY in extract/extract_xml.py, then:
python extract/extract_xml.py --dsn "DRIVER=...;SERVER=...;DATABASE=...;Trusted_Connection=yes"
#    or from an exported file:
python extract/extract_xml.py --from-file exports/solution.xml

python pipeline.py --only parse merge     # stop here and sanity-check canonical_model.json
python pipeline.py --only docs review
```

Re-run a single stage with `--force`, e.g. `python pipeline.py --only docs --force`.
Delete one output file to regenerate just that document.

## Prompt files

| File | Stage | Output |
|---|---|---|
| 00_system.md | all | shared rules: evidence-only, ID scheme, no invention |
| 01_parse_component.md | 2a | component JSON |
| 02_merge_model.md | 2b | canonical model + lineage + BR-IDs |
| 03_brd.md | 3 | BRD (business language, no SQL) |
| 04_frd.md | 3 | FRD (FR-IDs, Given/When/Then) |
| 05_srs.md | 3 | SRS (technical, SQL allowed) |
| 06_prd.md | 3 | PRD (web app features, user stories) |
| 07_data_mapping.md | 3 | source→target CSV |
| 08_use_cases.md | 3 | use case specs |
| 09_diagrams.md | 3 | 6 Mermaid diagrams |
| 10_traceability.md | 3 | RTM CSV with test ideas |
| 11_review.md | 4 | reviewer report per doc |

## Tips
- **Company templates:** drop `templates/brd_template.md` to override the BRD headings (you can extend the same idea to the other docs).
- **Few-shot examples:** paste one hand-written good FR or mapping row into a prompt; this improves output a lot.
- **Large solutions:** if the merge prompt gets too big, merge per sub-flow first, then merge the merged models.
- **Mermaid:** paste Diagrams.md into mermaid.live or any Markdown viewer that renders Mermaid.
- **Sensitive data:** the definition XML may contain connection strings or credentials. Scrub them in extract_xml.py before sending anything to an API.
