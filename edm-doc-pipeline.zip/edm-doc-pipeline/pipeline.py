"""EDM documentation prompt pipeline.

Stages
  2a parse     work/xml/*.xml            -> work/components/*.json   (one LLM call per component)
  2b merge     work/components/*.json    -> work/canonical_model.json
  3  docs      canonical_model.json      -> output/BRD.md, FRD.md, SRS.md, PRD.md,
                                             Data_Mapping.csv, Use_Cases.md, Diagrams.md, RTM.csv
  4  review    each doc vs model         -> output/reviews/*_review.md

Outputs are cached: a stage is skipped if its output exists (use --force to redo).

Usage:
  export ANTHROPIC_API_KEY=...
  python pipeline.py                 # run everything
  python pipeline.py --only parse merge
  python pipeline.py --only docs --force
"""
import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path

import anthropic

MODEL = "claude-sonnet-5-5"          # parse/merge/docs; switch to claude-opus-5-5 for hardest parts
REVIEW_MODEL = "claude-opus-5-5"     # independent reviewer
MAX_TOKENS = 32000

ROOT = Path(__file__).parent
P = ROOT / "prompts"
WORK, OUT = ROOT / "work", ROOT / "output"
XML_DIR, COMP_DIR = WORK / "xml", WORK / "components"
MODEL_FILE = WORK / "canonical_model.json"

SYSTEM_CONTEXT = (ROOT / "system_context.md").read_text(encoding="utf-8") \
    if (ROOT / "system_context.md").exists() else \
    "Source File -> ETL Pipeline -> Markit EDM (backend + web app). SQL logic lives in definition XML."

client = anthropic.Anthropic()


def render(name: str, **vars) -> str:
    text = (P / name).read_text(encoding="utf-8")
    for k, v in vars.items():
        text = text.replace("{{" + k + "}}", v)
    return text


SYSTEM = render("00_system.md", SYSTEM_CONTEXT=SYSTEM_CONTEXT)


def call(prompt: str, model: str = MODEL) -> str:
    with client.messages.stream(model=model, max_tokens=MAX_TOKENS, system=SYSTEM,
                                messages=[{"role": "user", "content": prompt}]) as s:
        msg = s.get_final_message()
    return "".join(b.text for b in msg.content if b.type == "text").strip()


def strip_fences(text: str) -> str:
    m = re.search(r"```(?:json|csv|markdown|md)?\s*\n(.*)\n```", text, re.S)
    return m.group(1).strip() if m and text.lstrip().startswith("```") else text


def parse_json(text: str, label: str) -> dict:
    try:
        return json.loads(strip_fences(text))
    except json.JSONDecodeError:
        retry = call("The following was meant to be valid JSON but is not. Return ONLY the "
                     f"corrected valid JSON, nothing else.\n\n{text}")
        try:
            return json.loads(strip_fences(retry))
        except json.JSONDecodeError as e:
            sys.exit(f"[{label}] invalid JSON after retry: {e}")


def done(path: Path, force: bool) -> bool:
    if path.exists() and not force:
        print(f"  skip  {path.relative_to(ROOT)} (exists)")
        return True
    return False


# ---------------- stages ----------------

def stage_parse(force: bool) -> None:
    COMP_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted(XML_DIR.glob("*.xml"))
    if not files:
        sys.exit(f"No XML in {XML_DIR}. Run extract/extract_xml.py first.")
    for f in files:
        out = COMP_DIR / f"{f.stem}.json"
        if done(out, force):
            continue
        print(f"  parse {f.name}")
        data = parse_json(call(render("01_parse_component.md", FILE_NAME=f.name,
                                      XML=f.read_text(encoding="utf-8"))), f.name)
        out.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def stage_merge(force: bool) -> None:
    if done(MODEL_FILE, force):
        return
    comps = [json.loads(p.read_text(encoding="utf-8")) for p in sorted(COMP_DIR.glob("*.json"))]
    print(f"  merge {len(comps)} components")
    model = parse_json(call(render("02_merge_model.md",
                                   COMPONENTS_JSON=json.dumps(comps, indent=1, ensure_ascii=False))),
                       "merge")
    MODEL_FILE.write_text(json.dumps(model, indent=2, ensure_ascii=False), encoding="utf-8")


def stage_docs(force: bool) -> None:
    OUT.mkdir(exist_ok=True)
    model = MODEL_FILE.read_text(encoding="utf-8")
    today = dt.date.today().isoformat()
    tpl = ROOT / "templates" / "brd_template.md"
    template = f"Company template (use these headings instead):\n{tpl.read_text()}" if tpl.exists() else ""

    def gen(fname: str, prompt_file: str, **extra) -> str:
        out = OUT / fname
        if not done(out, force):
            print(f"  gen   {fname}")
            out.write_text(strip_fences(call(render(prompt_file, MODEL=model, **extra))) + "\n",
                           encoding="utf-8")
        return out.read_text(encoding="utf-8")

    # order matters: later docs build on earlier ones
    brd = gen("BRD.md", "03_brd.md", DATE=today, TEMPLATE=template)
    frd = gen("FRD.md", "04_frd.md", BRD=brd)
    gen("SRS.md", "05_srs.md", FRD=frd)
    gen("PRD.md", "06_prd.md", FRD=frd)
    dm = gen("Data_Mapping.csv", "07_data_mapping.md")
    uc = gen("Use_Cases.md", "08_use_cases.md", FRD=frd)
    gen("Diagrams.md", "09_diagrams.md")
    gen("RTM.csv", "10_traceability.md", FRD=frd, DATA_MAPPING=dm, USE_CASES=uc)


def stage_review(force: bool) -> None:
    rdir = OUT / "reviews"
    rdir.mkdir(parents=True, exist_ok=True)
    model = MODEL_FILE.read_text(encoding="utf-8")
    for doc in ["BRD.md", "FRD.md", "SRS.md", "PRD.md", "Data_Mapping.csv", "Use_Cases.md"]:
        src, out = OUT / doc, rdir / f"{Path(doc).stem}_review.md"
        if not src.exists() or done(out, force):
            continue
        print(f"  review {doc}")
        out.write_text(call(render("11_review.md", DOC_TYPE=doc, MODEL=model,
                                   DOCUMENT=src.read_text(encoding="utf-8")),
                            model=REVIEW_MODEL) + "\n", encoding="utf-8")


STAGES = {"parse": stage_parse, "merge": stage_merge, "docs": stage_docs, "review": stage_review}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="+", choices=STAGES, default=list(STAGES))
    ap.add_argument("--force", action="store_true", help="regenerate even if output exists")
    a = ap.parse_args()
    for name in STAGES:
        if name in a.only:
            print(f"== {name}")
            STAGES[name](a.force)
    print("Done. See output/ and output/reviews/")
