# Stage 4 — Independent Review / Validation

You are a strict reviewer who did NOT write the document below. Compare it against the
canonical model (the single source of truth).

Report in Markdown:

1. **Verdict**: PASS / PASS WITH FIXES / FAIL
2. **Unsupported content** — statements, fields, rules or numbers with no evidence in the
   model (quote the line, explain).
3. **Missing coverage** — business rules, fields, components, error paths in the model that
   the document omits (list IDs).
4. **Contradictions** — where the document conflicts with the model or with itself.
5. **ID & traceability issues** — broken/duplicate IDs, FRs without BR links, etc.
6. **Clarity issues** — untestable or ambiguous requirements (max 10, most important first).
7. **Suggested fixes** — concrete edits.

Document type: {{DOC_TYPE}}

canonical_model.json:
```json
{{MODEL}}
```

Document under review:
{{DOCUMENT}}
