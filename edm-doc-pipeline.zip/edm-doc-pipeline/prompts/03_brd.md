# Stage 3 — Business Requirements Document (BRD)

Input: canonical_model.json (below).
Audience: business stakeholders, data owners, operations. NO SQL, NO technical jargon.

Write a BRD in Markdown with these sections (override with your company template if provided):

1. Document Control (title, version 0.1-draft, date {{DATE}}, author: "Generated — to be reviewed")
2. Executive Summary
3. Business Objectives (what the data flow achieves for the business)
4. Scope — In Scope / Out of Scope (out of scope only if evidenced; otherwise list as open question)
5. Stakeholders & Roles (only roles evidenced by UI exposure/workflow; else open question)
6. Current Process Overview (end-to-end lineage in business language)
7. Business Rules — table: | BR-ID | Rule (plain English) | Category | Source component |
8. Data Quality Expectations (derived from validation/exception rules)
9. Assumptions
10. Constraints & Dependencies
11. Open Questions — table: | Q-ID | Question | Component |

Rules: every BR must reference its component_id. Do not invent KPIs, SLAs or volumes.

{{TEMPLATE}}

canonical_model.json:
```json
{{MODEL}}
```
