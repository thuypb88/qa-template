# Stage 2b — Merge component JSONs into one canonical system model

Task: Merge the per-component JSON objects below into ONE system-level canonical model.

Instructions:
- Keep every component; do not drop or rewrite facts.
- Re-number business rules globally as BR-001, BR-002 … and keep the original local id in
  `local_id` plus `component_id` for traceability.
- Build the end-to-end data lineage: source file → ETL components → EDM tables → web/UI.
- Deduplicate systems/tables by name; list which components use each.
- Detect inconsistencies (same field, different types/logic) and add them to `conflicts`.
- Consolidate open questions as Q-001 … with their component_id.

Output: valid JSON only:

```json
{
  "system_name": "",
  "summary": "3-5 sentence plain-English overview",
  "components": [ /* original component objects, unchanged */ ],
  "business_rules": [{"id": "BR-001", "local_id": "", "component_id": "", "description": "", "category": "", "sql_ref": "", "evidence": ""}],
  "systems": [{"name": "", "role": "source|target|internal", "used_by": [""]}],
  "data_objects": [{"name": "", "kind": "", "read_by": [""], "written_by": [""]}],
  "lineage": [{"step": 1, "from": "", "to": "", "via_component": "", "description": ""}],
  "conflicts": [{"description": "", "components": [""]}],
  "open_questions": [{"id": "Q-001", "component_id": "", "question": ""}]
}
```

Component JSONs:

{{COMPONENTS_JSON}}
