# Stage 3 — Product Requirements Document (PRD) — EDM web app

Input: canonical_model.json and FRD (below).
Focus: the user-facing EDM web application and the value it delivers.

Write a PRD in Markdown:

1. Overview & Problem Statement
2. Goals / Non-goals
3. Personas (only roles evidenced by ui_exposure / workflow; otherwise mark as assumed)
4. Features — for each:
   - Feature name, description, persona, priority (MoSCoW — mark as "proposed")
   - User stories: "As a <persona>, I want <capability>, so that <benefit>"
   - Acceptance criteria (Given/When/Then)
   - Traces to: FR-### / BR-###
5. User Journeys (step lists: e.g. review exceptions → correct data → approve → publish)
6. Success Metrics (proposed, clearly labelled as to-be-agreed)
7. Release Considerations / Dependencies
8. Open Questions

canonical_model.json:
```json
{{MODEL}}
```

FRD:
{{FRD}}
