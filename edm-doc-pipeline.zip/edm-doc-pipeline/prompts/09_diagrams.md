# Stage 3 — Flow Diagrams (Mermaid)

Input: canonical_model.json (below).

Produce a Markdown file containing exactly these Mermaid diagrams, each under its own
heading with a 1-2 sentence caption:

1. **End-to-end data flow** — `flowchart LR`: source files/systems → each ETL component →
   EDM tables → web app → outbound targets. Label edges with what flows.
2. **Component dependency graph** — `flowchart TD` from `dependencies`.
3. **ETL run sequence** — `sequenceDiagram`: scheduler/trigger, porters, inspectors/validators,
   constructors, DB, web app, including the main error path (`alt` block).
4. **Exception handling** — `flowchart TD` decision diagram from error_handling and
   validation rules (label nodes with BR-IDs).
5. **Data model** — `erDiagram` for target tables and key fields (only evidenced fields/keys).
6. **Use case overview** — `flowchart LR` with actors on the left, use cases (UC-IDs) as
   rounded nodes.

Rules:
- Valid Mermaid syntax only: node IDs alphanumeric/underscore; put labels with spaces or
  symbols in quotes, e.g. A["Bloomberg file (.out)"].
- Max ~25 nodes per diagram; group with `subgraph` if larger.
- Only use names that exist in the model.

canonical_model.json:
```json
{{MODEL}}
```
