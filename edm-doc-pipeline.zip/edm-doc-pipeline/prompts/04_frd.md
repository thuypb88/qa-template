# Stage 3 — Functional Requirements Document (FRD)

Input: canonical_model.json and the approved BRD (below).
Audience: BAs, developers, testers.

Write an FRD in Markdown:

1. Document Control
2. Purpose & References (link to BRD)
3. System Overview (components and their responsibilities — table)
4. Functional Requirements, grouped by stage (Ingestion, Validation, Transformation,
   Matching/Mastering, Load, Distribution/Outbound, UI):
   For each requirement:
   - **FR-###** — "The system shall …" (one testable behaviour)
   - Traces to: BR-### | component_id
   - Inputs / Processing / Outputs
   - Acceptance criteria (Given/When/Then, at least one positive and one negative)
5. Error & Exception Handling (table: condition → system behaviour → FR-ID)
6. Interfaces (inbound files/feeds, outbound targets)
7. Open Questions

Rules: every BR in the model must be covered by ≥1 FR. If a BR cannot be turned into a
testable FR, list it under Open Questions.

canonical_model.json:
```json
{{MODEL}}
```

BRD:
{{BRD}}
