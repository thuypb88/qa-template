# Stage 2a — Parse one EDM component definition into JSON

Task: Analyse the single EDM component definition XML below and extract ONLY what is
present into the JSON schema. This is the foundation for all downstream documents, so
accuracy beats completeness.

Instructions:
- Identify the component type (e.g. data porter, data inspector, data constructor,
  inbound/outbound, matcher, business rule, workflow, solution, table/view, report).
- For every embedded SQL block: keep the raw SQL in `sql_snippet` AND explain it in
  plain English in `transform` or `business_rules[].description`.
- Capture joins, filters (WHERE), lookups, defaults, CASE logic, aggregations and
  error/exception handling as business rules.
- `evidence` = the XPath (or element path) where you found the item.
- Anything you cannot determine → `open_questions`. Do not guess.

Output: valid JSON only, matching this schema exactly:

```json
{
  "component_id": "string (stable id from XML, else file name)",
  "type": "string",
  "name": "string",
  "description": "string (1-2 sentences, plain English)",
  "source_systems": [{"name": "", "format": "", "evidence": ""}],
  "source_objects": [{"name": "", "kind": "file|table|view|feed", "evidence": ""}],
  "target_objects": [{"name": "", "kind": "table|view|file|api", "evidence": ""}],
  "fields": [{
    "source": "", "target": "", "data_type": "",
    "transform": "plain-English logic", "sql_snippet": "",
    "mandatory": "yes|no|unknown", "evidence": ""
  }],
  "business_rules": [{
    "id": "BR-local-001", "description": "", "category": "validation|derivation|filter|lookup|matching|exception",
    "sql_ref": "", "evidence": ""
  }],
  "dependencies": [{"component": "", "relation": "calls|reads|writes|triggered_by", "evidence": ""}],
  "schedule_or_trigger": "",
  "error_handling": [{"condition": "", "action": "", "evidence": ""}],
  "ui_exposure": [{"screen_or_entity": "", "action": "view|edit|approve|export", "evidence": ""}],
  "open_questions": [""]
}
```

XML file name: {{FILE_NAME}}

```xml
{{XML}}
```
