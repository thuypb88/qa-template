# Stage 3 — Use Case Specifications

Input: canonical_model.json and FRD (below).

Identify actors (human: from ui_exposure/workflow; system: schedulers, source systems,
downstream consumers). Then write use cases in Markdown.

Start with a summary table: | UC-ID | Name | Primary Actor | Trigger | Related FRs |

Then for each use case:

### UC-### — <Name>
- **Primary actor / Secondary actors**
- **Trigger**
- **Preconditions**
- **Main success flow** (numbered steps, actor ↔ system)
- **Alternate flows** (A1, A2 …)
- **Exception flows** (E1, E2 … — from error_handling and validation rules)
- **Postconditions**
- **Business rules**: BR-###
- **Traces to**: FR-###

Cover at minimum: file arrival & ingestion, validation failure, transformation & load,
exception review/correction in the web app (if evidenced), outbound distribution.

canonical_model.json:
```json
{{MODEL}}
```

FRD:
{{FRD}}
