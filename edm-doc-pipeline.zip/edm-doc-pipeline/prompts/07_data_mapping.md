# Stage 3 — Source-to-Target Data Mapping

Input: canonical_model.json (below).

Produce a CSV (comma-separated, double-quote every value, header row first) with columns:

DM_ID,Source_System,Source_Object,Source_Field,Source_Type,Transformation_Rule,SQL_Logic,Target_Object,Target_Field,Target_Type,Mandatory,Default_Value,BR_ID,Component_ID,Evidence,Sample_Input,Sample_Output,Notes

Rules:
- One row per source→target field hop. Multi-hop lineage (file → staging → master) = multiple rows.
- Transformation_Rule in plain English; SQL_Logic = short snippet (no line breaks — replace with spaces).
- Sample_Input/Sample_Output: only realistic illustrative values consistent with the rule;
  prefix with "e.g." Leave blank if the rule is unclear.
- Fields with no mapping found → row with Target_Field blank and Notes = "UNMAPPED — see Q-xxx".
- Output CSV only. No Markdown fences.

canonical_model.json:
```json
{{MODEL}}
```
