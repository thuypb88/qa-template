# Stage 3 — Requirements Traceability Matrix (RTM)

Input: canonical model, FRD, data mapping and use cases (below).

Produce a CSV (double-quote every value, header first) with columns:

BR_ID,BR_Description,FR_IDs,UC_IDs,DM_IDs,Component_ID,XML_Evidence,Suggested_Test_Cases,Coverage_Status

- Suggested_Test_Cases: 1-3 short test ideas (positive, negative, boundary), separated by " | ".
- Coverage_Status: "Covered" (has FR + test idea), "Partial" (missing FR, UC or DM), "Gap" (no FR).
- Output CSV only. No Markdown fences.

canonical_model.json:
```json
{{MODEL}}
```

FRD:
{{FRD}}

Data mapping CSV:
{{DATA_MAPPING}}

Use cases:
{{USE_CASES}}
