# Stage 3 — Software Requirements Specification (SRS)

Input: canonical_model.json and FRD (below).
Audience: developers, architects, QA automation. Technical detail and SQL ARE allowed here.

Write an SRS in Markdown (IEEE 29148-style, trimmed):

1. Introduction (purpose, scope, definitions/acronyms, references to BRD/FRD)
2. Overall Description (architecture: Source File → ETL → EDM backend → Web app; component
   inventory table with type, inputs, outputs)
3. Specific Requirements
   3.1 Functional — restate each FR-### with technical realisation: component, tables,
       SQL logic summary (include short sql_snippet where helpful), triggers
   3.2 Data Requirements — entities/tables, key fields, data types, keys, constraints
   3.3 External Interfaces — file layouts, feeds, outbound formats
   3.4 Non-Functional (NFR-###) — ONLY those evidenced (schedule, error handling, audit,
       security/UI permissions). Anything else → Open Questions, do not invent numbers.
4. Traceability summary: | FR-ID | Component | Tables | XML evidence |
5. Open Questions

canonical_model.json:
```json
{{MODEL}}
```

FRD:
{{FRD}}
