"""Stage 1 — Extract EDM definition XML from the database and split it per component.

The SQL query is a PLACEHOLDER: point it at the table/view where your EDM
environment stores component definitions (or use an EDM solution export instead,
via --from-file).

Usage:
  python extract/extract_xml.py --dsn "DRIVER={ODBC Driver 18 for SQL Server};SERVER=...;DATABASE=...;Trusted_Connection=yes"
  python extract/extract_xml.py --from-file exports/solution_export.xml
"""
import argparse
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

# >>> EDIT: query returning (component_id, component_name, component_type, definition_xml)
QUERY = """
SELECT component_id, component_name, component_type, definition_xml
FROM   <your_schema>.<your_definition_table>
WHERE  <solution_or_project_filter>
"""

# >>> EDIT: element tags that represent one component in a solution export file
COMPONENT_TAGS = {"DataPorter", "DataInspector", "DataConstructor", "Matcher",
                  "BusinessRule", "Workflow", "Table", "View", "Report"}

OUT_DIR = Path("work/xml")


def safe(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("_")[:120] or "component"


def from_db(dsn: str) -> int:
    import pyodbc  # pip install pyodbc
    conn = pyodbc.connect(dsn)
    rows = conn.cursor().execute(QUERY).fetchall()
    for cid, name, ctype, xml in rows:
        (OUT_DIR / f"{safe(str(ctype))}__{safe(str(name))}__{safe(str(cid))}.xml").write_text(
            xml, encoding="utf-8")
    return len(rows)


def from_file(path: str) -> int:
    root = ET.parse(path).getroot()
    count = 0
    for el in root.iter():
        tag = el.tag.split("}")[-1]
        if tag in COMPONENT_TAGS:
            name = el.get("Name") or el.get("name") or f"{tag}_{count}"
            (OUT_DIR / f"{safe(tag)}__{safe(name)}.xml").write_text(
                ET.tostring(el, encoding="unicode"), encoding="utf-8")
            count += 1
    if count == 0:  # no known tags — keep the whole file as one component
        (OUT_DIR / Path(path).name).write_text(Path(path).read_text(encoding="utf-8"), encoding="utf-8")
        count = 1
    return count


def main() -> None:
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--dsn")
    g.add_argument("--from-file")
    a = ap.parse_args()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    n = from_db(a.dsn) if a.dsn else from_file(a.from_file)
    print(f"Wrote {n} component XML file(s) to {OUT_DIR}/", file=sys.stderr)


if __name__ == "__main__":
    main()
